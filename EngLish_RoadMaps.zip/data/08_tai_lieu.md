# 08 — Tài liệu

Dùng **ít sách nhưng làm kỹ**. Mua bản gốc hoặc bản in phổ biến ở các nhà sách/hiệu photo tài liệu TOEIC.

## Theo giai đoạn

| Giai đoạn | Mảng | Tài liệu |
|---|---|---|
| GĐ1 (T1–6) | Ngữ pháp | *English Grammar in Use* (Raymond Murphy, bản xanh dương) — chỉ học các unit ứng với Nhóm A |
| | Ngữ pháp TOEIC | *Hackers TOEIC Start* (Reading) hoặc sách ngữ pháp TOEIC cơ bản tương đương |
| | Phát âm | Video bảng IPA (BBC Learning English – *The Sounds of English*) |
| | Từ vựng | Oxford 3000 (A1–B1) trên Anki |
| | Nghe | *Hackers TOEIC Start Listening*; dailydictation.com |
| GĐ2 (T7–14) | Từ vựng | *600 Essential Words for the TOEIC* → *Hackers TOEIC Vocabulary* |
| | Luyện Part | *Hackers TOEIC Listening* / *Hackers TOEIC Reading* (hoặc bộ *Economy TOEIC LC/RC 1000*) |
| GĐ3–4 (T15–26) | Đề | **ETS TOEIC** chính thức (các bộ đề ETS gần nhất — sát đề thật nhất) |
| | Part 5 nâng cao | Bộ 1000 câu Part 5 (*Economy RC 1000* hoặc tương đương) |

**Ưu tiên đề ETS** cho các bài đo tiến độ; đề trôi nổi chất lượng không đều, dễ làm sai lệch điểm.

## Công cụ

| Công cụ | Dùng để |
|---|---|
| Anki | Từ vựng, lặp lại ngắt quãng |
| dailydictation.com | Chép chính tả |
| YouGlish (youglish.com) | Nghe cách người bản xứ phát âm 1 từ trong nhiều ngữ cảnh |
| Cambridge Dictionary / Oxford Learner's Dictionaries | Tra nghĩa, phiên âm, họ từ, ví dụ |
| VOA Learning English, BBC Learning English | Đọc/nghe thêm từ tuần 10 |
| Audacity hoặc trình phát có tua câu (VLC, phím tắt) | Nghe lại từng câu khi chép chính tả |

## Số lượng đề cần có
- Tuần 6–14: ~5 đề (mỗi 2 tuần 1 đề).
- Tuần 15–22: 16 đề (2 đề/tuần).
- Tuần 23–26: ~10 đề.
- **Tổng ~30 đề** → cần khoảng 3 bộ ETS (mỗi bộ 10 đề). Giữ 2–3 đề ETS mới nhất cho 2 tuần cuối.
