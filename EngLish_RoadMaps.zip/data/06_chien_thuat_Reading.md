# 06 — Chiến thuật Reading (150 → 370+)

**Mục tiêu số câu đúng cho ~370–430:** Part 5: 26/30 · Part 6: 13/16 · Part 7: 42/54.

Reading 150 → 370 là phần cần tăng nhiều nhất. Thứ tự ưu tiên: **Part 5 → Part 6 → Part 7**, vì Part 5 tăng nhanh nhất khi ngữ pháp + từ vựng tốt lên.

## Quản lý thời gian (75 phút)

| Part | Số câu | Thời gian | Tốc độ |
|---|---|---|---|
| 5 | 30 | 10–11 phút | ~20 giây/câu |
| 6 | 16 | 8–9 phút | ~2 phút/đoạn |
| 7 | 54 | 55 phút | ~1 phút/câu |

Đeo đồng hồ, ghi mốc: **bắt đầu Part 6 phút thứ 11, Part 7 phút thứ 20, đoạn đôi phút thứ 45**. Câu nào quá 1 phút → đánh dấu, chọn đại, quay lại sau.

---

## Part 5 — Điền câu (30 câu)
**Quy trình mỗi câu:**
1. Nhìn 4 đáp án trước → biết dạng câu:
    - Cùng gốc khác đuôi (*decide/decision/decisive/decisively*) → câu **từ loại**: chỉ cần nhìn quanh chỗ trống, không cần dịch cả câu.
    - Cùng động từ khác dạng (*approve/approved/approving/is approving*) → **thì / chủ – bị động / hòa hợp**.
    - Giới từ / liên từ / trạng từ → nhìn sau chỗ trống là cụm danh từ hay mệnh đề.
    - Đại từ → xác định vị trí (chủ ngữ, tân ngữ, sở hữu, phản thân).
    - 4 từ khác nghĩa cùng loại → câu **từ vựng**: đọc cả câu, tìm collocation.
2. Câu ngữ pháp làm trong 10 giây; dồn thời gian cho câu từ vựng.

## Part 6 — Điền đoạn (16 câu, 4 đoạn)
- **Đọc cả đoạn từ đầu**, không nhảy vào chỗ trống ngay.
- Câu **thì** ở Part 6 phụ thuộc ngữ cảnh đoạn (email gửi sau sự kiện → quá khứ).
- Câu **trạng từ nối** → xác định quan hệ câu trước – câu sau (bổ sung / tương phản / kết quả).
- **Câu điền cả câu** (mỗi đoạn 1 câu): đáp án đúng phải nối được với **cả câu trước và câu sau**, thường có từ tham chiếu (*this, these, such, it*) chỉ về ý ngay trước.

## Part 7 — Đọc hiểu (54 câu)

Gồm 10 đoạn đơn (29 câu, câu 147–175), 2 bộ đoạn đôi (10 câu, 176–185) và 3 bộ đoạn ba (15 câu, 186–200). Đoạn đôi/ba thường dễ hơn các đoạn đơn dài cuối Part — đừng bỏ trống chúng vì hết giờ.

### Thứ tự làm bài
1. Đọc **câu hỏi trước**, gạch từ khóa (tên riêng, số, ngày).
2. Đọc lướt đoạn (skim) 20–30 giây: loại văn bản, ai gửi ai, mục đích.
3. Quét (scan) tìm từ khóa → đọc kỹ 1–2 câu quanh đó → chọn đáp án là **paraphrase**.

### Dạng câu hỏi và cách xử lý
| Dạng | Dấu hiệu | Cách làm |
|---|---|---|
| Mục đích / chủ đề | *purpose, mainly about, why was ... written* | Câu đầu, đoạn đầu |
| Chi tiết | *what, when, how much* | Scan từ khóa |
| NOT / true | *is NOT mentioned, is indicated* | Loại trừ từng đáp án — mất thời gian, làm sau |
| Suy luận | *suggested, implied, most likely* | Đáp án không viết thẳng, nhưng có căn cứ rõ |
| Từ đồng nghĩa | *the word "X" in paragraph 2 is closest in meaning to* | Đọc câu chứa từ, thay từng đáp án vào |
| Điền câu | *In which position [1]–[4] does the sentence belong?* | Tìm từ tham chiếu trong câu cho sẵn |
| Ý định trong chat | *At 10:15, what does Ms. X mean when she writes...* | Đọc tin trước và sau |
| Đoạn đôi/ba | Câu hỏi liên kết 2 văn bản | Câu thứ 2–3 thường cần ghép thông tin từ 2 văn bản |

### Loại văn bản thường gặp
Email/thư · thông báo · quảng cáo · bài báo · tin nhắn/chat · biểu mẫu/hóa đơn · lịch trình · đánh giá của khách hàng · thông cáo báo chí · tin tuyển dụng.

### Tăng tốc độ đọc
- Tuần 9–14: đọc 6–10 đoạn Part 7/ngày, **bấm giờ** từng đoạn.
- Không dịch từng chữ sang tiếng Việt trong đầu — đọc theo cụm (*the new branch / will open / next month*).
- Đọc thêm tin tức kinh doanh đơn giản 15 phút/ngày từ tuần 10 (VOA Learning English, BBC Learning English).
