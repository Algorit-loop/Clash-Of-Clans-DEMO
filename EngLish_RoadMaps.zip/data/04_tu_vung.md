# 04 — Từ vựng

**Mục tiêu cho 800+:** ~1.500 từ thông dụng + ~2.000 từ TOEIC (bao gồm họ từ và collocation).
Từ vựng là thứ quyết định cả Nghe lẫn Đọc — nếu chỉ được làm một việc mỗi ngày, hãy làm Anki.

## Tiến độ

| Tuần | Bộ từ | Tốc độ | Tích lũy |
|---|---|---|---|
| 1–6 | 1.500 từ thông dụng (Oxford 3000 cấp A1–B1) + bắt đầu TOEIC | 30 từ/ngày | ~1.500 + 200 TOEIC |
| 7–14 | TOEIC theo chủ đề (600 Essential Words → Hackers Vocabulary) | 25 từ/ngày | ~1.200 TOEIC |
| 15–22 | TOEIC nâng cao + từ sai trong đề | 20–25 từ/ngày | ~2.000 TOEIC |
| 23–26 | Không thêm mới nhiều; ôn thẻ khó + từ trong sổ lỗi sai | 10 từ/ngày | — |

## Cách tạo thẻ Anki đúng (đừng chỉ ghi Anh – Việt)

**Mặt trước:**
- Câu ví dụ có chỗ trống: *The new policy will take effect ___ March 1.* (as of)
- Hoặc từ + phiên âm + audio

**Mặt sau:**
- Nghĩa tiếng Việt
- Từ loại + họ từ (*approve (v) – approval (n) – approved (adj)*)
- Collocation (*seek approval, final approval, approval from*)
- 1 câu ví dụ trong ngữ cảnh công việc

Cài đặt: mỗi ngày ôn hết thẻ đến hạn **trước** khi học từ mới. Không để tồn thẻ quá 1 ngày.

## Chủ đề TOEIC (học theo thứ tự này)

1. Văn phòng, công việc hàng ngày (office, schedule, meeting, deadline)
2. Nhân sự, tuyển dụng (applicant, résumé, interview, promotion, benefits)
3. Hợp đồng, pháp lý (contract, terms, comply, clause, renew)
4. Marketing, quảng cáo (campaign, survey, promote, target)
5. Bán hàng, mua sắm (discount, refund, warranty, receipt, merchandise)
6. Đặt hàng, vận chuyển (shipment, invoice, delivery, inventory, supplier)
7. Tài chính, ngân hàng (budget, expense, reimburse, account, revenue)
8. Du lịch, khách sạn (itinerary, reservation, boarding pass, check in)
9. Nhà hàng, sự kiện (catering, banquet, venue, reception)
10. Sản xuất, nhà máy (assembly, facility, equipment, quality control)
11. Y tế, sức khỏe (appointment, prescription, clinic, insurance)
12. Bất động sản, xây dựng (lease, tenant, renovation, property)
13. Công nghệ, máy tính (software, upgrade, install, malfunction)
14. Họp hành, hội nghị (agenda, minutes, keynote, attendee)
15. Giao thông (commute, detour, delay, fare)

## Họ từ — học cả cụm, không học từ lẻ

| Động từ | Danh từ (vật/việc) | Danh từ (người) | Tính từ | Trạng từ |
|---|---|---|---|---|
| apply | application | applicant | applicable | — |
| decide | decision | — | decisive | decisively |
| produce | production / product | producer | productive | productively |
| compete | competition | competitor | competitive | competitively |
| succeed | success | — | successful | successfully |
| rely | reliance / reliability | — | reliable | reliably |
| attend | attendance | attendee / attendant | — | — |
| employ | employment | employee / employer | — | — |
| inform | information | informant | informative | — |
| expand | expansion | — | expansive | — |

Mỗi khi gặp từ mới: tra luôn cả họ từ và ghi vào thẻ.

## Tiền tố hay gặp
un-, in-, im-, ir-, il-, dis- (phủ định) · re- (lại) · pre- (trước) · over- (quá) · under- (dưới, thiếu) · mis- (sai) · co- (cùng) · inter- (giữa).

## Paraphrase — chìa khóa Part 3, 4, 7

Đề **ít khi dùng lại từ trong bài**; đáp án thường là cách nói khác. Mỗi lần chữa đề, ghi lại cặp paraphrase:

| Trong bài | Trong đáp án |
|---|---|
| The printer is broken | The equipment is not working |
| We're short-staffed | There aren't enough employees |
| I'll email you the file | Send a document |
| reschedule the meeting | change an appointment |
| inexpensive | affordable / reasonably priced |
| get in touch with | contact |
| free of charge | complimentary / at no cost |

Ghi ít nhất 10 cặp mới sau mỗi đề.
