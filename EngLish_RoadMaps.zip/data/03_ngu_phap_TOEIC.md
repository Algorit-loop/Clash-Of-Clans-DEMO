# 03 — Ngữ pháp TOEIC (đủ cho 800–900)

Chia 3 nhóm: **A** = bắt buộc cho 550–650 · **B** = cho 700–800 · **C** = để chạm 850–900.
Học xong mỗi chủ điểm: làm ≥ 30 câu Part 5 đúng dạng đó, ghi câu sai vào sổ.

---

## Nhóm A — Nền (Tuần 1–6)

### A1. Từ loại và vị trí (chiếm ~30–40% Part 5 — học kỹ nhất)

| Vị trí | Cần từ loại | Ví dụ |
|---|---|---|
| Sau mạo từ / tính từ sở hữu / giới từ | Danh từ | the **decision**, their **approval**, for **access** |
| Trước danh từ, sau *be / become / seem / remain* | Tính từ | a **successful** launch; remain **competitive** |
| Bổ nghĩa động từ, tính từ, cả câu | Trạng từ | work **efficiently**, **highly** recommended |
| Sau chủ ngữ, có thì | Động từ | The manager **approved** it |
| Giữa *be* và V3/V-ing | Trạng từ | is **currently** being reviewed |

**Hậu tố nhận biết:**
- Danh từ: -tion, -sion, -ment, -ness, -ity, -ance/-ence, -er/-or/-ee/-ist (người), -ship, -al (approval, arrival)
- Tính từ: -ful, -less, -ive, -able/-ible, -ous, -al, -ic, -ent/-ant, -ary
- Động từ: -ize, -ify, -ate, -en
- Trạng từ: -ly (cẩn thận: *friendly, costly, timely, likely* là **tính từ**)

**Bẫy:** danh từ chỉ người vs danh từ chỉ vật (*applicant / application*); *a + N đếm được số ít* — nếu thấy "an ___" mà đáp án là danh từ không đếm được thì sai.

### A2. 12 thì và dấu hiệu

| Thì | Dấu hiệu |
|---|---|
| Hiện tại đơn | every, usually, always; lịch trình (The train leaves at 9) |
| Hiện tại tiếp diễn | now, currently, at the moment |
| Hiện tại hoàn thành | since, for, already, yet, recently, so far, over the past ___ |
| Quá khứ đơn | yesterday, last ___, ___ ago, in 2019 |
| Quá khứ hoàn thành | before/by the time + quá khứ đơn |
| Tương lai đơn | tomorrow, next ___, soon |
| Tương lai hoàn thành | **by** + mốc tương lai (by next month, by the time + HTĐ) |

**Bẫy:** mệnh đề thời gian (when, after, before, as soon as, once, until) dùng **hiện tại** thay cho tương lai: *Once the contract **is** signed, we **will** begin.*

### A3. Hòa hợp chủ ngữ – động từ
- Chủ ngữ là cụm dài → tìm danh từ chính: *The list **of** new employees **is**...*
- *Each / Every / Either / Neither / One of* + động từ số ít.
- *A number of* + số nhiều; *The number of* + số ít.
- Danh từ không đếm được (information, equipment, furniture, advice) → số ít.

### A4. Câu bị động
- Công thức: be + V3 (mọi thì): *has been approved, will be delivered, is being repaired, must be submitted*.
- Cách chọn nhanh trong Part 5: **sau chỗ trống có tân ngữ → chủ động; không có → bị động** (trừ động từ 2 tân ngữ).
- Bị động + giới từ: *be satisfied with, be involved in, be committed to, be based on, be located in*.

### A5. Đại từ
- Chủ ngữ / tân ngữ / sở hữu / đại từ sở hữu / phản thân: *he / him / his / his / himself*.
- **Phản thân:** khi chủ ngữ = tân ngữ, hoặc nhấn mạnh; *by oneself* = một mình.
- *Those who* = những người mà; *anyone who*.

### A6. Giới từ – Liên từ – Trạng từ nối (bẫy kinh điển Part 5)

| Nghĩa | Giới từ (+ N/V-ing) | Liên từ (+ mệnh đề) | Trạng từ nối (; hoặc . đứng trước) |
|---|---|---|---|
| Mặc dù | despite, in spite of | although, even though, though | nevertheless, however |
| Vì | because of, due to, owing to | because, since, as | therefore (kết quả) |
| Trong khi | during | while | meanwhile |
| Nếu không | without | unless | otherwise |
| Ngoài ra | in addition to, besides | — | moreover, in addition |

**Quy tắc chọn:** nhìn phía sau chỗ trống — **cụm danh từ → giới từ; mệnh đề (S + V) → liên từ**.

Giới từ thời gian: *in* (tháng/năm), *on* (ngày/thứ), *at* (giờ), *by* (trước/chậm nhất), *until* (kéo dài đến), *within* (trong vòng), *throughout* (suốt).

### A7. Mệnh đề quan hệ
- who (người), which (vật), that (cả hai, không dùng sau dấu phẩy và giới từ), whose + N (sở hữu), where/when.
- Rút gọn: chủ động → V-ing (*employees **wishing** to attend*); bị động → V3 (*the report **submitted** yesterday*).

### A8. So sánh
- Hơn: adj-er / more adj + **than**; nhất: the adj-est / the most adj (+ *of/in/ever*).
- Bằng: as adj/adv as. Kép: *the more..., the more...*
- Bổ nghĩa so sánh hơn: **much, far, even, still, a lot** + so sánh hơn (không dùng *very*).

### A9. V-ing vs to V
- + to V: plan, decide, agree, hope, expect, intend, aim, offer, refuse, fail, be able to, be likely to, in order to.
- + V-ing: avoid, consider, suggest, recommend, finish, enjoy, mind, postpone, look forward to, be committed to, be used to, object to.
- Sau giới từ → luôn V-ing.

---

## Nhóm B — Kỹ năng (Tuần 7–14)

### B1. Phân từ làm tính từ
- -ing = gây ra cảm xúc / chủ động (*an exciting offer*); -ed = chịu cảm xúc / bị động (*excited staff, a detailed report*).
- Cụm hay gặp: *experienced staff, qualified candidates, attached file, enclosed document, rising costs, existing customers, leading company, demanding schedule*.

### B2. Câu điều kiện
| Loại | Mệnh đề if | Mệnh đề chính |
|---|---|---|
| 0 | HTĐ | HTĐ |
| 1 | HTĐ | will / can / imperative |
| 2 | QKĐ (were) | would / could + V |
| 3 | QKHT | would have + V3 |

Thay *if*: unless, provided (that), as long as, in case, in the event that.

### B3. Mệnh đề danh từ
- *that* (rằng), *whether/if* (liệu), *what* (cái mà), *how/why/when/where*.
- *whether* đi được với *or not* và đứng sau giới từ; *if* thì không.

### B4. Mệnh đề trạng ngữ rút gọn
- *When/While/After/Before + V-ing*: *Before **submitting** the form, check...*
- *Once/If/Unless/As + V3*: *Unless **otherwise noted**, ... / As **mentioned** earlier, ...*

### B5. Lượng từ
- each/every + N số ít; all/most/some + N số nhiều hoặc không đếm được.
- *most* vs *most of the*: *most employees / most of the employees* (không có *most of employees*).
- *almost* là trạng từ: *almost all employees*, không *almost employees*.
- few/a few + đếm được; little/a little + không đếm được.
- *another + N số ít; other + N số nhiều; the other(s); others*.

### B6. Câu giả định
- *recommend / suggest / request / require / insist / ask that + S + V nguyên mẫu*: *We request that each employee **submit**...*
- *It is essential / important / necessary / imperative that + S + V nguyên mẫu*.

### B7. Trạng từ nối và mạch văn (Part 6)
- Bổ sung: in addition, furthermore, moreover, also.
- Tương phản: however, nevertheless, on the other hand, in contrast.
- Kết quả: therefore, as a result, consequently, accordingly.
- Thứ tự/thời gian: first, then, afterward, meanwhile, in the meantime, subsequently.
- Ví dụ: for example, for instance. Điều kiện: otherwise.

### B8. Đảo ngữ cơ bản
- *Should you have any questions, ...* (= If you should have).
- *Had we known, ...* (= If we had known). *Were it not for ...*.
- *Not only does the company..., but it also...* · *Only after ... did ...*

---

## Nhóm C — Nâng cao (Tuần 15–22)

### C1. Đảo ngữ nâng cao
*Hardly had ... when ...* · *No sooner had ... than ...* · *Rarely/Seldom/Never have ...* · *Under no circumstances should ...* · *Enclosed/Attached is ...* (đảo khi tính từ/phân từ đứng đầu).

### C2. Cấu trúc nhờ/bảo/khiến
- have sb **do** / have sth **done**; get sb **to do** / get sth **done**; make sb **do**; let sb **do**; help sb **(to) do**.
- *allow / enable / permit / encourage / require sb **to do***.

### C3. Liên từ tương quan
both A **and** B · either A **or** B · neither A **nor** B · not only A **but (also)** B · A **as well as** B · whether A **or** B.
Động từ hòa hợp với **B** ở *either/neither/not only*.

### C4. Collocation động từ/tính từ + giới từ (học thuộc như từ vựng)
comply with · adhere to · be eligible for · be responsible for · be aware of · be capable of · be familiar with · depend on/rely on · in accordance with · on behalf of · in charge of · in response to · with regard to · prior to · subject to · contribute to · result in / result from · consist of · account for · refrain from · be entitled to.

### C5. Danh từ
- Không đếm được: information, equipment, furniture, merchandise, luggage, baggage, advice, feedback, research, machinery, stationery, access.
- Danh từ ghép: *safety regulations, customer satisfaction, application form, sales figures, expiration date, retail outlet*.
- Mạo từ: *a/an* + đếm được số ít; *the* khi xác định; bỏ mạo từ với danh từ số nhiều/không đếm được mang nghĩa chung.

### C6. Từ vựng gần nghĩa (Part 5 khó nhất ở mức 850+)
Phải học theo cặp/nhóm, có ví dụ:
- *affordable / reasonable / economical* (giá)
- *extend / expand / enlarge* (mở rộng)
- *ensure / assure / insure* (đảm bảo)
- *accept / except / expect*
- *nearly / almost / approximately* (gần như)
- *lately / recently / currently*
- *promptly / punctually / immediately*
- *exclusively / solely / only*
- *substantially / considerably / significantly*
- *reservation / booking / appointment*

### C7. Một số cấu trúc khác hay ra
- *so + adj/adv + that* · *such + (a) adj + N + that* · *too ... to* · *enough + N / adj + enough*.
- *It takes (sb) + time + to do*.
- *as of + ngày* (kể từ) · *as soon as possible* · *as well as* · *as such*.
- *whoever / whatever / whichever / however + adj*.
- *would rather + V* · *had better + V*.
- Câu chẻ: *It was ... that ...*.
