# 07 — Phương pháp học

Trước giờ bạn học kiểu "làm đề → xem điểm". Các phương pháp dưới đây thay thế thói quen đó.

## 1. Chép chính tả (dictation) — tăng điểm Nghe mạnh nhất

1. Nghe cả đoạn 1 lần, không dừng, để nắm ý.
2. Nghe từng câu: dừng, chép lại **từng chữ**. Nghe tối đa 5 lần/câu.
3. Chỗ nào không nghe ra → để trống `____`, đi tiếp.
4. Mở transcript, so sánh, **gạch đỏ chỗ sai** và phân loại:
    - Không biết từ → thêm vào Anki.
    - Biết từ nhưng không nhận ra âm → ghi lại hiện tượng (nối âm, nuốt âm, dạng yếu).
5. Nghe lại 2–3 lần, nhìn transcript.
6. Chuyển sang shadowing đoạn đó.

Công cụ: [dailydictation.com](https://dailydictation.com) (có sẵn bài TOEIC), hoặc audio đề ETS + transcript.

## 2. Shadowing — nghe + nói cùng lúc

1. Chọn đoạn đã chép chính tả (30–60 giây).
2. Vừa nhìn transcript vừa đọc theo, trễ audio ~1 giây. 3 lần.
3. Không nhìn transcript, nói đuổi theo audio. 3–5 lần.
4. Ghi âm lần cuối, nghe lại, so với bản gốc.

Mục đích: tai quen tốc độ, nhận ra nối âm, và phát âm của bạn đúng hơn → nghe đúng hơn.

## 3. Anki — lặp lại ngắt quãng

- Cài Anki (máy tính) + AnkiDroid/AnkiMobile.
- Cài đặt gợi ý: New cards/day = 25–30, Maximum reviews/day = 9999.
- **Thứ tự mỗi ngày:** ôn hết thẻ đến hạn → học thẻ mới.
- Thẻ sai 4 lần (leech) → viết lại thẻ với câu ví dụ khác.
- Cách làm thẻ: xem [04_tu_vung.md](04_tu_vung.md).

## 4. Chữa đề 3 vòng — thay cho "làm đề → xem điểm"

**Vòng 1 — ngay sau khi làm (1 giờ)**
- Chấm điểm, ghi tracker.
- Câu sai **và** câu đúng nhưng đoán → làm lại **không xem đáp án**, có tra từ điển. Lần này sai nữa mới xem đáp án.

**Vòng 2 — hôm sau (1–1,5 giờ)**
- Mỗi câu sai: viết vào sổ lỗi sai **vì sao sai** (thiếu từ / không nắm ngữ pháp / nghe không ra / bị bẫy / hết giờ).
- Listening: chép chính tả các đoạn có câu sai.
- Reading: dịch các câu Part 5 sai; gạch chỗ chứa đáp án trong Part 7.

**Vòng 3 — hôm sau nữa (1 giờ)**
- Toàn bộ từ mới trong đề → Anki.
- Ghi 10 cặp paraphrase.
- Shadowing 2 đoạn Part 3/4 của đề.

Một đề chữa kỹ có giá trị hơn 5 đề làm xong để đó.

## 5. Sổ lỗi sai

Mỗi lỗi một dòng (mẫu ở [09_tracker.md](09_tracker.md)): ngày · đề · câu · Part · loại lỗi · ghi chú đúng.
**Chủ nhật hàng tuần:** đọc lại toàn bộ lỗi của tuần, đếm loại lỗi nhiều nhất → tuần sau tập trung vào loại đó.

## 6. Ngày bận — gói tối thiểu 1 giờ
1. Anki (20')
2. 30 câu Part 5 (15')
3. 1 đoạn chép chính tả (20')
4. Đọc lại sổ lỗi sai (5')

## 7. Giữ sức để cày 6 tháng
- Học theo khối 50 phút + nghỉ 10 phút.
- Ngủ đủ 7 tiếng — trí nhớ từ vựng được củng cố khi ngủ.
- Chủ nhật học nhẹ. Học quá sức 2 tuần rồi bỏ cuộc tệ hơn học vừa đủ 26 tuần.
