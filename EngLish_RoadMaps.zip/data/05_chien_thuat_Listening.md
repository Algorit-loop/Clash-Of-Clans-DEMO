# 05 — Chiến thuật Listening (250 → 430+)

**Mục tiêu số câu đúng cho ~430–470:** Part 1: 6/6 · Part 2: 22/25 · Part 3: 33/39 · Part 4: 25/30.

## Nguyên tắc chung
- Nghe không ra thường do **3 nguyên nhân**: không biết từ / biết từ nhưng không nhận ra âm (nối âm, nuốt âm) / không theo kịp tốc độ. Chép chính tả sửa được cả 3.
- Trong phòng thi: **dùng thời gian đọc hướng dẫn để đọc trước câu hỏi** Part 3, 4.
- Câu nào không nghe ra → chọn đại 1 đáp án, **bỏ qua ngay**, không tiếc. Tiếc 1 câu sẽ mất 3 câu sau.

---

## Part 1 — Mô tả tranh (6 câu)
- Trước khi nghe: nhìn tranh, đoán chủ ngữ (người/vật), hành động, vị trí.
- **Bẫy:**
    - Từ đúng nhưng hành động sai (*He's putting on a jacket* vs đang mặc sẵn = *wearing*).
    - *is being + V3* = đang được làm (phải có người đang làm). Tranh không có người → thường sai.
    - Đáp án nhắc đồ vật không có trong tranh.
- Học bộ từ: *lean against, stack, pile, arrange, hang, face, kneel, reach for, browse, line up, unload, sweep*.

## Part 2 — Hỏi – đáp (25 câu) — phần dễ tăng điểm nhất
- **Bắt chặt từ để hỏi đầu câu** (Who/When/Where/Why/How...). Đáp án *Where* không thể là thời gian.
- **Bẫy:**
    - Đáp án lặp lại từ trong câu hỏi hoặc từ phát âm giống → thường sai.
    - Câu trả lời yes/no cho câu hỏi Wh-.
- **Câu trả lời gián tiếp** (ngày càng nhiều): *"When is the meeting?" → "Didn't you get the email?" / "It's been postponed." / "Ask Mr. Kim."* — đây thường là đáp án đúng.
- 8 dạng cần luyện: Wh- · Yes/No · câu hỏi lựa chọn (A or B) · câu hỏi đuôi · câu hỏi phủ định · đề nghị/yêu cầu (*Could you...? Why don't we...?*) · câu trần thuật · câu hỏi gián tiếp.

## Part 3 — Hội thoại (39 câu, 13 đoạn)
- **Đọc trước 3 câu hỏi**, gạch từ khóa (who, what problem, what next). Câu hỏi đi theo thứ tự hội thoại: câu 1 ở đầu, câu 2 ở giữa, câu 3 ở cuối.
- Dạng câu hỏi thường gặp:
    - Chủ đề / nơi làm việc của người nói → nghe 2 câu đầu.
    - Vấn đề là gì → nghe *but, unfortunately, I'm afraid, the problem is*.
    - Sẽ làm gì tiếp → nghe câu cuối (*I'll..., Let me..., Why don't you...*).
    - Ý định người nói ("What does the woman imply when she says..."): hiểu ngữ cảnh trước và sau câu đó.
    - Graphic (bảng, biểu đồ, bản đồ): đáp án nằm ở **cột không phải cột được nhắc trực tiếp**.
- Hội thoại 3 người: chú ý *man/woman* và tên riêng.
- Đáp án là **paraphrase**, không phải lặp từ.

## Part 4 — Bài nói ngắn (30 câu, 10 bài)
- Giống Part 3: đọc trước câu hỏi.
- Xác định loại bài trong 5 giây đầu, mỗi loại có khung cố định:

| Loại | Khung nội dung |
|---|---|
| Tin nhắn thoại | Ai gọi → vì sao gọi → yêu cầu gọi lại/làm gì |
| Thông báo (sân bay, cửa hàng, công ty) | Thông báo gì → thay đổi gì → người nghe cần làm gì |
| Giới thiệu diễn giả | Tên → thành tích → chủ đề bài nói |
| Quảng cáo | Sản phẩm → ưu điểm → khuyến mãi/cách mua |
| Tin tức / thời tiết / giao thông | Sự kiện → ảnh hưởng → khuyến nghị |
| Hướng dẫn tour | Nơi tham quan → lịch trình → lưu ý |
| Họp nội bộ | Chủ đề → vấn đề → giao việc |

---

## Lộ trình luyện nghe theo tuần
| Tuần | Bài chép chính tả | Shadowing |
|---|---|---|
| 1–3 | Part 1, Part 2 | Câu ngắn Part 2 |
| 4–6 | Part 3 (1–2 đoạn/ngày), bắt đầu Part 4 | Đoạn Part 3 |
| 7–14 | Part 3, 4 (3–4 đoạn/ngày) | Part 4 |
| 15–26 | Đoạn sai trong đề vừa làm | Part 4 tốc độ 1.0–1.2x |

Ngoài giờ: nghe lại đoạn đã chép khi đi đường (nghe thụ động **chỉ có tác dụng với bài đã học kỹ**).
Làm quen giọng Anh – Anh và Úc (đề có đủ giọng Mỹ, Anh, Canada, Úc).
