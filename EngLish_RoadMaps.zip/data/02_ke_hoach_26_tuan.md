# 02 — Kế hoạch 26 tuần

## Lịch học mỗi ngày (≈ 4,5–5 giờ)

### Giai đoạn 1–2 (Tuần 1–14)

| Khung | Thời lượng | Nội dung |
|---|---|---|
| Sáng | 30' | Anki: ôn thẻ cũ + 20–30 từ mới |
| Sáng | 60' | Ngữ pháp: học lý thuyết chủ điểm của tuần + 20–30 câu bài tập |
| Sáng | 30' | Part 5: 30 câu, chữa từng câu |
| Chiều | 60' | Chép chính tả (dictation) — theo Part của tuần |
| Chiều | 20' | Shadowing (đoạn đã chép chính tả) |
| Tối | 60' | Đọc: Part 6/7 hoặc đọc bài ngắn (GĐ1: đọc song ngữ, đoán từ) |
| Tối | 20' | Ôn sổ lỗi sai + từ mới trong ngày |

Thứ 2 – Thứ 7 học theo bảng trên. **Chủ nhật** chỉ ôn nhẹ 1–2 giờ: Anki, đọc lại sổ lỗi sai, làm bài kiểm tra cuối tuần (nếu có) và ghi tracker.

### Giai đoạn 3–4 (Tuần 15–26)

| Ngày | Nội dung chính |
|---|---|
| Thứ 2 | Đề full (2h) + chữa vòng 1 (1h) + Anki |
| Thứ 3 | Chữa vòng 2–3 đề hôm qua (2h) + chép chính tả Part 3/4 của đề (1h) + Anki |
| Thứ 4 | Ngữ pháp Nhóm C (1h) + 60 câu Part 5 (1h) + Part 7 đoạn đôi/ba (1,5h) |
| Thứ 5 | Đề full + chữa vòng 1 |
| Thứ 6 | Chữa vòng 2–3 + chép chính tả + shadowing |
| Thứ 7 | Part yếu nhất tuần (2h) + từ vựng từ đề (1h) + đọc tự do (1h) |
| Chủ nhật | **Ôn nhẹ 1–2h:** sổ lỗi sai, Anki, ghi tracker. Nghỉ ngơi. |

GĐ4 (Tuần 23–26): thêm 1 đề vào Thứ 7 → 3 đề/tuần.

---

## Giai đoạn 1 — Xây nền

### Tuần 0 — Chẩn đoán và chuẩn bị
- **Đề chẩn đoán:** Làm 1 đề ETS full, bấm giờ đúng 2 tiếng. Ghi số câu đúng của từng Part vào tracker.
- **Phân tích:** Đếm số câu sai theo Part để biết Part nào yếu nhất (dự đoán: Part 5, 7 và Part 3, 4).
- **Công cụ:** Cài Anki trên máy tính + điện thoại, tạo tài khoản dailydictation.com.
- **Tài liệu:** Chuẩn bị sách Giai đoạn 1 và ít nhất 1 bộ đề ETS (xem file Tài liệu).
- **Lịch:** Chọn khung giờ học cố định mỗi ngày; chọn ngày thi dự kiến (khoảng tuần 26–27).

### Tuần 1 — Phát âm + từ loại
- **Phát âm:** 44 âm IPA (nguyên âm ngắn/dài: /ɪ/–/iː/, /æ/–/e/, /ʊ/–/uː/; phụ âm /θ/ /ð/ /ʃ/ /ʒ/ /tʃ/ /dʒ/).
- **Ngữ pháp:** Từ loại (danh, động, tính, trạng từ), vị trí của từng loại trong câu, hậu tố nhận biết.
- **Từ vựng:** Cài Anki, bắt đầu 1.500 từ thông dụng: 30 từ/ngày.
- **Nghe:** Chép chính tả câu ngắn (Part 1 — 6 câu/ngày).
- **Đọc:** Mỗi ngày 30 câu Part 5 *chỉ dạng từ loại*.

### Tuần 2 — Âm cuối + thì cơ bản
- **Phát âm:** Âm cuối -s/-es (/s/ /z/ /ɪz/), -ed (/t/ /d/ /ɪd/), trọng âm từ.
- **Ngữ pháp:** Hiện tại đơn, hiện tại tiếp diễn, quá khứ đơn, tương lai đơn, hiện tại hoàn thành. Dấu hiệu nhận biết.
- **Từ vựng:** 30 từ/ngày (thông dụng).
- **Nghe:** Part 1 (chép chính tả) + Part 2 (10 câu/ngày).
- **Kiểm tra cuối tuần:** 30 câu Part 5 hỗn hợp → mục tiêu ≥ 15/30.

### Tuần 3 — Nối âm + thì nâng cao + hòa hợp chủ vị
- **Phát âm:** Nối âm (phụ âm + nguyên âm), nuốt âm /t/ /d/, dạng yếu (can, to, for, and, of).
- **Ngữ pháp:** Quá khứ tiếp diễn, quá khứ hoàn thành, tương lai hoàn thành, hiện tại hoàn thành tiếp diễn; hòa hợp chủ ngữ – động từ.
- **Từ vựng:** Hoàn thành ~600 từ thông dụng.
- **Nghe:** Part 2: 25 câu/ngày, chép chính tả câu hỏi.
- **Đọc:** Đọc 1 đoạn email ngắn/ngày (Part 7 đơn giản), tra từ.

### Tuần 4 — Bị động + đại từ
- **Ngữ pháp:** Câu bị động (mọi thì, bị động với động từ khuyết thiếu), đại từ (nhân xưng, sở hữu, phản thân), chủ động vs bị động trong Part 5.
- **Từ vựng:** ~800 từ; bắt đầu học **họ từ** (xem [04_tu_vung.md](04_tu_vung.md)).
- **Nghe:** Part 2 + bắt đầu Part 3 (1 đoạn/ngày, chép chính tả toàn bộ).
- **Kiểm tra cuối tuần:** Nửa đề → ghi tracker.

### Tuần 5 — Giới từ, liên từ, mệnh đề quan hệ
- **Ngữ pháp:** Giới từ thời gian/nơi chốn; liên từ (because/although/while/unless) vs giới từ (because of/despite/during) vs trạng từ nối (however/therefore); mệnh đề quan hệ (who/which/that/whose/where).
- **Từ vựng:** ~1.100 từ thông dụng.
- **Nghe:** Part 3: 2 đoạn/ngày chép chính tả + shadowing.
- **Đọc:** Part 6: 1 đoạn/ngày.

### Tuần 6 — So sánh, V-ing/to V, tổng ôn Nhóm A
- **Ngữ pháp:** So sánh (hơn, nhất, bằng, kép); danh động từ vs động từ nguyên mẫu; tổng ôn Nhóm A.
- **Từ vựng:** Hoàn thành 1.500 từ thông dụng → chuyển sang từ TOEIC (chủ đề 1–4).
- **Nghe:** Part 4: 1 bài/ngày chép chính tả.
- **Kiểm tra cuối tuần:** **Đề full #1** → mục tiêu 550. Chữa đề 3 vòng (xem [07_phuong_phap_hoc.md](07_phuong_phap_hoc.md)).

---

## Giai đoạn 2 — Kỹ năng theo Part

### Tuần 7 — Part 1 + Part 5 (từ loại nâng cao)
- **Ngữ pháp:** Phân từ (-ing/-ed) làm tính từ; tính từ ghép; trạng từ bổ nghĩa cho tính từ/động từ/cả câu.
- **Nghe:** Hoàn thiện Part 1 (bẫy: hành động vs trạng thái, *being + V3*). Học bộ từ vựng Part 1 (đồ vật, tư thế, vị trí).
- **Đọc:** Part 5: 40 câu/ngày.
- **Từ vựng:** TOEIC 25 từ/ngày + họ từ.

### Tuần 8 — Part 2 chuyên sâu
- **Ngữ pháp:** Câu điều kiện loại 0, 1, 2, 3, hỗn hợp; unless, provided that, as long as.
- **Nghe:** Part 2: 50 câu/ngày. Học 8 dạng câu hỏi + câu trả lời gián tiếp (xem [05_chien_thuat_Listening.md](05_chien_thuat_Listening.md)).
- **Đọc:** Part 5 + Part 6.

### Tuần 9 — Part 3 (1)
- **Ngữ pháp:** Mệnh đề danh từ (that/whether/what/how); mệnh đề trạng ngữ rút gọn.
- **Nghe:** Đọc câu hỏi trước khi nghe; Part 3: 3 đoạn/ngày (làm → chép chính tả → shadowing).
- **Đọc:** Part 7 đoạn đơn (email, thông báo): 3 đoạn/ngày.

### Tuần 10 — Part 3 (2) + đo
- **Ngữ pháp:** Lượng từ (each/every/all/most/almost/few/a few/little/a little/the number of/a number of).
- **Nghe:** Part 3 có biểu đồ (graphic) + câu hỏi ý định người nói ("What does the man mean when he says...").
- **Kiểm tra cuối tuần:** **Đề full #2** → mục tiêu 620.

### Tuần 11 — Part 4
- **Ngữ pháp:** Câu giả định (recommend/suggest/insist that + V nguyên mẫu; It is essential that...).
- **Nghe:** Các loại bài nói: thông báo, quảng cáo, tin tức, tin nhắn thoại, giới thiệu diễn giả, tour. 2–3 bài/ngày.
- **Đọc:** Part 7: 4 đoạn/ngày, bấm giờ.

### Tuần 12 — Part 6
- **Ngữ pháp:** Trạng từ nối và mạch văn (however, therefore, in addition, as a result, otherwise, meanwhile); câu điền cả câu.
- **Đọc:** Part 6: 4 đoạn/ngày. Luyện đọc toàn đoạn trước khi chọn.
- **Nghe:** Luân phiên Part 3/4.
- **Kiểm tra cuối tuần:** **Đề full #3**.

### Tuần 13 — Part 7 đoạn đơn + tốc độ đọc
- **Ngữ pháp:** Đảo ngữ cơ bản (Only, Not only, Should/Had/Were thay cho if).
- **Đọc:** Part 7: dạng câu hỏi (chủ đề, chi tiết, suy luận, NOT true, điền câu, từ đồng nghĩa). 6 đoạn/ngày.
- **Từ vựng:** TOEIC ~1.000 từ.

### Tuần 14 — Tổng ôn Nhóm B + đo
- **Ngữ pháp:** Tổng ôn Nhóm B.
- **Nghe + Đọc:** Mỗi Part 1 bài lẻ mỗi ngày.
- **Kiểm tra cuối tuần:** **Đề full #4** → mục tiêu 680. Thống kê tỷ lệ sai từng Part → chọn 2 Part yếu nhất cho GĐ3.

---

## Giai đoạn 3 — Luyện đề + nâng cao

Mỗi tuần: **2 đề full** (Thứ 2, Thứ 5) + chữa đề 3 vòng + 1 chủ điểm ngữ pháp Nhóm C, theo lịch tuần ở trên.

### Tuần 15 — Đảo ngữ nâng cao + Part 7 đoạn đôi
- **Ngữ pháp:** Đảo ngữ nâng cao (Hardly/No sooner/Rarely/Under no circumstances) — 60 câu bài tập.
- **Đề:** 2 đề full + chữa đề 3 vòng.
- **Đọc:** Part 7 đoạn đôi: 4 bộ/ngày, luyện ghép thông tin 2 văn bản.
- **Từ vựng:** Từ mới trong 2 đề → Anki; 10 cặp paraphrase/đề.
- **Mục tiêu đề:** 700.

### Tuần 16 — Cấu trúc nhờ/bảo + Part 3 graphic
- **Ngữ pháp:** have/get/make/let sb do; allow/enable/require sb to do; câu chẻ.
- **Đề:** 2 đề full + chữa đề 3 vòng.
- **Nghe:** Part 3 có biểu đồ/bảng: 5 đoạn/ngày.
- **Từ vựng:** Từ mới trong đề → Anki.
- **Mục tiêu đề:** 720.

### Tuần 17 — Liên từ tương quan + Part 7 đoạn ba
- **Ngữ pháp:** both...and, either...or, neither...nor, not only...but also, hòa hợp động từ.
- **Đề:** 2 đề full + chữa đề 3 vòng.
- **Đọc:** Part 7 đoạn ba: 3 bộ/ngày, bấm 5 phút/bộ.
- **Từ vựng:** Từ mới trong đề → Anki.
- **Mục tiêu đề:** 730.

### Tuần 18 — Collocation + Part 5 từ vựng
- **Ngữ pháp:** Collocation động từ/tính từ + giới từ (mục C4) — học thuộc 40 cụm.
- **Đề:** 2 đề full + chữa đề 3 vòng.
- **Đọc:** 60 câu Part 5 dạng từ vựng/ngày.
- **Kiểm tra:** So điểm với mốc 740; ghi Part yếu nhất.
- **Mục tiêu đề:** 740.

### Tuần 19 — Danh từ, mạo từ + Part 4
- **Ngữ pháp:** Danh từ đếm được/không đếm được, danh từ ghép, mạo từ (mục C5).
- **Đề:** 2 đề full + chữa đề 3 vòng.
- **Nghe:** Part 4: 4 bài/ngày, chép chính tả bài sai.
- **Từ vựng:** Từ mới trong đề → Anki.
- **Mục tiêu đề:** 760.

### Tuần 20 — Từ gần nghĩa + Part 6 câu điền cả câu
- **Ngữ pháp:** Nhóm từ gần nghĩa (mục C6) — mỗi nhóm 1 câu ví dụ tự viết.
- **Đề:** 2 đề full + chữa đề 3 vòng.
- **Đọc:** Part 6: 6 đoạn/ngày, tập trung câu điền cả câu.
- **Từ vựng:** Từ mới trong đề → Anki.
- **Mục tiêu đề:** 770.

### Tuần 21 — Tổng ôn ngữ pháp + Part yếu nhất
- **Ngữ pháp:** Tổng ôn toàn bộ Nhóm A, B, C: 60 câu Part 5/ngày.
- **Đề:** 2 đề full + chữa đề 3 vòng.
- **Part yếu nhất:** 1,5 giờ/ngày cho Part có tỷ lệ sai cao nhất trong tracker.
- **Từ vựng:** Ôn thẻ khó (leech) trong Anki.
- **Mục tiêu đề:** 790.

### Tuần 22 — Sổ lỗi sai + thời gian Reading
- **Ôn tập:** Đọc lại toàn bộ sổ lỗi sai; làm lại các câu đã sai.
- **Đề:** 2 đề full, ghi mốc thời gian từng Part Reading.
- **Thời gian:** Đạt Part 5 ≤ 11 phút, Part 6 ≤ 9 phút.
- **Đăng ký thi:** Nếu 2 đề liên tiếp ≥ 800 → đăng ký ngày thi tuần 26–27.
- **Mục tiêu đề:** **800**.

---

## Giai đoạn 4 — Sprint

Mỗi tuần **3 đề full** trong điều kiện thi thật (8h sáng, 2 tiếng liền, có tô phiếu).

### Tuần 23 — Thi thử điều kiện thật
- **Đề:** 3 đề full (Thứ 2, Thứ 4, Thứ 6) lúc 8h sáng, có phiếu tô.
- **Chữa đề:** Chữa đề 3 vòng cho từng đề.
- **Từ vựng:** Chỉ thêm từ sai trong đề, 10 từ/ngày.
- **Mục tiêu đề:** 800+.

### Tuần 24 — Từ vựng trong đề
- **Đề:** 3 đề full + chữa đề.
- **Từ vựng:** Ôn toàn bộ từ đã sai trong các đề GĐ3–4.
- **Nghe:** Shadowing 2 đoạn Part 4/ngày.
- **Mục tiêu đề:** 820.

### Tuần 25 — Sổ lỗi sai lần cuối
- **Đề:** 3 đề full (dùng các đề ETS mới nhất đã để dành).
- **Ôn tập:** Đọc lại sổ lỗi sai, tập trung loại lỗi nhiều nhất.
- **Ngữ pháp:** 30 câu Part 5/ngày để giữ tay.
- **Mục tiêu đề:** 830+.

### Tuần 26 — Giảm tải và đi thi
- **Đề:** 1–2 đề đầu tuần, sau đó không làm đề full nữa.
- **Ôn nhẹ:** Anki + sổ lỗi sai, mỗi ngày 1–2 giờ.
- **Trước thi 2 ngày:** Không học nặng, ngủ sớm.
- **Ngày thi:** Mang CCCD, bút chì 2B, tẩy; ăn sáng; đến sớm 30 phút.
- **Mục tiêu:** Thi 820–900.
