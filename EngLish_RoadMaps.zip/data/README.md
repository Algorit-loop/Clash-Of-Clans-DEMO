# zEnglish_TOEIC — Lộ trình 400 → 800+ (hướng 900) trong 6 tháng

**Điểm xuất phát:** 400 (Nghe 250 · Đọc 150) — tự học, chủ yếu luyện đề.
**Mục tiêu:** 800+ sau 26 tuần, cố gắng chạm 900.
**Cường độ:** 4–6 giờ/ngày, 6 ngày/tuần + 1 ngày ôn nhẹ.

## Thực tế cần biết trước

- 400 → 800 thường cần khoảng **600–800 giờ học có chủ đích**. 26 tuần × 6 ngày × 4,5 giờ ≈ **700 giờ** → khả thi, nhưng chỉ khi học đều và đúng cách.
- Điểm yếu lớn nhất của bạn là **Reading (150)**. 800 điểm cần khoảng **Nghe 430 + Đọc 370** → Đọc phải tăng ~220, Nghe ~180. Reading được ưu tiên thời gian hơn.
- Bỏ thói quen "cày đề liên tục". Trong 6 tuần đầu **gần như không làm đề full** — chỉ xây nền.

## Đọc theo thứ tự

| File | Nội dung |
|---|---|
| [01_lo_trinh_tong_quan.md](01_lo_trinh_tong_quan.md) | 4 giai đoạn, mốc điểm từng tháng, cấu trúc đề |
| [02_ke_hoach_26_tuan.md](02_ke_hoach_26_tuan.md) | Kế hoạch chi tiết từng tuần + lịch học mỗi ngày |
| [03_ngu_phap_TOEIC.md](03_ngu_phap_TOEIC.md) | Toàn bộ chủ điểm ngữ pháp cần cho 800–900, kèm bẫy hay gặp |
| [04_tu_vung.md](04_tu_vung.md) | Chiến lược từ vựng, chủ đề, họ từ, paraphrase |
| [05_chien_thuat_Listening.md](05_chien_thuat_Listening.md) | Chiến thuật Part 1–4 |
| [06_chien_thuat_Reading.md](06_chien_thuat_Reading.md) | Chiến thuật Part 5–7, quản lý thời gian |
| [07_phuong_phap_hoc.md](07_phuong_phap_hoc.md) | Chép chính tả, shadowing, Anki, chữa đề 3 vòng |
| [08_tai_lieu.md](08_tai_lieu.md) | Sách, đề, công cụ — dùng gì ở giai đoạn nào |
| [09_tracker.md](09_tracker.md) | Bảng theo dõi điểm, giờ học, sổ lỗi sai (mẫu) |

## Xem trên web

Folder `web/` là website (Flask) hiển thị toàn bộ nội dung trong `data/`: checklist từng tuần, ngữ pháp, từ vựng, chiến thuật, tracker điểm có biểu đồ.

```bash
cd zEnglish_TOEIC/web
./setup.sh    # lần đầu: tạo môi trường ảo web/.venv và cài Flask + Markdown
./run.sh      # mở http://127.0.0.1:5000
```

- Môi trường Python nằm gọn trong `web/.venv`, không cài gì ra ngoài.
- Web **chỉ đọc** các file `.md` này; sửa file `.md` rồi tải lại trang là thấy nội dung mới.
- Tiến độ (việc đã tích, điểm, giờ học, sổ lỗi sai) được lưu ở `data/progress.json` — file này tự tạo khi bạn tích việc đầu tiên.
- Muốn chạy cổng khác: `./run.sh --port 8000`.

## 5 nguyên tắc không được bỏ

1. **Ngày nào cũng học**, kể cả ngày bận (tối thiểu 1 giờ: Anki + 30 câu Part 5 + 15 phút chép chính tả).
2. **Chữa đề lâu gấp 2–3 lần thời gian làm đề.**
3. **Sổ lỗi sai** — mọi câu sai đều được ghi lại, ôn mỗi Chủ nhật.
4. **Anki mỗi ngày**, không để dồn thẻ.
5. **Đo tiến độ** mỗi 2 tuần bằng nửa đề / đề full và ghi vào [09_tracker.md](09_tracker.md).
