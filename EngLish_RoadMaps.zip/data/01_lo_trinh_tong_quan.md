# 01 — Lộ trình tổng quan

## Cấu trúc đề TOEIC Listening & Reading (format hiện hành)

| Phần | Part | Nội dung | Số câu | Thời gian |
|---|---|---|---|---|
| Listening | 1 | Mô tả tranh | 6 | ~45 phút cho cả phần Nghe |
| | 2 | Hỏi – đáp | 25 | |
| | 3 | Hội thoại (13 đoạn, có đoạn kèm biểu đồ) | 39 | |
| | 4 | Bài nói ngắn (10 bài) | 30 | |
| Reading | 5 | Điền câu chưa hoàn chỉnh (ngữ pháp + từ vựng) | 30 | 75 phút cho cả phần Đọc |
| | 6 | Điền đoạn văn (có câu điền cả câu) | 16 | |
| | 7 | Đọc hiểu: đoạn đơn (29) + 2 bộ đoạn đôi (10) + 3 bộ đoạn ba (15) | 54 | |

Mỗi phần 5–495 điểm, tổng 10–990.

## Điểm hiện tại và điểm cần đạt

| | Hiện tại | Mục tiêu 800 | Mục tiêu 900 | Cần tăng (800) |
|---|---|---|---|---|
| Listening | 250 | 430 | 470 | +180 |
| Reading | 150 | 370 | 430 | +220 |
| **Tổng** | **400** | **800** | **900** | **+400** |

Quy đổi tương đối (thay đổi theo từng đề): Reading 370 ≈ đúng 78–82/100 câu; Listening 430 ≈ đúng 82–86/100 câu.

**Chẩn đoán:** Reading 150 nghĩa là bạn đang thiếu cả từ vựng lẫn ngữ pháp nền — không phải thiếu mẹo. Listening 250 cho thấy tai đã có nền, nhưng nghe chưa chính xác (thiếu từ, nghe không ra nối âm, không theo kịp Part 3–4).

## 4 giai đoạn

```
Tuần  1 ─────── 6 │ 7 ───────── 14 │ 15 ──────── 22 │ 23 ── 26
GĐ1: XÂY NỀN      │ GĐ2: KỸ NĂNG    │ GĐ3: LUYỆN ĐỀ   │ GĐ4: SPRINT
Mốc: 550          │ Mốc: 680        │ Mốc: 800        │ Thi: 820–900
```

### Giai đoạn 1 — Xây nền (Tuần 1–6) · mốc ~550
- Phát âm IPA, nối âm, âm cuối.
- 1.500 từ thông dụng + 500 từ TOEIC đầu tiên.
- Toàn bộ ngữ pháp **Nhóm A** (xem [03_ngu_phap_TOEIC.md](03_ngu_phap_TOEIC.md)).
- Chép chính tả Part 1, 2 mỗi ngày.
- **Không làm đề full.** Chỉ làm bài lẻ theo Part 1, 2, 5.

### Giai đoạn 2 — Kỹ năng theo Part (Tuần 7–14) · mốc ~680
- Ngữ pháp **Nhóm B**.
- Từ vựng TOEIC lên ~1.200 từ + họ từ + paraphrase.
- Chép chính tả Part 3, 4; shadowing hàng ngày.
- Part 6, Part 7 đoạn đơn; tốc độ đọc.
- Từ tuần 10: mỗi 2 tuần 1 đề full để đo.

### Giai đoạn 3 — Luyện đề + nâng cao (Tuần 15–22) · mốc ~800
- Ngữ pháp **Nhóm C** (câu khó, đảo ngữ, giả định...).
- Từ vựng lên ~2.000 từ TOEIC, ưu tiên từ đã sai trong đề.
- 2 đề full/tuần, chữa đề 3 vòng.
- Part 7 đoạn đôi/ba, quản lý thời gian.

### Giai đoạn 4 — Sprint (Tuần 23–26) · thi 820–900
- 3 đề full/tuần trong điều kiện thi thật (sáng, liền mạch 2 tiếng, có tô phiếu).
- Ôn sổ lỗi sai + Anki thẻ khó.
- Tuần cuối giảm tải, ngủ đủ.

## Mốc kiểm tra

| Cuối tuần | Bài kiểm tra | Mục tiêu tối thiểu | Nếu không đạt |
|---|---|---|---|
| 0 | Đề full chẩn đoán | Ghi điểm từng Part | — |
| 2 | 30 câu Part 5 | 15/30 | Ôn lại từ loại + thì |
| 4 | Nửa đề (50 Nghe + 50 Đọc) | ≈ 480 quy đổi | Kéo dài GĐ1 thêm 1 tuần |
| 6 | Đề full | 550 | Kéo dài GĐ1 thêm 1 tuần, giảm phần mới |
| 10 | Đề full | 620 | Xem lại tỷ lệ sai theo Part |
| 14 | Đề full | 680 | Tăng giờ từ vựng |
| 18 | Đề full | 740 | Tập trung Part yếu nhất |
| 22 | Đề full | 800 | Đăng ký thi nếu 2 đề liên tiếp ≥ 800 |
| 25 | Đề full | 820+ | — |

## Thông tin kỳ thi

- Tại Việt Nam, kỳ thi TOEIC chính thức do **IIG Việt Nam** tổ chức (đại diện của ETS). Kiểm tra lịch thi, lệ phí và địa điểm trên trang IIG trước khi đăng ký.
- Chọn ngày thi tầm tuần 26–27. **Đăng ký sớm 3–4 tuần** để có hạn chót cụ thể.
- Điểm TOEIC có giá trị **2 năm** kể từ ngày thi.
- Phòng thi không cho dùng bút mực; chỉ bút chì, không ghi chú lên đề.
