# 09 — Tracker

Cập nhật sau mỗi bài đo và mỗi Chủ nhật.

## Điểm đề full

| Tuần | Ngày | Đề | P1 /6 | P2 /25 | P3 /39 | P4 /30 | **LC** | P5 /30 | P6 /16 | P7 /54 | **RC** | **Tổng** | Mục tiêu |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | | Điểm thi gần nhất | | | | | 250 | | | | 150 | 400 | — |
| 6 | | | | | | | | | | | | | 550 |
| 10 | | | | | | | | | | | | | 620 |
| 14 | | | | | | | | | | | | | 680 |
| 18 | | | | | | | | | | | | | 740 |
| 22 | | | | | | | | | | | | | 800 |
| 25 | | | | | | | | | | | | | 820+ |

## Giờ học mỗi tuần

| Tuần | Giờ học | Từ mới (Anki) | Số đoạn chép chính tả | Câu Part 5 | Ghi chú |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |

Mục tiêu: ≥ 27 giờ/tuần.

## Sổ lỗi sai (mẫu)

Loại lỗi: **TV** = thiếu từ vựng · **NP** = ngữ pháp · **ÂM** = nghe không ra âm · **BẪY** = bị bẫy · **TG** = hết giờ / đoán.

| Ngày | Đề | Câu | Part | Loại | Sai vì sao | Ghi nhớ đúng |
|---|---|---|---|---|---|---|
| 2026-11-10 | ETS T1 | 112 | 5 | NP | Thấy "although" + cụm danh từ vẫn chọn | Sau chỗ trống là N → despite |
| | | | | | | |

## Tổng kết Chủ nhật

| Tuần | Loại lỗi nhiều nhất | Part yếu nhất | Tuần sau tập trung vào |
|---|---|---|---|
| 1 | | | |
