#!/usr/bin/env bash
# Tạo môi trường ảo .venv ngay trong web/ và cài thư viện. Không đụng tới Python hệ thống.
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -x .venv/bin/python ]; then
  if ! python3 -m venv .venv >/dev/null 2>&1; then
    # Máy thiếu ensurepip: tạo venv không có pip rồi tự cài pip vào venv
    rm -rf .venv
    python3 -m venv --without-pip .venv
    mkdir -p .cache
    python3 -m pip download pip --no-deps -d .cache -q
    WHL=$(ls .cache/pip-*.whl | head -1)
    .venv/bin/python "$WHL/pip" install --no-index "$WHL" -q
  fi
fi

.venv/bin/python -m pip install -q -r requirements.txt
echo "Xong. Chạy web: ./run.sh"
