"""Lưu tiến độ học (checklist, điểm, giờ học, lỗi sai...) vào data/progress.json."""
from __future__ import annotations

import json
import os
import threading
import uuid
from datetime import datetime
from pathlib import Path

from content import DATA_DIR

PATH = Path(os.environ.get("ZE_PROGRESS") or DATA_DIR / "progress.json")
_lock = threading.RLock()

DEFAULT = {
    "settings": {"start_date": None, "exam_date": None},
    "checks": {},      # id -> "YYYY-MM-DD" ngày đánh dấu xong
    "scores": [],      # đề full / nửa đề
    "hours": [],       # nhật ký giờ học theo tuần
    "errors": [],      # sổ lỗi sai
    "reviews": [],     # tổng kết Chủ nhật
}

# trường được phép cho từng collection: tên -> kiểu
FIELDS = {
    "scores": {"date": str, "week": int, "test": str, "lc": int, "rc": int,
               "p1": int, "p2": int, "p3": int, "p4": int, "p5": int, "p6": int, "p7": int},
    "hours": {"week": int, "hours": float, "words": int, "dictations": int, "part5": int, "note": str},
    "errors": {"date": str, "test": str, "question": str, "part": int, "type": str, "why": str, "fix": str},
    "reviews": {"week": int, "top_error": str, "weak_part": str, "focus": str},
}
SETTINGS = {"start_date", "exam_date"}


def load() -> dict:
    with _lock:
        if not PATH.exists():
            return json.loads(json.dumps(DEFAULT))
        data = json.loads(PATH.read_text(encoding="utf-8"))
    for k, v in DEFAULT.items():
        data.setdefault(k, json.loads(json.dumps(v)))
    return data


def _save(data: dict) -> None:
    tmp = PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, PATH)


def _mutate(fn):
    with _lock:
        data = load()
        result = fn(data)
        _save(data)
    return result


def set_check(cid: str, done: bool) -> None:
    def fn(d):
        if done:
            d["checks"][cid] = datetime.now().strftime("%Y-%m-%d")
        else:
            d["checks"].pop(cid, None)
    _mutate(fn)


def set_settings(values: dict) -> dict:
    def fn(d):
        for k in SETTINGS & values.keys():
            v = values[k]
            if v:
                datetime.strptime(v, "%Y-%m-%d")  # kiểm tra định dạng
            d["settings"][k] = v or None
        return d["settings"]
    return _mutate(fn)


def _clean(coll: str, values: dict) -> dict:
    out = {}
    for k, typ in FIELDS[coll].items():
        v = values.get(k)
        if v in (None, ""):
            continue
        try:
            out[k] = typ(v)
        except (TypeError, ValueError):
            raise ValueError(f"Giá trị không hợp lệ cho '{k}'")
        if typ is str:
            out[k] = out[k].strip()[:500]
    return out


def add_item(coll: str, values: dict) -> dict:
    item = _clean(coll, values)
    if coll in ("scores", "hours", "reviews"):
        if not 0 <= item.get("week", -1) <= 30:
            raise ValueError("Tuần phải từ 0 đến 30")
    if coll == "hours" and "hours" not in item:
        raise ValueError("Cần nhập số giờ học")
    if coll == "scores":
        for k, hi in (("lc", 495), ("rc", 495)):
            if k not in item or not 5 <= item[k] <= hi:
                raise ValueError("Điểm Listening/Reading phải từ 5 đến 495")
        if item.get("week") is not None and not 0 <= item["week"] <= 30:
            raise ValueError("Tuần phải từ 0 đến 30")
    item["id"] = uuid.uuid4().hex[:10]
    item["created"] = datetime.now().isoformat(timespec="seconds")
    _mutate(lambda d: d[coll].append(item))
    return item


def delete_item(coll: str, item_id: str) -> None:
    def fn(d):
        d[coll] = [x for x in d[coll] if x.get("id") != item_id]
    _mutate(fn)
