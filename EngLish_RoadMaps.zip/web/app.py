"""zEnglish TOEIC — web xem lộ trình học từ ../data.

Chạy:  ./run.sh   (hoặc .venv/bin/python app.py --port 5000)
"""
from __future__ import annotations

import argparse
from datetime import date, datetime, timedelta

from flask import Flask, abort, jsonify, render_template, request

import content
import store

app = Flask(__name__)
app.json.ensure_ascii = False

NAV = [
    ("Tổng quan", [
        ("home", "/", "Bảng điều khiển", "home"),
        ("lo-trinh", "/lo-trinh", "Lộ trình", "map"),
        ("ke-hoach", "/ke-hoach", "Kế hoạch 26 tuần", "calendar"),
    ]),
    ("Kiến thức", [
        ("ngu-phap", "/ngu-phap", "Ngữ pháp", "layers"),
        ("tu-vung", "/tu-vung", "Từ vựng", "book"),
        ("listening", "/listening", "Listening", "headphones"),
        ("reading", "/reading", "Reading", "eye"),
    ]),
    ("Học & theo dõi", [
        ("phuong-phap", "/phuong-phap", "Phương pháp học", "compass"),
        ("tai-lieu", "/tai-lieu", "Tài liệu", "library"),
        ("tracker", "/tracker", "Tracker", "chart"),
    ]),
]


def _parse_date(s):
    try:
        return datetime.strptime(s, "%Y-%m-%d").date() if s else None
    except ValueError:
        return None


def timeline(state: dict, total_weeks: int) -> dict:
    """Tuần hiện tại + ngày của từng tuần, dựa trên ngày bắt đầu (= đầu Tuần 0)."""
    today = date.today()
    start = _parse_date(state["settings"].get("start_date"))
    exam = _parse_date(state["settings"].get("exam_date"))
    info = {"today": today.isoformat(), "start": start, "exam": exam, "current": None,
            "status": "unset", "days_to_exam": (exam - today).days if exam else None, "week_dates": {}}
    if start:
        for w in range(total_weeks + 1):
            a = start + timedelta(weeks=w)
            info["week_dates"][w] = (a, a + timedelta(days=6))
        diff = (today - start).days
        if diff < 0:
            info["status"], info["days_to_start"] = "before", -diff
        elif diff // 7 > total_weeks:
            info["status"], info["current"] = "done", total_weeks
        else:
            info["status"], info["current"] = "running", diff // 7
    return info


def pct(done: int, total: int) -> int:
    return round(100 * done / total) if total else 0


@app.context_processor
def inject():
    return {"NAV": NAV}


@app.template_filter("dm")
def fmt_dm(d):
    return d.strftime("%d/%m") if d else ""


# ------------------------------------------------------------------ pages
@app.route("/")
def home():
    state = store.load()
    road, pl, gr, vo = content.roadmap(), content.plan(), content.grammar(), content.vocab()
    tl = timeline(state, road["total_weeks"])
    checks = state["checks"]

    all_tasks = [t for w in pl["weeks"] for t in w["tasks"]]
    topics = [t for g in gr["groups"] for t in g["topics"]]
    progress = {
        "plan": (sum(t["id"] in checks for t in all_tasks), len(all_tasks)),
        "grammar": (sum(t["id"] in checks for t in topics), len(topics)),
        "vocab": (sum(t["id"] in checks for t in vo["topics"]), len(vo["topics"])),
    }
    week = None
    if tl["current"] is not None:
        week = next((w for w in pl["weeks"] if w["n"] == tl["current"]), None)
    scores = sorted(state["scores"], key=lambda s: (s.get("week", 0), s.get("date", "")))
    latest = scores[-1] if scores else None
    best = max(scores, key=lambda s: s["lc"] + s["rc"]) if scores else None
    phase_now = next((p for p in road["phases"] if tl["current"] is not None and p["start"] <= tl["current"] <= p["end"]), None)
    return render_template("dashboard.html", page="home", h=content.home(), road=road, plan=pl, tl=tl,
                           progress=progress, pct=pct, week=week, checks=checks, latest=latest, best=best,
                           phase_now=phase_now, scores=scores, settings=state["settings"])


@app.route("/lo-trinh")
def roadmap():
    state = store.load()
    road = content.roadmap()
    return render_template("roadmap.html", page="lo-trinh", r=road, scores=state["scores"],
                           tl=timeline(state, road["total_weeks"]))


@app.route("/ke-hoach")
def plan():
    state = store.load()
    road, pl = content.roadmap(), content.plan()
    return render_template("plan.html", page="ke-hoach", p=pl, phases=road["phases"],
                           checks=state["checks"], tl=timeline(state, road["total_weeks"]), pct=pct)


@app.route("/ngu-phap")
def grammar():
    return render_template("grammar.html", page="ngu-phap", g=content.grammar(), checks=store.load()["checks"])


@app.route("/tu-vung")
def vocab():
    return render_template("vocab.html", page="tu-vung", v=content.vocab(), checks=store.load()["checks"])


@app.route("/listening")
@app.route("/reading")
def tactics():
    slug = request.path.strip("/")
    return render_template("tactics.html", page=slug, t=content.tactics(slug), kind=slug)


@app.route("/phuong-phap")
@app.route("/tai-lieu")
def generic():
    slug = request.path.strip("/")
    return render_template("generic.html", page=slug, d=content.generic(slug))


@app.route("/tracker")
def tracker():
    state = store.load()
    road = content.roadmap()
    return render_template("tracker.html", page="tracker", t=content.tracker(), road=road, state=state,
                           tl=timeline(state, road["total_weeks"]))


# ------------------------------------------------------------------ API
@app.get("/api/state")
def api_state():
    return jsonify(store.load())


@app.post("/api/check")
def api_check():
    body = request.get_json(force=True)
    cid = str(body.get("id", ""))[:40]
    if not cid:
        abort(400)
    store.set_check(cid, bool(body.get("done")))
    return jsonify(ok=True)


@app.post("/api/settings")
def api_settings():
    try:
        return jsonify(store.set_settings(request.get_json(force=True)))
    except ValueError:
        return jsonify(error="Ngày không hợp lệ (YYYY-MM-DD)"), 400


@app.post("/api/items/<coll>")
def api_add(coll):
    if coll not in store.FIELDS:
        abort(404)
    try:
        return jsonify(store.add_item(coll, request.get_json(force=True)))
    except ValueError as e:
        return jsonify(error=str(e)), 400


@app.delete("/api/items/<coll>/<item_id>")
def api_delete(coll, item_id):
    if coll not in store.FIELDS:
        abort(404)
    store.delete_item(coll, item_id)
    return jsonify(ok=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=6000)
    ap.add_argument("--debug", action="store_true")
    a = ap.parse_args()
    app.run(host=a.host, port=a.port, debug=a.debug)
