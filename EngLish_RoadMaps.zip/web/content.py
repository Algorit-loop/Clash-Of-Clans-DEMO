"""Đọc và phân tích các file Markdown trong ../data thành cấu trúc để hiển thị.

Markdown trong data/ là nguồn nội dung duy nhất; file này chỉ đọc, không ghi.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import markdown as md_lib
from markupsafe import Markup

DATA_DIR = Path(__file__).resolve().parent.parent / "data"

# slug trang  ->  file nguồn
PAGES = {
    "home": "README.md",
    "lo-trinh": "01_lo_trinh_tong_quan.md",
    "ke-hoach": "02_ke_hoach_26_tuan.md",
    "ngu-phap": "03_ngu_phap_TOEIC.md",
    "tu-vung": "04_tu_vung.md",
    "listening": "05_chien_thuat_Listening.md",
    "reading": "06_chien_thuat_Reading.md",
    "phuong-phap": "07_phuong_phap_hoc.md",
    "tai-lieu": "08_tai_lieu.md",
    "tracker": "09_tracker.md",
}
FILE_TO_SLUG = {v: k for k, v in PAGES.items()}

HEADING_RE = re.compile(r"^(#{1,6})\s+(.*?)\s*$")


# ---------------------------------------------------------------- tiện ích
def read(slug: str) -> str:
    return (DATA_DIR / PAGES[slug]).read_text(encoding="utf-8")


def _rewrite_links(html: str) -> str:
    """Link tới file .md trong data/ -> route của web."""
    def repl(m):
        target = m.group(1)
        name = target.split("/")[-1]
        if name in FILE_TO_SLUG:
            slug = FILE_TO_SLUG[name]
            return f'href="{"/" if slug == "home" else "/" + slug}"'
        return m.group(0)

    html = re.sub(r'href="([^"]+\.md)"', repl, html)
    # link ra ngoài mở tab mới
    html = re.sub(r'<a href="(https?://[^"]+)"', r'<a href="\1" target="_blank" rel="noopener"', html)
    return html


LIST_LINE = re.compile(r"^\s*(?:[-*+]|\d+\.)\s+")


def _fix_lists(text: str) -> str:
    """Python-Markdown cần dòng trống trước danh sách; file .md viết kiểu GitHub thì không."""
    out, prev = [], ""
    for line in text.splitlines():
        if LIST_LINE.match(line) and prev.strip() and not LIST_LINE.match(prev) and not prev.startswith((" ", "\t", "|")):
            out.append("")
        out.append(line)
        prev = line
    return "\n".join(out)


def render(text: str) -> Markup:
    html = md_lib.markdown(_fix_lists(text), extensions=["tables", "fenced_code", "sane_lists"])
    html = html.replace("<table>", '<div class="table-wrap"><table>').replace("</table>", "</table></div>")
    return Markup(_rewrite_links(html))


def inline(text: str) -> Markup:
    html = md_lib.markdown(text.strip())
    html = re.sub(r"^<p>(.*)</p>$", r"\1", html, flags=re.S)
    return Markup(_rewrite_links(html))


def plain(text: str) -> str:
    """Bỏ ký hiệu markdown inline."""
    return re.sub(r"[*_`]", "", text).strip()


@dataclass
class Section:
    level: int
    title: str
    body: str = ""  # markdown ngay dưới heading, trước heading con
    children: list["Section"] = field(default_factory=list)

    @property
    def html(self) -> Markup:
        return render(self.body)

    @property
    def title_html(self) -> Markup:
        return inline(self.title)

    def find(self, prefix: str) -> "Section | None":
        for c in self.children:
            if plain(c.title).startswith(prefix):
                return c
        return None


def parse_sections(text: str) -> Section:
    """Dựng cây heading. Gốc (level 0) chứa tiêu đề H1 và phần mở đầu."""
    root = Section(0, "")
    stack = [root]
    buf: list[str] = []
    in_code = False

    def flush():
        while buf and buf[-1].strip() in ("", "---"):
            buf.pop()
        stack[-1].body = ("\n".join(buf)).strip("\n")
        buf.clear()

    for line in text.splitlines():
        if line.strip().startswith("```"):
            in_code = not in_code
        m = None if in_code else HEADING_RE.match(line)
        if m and len(m.group(1)) >= 1:
            level = len(m.group(1))
            if level == 1:
                flush()
                root.title = m.group(2)
                continue
            flush()
            while stack[-1].level >= level:
                stack.pop()
            sec = Section(level, m.group(2))
            stack[-1].children.append(sec)
            stack.append(sec)
        else:
            buf.append(line)
    flush()
    return root


def parse_table(text: str) -> list[list[str]]:
    """Bảng pipe đầu tiên trong đoạn markdown -> danh sách hàng (gồm header)."""
    rows = []
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("|"):
            cells = [c.strip() for c in s.strip("|").split("|")]
            if all(re.fullmatch(r":?-{3,}:?", c) for c in cells):
                continue
            rows.append(cells)
        elif rows:
            break
    return rows


def strip_table(text: str) -> str:
    return "\n".join(l for l in text.splitlines() if not l.strip().startswith("|")).strip()


def bullets(text: str) -> list[str]:
    return [l.strip()[2:] for l in text.splitlines() if l.startswith("- ")]


def _num(s: str) -> int | None:
    m = re.search(r"\d{3}", s)
    return int(m.group()) if m else None


# ---------------------------------------------------------------- 01 lộ trình
PHASE_RE = re.compile(r"Giai đoạn (\d) — (.+?) \(Tuần (\d+)–(\d+)\) · (?:mốc ~?|thi )(\d+)")


def roadmap() -> dict:
    root = parse_sections(read("lo-trinh"))
    structure = parse_table(root.find("Cấu trúc đề").body)
    parts, section = [], None
    for r in structure[1:]:
        section = r[0] or section
        n = re.search(r"\d+", r[3])
        parts.append({"section": section, "part": r[1], "desc": inline(r[2]),
                      "count": int(n.group()) if n else 0, "time": r[4]})

    score_sec = root.find("Điểm hiện tại")
    score_rows = parse_table(score_sec.body)
    scores = {}
    for r in score_rows[1:]:
        key = plain(r[0]).lower()
        scores[key] = {"now": _num(r[1]), "t800": _num(r[2]), "t900": _num(r[3]), "gain": plain(r[4])}
    score_notes = render(strip_table(score_sec.body))

    phases_sec = root.find("4 giai đoạn")
    phases = []
    for c in phases_sec.children:
        m = PHASE_RE.search(plain(c.title))
        if not m:
            continue
        phases.append({
            "n": int(m.group(1)), "name": m.group(2), "start": int(m.group(3)),
            "end": int(m.group(4)), "target": int(m.group(5)),
            "bullets": [inline(b) for b in bullets(c.body)],
        })

    ms_rows = parse_table(root.find("Mốc kiểm tra").body)
    milestones = []
    for r in ms_rows[1:]:
        milestones.append({"week": int(r[0]), "test": inline(r[1]), "target_text": plain(r[2]),
                           "target": _num(r[2]) if "/" not in r[2] else None, "fallback": inline(r[3])})

    exam = root.find("Thông tin kỳ thi")
    return {
        "title": root.title, "intro": render(root.body), "parts": parts, "scores": scores,
        "score_notes": score_notes, "phases": phases, "milestones": milestones,
        "exam_info": render(exam.body) if exam else "",
        "total_weeks": max((p["end"] for p in phases), default=26),
    }


# ---------------------------------------------------------------- 02 kế hoạch
WEEK_RE = re.compile(r"Tuần (\d+) — (.+)")
TASK_RE = re.compile(r"^\*\*(.+?):\*\*\s*(.*)$")


def plan() -> dict:
    root = parse_sections(read("ke-hoach"))
    schedule = []
    sched = root.find("Lịch học mỗi ngày")
    for c in sched.children:
        rows = parse_table(c.body)
        schedule.append({"title": plain(c.title), "header": rows[0] if rows else [],
                         "rows": [[inline(x) for x in r] for r in rows[1:]],
                         "note": render(strip_table(c.body))})

    phases, weeks = [], []
    for sec in root.children:
        m = re.match(r"Giai đoạn (\d) — (.+)", plain(sec.title))
        if not m:
            continue
        pn = int(m.group(1))
        ph = {"n": pn, "name": m.group(2), "intro": render(sec.body), "weeks": []}
        for wsec in sec.children:
            wm = WEEK_RE.match(plain(wsec.title))
            if not wm:
                continue
            wn = int(wm.group(1))
            tasks = []
            for i, b in enumerate(bullets(wsec.body)):
                tm = TASK_RE.match(b)
                label, text = (tm.group(1), tm.group(2)) if tm else ("", b)
                tasks.append({"id": f"w{wn}-{i}", "label": label, "html": inline(text)})
            target = next((t for t in tasks if t["label"].startswith("Mục tiêu") or t["label"] == "Kiểm tra cuối tuần"), None)
            week = {"n": wn, "title": wm.group(2), "phase": pn, "tasks": tasks,
                    "target": _num(plain(str(target["html"]))) if target else None}
            ph["weeks"].append(week)
            weeks.append(week)
        phases.append(ph)
    return {"title": root.title, "schedule": schedule, "phases": phases, "weeks": weeks}


# ---------------------------------------------------------------- 03 ngữ pháp
def grammar() -> dict:
    root = parse_sections(read("ngu-phap"))
    groups = []
    for sec in root.children:
        m = re.match(r"Nhóm ([A-Z]) — (.+)", plain(sec.title))
        if not m:
            continue
        topics = []
        for t in sec.children:
            tm = re.match(r"([A-Z]\d+)\.\s*(.+)", plain(t.title))
            code = tm.group(1) if tm else t.title
            topics.append({"id": f"g-{code}", "code": code,
                           "title": inline(tm.group(2) if tm else t.title), "html": t.html})
        groups.append({"key": m.group(1), "name": m.group(2), "topics": topics})
    return {"title": root.title, "intro": render(root.body), "groups": groups}


# ---------------------------------------------------------------- 04 từ vựng
def vocab() -> dict:
    root = parse_sections(read("tu-vung"))
    stages_sec = root.find("Tiến độ")
    stages = [{"weeks": r[0], "set": inline(r[1]), "pace": r[2], "total": inline(r[3])}
              for r in parse_table(stages_sec.body)[1:]]
    topics_sec = root.find("Chủ đề TOEIC")
    topics = []
    for line in topics_sec.body.splitlines():
        m = re.match(r"^(\d+)\.\s+(.+?)\s*\((.+)\)\s*$", line.strip())
        if m:
            topics.append({"id": f"v-topic-{m.group(1)}", "n": int(m.group(1)),
                           "name": m.group(2), "words": m.group(3)})
    others = [s for s in root.children if s not in (stages_sec, topics_sec)]
    return {"title": root.title, "intro": render(root.body), "stages": stages,
            "topics": topics, "sections": others}


# ---------------------------------------------------------------- 05/06 chiến thuật
def tactics(slug: str) -> dict:
    root = parse_sections(read(slug))
    targets = []
    m = re.search(r"\*\*Mục tiêu[^*]*\*\*\s*(.+)", root.body)
    if m:
        for part in m.group(1).split("·"):
            pm = re.match(r"\s*Part (\d+):\s*(\d+)/(\d+)", part)
            if pm:
                targets.append({"part": int(pm.group(1)), "need": int(pm.group(2)), "of": int(pm.group(3))})
    intro = re.sub(r"\*\*Mục tiêu[^\n]*\n?", "", root.body).strip()

    timing = []
    parts, others = [], []
    for sec in root.children:
        t = plain(sec.title)
        pm = re.match(r"Part (\d+) — (.+)", t)
        if pm:
            parts.append({"n": int(pm.group(1)), "name": pm.group(2), "sec": sec})
        elif t.startswith("Quản lý thời gian"):
            rows = parse_table(sec.body)
            for r in rows[1:]:
                mins = re.search(r"\d+", r[2])
                timing.append({"part": r[0], "count": r[1], "time": r[2], "pace": r[3],
                               "mins": int(mins.group()) if mins else 0})
            others.append({"sec": sec, "timing": True, "after": render(strip_table(sec.body))})
        else:
            others.append({"sec": sec, "timing": False})
    return {"title": root.title, "intro": render(intro), "targets": targets,
            "parts": parts, "others": others, "timing": timing}


# ---------------------------------------------------------------- 07/08 chung
def generic(slug: str) -> dict:
    root = parse_sections(read(slug))
    return {"title": root.title, "intro": render(root.body), "sections": root.children}


# ---------------------------------------------------------------- 09 tracker
def tracker() -> dict:
    root = parse_sections(read("tracker"))
    err = root.find("Sổ lỗi sai")
    types = []
    if err:
        m = re.search(r"Loại lỗi:(.+)", err.body)
        if m:
            for k, v in re.findall(r"\*\*(.+?)\*\*\s*=\s*([^·\n]+)", m.group(1)):
                types.append({"code": k, "name": v.strip().rstrip(".")})
    score_header = parse_table(root.find("Điểm đề full").body)[0]
    part_cols = []
    for h in score_header:
        pm = re.match(r"P(\d)\s*/(\d+)", h)
        if pm:
            part_cols.append({"p": int(pm.group(1)), "max": int(pm.group(2))})
    hours_sec = root.find("Giờ học")
    hm = re.search(r"≥\s*(\d+)\s*giờ", hours_sec.body) if hours_sec else None
    return {"title": root.title, "intro": render(root.body), "error_types": types,
            "part_cols": part_cols, "hours_goal": int(hm.group(1)) if hm else 27}


def home() -> dict:
    root = parse_sections(read("home"))
    principles = root.find("5 nguyên tắc")
    reality = root.find("Thực tế")
    return {
        "title": root.title, "intro": render(root.body),
        "reality": [inline(b) for b in bullets(reality.body)] if reality else [],
        "principles": [inline(re.sub(r"^\d+\.\s*", "", l.strip()))
                       for l in principles.body.splitlines() if re.match(r"^\d+\.", l.strip())] if principles else [],
    }
