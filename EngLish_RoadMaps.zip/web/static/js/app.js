/* zEnglish TOEIC — tương tác phía trình duyệt (không dùng thư viện ngoài) */
(function () {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------------- theme ---------------- */
  function applyTheme(mode) {
    const html = document.documentElement;
    if (mode === "light" || mode === "dark") html.dataset.theme = mode; else delete html.dataset.theme;
    try { localStorage.setItem("ze-theme", mode); } catch (e) {}
    $$("[data-theme-set]").forEach(b => b.classList.toggle("on", b.dataset.themeSet === mode));
  }
  let saved = "system";
  try { saved = localStorage.getItem("ze-theme") || "system"; } catch (e) {}
  $$("[data-theme-set]").forEach(b => {
    b.classList.toggle("on", b.dataset.themeSet === saved);
    b.addEventListener("click", () => applyTheme(b.dataset.themeSet));
  });

  /* ---------------- mobile nav ---------------- */
  $$("[data-nav-open]").forEach(b => b.addEventListener("click", () => document.body.classList.add("nav-open")));
  $$("[data-nav-close]").forEach(b => b.addEventListener("click", () => document.body.classList.remove("nav-open")));

  /* ---------------- toast ---------------- */
  let toastTimer;
  window.toast = function (msg) {
    const t = $("#toast"); t.textContent = msg; t.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("show"), 2200);
  };

  /* ---------------- animate when visible ---------------- */
  function activate(el) {
    if (el.dataset.w !== undefined) el.style.width = Math.max(0, Math.min(100, +el.dataset.w)) + "%";
    if (el.dataset.ring !== undefined) setRing(el, +el.dataset.ring);
    if (el.dataset.count !== undefined) countUp(el);
  }
  function setRing(circle, pct) {
    const c = +circle.dataset.c;
    circle.style.strokeDashoffset = c * (1 - Math.max(0, Math.min(100, pct)) / 100);
  }
  function countUp(el) {
    const end = +el.dataset.count, dur = reduce ? 0 : 1100, t0 = performance.now();
    if (!dur) { el.textContent = end; return; }
    const step = now => {
      const p = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(end * e);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }
  // phần tử có width 0 (thanh tiến độ) không bao giờ "giao" với viewport -> theo dõi phần tử cha
  const watch = new Map();
  const io = "IntersectionObserver" in window ? new IntersectionObserver(entries => {
    entries.forEach(en => {
      if (!en.isIntersecting) return;
      (watch.get(en.target) || []).forEach(el => {
        if (el.classList.contains("reveal")) el.classList.add("in");
        activate(el);
      });
      watch.delete(en.target);
      io.unobserve(en.target);
    });
  }, { threshold: 0.05 }) : null;

  function observeAll(root = document) {
    // stagger cho các phần tử reveal trong cùng một khối cha
    const groups = new Map();
    $$(".reveal", root).forEach(el => {
      const p = el.parentElement; const i = groups.get(p) || 0; groups.set(p, i + 1);
      if (!el.style.getPropertyValue("--d")) el.style.setProperty("--d", Math.min(i, 8) * 0.06 + "s");
    });
    $$(".reveal, [data-w], [data-ring], [data-count]", root).forEach(el => {
      if (!io) { el.classList.add("in"); activate(el); return; }
      const target = el.dataset.w !== undefined ? el.parentElement : (el.dataset.ring !== undefined ? el.closest(".ring") || el : el);
      if (!watch.has(target)) { watch.set(target, []); io.observe(target); }
      watch.get(target).push(el);
    });
  }
  window.observeAll = observeAll;

  /* ---------------- tabs ---------------- */
  $$("[data-tabs]").forEach(tabs => {
    const btns = $$("button[data-tab]", tabs);
    btns.forEach(b => b.addEventListener("click", () => {
      btns.forEach(x => { x.classList.toggle("on", x === b); x.setAttribute("aria-selected", x === b); });
      btns.forEach(x => { const p = document.getElementById(x.dataset.tab); if (p) p.hidden = x !== b; });
      const p = document.getElementById(b.dataset.tab); if (p) observeAll(p);
    }));
  });

  /* ---------------- API ---------------- */
  async function api(method, url, body) {
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || "Lỗi " + r.status);
    return data;
  }
  window.api = api;

  /* ---------------- checklist ---------------- */
  function groupStats(g) {
    const boxes = $$("input[data-check]").filter(i => (" " + i.dataset.group + " ").includes(" " + g + " "));
    return { done: boxes.filter(b => b.checked).length, total: boxes.length };
  }
  function refreshProgress(changedGroups) {
    $$("[data-progress]").forEach(el => {
      const g = el.dataset.progress;
      if (changedGroups && !changedGroups.includes(g)) return;
      const { done, total } = groupStats(g);
      const pct = total ? Math.round(100 * done / total) : 0;
      const bar = $("[data-w]", el); if (bar) { bar.dataset.w = pct; bar.style.width = pct + "%"; }
      const ring = $("[data-ring]", el); if (ring) { ring.dataset.ring = pct; setRing(ring, pct); }
      const rt = $("[data-ring-text]", el); if (rt) rt.textContent = pct + "%";
      $$("[data-progress-text]", el).forEach(t => t.textContent = t.dataset.progressText === "pct" ? pct + "%" : done + "/" + total);
      const host = el.closest("[data-complete-host]") || (el.matches("[data-complete-host]") ? el : null);
      if (host) host.classList.toggle("complete", total > 0 && done === total);
    });
  }
  $$("input[data-check]").forEach(inp => {
    inp.addEventListener("change", async () => {
      const groups = (inp.dataset.group || "").split(/\s+/).filter(Boolean);
      refreshProgress(groups);
      const host = inp.closest("details.acc[data-done-toggle]"); if (host) host.classList.toggle("done", inp.checked);
      if (inp.checked) {
        const g = groups[0]; const s = g && groupStats(g);
        if (s && s.total > 1 && s.done === s.total) { confetti(inp); toast("Hoàn thành! 🎉"); }
      }
      try { await api("POST", "/api/check", { id: inp.dataset.check, done: inp.checked }); }
      catch (e) { inp.checked = !inp.checked; refreshProgress(groups); toast("Không lưu được: " + e.message); }
    });
  });

  function confetti(anchor) {
    if (reduce) return;
    const r = anchor.closest("label, .check, details")?.getBoundingClientRect() || { left: innerWidth / 2, top: innerHeight / 2, width: 0 };
    const colors = ["#4b4ee8", "#7a5cf0", "#0e9a85", "#e0603a", "#f2b33d"];
    for (let i = 0; i < 26; i++) {
      const d = document.createElement("span"); d.className = "confetti";
      d.style.left = r.left + 30 + "px"; d.style.top = r.top + 10 + "px";
      d.style.background = colors[i % colors.length];
      d.style.setProperty("--x", (Math.random() * 240 - 120) + "px");
      d.style.setProperty("--y", (Math.random() * -160 - 20) + "px");
      d.style.setProperty("--r", (Math.random() * 540) + "deg");
      document.body.appendChild(d); setTimeout(() => d.remove(), 950);
    }
  }

  /* ---------------- forms -> collections ---------------- */
  $$("form[data-coll]").forEach(f => {
    f.addEventListener("submit", async e => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(f).entries());
      const msg = $(".form-msg", f); if (msg) msg.textContent = "";
      try {
        await api("POST", "/api/items/" + f.dataset.coll, body);
        sessionStorage.setItem("ze-toast", f.dataset.ok || "Đã lưu");
        location.reload();
      } catch (err) { if (msg) msg.textContent = err.message; else toast(err.message); }
    });
  });
  $$("[data-del]").forEach(b => b.addEventListener("click", async () => {
    if (!confirm("Xóa mục này?")) return;
    try {
      await api("DELETE", "/api/items/" + b.dataset.del);
      sessionStorage.setItem("ze-toast", "Đã xóa"); location.reload();
    } catch (e) { toast(e.message); }
  }));
  $$("form[data-settings]").forEach(f => {
    f.addEventListener("submit", async e => {
      e.preventDefault();
      try {
        await api("POST", "/api/settings", Object.fromEntries(new FormData(f).entries()));
        sessionStorage.setItem("ze-toast", "Đã lưu cài đặt"); location.reload();
      } catch (err) { toast(err.message); }
    });
  });
  try { const t = sessionStorage.getItem("ze-toast"); if (t) { sessionStorage.removeItem("ze-toast"); setTimeout(() => toast(t), 200); } } catch (e) {}

  /* ---------------- tooltip ---------------- */
  const tip = $("#tip");
  window.showTip = (html, x, y) => { tip.innerHTML = html; tip.style.left = x + 14 + "px"; tip.style.top = y - 10 + "px"; tip.classList.add("show"); };
  window.hideTip = () => tip.classList.remove("show");

  /* ---------------- score chart (SVG) ----------------
     data = { weeks: 26, targets: [[w, score]...], series: [{name, color, points:[[w, score, label]...]}] } */
  window.scoreChart = function (el, data) {
    const W = Math.max(320, Math.round(el.clientWidth || 760)), H = Math.round(Math.min(340, Math.max(220, W * 0.45))), m = { l: 44, r: 16, t: 18, b: 30 };
    const step = W < 560 ? 4 : 2;
    const yMin = data.yMin ?? 0, yMax = data.yMax ?? 990;
    const x = w => m.l + (w / data.weeks) * (W - m.l - m.r);
    const y = v => H - m.b - ((v - yMin) / (yMax - yMin)) * (H - m.t - m.b);
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`); svg.setAttribute("class", "chart"); svg.setAttribute("role", "img");
    svg.setAttribute("aria-label", data.label || "Biểu đồ điểm");
    const add = (tag, attrs, parent = svg) => { const e = document.createElementNS(ns, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); parent.appendChild(e); return e; };

    for (let v = Math.ceil(yMin / 100) * 100; v <= yMax; v += data.yStep || 200) {
      add("line", { x1: m.l, x2: W - m.r, y1: y(v), y2: y(v), class: "grid-line" });
      add("text", { x: m.l - 8, y: y(v) + 4, "text-anchor": "end", class: "axis-label" }).textContent = v;
    }
    for (let w = 0; w <= data.weeks; w += step) {
      add("text", { x: x(w), y: H - 12, "text-anchor": "middle", class: "axis-label" }).textContent = w === 0 ? "T0" : w;
    }
    const path = pts => pts.map((p, i) => (i ? "L" : "M") + x(p[0]).toFixed(1) + " " + y(p[1]).toFixed(1)).join(" ");
    (data.targetSets || (data.targets ? [data.targets] : [])).forEach(ts => {
      if (!ts.length) return;
      add("path", { d: path(ts), class: "target-line" });
      ts.forEach(p => {
        const c = add("circle", { cx: x(p[0]), cy: y(p[1]), r: 3.5, fill: "var(--muted)" });
        c.addEventListener("mousemove", e => showTip(`Mốc tuần ${p[0]}: <b>${p[1]}</b>`, e.clientX, e.clientY));
        c.addEventListener("mouseleave", hideTip);
      });
    });
    if (data.now !== undefined && data.now !== null) {
      add("line", { x1: x(data.now), x2: x(data.now), y1: m.t, y2: H - m.b, stroke: "var(--accent)", "stroke-width": 1.5, "stroke-dasharray": "2 4" });
      add("text", { x: x(data.now) + 6, y: m.t + 10, class: "axis-label", fill: "var(--accent)" }).textContent = "Hiện tại";
    }
    (data.series || []).forEach((s, si) => {
      if (!s.points.length) return;
      const pts = s.points.slice().sort((a, b) => a[0] - b[0]);
      if (s.area && pts.length > 1) {
        const d = path(pts) + ` L${x(pts[pts.length - 1][0])} ${y(yMin)} L${x(pts[0][0])} ${y(yMin)} Z`;
        add("path", { d, fill: s.color, class: "area" });
      }
      if (pts.length > 1) {
        const p = add("path", { d: path(pts), stroke: s.color, class: "series" + (reduce ? "" : " draw") });
        p.dataset.draw = "1"; // độ dài đường được đo sau khi gắn vào DOM
      }
      pts.forEach(pt => {
        const c = add("circle", { cx: x(pt[0]), cy: y(pt[1]), r: 5, fill: s.color, class: "pt" });
        c.addEventListener("mousemove", e => showTip(`${s.name} · tuần ${pt[0]}: <b>${pt[1]}</b>${pt[2] ? "<br>" + pt[2] : ""}`, e.clientX, e.clientY));
        c.addEventListener("mouseleave", hideTip);
      });
    });
    el.innerHTML = ""; el.appendChild(svg);
    $$("path[data-draw]", svg).forEach(p => { const L = p.getTotalLength(); p.style.setProperty("--len", L); });
  };

  observeAll();
})();
