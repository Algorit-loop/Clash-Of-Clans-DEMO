# WAO – Từ vựng & TOEIC

Mở `index.html` bằng trình duyệt (không cần server). Tiến độ lưu trong localStorage của trình duyệt.

- **Trang chủ**: mục tiêu mỗi ngày, chuỗi ngày học, lối tắt, từ của ngày.
- **Thư viện**: tìm kiếm Anh/Việt, lọc theo từ loại & trạng thái; bấm thẻ để xem chi tiết.
- **Flashcard**: thẻ lật, tự chấm Đúng / Sai (phím ← →, hoặc vuốt trên điện thoại), xem chi tiết (X).
- **TOEIC**: Part 5 (chọn dạng câu hỏi, chế độ Luyện tập hoặc Thi thử 30 giây/câu) và Part 6 (đoạn văn 4 chỗ trống, có câu chèn câu).
- **Tiến độ**: mức độ thuộc từ, độ chính xác theo dạng câu TOEIC, 14 ngày gần đây, sao lưu/nhập.

## Dữ liệu
Sửa file trong `data/`, sau đó chạy `node build.mjs` để sinh lại `data.js` (bộ build tự báo lỗi cú pháp, câu thiếu đáp án, lựa chọn trùng…).

### Từ vựng — `data/vocab/*.txt`
```
# word | /ipa/
fam: evaluation (n) nghĩa; evaluator (n) nghĩa
tip: Mẹo TOEIC
@v
1. nghĩa tiếng Việt | Câu ví dụ có *từ mục tiêu*. | Dịch tiếng Việt.
col: cụm từ = nghĩa; cụm khác = nghĩa
prep: cấu trúc/giới từ = nghĩa
syn: a, b
ant: c, d
use: ghi chú cách dùng
```
Từ loại: `n v adj adv prep conj pron det phr`.

### Part 5 — `data/toeic/part5-*.txt`
```
@ wordform
The software will ------- reduce costs.
- significant
+ significantly
- significance
- signify
= Giải thích
~ Bản dịch
```
Dạng: `wordform tense voice verbform agreement prep conj pron relative compare quant vocab`.

### Part 6 — `data/toeic/part6.txt`
Xem chú thích đầu file. Mỗi đoạn có 4 chỗ trống `[1]`–`[4]`, trong đó 1 câu dạng `sentence`.
