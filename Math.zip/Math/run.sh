#!/usr/bin/env bash
# Start MathVerse (everything lives in this folder)
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  python3 -m venv --without-pip .venv
  curl -sS https://bootstrap.pypa.io/get-pip.py -o .cache/get-pip.py && .venv/bin/python .cache/get-pip.py -q
fi
export PIP_CACHE_DIR="$PWD/.cache/pip"
.venv/bin/pip install -q -r requirements.txt
[ -f data/demo.json ] || cp data/demo.seed.json data/demo.json
exec .venv/bin/uvicorn app.main:app --host "${HOST:-0.0.0.0}" --port "${PORT:-8000}" ${RELOAD:+--reload}
