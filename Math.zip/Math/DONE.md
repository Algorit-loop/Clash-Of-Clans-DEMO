# MathVerse: Những gì đã làm

> Ngày 2026-11-05 · Yêu cầu gốc xem tại [requirement.md](requirement.md)

## Cách chạy

```bash
cd /home/worker/zFree/Math
./run.sh                 # mở http://127.0.0.1:8000
PORT=9000 ./run.sh       # đổi cổng
RELOAD=1 ./run.sh        # tự reload khi sửa code
```

| Tài khoản demo | Vai trò | Mật khẩu |
|---|---|---|
| `admin@mathverse.vn` | Quản trị viên | `123456` |
| `an@student.vn` | Học sinh THPT (đã có tiến độ, điểm thi, streak) | `123456` |
| `binh@uni.edu.vn` | Sinh viên | `123456` |
| `chi@student.vn` | Học sinh THCS | `123456` |

- Reset dữ liệu demo: `cp data/demo.seed.json data/demo.json` rồi khởi động lại server.
- Tạo lại toàn bộ demo (JSON + PDF + hình SVG): `.venv/bin/python scripts/build_demo.py`
- API docs (Swagger): `/docs`

## 1. Môi trường (tất cả nằm trong thư mục dự án)

| Hạng mục | Chi tiết |
|---|---|
| Python | `.venv` (Python 3.10). pip được bootstrap vào venv vì máy thiếu `python3-venv` |
| Cache | pip và npm cache nằm trong `.cache/`; không ghi gì ra ngoài thư mục |
| Thư viện backend | FastAPI, Uvicorn, Jinja2, python-multipart, itsdangerous (`requirements.txt`) |
| Thư viện dev | fpdf2 để sinh PDF tạp chí mẫu (`requirements-dev.txt`) |
| Thư viện frontend | KaTeX, marked, DOMPurify, canvas-confetti, tải về `app/static/vendor/`, **không dùng CDN** |
| Font | Be Vietnam Pro (UI), Lora (tạp chí), JetBrains Mono, đều self-host, hỗ trợ tiếng Việt |

## 2. Backend (FastAPI + Jinja2)

| File | Nội dung |
|---|---|
| `app/main.py` | Khởi tạo app, session cookie ký số, static, xử lý 401/403/404 |
| `app/store.py` | Đọc/ghi `data/demo.json` (có khóa luồng, ghi atomic), tính XP/streak/huy hiệu |
| `app/security.py` | Hash mật khẩu PBKDF2-SHA256 (200k vòng) |
| `app/i18n.py` | ~230 chuỗi giao diện song ngữ VI/EN |
| `app/deps.py` | Render template, user hiện tại, flash message, phân quyền |
| `app/routes/public.py` | Trang chủ, khóa học, đăng ký học, thanh toán giả lập, bài học, tạp chí, đăng nhập/đăng ký |
| `app/routes/learn.py` | Luyện tập, làm bài thi, kết quả, dashboard, JSON API (quiz, bài toán mỗi ngày, hoàn thành bài) |
| `app/routes/admin.py` | Toàn bộ trang quản trị + upload ảnh/PDF |

## 3. Tính năng

| # | Tính năng | Trạng thái |
|---|---|---|
| 1 | Đăng ký / đăng nhập thật (hash mật khẩu, session), vai trò học sinh / sinh viên / admin | ✅ |
| 2 | Danh sách khóa học: lọc theo cấp độ (THCS/THPT/ĐH), chủ đề, tìm kiếm | ✅ |
| 3 | Chi tiết khóa học: giới thiệu, giáo trình, giảng viên, giá, % giảm giá | ✅ |
| 4 | Khóa miễn phí → đăng ký ngay; khóa trả phí → **thanh toán giả lập** (Thẻ / MoMo / Chuyển khoản) | ✅ |
| 5 | Bài học: **video YouTube**, nội dung Markdown + LaTeX, **quiz cuối bài**, nút hoàn thành (+20 XP) | ✅ |
| 6 | Bài học "Học thử" mở cho mọi người; bài khác khóa đến khi đăng ký | ✅ |
| 7 | **Bài toán mỗi ngày**: tự đổi theo ngày, mỗi tài khoản trả lời 1 lần/ngày, +30 XP, có confetti | ✅ |
| 8 | **Thi thử kiểu THPT QG**: đồng hồ đếm ngược, bảng chọn câu, đánh dấu câu, tự nộp khi hết giờ, giữ bài khi lỡ F5 | ✅ |
| 9 | Kết quả thi: điểm thang 10 (vòng tròn animation), số câu đúng, thời gian, xem lại từng câu kèm lời giải | ✅ |
| 10 | Dashboard: XP, cấp độ, streak, số bài đã học, điểm TB, tiến độ khóa học, heatmap 12 tuần, 8 huy hiệu, lịch sử thi | ✅ |
| 11 | Tạp chí (khung cơ bản): trang bìa kiểu editorial, số mới nhất, kho lưu trữ, **đọc PDF trên web** và tải về | ✅ |
| 12 | Song ngữ **VI/EN** (nút chuyển, nhớ bằng cookie) | ✅ |
| 13 | **Dark/Light** (theo hệ điều hành mặc định, nút chuyển có hiệu ứng, không bị nháy khi tải trang) | ✅ |

## 4. Trang quản trị (`/admin`)

| Trang | Chức năng |
|---|---|
| Tổng quan | Thống kê người dùng / khóa học / câu hỏi / lượt thi / doanh thu giả lập, biểu đồ lượt đăng ký, lượt thi gần đây |
| Khóa học | Thêm/sửa/xóa khóa học (song ngữ, giá, màu, icon); thêm/sửa/xóa/sắp xếp bài học; gắn video và chọn câu quiz |
| **Ngân hàng câu hỏi** | Soạn bằng **Markdown + LaTeX** với **xem trước trực tiếp**; **chèn ảnh** (nút upload hoặc dán Ctrl+V); **mặc định 4 lựa chọn A–D, thêm/bớt tùy ý (2–10)**; chọn đáp án đúng; lời giải; chủ đề, mức độ (Nhận biết → Vận dụng cao), lớp; đánh dấu dùng làm bài toán mỗi ngày; lọc / tìm kiếm |
| **Bài kiểm tra** | Tạo đề bằng cách **chọn câu từ ngân hàng** (lọc theo chủ đề/mức độ/từ khóa), sắp xếp thứ tự, **chọn ngẫu nhiên N câu**, xem phân bố mức độ; đặt thời gian, cấp độ, công khai/nháp |
| Tạp chí | Upload PDF kèm tiêu đề, tóm tắt, số, ngày, màu bìa, ký hiệu; xóa số tạp chí |
| Người dùng | Danh sách, XP, streak, số khóa học; đổi vai trò |

## 5. Giao diện & animation

| Hiệu ứng | Ở đâu |
|---|---|
| Ký hiệu toán học trôi trên canvas, có parallax theo chuột | Hero trang chủ |
| Quỹ đạo ký hiệu xoay, khối π nổi, thẻ công thức KaTeX bay lơ lửng, blob gradient chuyển động | Hero |
| Chữ gradient chạy màu | Tiêu đề, logo |
| Số liệu đếm tăng dần | Thống kê, dashboard |
| Nút: ripple khi bấm, quét sáng khi hover, **magnetic** (nút hút theo con trỏ), mũi tên trượt | Toàn site |
| Thẻ **nghiêng 3D** và vệt sáng theo chuột | Thẻ khóa học, lộ trình, đề thi |
| Nội dung hiện dần khi cuộn, các phần tử con hiện so le | Toàn site |
| Thanh tiến độ và vòng tiến độ chạy | Khóa học, dashboard, kết quả thi |
| Trả lời đúng: nảy + confetti + "+XP" bay lên; trả lời sai: rung lắc | Quiz, bài toán mỗi ngày |
| Bìa tạp chí lật 3D khi hover | Tạp chí |
| Băng chuyền cảm nhận học viên (dừng khi hover) | Trang chủ |
| Toast thông báo, chuyển trang mượt, menu dropdown có animation | Toàn site |
| Lửa streak nhấp nháy, đồng hồ thi đỏ nhấp nháy khi còn 5 phút | Nav, trang thi |
| Tôn trọng `prefers-reduced-motion`; responsive tới 390px | Toàn site |

## 6. Dữ liệu demo (`data/demo.json`)

| Loại | Số lượng |
|---|---|
| Người dùng | 4 (1 admin, 2 học sinh, 1 sinh viên) |
| Giảng viên / Chủ đề | 4 / 5 |
| Khóa học / Bài học | 9 / 28 (2 THCS, 4 THPT, 3 Đại học; có khóa miễn phí và trả phí) |
| Câu hỏi | 46, có lời giải; có câu 2 lựa chọn (Đúng/Sai), câu 5 lựa chọn, câu có hình (SVG đồ thị, hình chóp) |
| Đề thi | 5 (đề thi thử THPT QG 30 câu/60 phút, các đề chuyên đề 15–20 phút, đề THCS, đề ĐH) |
| Tạp chí | 4 số, mỗi số là PDF tiếng Việt 4 trang sinh bằng `scripts/build_demo.py` |
| Khác | Đăng ký học, thanh toán, tiến độ, lượt thi, lịch sử bài toán mỗi ngày, 8 huy hiệu, 5 cảm nhận |

## 7. Kiểm thử đã chạy

| Kiểm tra | Kết quả |
|---|---|
| Tất cả trang công khai, trang học viên, 15 trang admin | HTTP 200 |
| Phân quyền: học viên vào `/admin` → 403; chưa đăng nhập → chuyển về `/login?next=…` | ✅ |
| Đăng ký mới, trùng email (400), sai mật khẩu (400) | ✅ |
| Đăng ký khóa miễn phí, khóa trả phí → checkout → mở bài học | ✅ |
| API quiz / bài toán mỗi ngày / hoàn thành bài, nộp bài thi và chấm điểm | ✅ |
| Admin: tạo câu hỏi 3 lựa chọn, tạo đề (lọc id trùng/không tồn tại), xóa câu thì tự gỡ khỏi đề | ✅ |
| Upload: ảnh hợp lệ được chấp nhận; file `.sh` bị từ chối; SVG bị chặn (tránh XSS); PDF kiểm tra header `%PDF` | ✅ |
| Chromium headless: chụp desktop (sáng/tối) + mobile 390px, **không có lỗi JS console** | ✅ |
| Đủ khóa dịch VI/EN cho mọi template | ✅ |

## 8. Hạn chế / gợi ý bước tiếp theo

| Mục | Ghi chú |
|---|---|
| Lưu trữ JSON | Phù hợp demo; khi có nhiều người dùng thật nên chuyển sang SQLite/PostgreSQL (lớp `store.py` đã tách riêng để dễ thay) |
| Thanh toán | Giả lập, chưa tích hợp VNPay/MoMo thật |
| CSRF | Đang dựa vào cookie `SameSite=Lax`; khi lên production nên thêm CSRF token cho form |
| Tạp chí | Mới có khung cơ bản (theo yêu cầu): chưa có tìm kiếm / phân chuyên mục nâng cao |
| Video | Nhúng YouTube nên cần internet; một số ID video demo lấy từ series 3Blue1Brown |
| Dev tool | `scripts/screenshot.mjs` dùng Chromium headless có sẵn trên máy để chụp màn hình và bắt lỗi JS |

## 9. Rà soát nội dung "nhựa" (2026-11-09)

| Bỏ / sửa | Lý do |
|---|---|
| Nhãn nhỏ lặp tiêu đề: "∑ Khóa học", "🧠 Luyện tập", "📝 Đề thi thử", "01 · Paths" … "05 · Community" | Trùng ý với tiêu đề ngay bên dưới |
| "Mỗi số là một file PDF để đọc online hoặc tải về", footer "Bản demo chạy trên dữ liệu demo.json", link "API docs" ở footer, "ISSN 0000-MATH" | Thông tin kỹ thuật / yêu cầu, không giúp người học |
| Đoạn "Bài viết minh họa trong bản demo…" trong các PDF tạp chí; mô tả đề "Có câu Đúng/Sai (2 lựa chọn)…" | Ghi chú kiểm thử lọt ra nội dung |
| "Chứng nhận hoàn thành", "Truy cập trọn đời", "3 video bài giảng" (sai) | Hứa tính năng không có → thay bằng số liệu thật tính từ dữ liệu (số bài, giờ, video, câu kiểm tra, bài học thử) |
| Badge "NEW · Nền tảng thế hệ mới", "— tất cả ở một nơi", "chỉ mất 30 giây", "hành trình Toán học", "Sẵn sàng chinh phục…", ★★★★★ trên mọi cảm nhận, dấu "+" sau số học viên, emoji gắn vào tiêu đề | Câu sáo rỗng kiểu template |
| Khối 3 tính năng "Học bằng cách làm / Thi thử như thật / Động lực mỗi ngày" | Lặp lại những gì trang đã thể hiện |
| Ruy-băng "BÀI TOÁN CỦA NGÀY" | Lặp tiêu đề ngay phía trên (đồng thời hết lỗi bị cắt chữ) |
| Tên số tạp chí in dưới bìa ở phần lưu trữ; số mới nhất xuất hiện 2 lần | Lặp nội dung đã có trên bìa / khối nổi bật |
| "Hôm nay bạn muốn học gì?" trên Dashboard | Thay bằng "Học tiếp: <bài kế tiếp> →" |
| Hai bộ lọc cùng tên "Tất cả" | Đổi thành "Mọi cấp độ" / "Mọi chủ đề"; dòng phụ thay bằng số khóa học tìm được |
| Nhãn tiếng Anh sót: "Card number", "MM/YY", "Activity"; công thức `e^{iπ}` hiện thô ở trang đăng nhập | Dịch / sửa hiển thị |

## 10. Bỏ "Bài toán của ngày", đổi "Luyện tập" → "Đề thi" (2026-11-09)

| Hạng mục | Đã làm |
|---|---|
| Giao diện | Xóa khỏi trang chủ, trang Đề thi, dashboard, footer; xóa `_daily.html`, CSS `.daily-card`/ruy-băng; nút hero đổi thành "Làm đề thi thử" |
| Backend | Xóa `daily_question`, `daily_state`, API `POST /api/daily/answer` (giờ trả 404), hằng `XP_DAILY`, luật huy hiệu "Giải đố" |
| Admin | Xóa ô "Dùng làm bài toán mỗi ngày" và nhãn "daily"; không còn lưu cờ `daily` |
| JS / i18n | Bỏ nhánh `daily` trong widget quiz; xóa các chuỗi `home.daily*`, `daily.answered`, `admin.daily` |
| Dữ liệu | Gỡ `daily_answers`, cờ `daily` trên câu hỏi, huy hiệu `daily_5` trực tiếp trong `demo.json` và `demo.seed.json` (không tạo lại file để giữ dữ liệu đang dùng); `build_demo.py` không còn sinh các trường này |
| Đổi tên | "Luyện tập" → "Đề thi" (EN: "Exams") ở menu, menu tài khoản, footer, tiêu đề trang; trang chỉ còn lưới đề thi |
| Giữ nguyên | Code cộng XP vẫn để dạng comment như yêu cầu trước |

## 11. Xóa "Tags" của khóa học (2026-11-09)

| Hạng mục | Đã làm |
|---|---|
| Lý do | Chip "# lớp 12", "# giải tích"… lặp lại nhãn cấp độ / chủ đề đã có; tìm kiếm đã khớp theo tên + mô tả ngắn |
| Xóa | Ô "Tags (comma)" trong admin, chip ở trang khóa học, khớp tags trong tìm kiếm, trường `tags` trong `demo.json`, `demo.seed.json` và `build_demo.py` |

## 12. Bố cục chiếm toàn bộ chiều ngang (2026-11-09)

| Hạng mục | Đã làm |
|---|---|
| `.container` | Bỏ giới hạn 1200px → rộng 100%, lề co giãn 16–48px |
| Lưới `.grid-3` / `.grid-4` | Số cột cố định theo màn hình (1→2→3, 1→2→4) để 3/6/9 thẻ luôn lấp kín hàng, không còn thẻ lẻ hay nửa hàng trống |
| Trang chủ | Tạp chí hiện 4 số trên lưới 4 cột |
| Trang Đề thi, Dashboard | Dùng lưới 3 cột; gợi ý khóa học tối đa 3 |

## 13. Xem trước Markdown, lề trang, danh sách câu hỏi (2026-11-09)

| Hạng mục | Đã làm |
|---|---|
| Xem trước | Mọi ô Markdown + LaTeX có khung "XEM TRƯỚC" có nhãn, cập nhật khi gõ: nội dung/lời giải câu hỏi, từng lựa chọn (có hàng tiêu đề), nội dung bài học, **giới thiệu khóa học (mới thêm)**; trên điện thoại khung xem trước của lựa chọn hiện dưới ô nhập thay vì bị ẩn |
| Lề trang | `.container` lề 16px → 6vw → tối đa 120px; sửa các bố cục (admin, bài học, thi, khóa học, tạp chí) từng ghi đè mất lề trái/phải |
| Danh sách câu hỏi | Ô tìm kiếm tối đa 360px; lựa chọn A/B/C/D thành lưới ô bằng nhau, căn giữa; "4 options" → "4 lựa chọn", "Lớp 13" → "Đại học", "📝 ×1" → "Dùng trong 1 đề" |
| Cache | CSS/JS kèm `?v=<mtime>` để trình duyệt/proxy luôn tải bản mới |
