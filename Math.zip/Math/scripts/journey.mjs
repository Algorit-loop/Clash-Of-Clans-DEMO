// Dev tool: drive a real headless Chromium like a user (click/type/submit) via CDP, log findings.
import { spawn } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";

const base = "http://127.0.0.1:8765", out = process.argv[2];
mkdirSync(out, { recursive: true });
const CHROME = `${process.env.HOME}/.cache/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell`;
const port = 9800 + Math.floor(Math.random() * 100);
const proc = spawn(CHROME, [`--remote-debugging-port=${port}`, "--no-sandbox", "--hide-scrollbars", `--user-data-dir=${out}/.p${port}`, "about:blank"], { stdio: "ignore" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let wsUrl;
for (let i = 0; i < 50 && !wsUrl; i++) { await sleep(200); try { wsUrl = (await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()).find((t) => t.type === "page")?.webSocketDebuggerUrl; } catch {} }
const ws = new WebSocket(wsUrl); await new Promise((r) => ws.addEventListener("open", r));
let id = 0; const pend = new Map(); let errs = [];
ws.addEventListener("message", (e) => { const m = JSON.parse(e.data);
  if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); }
  if (m.method === "Runtime.exceptionThrown") errs.push("EXC " + (m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text));
  if (m.method === "Log.entryAdded" && m.params.entry.level === "error" && !/youtube|favicon/.test(m.params.entry.url || "")) errs.push("LOG " + m.params.entry.text + " " + (m.params.entry.url || "")); });
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
for (const d of ["Runtime", "Log", "Page", "Network"]) await send(d + ".enable");
await send("Emulation.setDeviceMetricsOverride", { width: 1366, height: 900, deviceScaleFactor: 1, mobile: false });
const ev = async (expr) => { const r = await send("Runtime.evaluate", { expression: expr, awaitPromise: true, returnByValue: true }); return r.result?.result?.value; };
const go = async (p) => { await send("Page.navigate", { url: base + p }); await sleep(1500); };
const shot = async (n) => { const { result } = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: false }); writeFileSync(`${out}/${n}.png`, Buffer.from(result.data, "base64")); };
const click = (sel) => ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e)return 'NOT FOUND';e.click();return 'ok'})()`);
const type = (sel, v) => ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e)return 'NOT FOUND';e.value=${JSON.stringify(v)};e.dispatchEvent(new Event('input',{bubbles:true}));return 'ok'})()`);
const log = []; const note = (s) => { log.push(s); console.log(s); };
const flush = (label) => { if (errs.length) note(`  ⚠ JS errors @${label}: ${errs.join(" | ")}`); errs = []; };

// ---- 1. visitor
await go("/"); note("home title: " + await ev("document.title")); flush("home");
note("lang toggle EN: " + await click(".lang-switch a[href='/lang/en']")); await sleep(1500);
note("hero h1 in EN: " + await ev("document.querySelector('.hero h1').innerText.replace(/\\n/g,' ')"));
await click(".lang-switch a[href='/lang/vi']"); await sleep(1500);
note("theme toggle: " + await click("[data-theme-toggle]") + " -> " + await ev("document.documentElement.dataset.theme"));
await go("/"); note("theme persists after reload: " + await ev("document.documentElement.dataset.theme")); await click("[data-theme-toggle]");

// daily problem as anonymous
await go("/practice");
note("daily click wrong option (anon): " + await click("#daily .opt[data-i='3']")); await sleep(1200);
note("  feedback: " + await ev("document.querySelector('#daily .feedback').innerText.slice(0,100)"));
note("  toast: " + await ev("[...document.querySelectorAll('.toast')].map(t=>t.innerText).join(' / ')"));
note("anon opens exam: " + await ev("fetch('/exams/1',{redirect:'manual'}).then(r=>r.type+' '+r.status)"));
// locked lesson as anon
await go("/courses/mu-va-logarit/lessons/11"); note("anon opens locked lesson -> " + await ev("location.pathname"));
await go("/courses/mu-va-logarit/lessons/10"); note("anon opens preview lesson -> " + await ev("location.pathname + ' video=' + !!document.querySelector('.video iframe')"));
await shot("01-preview-lesson"); flush("lessons");

// ---- 2. register
await go("/register");
await type("[name=name]", "Phạm Học Sinh"); await type("[name=email]", "hs@test.vn"); await type("[name=password]", "abcdef");
await click("form[action='/register'] button.btn-primary"); await sleep(1800);
note("after register -> " + await ev("location.pathname") + " toast=" + await ev("[...document.querySelectorAll('.toast')].map(t=>t.innerText).join('/')"));
await shot("02-dashboard-new"); flush("register");

// ---- 3. enroll free, learn
await go("/courses/ham-so-va-do-thi-12"); note("detail CTA: " + await ev("document.querySelector('aside .btn-primary').innerText.trim()"));
await click("aside form button"); await sleep(1800); note("after enroll -> " + await ev("location.pathname"));
note("complete lesson: " + await click("#complete-btn")); await sleep(1200);
note("  btn: " + await ev("document.querySelector('#complete-btn').innerText.trim()") + " | xp pill: " + await ev("document.querySelector('[data-xp]').innerText") + " | progress: " + await ev("document.querySelector('#progress-label').innerText"));
note("quiz: wrong then right"); await click(".quiz .opt[data-i='1']"); await sleep(900);
note("  wrong fb: " + await ev("document.querySelector('.quiz .feedback').innerText"));
await click(".quiz .opt[data-i='0']"); await sleep(1200);
note("  right fb: " + await ev("document.querySelector('.quiz .feedback').innerText.slice(0,60)") + " | solved=" + await ev("document.querySelector('.quiz').classList.contains('solved')"));
await shot("03-lesson-quiz"); flush("lesson");

// ---- 4. paid course
await go("/courses/mu-va-logarit"); await click("aside a.btn-primary"); await sleep(1500);
note("buy -> " + await ev("location.pathname")); await click("input[value=momo]"); await sleep(300); await shot("04-checkout");
await click("#pay-btn"); await sleep(2200); note("after pay -> " + await ev("location.pathname")); flush("checkout");

// ---- 5. exam
await go("/practice"); await click("#exams a.btn-primary"); await sleep(1500);
note("exam page: " + await ev("location.pathname + ' qs=' + document.querySelectorAll('.q-card').length + ' timer=' + document.querySelector('#timer').innerText"));
await ev("document.querySelectorAll('.q-card').forEach((c,i)=>{ if(i<4) c.querySelector('.opt[data-i=\"0\"]').click() })"); await sleep(300);
note("answered count: " + await ev("document.querySelector('#answered-count').innerText"));
await click(".q-card .flag-btn"); await shot("05-exam");
// reload mid-exam: state kept?
await send("Page.reload"); await sleep(1800); note("after reload answered: " + await ev("document.querySelector('#answered-count').innerText"));
// confirm() dialogs auto-accept
ws.addEventListener("message", (e) => { const m = JSON.parse(e.data); if (m.method === "Page.javascriptDialogOpening") send("Page.handleJavaScriptDialog", { accept: true }); });
await click("#submit-btn"); await sleep(2500);
note("after submit -> " + await ev("location.pathname + ' score=' + document.querySelector('.score-ring b').innerText"));
await shot("06-result"); flush("exam");

// ---- 6. dashboard + logout
await go("/dashboard"); note("dashboard tiles: " + await ev("[...document.querySelectorAll('.tile')].map(t=>t.innerText.replace(/\\n/g,' ')).join(' | ')"));
note("badges: " + await ev("[...document.querySelectorAll('.badge-item:not(.off)')].map(b=>b.innerText.trim()).join(', ')")); await shot("07-dashboard");
note("student->/admin: " + await ev("fetch('/admin').then(r=>r.status)")); flush("dash");
await ev("fetch('/logout',{method:'POST'})"); await sleep(500);

// ---- 7. admin
await go("/login"); await click("[data-demo='admin@mathverse.vn']"); await sleep(2000); note("admin login -> " + await ev("location.pathname"));
await go("/admin/questions/0");
await type("[name=topic]", "Kiểm thử"); await type("[name=content]", "Tính $\\int_0^1 x\\,dx$"); await sleep(500);
note("live preview rendered katex: " + await ev("!!document.querySelector('[data-md-preview] .katex')"));
note("default option rows: " + await ev("document.querySelectorAll('.opt-row').length"));
await click("#add-opt"); note("after + : " + await ev("document.querySelectorAll('.opt-row').length"));
await ev("document.querySelectorAll('[name=options]').forEach((t,i)=>{t.value=['1/2','1','2','0','3'][i];t.dispatchEvent(new Event('input'))})");
await click(".opt-row:nth-child(1) input[type=radio]"); await shot("08-admin-question");
await click("#q-form button.btn-primary"); await sleep(1500); note("saved question -> " + await ev("location.pathname + ' first card: ' + document.querySelector('.card[data-reveal]')?.innerText.slice(0,60).replace(/\\n/g,' ')"));
await go("/admin/exams/0"); note("exam builder: bank items=" + await ev("document.querySelectorAll('#pk-bank .pick-item').length"));
await ev("document.querySelectorAll('#pk-bank .pick-item')[0].click();document.querySelectorAll('#pk-bank .pick-item')[1].click()"); await click("#pk-random"); await sleep(300);
note("selected count after 2 clicks + random 10: " + await ev("document.querySelector('#pk-count').innerText")); await shot("09-admin-exam");
await go("/admin"); await shot("10-admin-home"); flush("admin");
console.log("\nTOTAL JS ERRORS: " + errs.length);
ws.close(); proc.kill(); process.exit(0);
