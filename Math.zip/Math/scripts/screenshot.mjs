// Dev tool: screenshot pages + collect JS console errors via Chrome DevTools Protocol (no npm deps).
// usage: node scripts/screenshot.mjs <baseUrl> <outDir> [email] [theme] [width] path1 path2 ...
import { spawn } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";

const [base, out, email, theme = "light", width = "1366", ...paths] = process.argv.slice(2);
const CHROME = process.env.CHROME || `${process.env.HOME}/.cache/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell`;
mkdirSync(out, { recursive: true });
const port = 9300 + Math.floor(Math.random() * 500);
const proc = spawn(CHROME, [`--remote-debugging-port=${port}`, "--no-sandbox", "--hide-scrollbars", `--user-data-dir=${out}/.profile-${port}`, "about:blank"], { stdio: "ignore" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let wsUrl;
for (let i = 0; i < 50 && !wsUrl; i++) {
  await sleep(200);
  try { wsUrl = (await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()).find((t) => t.type === "page")?.webSocketDebuggerUrl; } catch {}
}
const ws = new WebSocket(wsUrl);
await new Promise((r) => ws.addEventListener("open", r));
let id = 0; const pending = new Map(); const errors = [];
ws.addEventListener("message", (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
  if (m.method === "Runtime.exceptionThrown") errors.push(m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text);
  if (m.method === "Runtime.consoleAPICalled" && m.params.type === "error") errors.push(m.params.args.map((a) => a.value ?? a.description).join(" "));
  if (m.method === "Log.entryAdded" && m.params.entry.level === "error" && !/youtube|favicon/.test(m.params.entry.url || "")) errors.push(`${m.params.entry.text} ${m.params.entry.url || ""}`);
});
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
await send("Runtime.enable"); await send("Log.enable"); await send("Page.enable"); await send("Network.enable");
const w = +width, mobile = w < 600;
await send("Emulation.setDeviceMetricsOverride", { width: w, height: mobile ? 844 : 900, deviceScaleFactor: 1, mobile });
await send("Emulation.setEmulatedMedia", { features: [{ name: "prefers-color-scheme", value: theme }] });

async function go(url) { await send("Page.navigate", { url }); await sleep(1800); }
if (email) {
  await go(`${base}/login`);
  await send("Runtime.evaluate", { expression: `document.querySelector('[name=email]').value='${email}';document.querySelector('[name=password]').value='123456';document.querySelector('#login-form').submit()` });
  await sleep(1500);
}
const report = {};
for (const p of paths) {
  errors.length = 0;
  await go(base + p);
  // scroll through the page so reveal-on-scroll animations fire, then back to top
  await send("Runtime.evaluate", { expression: "(async()=>{for(let y=0;y<document.body.scrollHeight;y+=500){window.scrollTo({top:y,behavior:'instant'});await new Promise(r=>setTimeout(r,60))}window.scrollTo({top:0,behavior:'instant'})})()", awaitPromise: true });
  await sleep(1200);
  const { result } = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: true });
  const name = (p.replace(/[^a-z0-9]+/gi, "_").replace(/^_|_$/g, "") || "home") + `-${theme}-${w}.png`;
  writeFileSync(`${out}/${name}`, Buffer.from(result.data, "base64"));
  report[p] = [...errors];
}
console.log(JSON.stringify(report, null, 1));
ws.close(); proc.kill();
process.exit(0);
