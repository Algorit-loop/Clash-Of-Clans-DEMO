"""Generate data/demo.json (+ demo.seed.json) and the sample magazine PDFs.

    .venv/bin/python scripts/build_demo.py

Re-running overwrites demo.json with fresh demo data (dates relative to today).
"""
from __future__ import annotations

import json
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from app.security import hash_password  # noqa: E402

TODAY = date.today()


def d(days_ago: int, hour: int = 20) -> str:
    return datetime.combine(TODAY - timedelta(days=days_ago), datetime.min.time()).replace(hour=hour).isoformat()


def vi_en(vi: str, en: str) -> dict:
    return {"vi": vi, "en": en}


# ----------------------------------------------------------------------------------------------
# Question bank — THPT national-exam style (+ THCS and university). answer = 0-based index.
# ----------------------------------------------------------------------------------------------
Q = []


def q(topic, diff, grade, content, options, answer, explanation):
    Q.append({"id": len(Q) + 1, "topic": topic, "difficulty": diff, "grade": grade, "content": content,
              "options": options, "answer": answer, "explanation": explanation,
              "created_at": d(60)})


# Hàm số
q("Hàm số", 1, 12, "Cho hàm số $y = x^3 - 3x + 2$ có đồ thị như hình bên.\n\n![Đồ thị hàm số](/static/uploads/images/demo-cubic.svg)\n\nHàm số đạt **cực đại** tại điểm nào?",
  ["$x = -1$", "$x = 1$", "$x = 0$", "$x = 2$"], 0,
  "$y' = 3x^2 - 3 = 0 \\Leftrightarrow x = \\pm 1$. Vì $y'' = 6x$ và $y''(-1) = -6 < 0$ nên hàm số đạt cực đại tại $x = -1$.")
q("Hàm số", 1, 12, "Đường tiệm cận đứng của đồ thị hàm số $y = \\dfrac{2x+1}{x-1}$ là",
  ["$x = 2$", "$x = 1$", "$y = 2$", "$x = -1$"], 1,
  "Mẫu bằng $0$ khi $x = 1$ và tử khác $0$ tại đó, nên $x = 1$ là tiệm cận đứng. ($y = 2$ là tiệm cận **ngang**.)")
q("Hàm số", 2, 12, "Số giao điểm của đồ thị hàm số $y = x^3 - 3x$ với trục hoành là",
  ["$1$", "$2$", "$3$", "$0$"], 2,
  "$x^3 - 3x = 0 \\Leftrightarrow x(x^2 - 3) = 0 \\Leftrightarrow x \\in \\{0; \\pm\\sqrt3\\}$ — có **3** giao điểm.")
q("Hàm số", 2, 12, "Giá trị lớn nhất của hàm số $f(x) = x^3 - 3x^2 + 1$ trên đoạn $[-1; 2]$ bằng",
  ["$1$", "$-3$", "$3$", "$5$"], 0,
  "$f'(x) = 3x^2 - 6x = 0 \\Leftrightarrow x = 0$ hoặc $x = 2$.\n\n$f(-1) = -3,\\; f(0) = 1,\\; f(2) = -3$. Vậy $\\max f = 1$.")
q("Hàm số", 3, 12, "Tìm $m$ để hàm số $y = x^3 - 3mx^2 + 3(m^2 - 1)x$ đạt **cực tiểu** tại $x = 2$.",
  ["$m = 1$", "$m = 3$", "$m = 1$ hoặc $m = 3$", "$m = 2$"], 0,
  "$y'(2) = 3m^2 - 12m + 9 = 0 \\Leftrightarrow m \\in \\{1; 3\\}$.\n\n$y''(2) = 12 - 6m > 0 \\Leftrightarrow m < 2$. Vậy $m = 1$.")
q("Hàm số", 2, 12, "Hàm số $y = -x^4 + 2x^2 + 1$ đồng biến trên khoảng nào dưới đây?",
  ["$(-\\infty; -1)$", "$(-1; 0)$", "$(1; +\\infty)$", "$(-1; 1)$"], 0,
  "$y' = -4x^3 + 4x = -4x(x-1)(x+1)$. Lập bảng xét dấu: $y' > 0$ trên $(-\\infty;-1)$ và $(0;1)$.")
# Mũ - logarit
q("Mũ – Logarit", 1, 12, "Giá trị của $\\log_2 8$ là", ["$2$", "$3$", "$4$", "$8$"], 1, "$2^3 = 8 \\Rightarrow \\log_2 8 = 3$.")
q("Mũ – Logarit", 1, 12, "Nghiệm của phương trình $2^{x-1} = 8$ là", ["$x = 3$", "$x = 4$", "$x = 2$", "$x = 5$"], 1,
  "$2^{x-1} = 2^3 \\Leftrightarrow x - 1 = 3 \\Leftrightarrow x = 4$.")
q("Mũ – Logarit", 2, 12, "Tập nghiệm của bất phương trình $\\log_{\\frac12}(x - 1) > -1$ là",
  ["$(1; 3)$", "$(3; +\\infty)$", "$(-\\infty; 3)$", "$(1; +\\infty)$"], 0,
  "Điều kiện $x > 1$. Vì cơ số $\\tfrac12 < 1$ nên bất phương trình $\\Leftrightarrow x - 1 < 2 \\Leftrightarrow x < 3$. Kết hợp: $1 < x < 3$.")
q("Mũ – Logarit", 2, 12, "Đạo hàm của hàm số $y = \\ln(x^2 + 1)$ là",
  ["$\\dfrac{2x}{x^2+1}$", "$\\dfrac{1}{x^2+1}$", "$\\dfrac{2x}{\\ln(x^2+1)}$", "$2x\\ln(x^2+1)$"], 0,
  "$(\\ln u)' = \\dfrac{u'}{u}$ với $u = x^2 + 1$, $u' = 2x$.")
q("Mũ – Logarit", 3, 12, "Ông A gửi $100$ triệu đồng vào ngân hàng với lãi suất $6\\%$/năm theo hình thức **lãi kép**. Sau $2$ năm ông A nhận được bao nhiêu (cả gốc lẫn lãi)?",
  ["$112{,}36$ triệu", "$112$ triệu", "$106$ triệu", "$112{,}6$ triệu"], 0,
  "$T = 100(1 + 0{,}06)^2 = 112{,}36$ (triệu đồng).")
# Tích phân
q("Tích phân", 1, 12, "Tính $\\displaystyle\\int_0^1 2x\\,dx$.", ["$1$", "$2$", "$\\tfrac12$", "$0$"], 0, "$\\displaystyle\\int_0^1 2x\\,dx = x^2\\Big|_0^1 = 1$.")
q("Tích phân", 1, 12, "Họ nguyên hàm của hàm số $f(x) = \\cos x$ là",
  ["$\\sin x + C$", "$-\\sin x + C$", "$\\cos x + C$", "$-\\cos x + C$"], 0, "$(\\sin x)' = \\cos x$.")
q("Tích phân", 2, 12, "Tính $I = \\displaystyle\\int_1^e \\frac{\\ln x}{x}\\,dx$.", ["$\\tfrac12$", "$1$", "$e$", "$2$"], 0,
  "Đặt $t = \\ln x \\Rightarrow dt = \\dfrac{dx}{x}$. $I = \\displaystyle\\int_0^1 t\\,dt = \\tfrac12$.")
q("Tích phân", 2, 12, "Diện tích hình phẳng giới hạn bởi hai đồ thị $y = x^2$ và $y = x$ bằng",
  ["$\\tfrac16$", "$\\tfrac13$", "$\\tfrac12$", "$\\tfrac56$"], 0,
  "Hoành độ giao điểm: $x = 0, x = 1$. $S = \\displaystyle\\int_0^1 (x - x^2)\\,dx = \\tfrac12 - \\tfrac13 = \\tfrac16$.")
q("Tích phân", 3, 12, "Thể tích khối tròn xoay tạo thành khi quay hình phẳng giới hạn bởi $y = \\sqrt{x}$, $y = 0$, $x = 4$ quanh trục $Ox$ là",
  ["$8\\pi$", "$16\\pi$", "$4\\pi$", "$\\tfrac{32\\pi}{3}$"], 0, "$V = \\pi\\displaystyle\\int_0^4 x\\,dx = \\pi\\cdot\\frac{x^2}{2}\\Big|_0^4 = 8\\pi$.")
q("Tích phân", 3, 12, "Tính $\\displaystyle\\int_0^{\\pi/2} x\\cos x\\,dx$.",
  ["$\\tfrac{\\pi}{2} - 1$", "$\\tfrac{\\pi}{2} + 1$", "$1$", "$\\tfrac{\\pi}{2}$"], 0,
  "Từng phần: $u = x, dv = \\cos x\\,dx$. Kết quả $\\big[x\\sin x + \\cos x\\big]_0^{\\pi/2} = \\tfrac{\\pi}{2} - 1$.")
# Số phức
q("Số phức", 1, 12, "Số phức liên hợp của $z = 3 - 4i$ là", ["$3 + 4i$", "$-3 + 4i$", "$-3 - 4i$", "$4 - 3i$"], 0, "$\\overline{a + bi} = a - bi$.")
q("Số phức", 1, 12, "Mô-đun của số phức $z = 3 + 4i$ bằng", ["$5$", "$7$", "$25$", "$\\sqrt7$"], 0, "$|z| = \\sqrt{3^2 + 4^2} = 5$.")
q("Số phức", 2, 12, "Số phức $(1 + i)^2$ bằng", ["$2i$", "$2$", "$0$", "$1 + 2i$"], 0, "$(1+i)^2 = 1 + 2i + i^2 = 2i$.")
q("Số phức", 2, 12, "Nghiệm phức của phương trình $z^2 + 2z + 5 = 0$ là",
  ["$-1 \\pm 2i$", "$1 \\pm 2i$", "$-1 \\pm 4i$", "$-2 \\pm i$"], 0, "$\\Delta' = 1 - 5 = -4 = (2i)^2 \\Rightarrow z = -1 \\pm 2i$.")
# Hình học không gian
q("Hình học không gian", 1, 12, "Thể tích khối lập phương cạnh $a$ là", ["$a^3$", "$3a$", "$a^2$", "$\\tfrac{a^3}{3}$"], 0, "$V = a \\cdot a \\cdot a = a^3$.")
q("Hình học không gian", 1, 12, "Thể tích khối chóp có diện tích đáy $B$ và chiều cao $h$ là",
  ["$\\tfrac13 Bh$", "$Bh$", "$\\tfrac12 Bh$", "$3Bh$"], 0, "Công thức: $V = \\tfrac13 Bh$.")
q("Hình học không gian", 3, 12, "Cho hình chóp $S.ABCD$ có đáy là hình vuông cạnh $a$, $SA \\perp (ABCD)$ và $SA = a\\sqrt2$.\n\n![Hình chóp](/static/uploads/images/demo-pyramid.svg)\n\nGóc giữa đường thẳng $SC$ và mặt phẳng đáy bằng",
  ["$45^\\circ$", "$30^\\circ$", "$60^\\circ$", "$90^\\circ$"], 0,
  "Góc cần tìm là $\\widehat{SCA}$. $AC = a\\sqrt2$, $\\tan\\widehat{SCA} = \\dfrac{SA}{AC} = 1 \\Rightarrow 45^\\circ$.")
q("Hình học không gian", 3, 12, "Bán kính mặt cầu ngoại tiếp hình lập phương cạnh $a$ là",
  ["$\\tfrac{a\\sqrt3}{2}$", "$a\\sqrt3$", "$\\tfrac{a\\sqrt2}{2}$", "$\\tfrac{a}{2}$"], 0, "Tâm là giao các đường chéo; $R = \\tfrac12 \\cdot a\\sqrt3$.")
# Tổ hợp – xác suất
q("Tổ hợp – Xác suất", 1, 11, "Gieo một con súc sắc cân đối một lần. Xác suất xuất hiện mặt có số chấm **chẵn** là",
  ["$\\tfrac12$", "$\\tfrac13$", "$\\tfrac16$", "$\\tfrac23$"], 0, "Có 3 mặt chẵn trên 6 mặt: $P = \\tfrac36 = \\tfrac12$.")
q("Tổ hợp – Xác suất", 1, 11, "Số cách chọn $2$ học sinh từ một nhóm $10$ học sinh là", ["$45$", "$90$", "$20$", "$100$"], 0, "$C_{10}^2 = \\dfrac{10\\cdot 9}{2} = 45$.")
q("Tổ hợp – Xác suất", 3, 11, "Một hộp có $5$ bi đỏ và $3$ bi xanh. Lấy ngẫu nhiên $2$ bi. Xác suất để $2$ bi **cùng màu** là",
  ["$\\tfrac{13}{28}$", "$\\tfrac{15}{28}$", "$\\tfrac{5}{14}$", "$\\tfrac{3}{28}$"], 0,
  "$P = \\dfrac{C_5^2 + C_3^2}{C_8^2} = \\dfrac{10 + 3}{28} = \\dfrac{13}{28}$.")
q("Tổ hợp – Xác suất", 2, 11, "Từ các chữ số $1, 2, 3, 4, 5$ lập được bao nhiêu số tự nhiên có $3$ chữ số **đôi một khác nhau**?",
  ["$60$", "$125$", "$10$", "$120$"], 0, "$A_5^3 = 5 \\cdot 4 \\cdot 3 = 60$.")
# Dãy số
q("Dãy số – Cấp số", 1, 11, "Cấp số cộng $(u_n)$ có $u_1 = 2$, công sai $d = 3$. Số hạng $u_{10}$ bằng", ["$29$", "$32$", "$30$", "$27$"], 0, "$u_{10} = u_1 + 9d = 2 + 27 = 29$.")
q("Dãy số – Cấp số", 2, 11, "Cấp số nhân $(u_n)$ có $u_1 = 3$, công bội $q = 2$. Tổng $5$ số hạng đầu $S_5$ bằng", ["$93$", "$96$", "$48$", "$45$"], 0,
  "$S_5 = u_1\\dfrac{q^5 - 1}{q - 1} = 3 \\cdot 31 = 93$.")
# Variable number of options
q("Giới hạn – Liên tục", 2, 11, "**Đúng hay sai?** Mọi hàm số liên tục trên đoạn $[a; b]$ đều đạt giá trị lớn nhất và giá trị nhỏ nhất trên đoạn đó.",
  ["Đúng", "Sai"], 0, "Đây là **định lý Weierstrass**.")
q("Giới hạn – Liên tục", 2, 11, "Tính $\\displaystyle\\lim_{x \\to 0} \\frac{\\sin 3x}{x}$.", ["$0$", "$1$", "$3$", "$\\tfrac13$", "$+\\infty$"], 2,
  "$\\dfrac{\\sin 3x}{x} = 3 \\cdot \\dfrac{\\sin 3x}{3x} \\to 3 \\cdot 1 = 3$.")
# THCS
q("Đại số THCS", 1, 8, "Khai triển $(a + b)^2$ ta được", ["$a^2 + 2ab + b^2$", "$a^2 + b^2$", "$a^2 - 2ab + b^2$", "$a^2 + ab + b^2$"], 0, "Hằng đẳng thức đáng nhớ số 1.")
q("Đại số THCS", 1, 8, "Phân tích đa thức $x^2 - 9$ thành nhân tử", ["$(x - 3)(x + 3)$", "$(x - 3)^2$", "$(x - 9)(x + 1)$", "$(x + 3)^2$"], 0, "Hiệu hai bình phương: $A^2 - B^2 = (A - B)(A + B)$.")
q("Hình học THCS", 1, 8, "Một tam giác vuông có hai cạnh góc vuông dài $6$ cm và $8$ cm. Độ dài cạnh huyền là", ["$10$ cm", "$14$ cm", "$12$ cm", "$7$ cm"], 0,
  "Định lý Pythagore: $\\sqrt{6^2 + 8^2} = \\sqrt{100} = 10$.")
q("Đại số THCS", 1, 7, "Giá trị của $x$ thỏa mãn $2x + 5 = 11$ là", ["$3$", "$8$", "$-3$", "$6$"], 0, "$2x = 6 \\Rightarrow x = 3$.")
q("Hình học THCS", 2, 9, "Góc nội tiếp chắn nửa đường tròn có số đo bằng", ["$90^\\circ$", "$180^\\circ$", "$45^\\circ$", "$60^\\circ$"], 0, "Góc nội tiếp bằng nửa số đo cung bị chắn: $\\tfrac{180^\\circ}{2} = 90^\\circ$.")
q("Đại số THCS", 2, 8, "Đẳng thức nào sau đây **đúng**?", ["$x^3 - 8 = (x - 2)(x^2 + 2x + 4)$", "$x^3 - 8 = (x - 2)^3$", "$x^3 - 8 = (x - 2)(x^2 - 2x + 4)$", "$x^3 - 8 = (x + 2)(x^2 - 2x + 4)$"], 0,
  "Hiệu hai lập phương: $A^3 - B^3 = (A - B)(A^2 + AB + B^2)$.")
# University
q("Giải tích 1", 1, 13, "Đạo hàm của $f(x) = e^{x^2}$ là", ["$2x\\,e^{x^2}$", "$e^{x^2}$", "$x^2 e^{x^2 - 1}$", "$2e^{x^2}$"], 0, "Quy tắc dây chuyền: $(e^u)' = u' e^u$.")
q("Giải tích 1", 1, 13, "$\\displaystyle\\lim_{n \\to \\infty}\\left(1 + \\frac1n\\right)^n$ bằng", ["$e$", "$1$", "$+\\infty$", "$0$"], 0, "Đây là định nghĩa của số $e \\approx 2{,}71828$.")
q("Đại số tuyến tính", 1, 13, "Tính định thức $\\begin{vmatrix} 1 & 2 \\\\ 3 & 4 \\end{vmatrix}$.", ["$-2$", "$2$", "$10$", "$-10$"], 0, "$1 \\cdot 4 - 2 \\cdot 3 = -2$.")
q("Đại số tuyến tính", 2, 13, "Hạng của ma trận $A = \\begin{pmatrix} 1 & 2 \\\\ 2 & 4 \\end{pmatrix}$ là", ["$1$", "$2$", "$0$", "$4$"], 0, "Hàng 2 bằng 2 lần hàng 1, nên $\\operatorname{rank} A = 1$.")
q("Giải tích 1", 3, 13, "Tổng của chuỗi $\\displaystyle\\sum_{n=1}^{\\infty} \\frac{1}{n^2}$ bằng", ["$\\dfrac{\\pi^2}{6}$", "$1$", "Chuỗi phân kỳ", "$\\dfrac{\\pi}{4}$"], 0,
  "Bài toán Basel, được Euler giải năm 1734.")
q("Đại số tuyến tính", 2, 13, "Các trị riêng của ma trận $\\begin{pmatrix} 2 & 0 \\\\ 0 & 3 \\end{pmatrix}$ là", ["$2$ và $3$", "$5$", "$6$", "$0$ và $5$"], 0, "Ma trận đường chéo có trị riêng là các phần tử trên đường chéo.")
q("Xác suất thống kê", 2, 13, "Biến ngẫu nhiên $X \\sim B(10;\\, 0{,}5)$. Kỳ vọng $E(X)$ bằng", ["$5$", "$2{,}5$", "$10$", "$0{,}5$"], 0, "$E(X) = np = 10 \\cdot 0{,}5 = 5$.")

THPT_IDS = [x["id"] for x in Q if x["grade"] in (11, 12)]

# ----------------------------------------------------------------------------------------------
INSTRUCTORS = [
    {"id": 1, "name": "TS. Nguyễn Minh Khoa", "color": "#6d5dfc", "title": vi_en("Tiến sĩ Toán học, ĐH Khoa học Tự nhiên", "PhD in Mathematics, VNU University of Science"),
     "bio": vi_en("10 năm giảng dạy Giải tích và luyện thi THPT Quốc gia. Đam mê biến công thức khô khan thành hình ảnh trực quan.", "10 years teaching calculus and exam prep. Loves turning dry formulas into pictures.")},
    {"id": 2, "name": "ThS. Trần Thu Hà", "color": "#ff5c8a", "title": vi_en("Giáo viên THPT chuyên", "Specialist high-school teacher"),
     "bio": vi_en("Huấn luyện đội tuyển HSG cấp tỉnh, tác giả nhiều chuyên đề Hình học không gian.", "Coaches provincial olympiad teams; author of many solid-geometry guides.")},
    {"id": 3, "name": "Cô Lê Mai Anh", "color": "#10c9a5", "title": vi_en("Giáo viên THCS", "Middle-school teacher"),
     "bio": vi_en("Giúp hàng nghìn học sinh lớp 6–9 yêu lại môn Toán bằng trò chơi và câu đố.", "Helped thousands of grade 6–9 students fall back in love with math through games and puzzles.")},
    {"id": 4, "name": "PGS. Phạm Quốc Bảo", "color": "#ffb020", "title": vi_en("Phó Giáo sư, Khoa Toán – Tin", "Associate Professor, Faculty of Math & CS"),
     "bio": vi_en("Nghiên cứu Đại số tuyến tính ứng dụng và Học máy.", "Researches applied linear algebra and machine learning.")},
]
CATEGORIES = [
    {"id": "dai-so", "icon": "𝑥", "name": vi_en("Đại số", "Algebra")},
    {"id": "hinh-hoc", "icon": "△", "name": vi_en("Hình học", "Geometry")},
    {"id": "giai-tich", "icon": "∫", "name": vi_en("Giải tích", "Calculus")},
    {"id": "xac-suat", "icon": "🎲", "name": vi_en("Xác suất – Thống kê", "Probability & Statistics")},
    {"id": "luyen-thi", "icon": "🎯", "name": vi_en("Luyện thi", "Exam prep")},
]


def lesson(lid, vi, en, video, mins, content_vi, content_en, quiz=(), preview=False):
    return {"id": lid, "title": vi_en(vi, en), "video": video, "duration_min": mins, "preview": preview,
            "content": vi_en(content_vi, content_en), "quiz": list(quiz)}


L = iter(range(1, 1000))
COURSES = [
    {"id": 1, "slug": "toan-8-hang-dang-thuc", "level": "thcs", "category": "dai-so", "instructor_id": 3, "price": 0, "old_price": 0,
     "color": "#10c9a5", "icon": "x²", "rating": 4.9, "students": 3120, "duration_hours": 6,
     "title": vi_en("Toán 8: Hằng đẳng thức đáng nhớ", "Grade 8: Essential algebraic identities"),
     "subtitle": vi_en("7 hằng đẳng thức qua hình vẽ và trò chơi", "The 7 identities through pictures and games"),
     "description": vi_en("Hiểu **vì sao** $(a+b)^2 = a^2 + 2ab + b^2$ bằng cách ghép các hình vuông, rồi áp dụng để phân tích đa thức thành nhân tử thật nhanh.\n\n- 7 hằng đẳng thức đáng nhớ\n- Phân tích đa thức thành nhân tử\n- Bài tập trắc nghiệm có lời giải",
                          "Understand **why** $(a+b)^2 = a^2 + 2ab + b^2$ by assembling squares, then use it to factor polynomials fast."),
     "lessons": [
         lesson(next(L), "Bình phương của một tổng — nhìn bằng hình", "Square of a sum — seen geometrically", "", 12,
                "## Ý tưởng\nGhép một hình vuông cạnh $a + b$ từ 4 mảnh: một hình vuông $a^2$, một hình vuông $b^2$ và hai hình chữ nhật $ab$.\n\n$$(a+b)^2 = a^2 + 2ab + b^2$$\n\n> 💡 Mẹo nhớ: *bình phương số thứ nhất, cộng hai lần tích, cộng bình phương số thứ hai.*\n\n## Ví dụ\n$$(x + 3)^2 = x^2 + 6x + 9$$",
                "## Idea\nBuild a square of side $a+b$ out of four pieces: $a^2$, $b^2$ and two $ab$ rectangles.\n\n$$(a+b)^2 = a^2 + 2ab + b^2$$", quiz=[34], preview=True),
         lesson(next(L), "Hiệu hai bình phương", "Difference of squares", "", 10,
                "$$A^2 - B^2 = (A - B)(A + B)$$\n\n**Ví dụ.** $x^2 - 9 = (x-3)(x+3)$\n\n**Tính nhẩm.** $49 \\cdot 51 = (50-1)(50+1) = 2500 - 1 = 2499$ 🤯",
                "$$A^2 - B^2 = (A - B)(A + B)$$\n\n**Mental math.** $49 \\cdot 51 = 2500 - 1 = 2499$ 🤯", quiz=[35]),
         lesson(next(L), "Lập phương của tổng, hiệu và các hằng đẳng thức còn lại", "Cubes and the remaining identities", "", 15,
                "| Hằng đẳng thức | Công thức |\n|---|---|\n| Lập phương tổng | $(A+B)^3 = A^3 + 3A^2B + 3AB^2 + B^3$ |\n| Lập phương hiệu | $(A-B)^3 = A^3 - 3A^2B + 3AB^2 - B^3$ |\n| Tổng hai lập phương | $A^3 + B^3 = (A+B)(A^2 - AB + B^2)$ |\n| Hiệu hai lập phương | $A^3 - B^3 = (A-B)(A^2 + AB + B^2)$ |",
                "| Identity | Formula |\n|---|---|\n| Cube of a sum | $(A+B)^3 = A^3 + 3A^2B + 3AB^2 + B^3$ |\n| Difference of cubes | $A^3 - B^3 = (A-B)(A^2 + AB + B^2)$ |", quiz=[39, 37]),
     ]},
    {"id": 2, "slug": "hinh-hoc-thcs-tam-giac-duong-tron", "level": "thcs", "category": "hinh-hoc", "instructor_id": 3, "price": 199000, "old_price": 299000,
     "color": "#3b82f6", "icon": "△", "rating": 4.8, "students": 1540, "duration_hours": 9,
     "title": vi_en("Hình học THCS: Tam giác & Đường tròn", "Middle-school geometry: triangles & circles"),
     "subtitle": vi_en("Pythagore, tam giác đồng dạng, góc nội tiếp", "Pythagoras, similar triangles, inscribed angles"),
     "description": vi_en("Nắm chắc hình học lớp 8–9 với hình vẽ động và hàng chục bài tập tự luyện.", "Master grade 8–9 geometry with dynamic figures and dozens of exercises."),
     "lessons": [
         lesson(next(L), "Định lý Pythagore và 1001 cách chứng minh", "Pythagoras' theorem and its many proofs", "", 14,
                "Trong tam giác vuông với cạnh huyền $c$:\n\n$$a^2 + b^2 = c^2$$\n\nBộ ba Pythagore quen thuộc: $(3,4,5)$, $(5,12,13)$, $(8,15,17)$.", "In a right triangle with hypotenuse $c$: $$a^2 + b^2 = c^2$$", quiz=[36], preview=True),
         lesson(next(L), "Góc nội tiếp", "Inscribed angles", "", 12,
                "Số đo góc nội tiếp bằng **nửa** số đo cung bị chắn.\n\n$$\\widehat{BAC} = \\tfrac12\\, \\text{sđ}\\,\\overset{\\frown}{BC}$$\n\nHệ quả: góc nội tiếp chắn nửa đường tròn là góc vuông.", "An inscribed angle is **half** of the intercepted arc.", quiz=[38]),
     ]},
    {"id": 3, "slug": "ham-so-va-do-thi-12", "level": "thpt", "category": "giai-tich", "instructor_id": 1, "price": 0, "old_price": 0,
     "color": "#6d5dfc", "icon": "ƒ", "rating": 4.9, "students": 8420, "duration_hours": 12,
     "title": vi_en("Hàm số & Đồ thị lớp 12", "Functions & graphs (grade 12)"),
     "subtitle": vi_en("Đơn điệu, cực trị, tiệm cận, khảo sát hàm số", "Monotonicity, extrema, asymptotes, curve sketching"),
     "description": vi_en("Chương quan trọng nhất của đề thi THPT Quốc gia (≈ 10 câu). Học bằng trực giác của đạo hàm trước, công thức sau.", "The most important chapter of the national exam (~10 questions)."),
     "lessons": [
         lesson(next(L), "Đạo hàm là gì? — Trực giác hình học", "What is a derivative? — geometric intuition", "9vKqVkMQHKk", 17,
                "Đạo hàm $f'(x_0)$ là **hệ số góc của tiếp tuyến** tại $x_0$:\n\n$$f'(x_0) = \\lim_{h \\to 0} \\frac{f(x_0 + h) - f(x_0)}{h}$$\n\n- $f' > 0$ trên khoảng $K$ ⟹ $f$ đồng biến trên $K$\n- $f' < 0$ trên khoảng $K$ ⟹ $f$ nghịch biến trên $K$",
                "The derivative is the **slope of the tangent line**: $$f'(x_0) = \\lim_{h \\to 0} \\frac{f(x_0 + h) - f(x_0)}{h}$$", quiz=[6], preview=True),
         lesson(next(L), "Cực trị của hàm số", "Local extrema", "", 15,
                "**Quy tắc 2.** Nếu $f'(x_0) = 0$ và\n- $f''(x_0) < 0$ thì $x_0$ là điểm **cực đại**\n- $f''(x_0) > 0$ thì $x_0$ là điểm **cực tiểu**", "**Second-derivative test**: $f'(x_0)=0$ and $f''(x_0)<0$ ⟹ local max.", quiz=[1, 5]),
         lesson(next(L), "GTLN – GTNN trên đoạn", "Max and min on a closed interval", "", 13,
                "1. Tìm các nghiệm $x_i \\in [a;b]$ của $f'(x) = 0$\n2. Tính $f(a), f(b), f(x_i)$\n3. So sánh và kết luận", "Evaluate $f$ at the endpoints and critical points, then compare.", quiz=[4]),
         lesson(next(L), "Tiệm cận và đồ thị", "Asymptotes and graphs", "", 14,
                "Với $y = \\dfrac{ax + b}{cx + d}$: tiệm cận đứng $x = -\\dfrac{d}{c}$, tiệm cận ngang $y = \\dfrac{a}{c}$.", "For $y = \\frac{ax+b}{cx+d}$: vertical $x = -d/c$, horizontal $y = a/c$.", quiz=[2, 3]),
     ]},
    {"id": 4, "slug": "mu-va-logarit", "level": "thpt", "category": "dai-so", "instructor_id": 2, "price": 299000, "old_price": 399000,
     "color": "#f97316", "icon": "eˣ", "rating": 4.7, "students": 2760, "duration_hours": 8,
     "title": vi_en("Hàm số Mũ & Logarit", "Exponentials & logarithms"),
     "subtitle": vi_en("Từ lãi kép ngân hàng tới phương trình logarit", "From compound interest to log equations"),
     "description": vi_en("Vì sao số $e$ xuất hiện ở khắp nơi? Khóa học gắn lý thuyết với các bài toán thực tế: lãi suất, tăng trưởng dân số, phân rã phóng xạ.", "Why is $e$ everywhere? Theory tied to real problems: interest, growth, decay."),
     "lessons": [
         lesson(next(L), "Số e đặc biệt ở đâu?", "What's so special about e?", "m2MIpDrF7Es", 14,
                "$$e = \\lim_{n\\to\\infty}\\left(1 + \\frac1n\\right)^n \\approx 2{,}71828$$\n\nHàm $e^x$ là hàm duy nhất (sai khác hằng số) **bằng chính đạo hàm của nó**.", "$e^x$ is the function that equals its own derivative.", quiz=[7], preview=True),
         lesson(next(L), "Phương trình & bất phương trình mũ – logarit", "Exponential & log equations", "", 18,
                "Chú ý: với $0 < a < 1$, bất phương trình **đổi chiều** khi bỏ cơ số.\n\n$$\\log_a f(x) > \\log_a g(x) \\Leftrightarrow 0 < f(x) < g(x) \\quad (0<a<1)$$", "With base $0<a<1$, the inequality **flips**.", quiz=[8, 9, 10]),
         lesson(next(L), "Bài toán lãi kép", "Compound interest", "", 11,
                "$$T_n = A(1 + r)^n$$\n\nVới $A$ là tiền gốc, $r$ là lãi suất mỗi kỳ, $n$ là số kỳ.", "$$T_n = A(1+r)^n$$", quiz=[11]),
     ]},
    {"id": 5, "slug": "nguyen-ham-tich-phan", "level": "thpt", "category": "giai-tich", "instructor_id": 1, "price": 399000, "old_price": 599000,
     "color": "#ec4899", "icon": "∫", "rating": 4.9, "students": 4310, "duration_hours": 14,
     "title": vi_en("Nguyên hàm – Tích phân – Ứng dụng", "Antiderivatives, integrals & applications"),
     "subtitle": vi_en("Diện tích, thể tích và định lý cơ bản của giải tích", "Area, volume and the fundamental theorem"),
     "description": vi_en("Hiểu tích phân như **tổng của vô số mảnh nhỏ**, rồi thành thạo đổi biến, từng phần và ứng dụng tính diện tích – thể tích.", "Integrals as **sums of infinitely many slices**."),
     "lessons": [
         lesson(next(L), "Tích phân và định lý cơ bản của giải tích", "Integration and the fundamental theorem", "rfG8ce4nNh0", 20,
                "$$\\int_a^b f(x)\\,dx = F(b) - F(a), \\quad F' = f$$\n\nTích phân = diện tích có dấu dưới đồ thị.", "$$\\int_a^b f(x)\\,dx = F(b) - F(a)$$", quiz=[12, 13], preview=True),
         lesson(next(L), "Đổi biến số và tích phân từng phần", "Substitution and integration by parts", "", 22,
                "**Từng phần:** $$\\int u\\,dv = uv - \\int v\\,du$$\n\nThứ tự ưu tiên chọn $u$: *\"Nhất log, nhì đa, tam lượng, tứ mũ\"*.", "**By parts:** $$\\int u\\,dv = uv - \\int v\\,du$$", quiz=[14, 17]),
         lesson(next(L), "Diện tích và thể tích", "Area and volume", "", 18,
                "$$S = \\int_a^b |f(x) - g(x)|\\,dx \\qquad V = \\pi \\int_a^b f^2(x)\\,dx$$", "$$S = \\int_a^b |f-g|\\,dx, \\quad V = \\pi\\int_a^b f^2\\,dx$$", quiz=[15, 16]),
     ]},
    {"id": 6, "slug": "luyen-thi-thpt-quoc-gia-9-plus", "level": "thpt", "category": "luyen-thi", "instructor_id": 2, "price": 799000, "old_price": 1200000,
     "color": "#7c3aed", "icon": "9⁺", "rating": 5.0, "students": 6050, "duration_hours": 40,
     "title": vi_en("Luyện thi THPT Quốc gia — Mục tiêu 9+", "National exam prep — target 9+"),
     "subtitle": vi_en("Tổng ôn 12 chuyên đề + 10 đề thi thử bấm giờ", "12 topics reviewed + 10 timed mock exams"),
     "description": vi_en("Lộ trình 12 tuần, mỗi tuần một chuyên đề, kèm đề thi thử chấm điểm tự động theo cấu trúc đề của Bộ GD&ĐT.", "A 12-week plan with auto-graded mock exams in the official format."),
     "lessons": [
         lesson(next(L), "Chiến thuật làm bài trắc nghiệm 90 phút", "Strategy for the 90-minute multiple-choice exam", "", 16,
                "1. **Lượt 1 (40′):** làm hết câu Nhận biết – Thông hiểu\n2. **Lượt 2 (35′):** câu Vận dụng\n3. **Lượt 3 (15′):** Vận dụng cao + rà soát\n\n> Không bỏ trống câu nào — không có điểm âm!", "Three passes: easy → medium → hard. Never leave blanks.", preview=True),
         lesson(next(L), "Chuyên đề Số phức", "Complex numbers", "", 20,
                "$$z = a + bi, \\quad |z| = \\sqrt{a^2 + b^2}, \\quad \\bar z = a - bi$$", "$$z = a + bi, \\quad |z| = \\sqrt{a^2+b^2}$$", quiz=[18, 19, 20, 21]),
         lesson(next(L), "Chuyên đề Hình học không gian", "Solid geometry", "", 25,
                "Góc giữa đường thẳng và mặt phẳng = góc giữa đường thẳng và **hình chiếu** của nó lên mặt phẳng.", "The angle between a line and a plane is the angle with its projection.", quiz=[22, 23, 24, 25]),
         lesson(next(L), "Chuyên đề Tổ hợp – Xác suất", "Combinatorics & probability", "", 22,
                "$$P(A) = \\frac{n(A)}{n(\\Omega)}, \\qquad C_n^k = \\frac{n!}{k!(n-k)!}$$", "$$P(A) = \\frac{|A|}{|\\Omega|}$$", quiz=[26, 27, 28, 29]),
     ]},
    {"id": 7, "slug": "giai-tich-1", "level": "university", "category": "giai-tich", "instructor_id": 1, "price": 0, "old_price": 0,
     "color": "#0ea5e9", "icon": "∂", "rating": 4.8, "students": 2210, "duration_hours": 30,
     "title": vi_en("Giải tích 1 cho sinh viên năm nhất", "Calculus I for first-year students"),
     "subtitle": vi_en("Giới hạn, đạo hàm, tích phân, chuỗi số", "Limits, derivatives, integrals, series"),
     "description": vi_en("Nền tảng cho mọi ngành kỹ thuật – kinh tế. Có video từ series *Essence of Calculus*.", "The foundation for engineering and economics, featuring *Essence of Calculus*."),
     "lessons": [
         lesson(next(L), "Bản chất của Giải tích", "The essence of calculus", "WUvTyaaNkzM", 17,
                "Giải tích ra đời từ câu hỏi: **diện tích hình tròn** được tính như thế nào? Chia nhỏ — cộng lại — lấy giới hạn.", "Calculus starts with: how do we find the **area of a circle**?", quiz=[41], preview=True),
         lesson(next(L), "Giới hạn và quy tắc L'Hôpital", "Limits and L'Hôpital's rule", "kfF40MiS7zA", 18,
                "$$\\lim_{x\\to a}\\frac{f(x)}{g(x)} = \\lim_{x\\to a}\\frac{f'(x)}{g'(x)} \\quad \\text{(dạng } 0/0 \\text{)}$$", "For $0/0$ forms, differentiate top and bottom.", quiz=[33, 40]),
         lesson(next(L), "Chuỗi Taylor", "Taylor series", "3d6DsjIBzJ4", 22,
                "$$e^x = \\sum_{n=0}^{\\infty} \\frac{x^n}{n!} = 1 + x + \\frac{x^2}{2!} + \\cdots$$", "$$e^x = \\sum_{n\\ge 0} \\frac{x^n}{n!}$$", quiz=[44]),
     ]},
    {"id": 8, "slug": "dai-so-tuyen-tinh", "level": "university", "category": "dai-so", "instructor_id": 4, "price": 499000, "old_price": 699000,
     "color": "#14b8a6", "icon": "λ", "rating": 4.9, "students": 1890, "duration_hours": 28,
     "title": vi_en("Đại số tuyến tính trực quan", "Visual linear algebra"),
     "subtitle": vi_en("Vector, ma trận, định thức, trị riêng — nhìn bằng hình học", "Vectors, matrices, determinants, eigenvalues — geometrically"),
     "description": vi_en("Ma trận là **phép biến đổi không gian**. Khi nhìn như vậy, định thức, hạng, trị riêng trở nên hiển nhiên. Nền tảng cho AI/ML.", "A matrix is a **transformation of space**. Foundation for AI/ML."),
     "lessons": [
         lesson(next(L), "Vector là gì?", "Vectors, what even are they?", "fNk_zzaMoSs", 10, "Vector vừa là **mũi tên** trong không gian, vừa là **danh sách số** $\\begin{pmatrix} x \\\\ y \\end{pmatrix}$.", "A vector is both an **arrow** and a **list of numbers**.", preview=True),
         lesson(next(L), "Ma trận và phép biến đổi tuyến tính", "Linear transformations and matrices", "kYB8IZa5AuE", 11, "Các cột của ma trận cho biết **vector cơ sở** $\\hat\\imath, \\hat\\jmath$ đi đâu sau phép biến đổi.", "Columns tell you where the basis vectors land."),
         lesson(next(L), "Định thức", "The determinant", "Ip3X9LOh2dk", 10, "$\\det A$ = **hệ số phóng đại diện tích** của phép biến đổi.\n\n$$\\det\\begin{pmatrix} a & b \\\\ c & d\\end{pmatrix} = ad - bc$$", "$\\det A$ is the area scaling factor.", quiz=[42, 43]),
         lesson(next(L), "Vector riêng và trị riêng", "Eigenvectors and eigenvalues", "PFDu9oVAE-g", 17, "$$A\\mathbf{v} = \\lambda \\mathbf{v}$$\n\nVector riêng là vector **chỉ bị co giãn**, không bị xoay.", "$$A\\mathbf v = \\lambda\\mathbf v$$", quiz=[45]),
     ]},
    {"id": 9, "slug": "xac-suat-thong-ke", "level": "university", "category": "xac-suat", "instructor_id": 4, "price": 349000, "old_price": 0,
     "color": "#eab308", "icon": "σ", "rating": 4.6, "students": 1320, "duration_hours": 20,
     "title": vi_en("Xác suất – Thống kê ứng dụng", "Applied probability & statistics"),
     "subtitle": vi_en("Từ định lý Bayes đến kiểm định giả thuyết", "From Bayes' theorem to hypothesis testing"),
     "description": vi_en("Tư duy xác suất cho dữ liệu thực tế: phân phối, kỳ vọng, phương sai, ước lượng và kiểm định.", "Probabilistic thinking for real data."),
     "lessons": [
         lesson(next(L), "Định lý Bayes", "Bayes' theorem", "HZGCoVF3YvM", 15, "$$P(A\\mid B) = \\frac{P(B \\mid A)\\,P(A)}{P(B)}$$", "$$P(A\\mid B) = \\frac{P(B\\mid A)P(A)}{P(B)}$$", preview=True),
         lesson(next(L), "Phân phối nhị thức", "The binomial distribution", "", 14, "$$P(X = k) = C_n^k p^k (1-p)^{n-k}, \\quad E(X) = np$$", "$$P(X=k) = \\binom nk p^k(1-p)^{n-k}$$", quiz=[46, 26]),
     ]},
]

EXAMS = [
    {"id": 1, "level": "thpt", "duration_min": 60, "published": True, "question_ids": [x for x in THPT_IDS if x not in (32, 33)][:30],
     "title": vi_en("Đề thi thử THPT Quốc gia 2027 — Đề số 1", "National exam mock 2027 — Paper 1"),
     "description": vi_en("30 câu trắc nghiệm, đủ 4 mức độ, cấu trúc bám sát đề minh họa của Bộ.", "30 multiple-choice questions across all 4 difficulty levels."), "created_at": d(30)},
    {"id": 2, "level": "thpt", "duration_min": 15, "published": True, "question_ids": [1, 2, 3, 4, 5, 6, 32, 33],
     "title": vi_en("Chuyên đề Hàm số — Kiểm tra 15 phút", "Functions — 15-minute quiz"),
     "description": vi_en("Cực trị, GTLN – GTNN, tiệm cận và giới hạn.", "Extrema, max/min, asymptotes and limits."), "created_at": d(20)},
    {"id": 3, "level": "thpt", "duration_min": 20, "published": True, "question_ids": list(range(12, 22)),
     "title": vi_en("Tích phân & Số phức — 20 phút", "Integrals & complex numbers — 20 minutes"),
     "description": vi_en("10 câu từ nhận biết đến vận dụng cao.", "10 questions from recall to advanced."), "created_at": d(15)},
    {"id": 4, "level": "thcs", "duration_min": 15, "published": True, "question_ids": [34, 35, 36, 37, 38, 39],
     "title": vi_en("Toán THCS — Kiểm tra 15 phút", "Middle-school math — 15-minute test"),
     "description": vi_en("Hằng đẳng thức, phương trình bậc nhất, Pythagore, góc nội tiếp.", "Identities, linear equations, Pythagoras, inscribed angles."), "created_at": d(12)},
    {"id": 5, "level": "university", "duration_min": 20, "published": True, "question_ids": [40, 41, 42, 43, 44, 45, 46],
     "title": vi_en("Giải tích & Đại số tuyến tính — Kiểm tra giữa kỳ", "Calculus & linear algebra — midterm"),
     "description": vi_en("Dành cho sinh viên năm nhất.", "For first-year university students."), "created_at": d(10)},
]

MAGAZINE = [
    {"id": 1, "issue": 1, "symbol": "π", "color": "#6d5dfc", "published": "2026-03-14",
     "title": vi_en("Số π — 4000 năm rượt đuổi", "π — a 4,000-year chase"),
     "summary": vi_en("Từ người Babylon đến siêu máy tính: hành trình tính các chữ số của π, cây kim Buffon và vì sao π xuất hiện trong xác suất.", "From Babylon to supercomputers: computing π, Buffon's needle, and why π shows up in probability."),
     "topics": ["Lịch sử", "Hình học", "Xác suất"],
     "articles": [{"page": 2, "title": vi_en("Lịch sử số π", "A history of π"), "author": "Ban biên tập"},
                  {"page": 3, "title": vi_en("Archimedes và đa giác 96 cạnh", "Archimedes and the 96-gon"), "author": "Nguyễn Minh Khoa"},
                  {"page": 4, "title": vi_en("Thả kim để tính π", "Dropping needles to compute π"), "author": "Trần Thu Hà"}]},
    {"id": 2, "issue": 2, "symbol": "∞", "color": "#ff5c8a", "published": "2026-06-01",
     "title": vi_en("Vô hạn có bao nhiêu loại?", "How many kinds of infinity?"),
     "summary": vi_en("Khách sạn Hilbert, đường chéo Cantor và câu hỏi khiến cả ngành Toán chao đảo: có tập nào lớn hơn ℕ nhưng nhỏ hơn ℝ?", "Hilbert's hotel, Cantor's diagonal, and the continuum hypothesis."),
     "topics": ["Lý thuyết tập hợp", "Logic"],
     "articles": [{"page": 2, "title": vi_en("Khách sạn Hilbert", "Hilbert's Grand Hotel"), "author": "Ban biên tập"},
                  {"page": 3, "title": vi_en("Phép chứng minh đường chéo của Cantor", "Cantor's diagonal argument"), "author": "Phạm Quốc Bảo"},
                  {"page": 4, "title": vi_en("Giả thuyết continuum", "The continuum hypothesis"), "author": "Phạm Quốc Bảo"}]},
    {"id": 3, "issue": 3, "symbol": "p", "color": "#10c9a5", "published": "2026-09-05",
     "title": vi_en("Số nguyên tố — những viên gạch của số học", "Primes — the atoms of arithmetic"),
     "summary": vi_en("Euclid chứng minh có vô hạn số nguyên tố; sàng Eratosthenes; và giả thuyết Riemann trị giá 1 triệu đô.", "Euclid's proof, the sieve of Eratosthenes, and the million-dollar Riemann hypothesis."),
     "topics": ["Số học", "Bài toán mở"],
     "articles": [{"page": 2, "title": vi_en("Vô hạn số nguyên tố", "Infinitely many primes"), "author": "Lê Mai Anh"},
                  {"page": 3, "title": vi_en("Sàng Eratosthenes", "The sieve of Eratosthenes"), "author": "Lê Mai Anh"},
                  {"page": 4, "title": vi_en("Giả thuyết Riemann", "The Riemann hypothesis"), "author": "Nguyễn Minh Khoa"}]},
    {"id": 4, "issue": 4, "symbol": "φ", "color": "#ffb020", "published": "2026-11-01",
     "title": vi_en("Tỉ lệ vàng φ và dãy Fibonacci", "The golden ratio φ and Fibonacci"),
     "summary": vi_en("Vì sao hoa hướng dương có 34 và 55 đường xoắn? Tỉ lệ vàng — huyền thoại và sự thật.", "Why do sunflowers have 34 and 55 spirals? The golden ratio: myth and fact."),
     "topics": ["Dãy số", "Tự nhiên", "Nghệ thuật"],
     "articles": [{"page": 2, "title": vi_en("Dãy Fibonacci", "The Fibonacci sequence"), "author": "Trần Thu Hà"},
                  {"page": 3, "title": vi_en("φ — con số vô tỉ nhất", "φ — the most irrational number"), "author": "Phạm Quốc Bảo"},
                  {"page": 4, "title": vi_en("Huyền thoại về tỉ lệ vàng", "Golden-ratio myths"), "author": "Ban biên tập"}]},
]

BADGES = [
    {"id": "first_step", "icon": "👣", "name": vi_en("Bước đầu tiên", "First step"), "desc": vi_en("Hoàn thành bài học đầu tiên", "Complete your first lesson")},
    {"id": "scholar", "icon": "📚", "name": vi_en("Học giả", "Scholar"), "desc": vi_en("Hoàn thành 10 bài học", "Complete 10 lessons")},
    {"id": "first_exam", "icon": "📝", "name": vi_en("Thí sinh", "Test taker"), "desc": vi_en("Làm bài thi thử đầu tiên", "Finish your first mock exam")},
    {"id": "perfect", "icon": "💯", "name": vi_en("Hoàn hảo", "Perfect"), "desc": vi_en("Đạt điểm 10 một bài thi", "Score 10/10 on an exam")},
    {"id": "streak_3", "icon": "🔥", "name": vi_en("Bền bỉ", "On fire"), "desc": vi_en("Học 3 ngày liên tiếp", "3-day streak")},
    {"id": "streak_7", "icon": "⚡", "name": vi_en("Một tuần", "Week warrior"), "desc": vi_en("Học 7 ngày liên tiếp", "7-day streak")},
    {"id": "xp_500", "icon": "🌟", "name": vi_en("500 XP", "500 XP"), "desc": vi_en("Đạt 500 điểm kinh nghiệm", "Earn 500 XP")},
]

TESTIMONIALS = [
    {"name": "Hoàng Gia Bảo", "color": "#6d5dfc", "role": vi_en("Học sinh lớp 12, Hà Nội", "Grade 12, Hanoi"), "text": vi_en("Điểm thi thử tăng từ 6,8 lên 9,2 sau 2 tháng. Phần tích phân giờ là phần mình thích nhất!", "My mock score went from 6.8 to 9.2 in two months.")},
    {"name": "Nguyễn Thảo Vy", "color": "#ff5c8a", "role": vi_en("Học sinh lớp 8, Đà Nẵng", "Grade 8, Da Nang"), "text": vi_en("Phần hằng đẳng thức có hình vẽ nên mình nhớ lâu hơn hẳn học thuộc lòng.", "The picture-based identities stuck far better than rote memorising.")},
    {"name": "Lý Minh Đức", "color": "#10c9a5", "role": vi_en("Sinh viên năm nhất Bách khoa", "First-year engineering student"), "text": vi_en("Đại số tuyến tính trực quan cứu mình khỏi môn học lại. Định thức cuối cùng cũng có nghĩa!", "Visual linear algebra saved me. Determinants finally make sense!")},
    {"name": "Phạm Khánh Linh", "color": "#ffb020", "role": vi_en("Phụ huynh", "Parent"), "text": vi_en("Con tôi tự giác học hơn hẳn nhờ huy hiệu và streak.", "My child studies on their own now thanks to badges and streaks.")},
    {"name": "Trần Quang Huy", "color": "#3b82f6", "role": vi_en("Giáo viên THPT", "High-school teacher"), "text": vi_en("Tôi dùng ngân hàng câu hỏi để giao bài kiểm tra 15 phút cho cả lớp. Rất tiện.", "I use the question bank for 15-minute class quizzes.")},
]

PW = hash_password("123456")
USERS = [
    {"id": 1, "name": "Quản trị viên", "email": "admin@mathverse.vn", "role": "admin", "level": "university", "avatar_color": "#17162b",
     "xp": 0, "streak": 0, "last_active": None, "badges": [], "created_at": d(90)},
    {"id": 2, "name": "Nguyễn Văn An", "email": "an@student.vn", "role": "student", "level": "thpt", "avatar_color": "#6d5dfc",
     "xp": 640, "streak": 4, "last_active": (TODAY - timedelta(days=1)).isoformat(), "badges": ["first_step", "first_exam", "streak_3", "xp_500"], "created_at": d(45)},
    {"id": 3, "name": "Trần Thị Bình", "email": "binh@uni.edu.vn", "role": "university", "level": "university", "avatar_color": "#ff5c8a",
     "xp": 310, "streak": 2, "last_active": (TODAY - timedelta(days=1)).isoformat(), "badges": ["first_step", "first_exam"], "created_at": d(30)},
    {"id": 4, "name": "Lê Minh Chi", "email": "chi@student.vn", "role": "student", "level": "thcs", "avatar_color": "#10c9a5",
     "xp": 120, "streak": 1, "last_active": (TODAY - timedelta(days=3)).isoformat(), "badges": ["first_step"], "created_at": d(20)},
]
for u in USERS:
    u["password_hash"] = PW

ENROLLMENTS = [
    {"user_id": 2, "course_id": 3, "enrolled_at": d(44), "paid": 0},
    {"user_id": 2, "course_id": 5, "enrolled_at": d(40), "paid": 399000},
    {"user_id": 2, "course_id": 6, "enrolled_at": d(25), "paid": 799000},
    {"user_id": 3, "course_id": 7, "enrolled_at": d(29), "paid": 0},
    {"user_id": 3, "course_id": 8, "enrolled_at": d(28), "paid": 499000},
    {"user_id": 4, "course_id": 1, "enrolled_at": d(19), "paid": 0},
]
PAYMENTS = [
    {"id": 1, "user_id": 2, "course_id": 5, "amount": 399000, "method": "momo", "status": "paid (demo)", "created_at": d(40)},
    {"id": 2, "user_id": 2, "course_id": 6, "amount": 799000, "method": "card", "status": "paid (demo)", "created_at": d(25)},
    {"id": 3, "user_id": 3, "course_id": 8, "amount": 499000, "method": "bank", "status": "paid (demo)", "created_at": d(28)},
]
cmap = {c["id"]: c for c in COURSES}
PROGRESS = []
for uid, cid, n, start in [(2, 3, 4, 43), (2, 5, 2, 30), (2, 6, 1, 20), (3, 7, 2, 25), (3, 8, 1, 10), (4, 1, 1, 5)]:
    for k, les in enumerate(cmap[cid]["lessons"][:n]):
        PROGRESS.append({"user_id": uid, "course_id": cid, "lesson_id": les["id"], "completed_at": d(start - k * 3)})

qmap = {x["id"]: x for x in Q}


def attempt(aid, uid, eid, wrong: set, days_ago: int, dur: int):
    qs = next(e for e in EXAMS if e["id"] == eid)["question_ids"]
    ans = {}
    for i in qs:
        a = qmap[i]["answer"]
        ans[str(i)] = (a + 1) % len(qmap[i]["options"]) if i in wrong else a
    correct = sum(1 for i in qs if i not in wrong)
    return {"id": aid, "user_id": uid, "exam_id": eid, "answers": ans, "correct": correct, "total": len(qs),
            "score": round(10 * correct / len(qs), 2), "started_at": d(days_ago, 19), "submitted_at": d(days_ago, 20), "duration_sec": dur}


ATTEMPTS = [attempt(1, 2, 2, {5, 33}, 18, 610), attempt(2, 2, 1, {5, 11, 16, 17, 24, 28}, 9, 3020),
            attempt(3, 2, 3, {16, 17}, 3, 1004), attempt(4, 3, 5, {44}, 6, 900)]

DB = {
    "meta": {"name": "MathVerse demo data", "version": 1, "generated_at": datetime.now().replace(microsecond=0).isoformat(),
             "note": "Demo password for every account: 123456"},
    "users": USERS, "instructors": INSTRUCTORS, "categories": CATEGORIES, "courses": COURSES,
    "enrollments": ENROLLMENTS, "payments": PAYMENTS, "progress": PROGRESS, "questions": Q, "exams": EXAMS,
    "attempts": ATTEMPTS, "magazine": MAGAZINE, "badges": BADGES, "testimonials": TESTIMONIALS,
}


# ----------------------------------------------------------------------------------------------
# SVG figures used inside questions (demonstrates images in Markdown)
# ----------------------------------------------------------------------------------------------
def write_svgs():
    img = ROOT / "app" / "static" / "uploads" / "images"
    img.mkdir(parents=True, exist_ok=True)
    pts = []
    for i in range(0, 121):
        x = -2.2 + i * 4.4 / 120
        y = x ** 3 - 3 * x + 2
        pts.append(f"{200 + x * 60:.1f},{170 - y * 25:.1f}")
    (img / "demo-cubic.svg").write_text(f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" width="400" height="300" font-family="Georgia" font-size="14">
<rect width="400" height="300" fill="#fff" rx="12"/>
<g stroke="#e4e2f0">{''.join(f'<line x1="{x}" y1="0" x2="{x}" y2="300"/>' for x in range(20, 400, 30))}{''.join(f'<line x1="0" y1="{y}" x2="400" y2="{y}"/>' for y in range(20, 300, 25))}</g>
<line x1="10" y1="170" x2="390" y2="170" stroke="#17162b" stroke-width="1.5"/><line x1="200" y1="290" x2="200" y2="10" stroke="#17162b" stroke-width="1.5"/>
<text x="378" y="186" font-style="italic">x</text><text x="208" y="22" font-style="italic">y</text><text x="186" y="186">O</text>
<polyline points="{' '.join(pts)}" fill="none" stroke="#6d5dfc" stroke-width="3" stroke-linejoin="round"/>
<circle cx="140" cy="70" r="5" fill="#ff5c8a"/><circle cx="260" cy="170" r="5" fill="#10c9a5"/>
<text x="112" y="58" fill="#ff5c8a">(-1; 4)</text><text x="266" y="194" fill="#10c9a5">(1; 0)</text>
</svg>""", encoding="utf-8")
    (img / "demo-pyramid.svg").write_text("""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 280" width="360" height="280" font-family="Georgia" font-size="16" font-style="italic">
<rect width="360" height="280" fill="#fff" rx="12"/>
<polygon points="70,220 230,220 290,160 130,160" fill="#6d5dfc22" stroke="#6d5dfc" stroke-width="2"/>
<line x1="130" y1="160" x2="70" y2="220" stroke="#6d5dfc" stroke-dasharray="6 5" stroke-width="2"/>
<line x1="130" y1="160" x2="290" y2="160" stroke="#6d5dfc" stroke-dasharray="6 5" stroke-width="2"/>
<line x1="70" y1="40" x2="70" y2="220" stroke="#ff5c8a" stroke-width="2.5"/>
<line x1="70" y1="40" x2="230" y2="220" stroke="#17162b" stroke-width="2"/><line x1="70" y1="40" x2="290" y2="160" stroke="#17162b" stroke-width="2"/>
<line x1="70" y1="40" x2="130" y2="160" stroke="#17162b" stroke-dasharray="6 5" stroke-width="2"/>
<line x1="70" y1="220" x2="290" y2="160" stroke="#10c9a5" stroke-dasharray="4 4" stroke-width="2"/>
<text x="56" y="34">S</text><text x="52" y="238">A</text><text x="230" y="240">B</text><text x="296" y="160">C</text><text x="124" y="152">D</text>
<text x="40" y="132" fill="#ff5c8a" font-size="13">a√2</text><polyline points="70,206 84,206 84,220" fill="none" stroke="#ff5c8a"/>
</svg>""", encoding="utf-8")


# ----------------------------------------------------------------------------------------------
# Magazine PDFs (fpdf2 + DejaVu fonts for Vietnamese)
# ----------------------------------------------------------------------------------------------
ARTICLE_TEXT = {
    1: ["Người Babylon cổ đại dùng xấp xỉ π ≈ 3,125, người Ai Cập dùng π ≈ 3,16. Năm 250 TCN, Archimedes kẹp đường tròn giữa hai đa giác đều 96 cạnh và chứng minh 3 10/71 < π < 3 1/7.",
        "Ý tưởng của Archimedes: chu vi đa giác nội tiếp luôn nhỏ hơn chu vi đường tròn, còn chu vi đa giác ngoại tiếp luôn lớn hơn. Tăng số cạnh lên gấp đôi nhiều lần, hai chặn tiến sát nhau.",
        "Năm 1777, Buffon hỏi: thả ngẫu nhiên một cây kim dài ℓ lên sàn kẻ các đường song song cách nhau d ≥ ℓ, xác suất kim cắt một đường là bao nhiêu? Đáp số: P = 2ℓ / (π d). Vậy ta có thể ước lượng π bằng cách… thả kim!"],
    2: ["Khách sạn Hilbert có vô hạn phòng, tất cả đều kín khách. Một vị khách mới đến? Chỉ cần mời khách phòng n chuyển sang phòng n + 1 — phòng 1 trống! Vô hạn cộng một vẫn là vô hạn ấy.",
        "Cantor chứng minh tập số thực ℝ không thể liệt kê thành dãy: với mọi danh sách, ta tạo được một số mới khác số thứ n ở chữ số thứ n. Vậy |ℝ| > |ℕ| — có nhiều hơn một loại vô hạn.",
        "Có tập nào có lực lượng nằm giữa ℕ và ℝ không? Gödel (1940) và Cohen (1963) chứng minh câu hỏi này không thể trả lời từ các tiên đề ZFC thông thường."],
    3: ["Giả sử chỉ có hữu hạn số nguyên tố p₁, p₂, …, pₙ. Xét N = p₁p₂…pₙ + 1. N không chia hết cho pᵢ nào cả, vậy N có một ước nguyên tố mới — mâu thuẫn. Đây là chứng minh của Euclid, hơn 2300 năm tuổi.",
        "Sàng Eratosthenes: viết các số từ 2 đến n, gạch bỏ bội của 2, rồi bội của 3, của 5,… Các số còn lại là số nguyên tố. Chỉ cần sàng tới √n.",
        "Hàm zeta ζ(s) = Σ 1/nˢ liên hệ mật thiết với phân bố số nguyên tố. Riemann (1859) phỏng đoán mọi không điểm không tầm thường của ζ nằm trên đường Re(s) = 1/2. Viện Clay treo thưởng 1 triệu USD cho lời giải."],
    4: ["Dãy Fibonacci: 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, … với Fₙ₊₁ = Fₙ + Fₙ₋₁. Tỉ số Fₙ₊₁/Fₙ tiến tới φ = (1 + √5)/2 ≈ 1,618.",
        "φ là nghiệm của x² = x + 1. Liên phân số của φ là [1; 1, 1, 1, …] — toàn số 1 — nên φ là số “khó xấp xỉ bằng phân số nhất”. Đó là lý do hoa hướng dương xếp hạt theo góc vàng ≈ 137,5°.",
        "Không phải mọi thứ đều chứa tỉ lệ vàng: kim tự tháp Giza, đền Parthenon hay bức Mona Lisa thường bị “gán” φ một cách gượng ép. Toán học đẹp hơn khi đúng sự thật!"],
}


def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


PDF_FIX = str.maketrans({"ℓ": "l", "ℕ": "N", "ℝ": "R", "ℙ": "P"})


def write_pdfs():
    from fpdf import FPDF
    fonts = ROOT / "scripts" / "fonts"
    out = ROOT / "app" / "static" / "magazine"
    out.mkdir(parents=True, exist_ok=True)
    for m in MAGAZINE:
        pdf = FPDF(format="A4")
        pdf.set_auto_page_break(True, 20)
        pdf.add_font("Serif", "", str(fonts / "DejaVuSerif.ttf"))
        pdf.add_font("Serif", "B", str(fonts / "DejaVuSerif-Bold.ttf"))
        pdf.add_font("Serif", "I", str(fonts / "DejaVuSerif-Italic.ttf"))
        pdf.add_font("Sans", "", str(fonts / "DejaVuSans.ttf"))
        pdf.add_font("Sans", "B", str(fonts / "DejaVuSans-Bold.ttf"))
        r, g, b = hex_rgb(m["color"])
        # cover
        pdf.add_page()
        pdf.set_fill_color(r, g, b)
        pdf.rect(0, 0, 210, 297, "F")
        pdf.set_fill_color(23, 22, 43)
        pdf.rect(0, 200, 210, 97, "F")
        pdf.set_text_color(255, 255, 255)
        pdf.set_font("Serif", "B", 34)
        pdf.set_xy(15, 18)
        pdf.cell(0, 14, "MathVerse")
        pdf.set_font("Sans", "B", 11)
        pdf.set_xy(15, 20)
        pdf.cell(180, 10, f"SỐ {m['issue']} · {m['published']}", align="R")
        pdf.line(15, 36, 195, 36)
        pdf.set_font("Serif", "I", 150)
        pdf.set_xy(0, 70)
        pdf.cell(210, 90, m["symbol"], align="C")
        pdf.set_font("Serif", "B", 24)
        pdf.set_xy(15, 212)
        pdf.multi_cell(180, 11, m["title"]["vi"])
        pdf.set_font("Serif", "I", 12)
        pdf.set_x(15)
        pdf.multi_cell(180, 6.5, m["summary"]["vi"].translate(PDF_FIX))
        # articles
        for a, text in zip(m["articles"], ARTICLE_TEXT[m["id"]]):
            pdf.add_page()
            pdf.set_text_color(r, g, b)
            pdf.set_font("Sans", "B", 9)
            pdf.cell(0, 6, f"MATHVERSE · SỐ {m['issue']} · TRANG {pdf.page_no()}", new_x="LMARGIN", new_y="NEXT")
            pdf.set_draw_color(r, g, b)
            pdf.line(10, pdf.get_y() + 1, 200, pdf.get_y() + 1)
            pdf.ln(8)
            pdf.set_text_color(23, 22, 43)
            pdf.set_font("Serif", "B", 24)
            pdf.multi_cell(0, 11, a["title"]["vi"])
            pdf.set_font("Sans", "", 10)
            pdf.set_text_color(98, 96, 122)
            pdf.cell(0, 8, f"Tác giả: {a['author']}", new_x="LMARGIN", new_y="NEXT")
            pdf.ln(4)
            pdf.set_text_color(23, 22, 43)
            pdf.set_font("Serif", "", 12.5)
            pdf.multi_cell(0, 7.5, text.translate(PDF_FIX))
            # decorative big symbol
            pdf.set_text_color(min(255, r + 170), min(255, g + 170), min(255, b + 170))
            pdf.set_font("Serif", "I", 120)
            pdf.set_xy(110, 200)
            pdf.cell(90, 60, m["symbol"], align="R")
        path = out / f"mathverse-so-{m['issue']}.pdf"
        pdf.output(str(path))
        m["pdf"] = f"/static/magazine/{path.name}"
        m["pages"] = pdf.page_no()


if __name__ == "__main__":
    write_svgs()
    write_pdfs()
    data_dir = ROOT / "data"
    data_dir.mkdir(exist_ok=True)
    text = json.dumps(DB, ensure_ascii=False, indent=2)
    (data_dir / "demo.json").write_text(text, encoding="utf-8")
    (data_dir / "demo.seed.json").write_text(text, encoding="utf-8")
    print(f"demo.json: {len(USERS)} users, {len(COURSES)} courses, {sum(len(c['lessons']) for c in COURSES)} lessons, "
          f"{len(Q)} questions, {len(EXAMS)} exams, {len(MAGAZINE)} magazine issues")
