# MathVerse — Yêu cầu dự án

> Ngày lập: 2026-11-05 · Thư mục dự án: `/home/worker/zFree/Math`

## 0. Ràng buộc chung
- **Mọi thứ nằm trong `/home/worker/zFree/Math`**: mã nguồn, dữ liệu, môi trường Python (`.venv`), cache pip/npm (`.cache`), thư viện frontend (`app/static/vendor`). Không cài gì ra ngoài thư mục này.
- Trước khi implement thì hỏi lại chủ dự án nếu còn chỗ chưa rõ.
- Ghi lại những gì đã làm trong `DONE.md` (liệt kê dạng bảng).

## 1. Mục đích
Website **học Toán** cho học sinh / sinh viên:
- Đăng ký **khóa học** (có khóa miễn phí và khóa trả phí giả lập).
- Có **tạp chí Toán học** (kiểu Quanta Magazine / AMS Notices).
- Giao diện có nhiều **animation** (button, hover, cuộn trang, …) để việc học thú vị hơn.

## 2. Research tham khảo
| Trang | Học hỏi điều gì |
|---|---|
| Brilliant.org | Học qua tương tác, gamification (streak, XP), hiệu ứng đúng/sai |
| Khan Academy | Lộ trình theo lớp, thanh tiến độ, dashboard học viên |
| Art of Problem Solving | Trang khóa học rõ cấp độ, giá, nút đăng ký |
| Mathigon | Minh họa SVG động, nội dung hiện dần khi cuộn |
| Quanta Magazine / Plus / AMS Notices | Bố cục tạp chí, typography serif, phân chuyên mục |
| 3Blue1Brown / Desmos | Trực quan hóa khái niệm |

## 3. Quyết định đã chốt
| Hạng mục | Lựa chọn |
|---|---|
| Bố cục | **Hybrid**: phần học kiểu Brilliant/Khan + phần tạp chí kiểu Quanta |
| Backend | **Python — FastAPI + Jinja2** (server render HTML + JSON API, Swagger tại `/docs`) |
| Frontend | HTML/CSS/JS thuần (không cần build), KaTeX, marked, DOMPurify, canvas-confetti; font Be Vietnam Pro / Lora tải về local |
| Dữ liệu | **Chỉ dùng `data/demo.json`** (không DB). Dữ liệu người dùng ghi ngược lại vào file JSON. Có bản gốc `data/demo.seed.json` để reset |
| Ngôn ngữ | **Song ngữ Việt / Anh** (nút chuyển VI/EN) |
| Giao diện màu | **Dark / Light** (nút chuyển, nhớ lựa chọn) |

## 4. Tính năng yêu cầu
### 4.1 Tài khoản
- Đăng ký / đăng nhập **thật**: mật khẩu hash (PBKDF2), session cookie ký số.
- Vai trò: học sinh (THCS/THPT), sinh viên, admin.

### 4.2 Khóa học
- Danh sách khóa học, lọc theo cấp độ / chủ đề, tìm kiếm.
- Trang chi tiết khóa học: mô tả, giảng viên, giáo trình, giá.
- **Khóa trả phí (giả lập)**: hiển thị giá, trang thanh toán giả lập.
- **Bài học có video** (nhúng YouTube) + nội dung Markdown/LaTeX + quiz cuối bài.
- Đánh dấu hoàn thành bài học → cộng XP, cập nhật tiến độ.

### 4.3 Luyện tập
- **Quiz cuối bài học**: hiệu ứng đúng/sai, confetti. *(Mục "Bài toán mỗi ngày" đã bỏ hoàn toàn theo yêu cầu ngày 2026-11-09.)*
- Mục menu "Luyện tập" đổi tên thành **"Đề thi"**.
- **Bài kiểm tra trắc nghiệm kiểu đề thi Toán THPT Quốc gia**:
  - Ngân hàng câu hỏi: nội dung viết bằng **Markdown** (có công thức LaTeX, **chèn được ảnh**).
  - Mặc định **4 lựa chọn A B C D**, có thể **ít hơn / nhiều hơn** tùy ý.
  - Khi tạo bài kiểm tra: **chọn các câu hỏi có sẵn** trong ngân hàng để thêm vào.
  - Làm bài: đồng hồ đếm ngược, bảng chọn câu, nộp bài, chấm điểm thang 10, xem lời giải.

### 4.4 Dashboard học viên
- Tiến độ khóa học, XP, streak, huy hiệu, lịch sử làm bài kiểm tra.

### 4.5 Tạp chí Toán (bản đầu: khung cơ bản)
- Trang danh sách các số tạp chí (ảnh bìa, tóm tắt).
- Xem **PDF** ngay trên web + tải về. Không chạy LaTeX trên server, chỉ upload file PDF.

### 4.6 Trang Admin
- Thống kê tổng quan.
- Quản lý khóa học và bài học.
- Ngân hàng câu hỏi (soạn Markdown, xem trước trực tiếp, upload ảnh).
- Tạo bài kiểm tra bằng cách chọn câu hỏi từ ngân hàng.
- Upload PDF tạp chí.
- Danh sách người dùng.

### 4.7 Giao diện & animation
- Hero có ký hiệu toán học bay, chữ gradient chuyển động, số liệu đếm tăng dần.
- Nút có hiệu ứng ripple / magnetic, thẻ có hiệu ứng nghiêng 3D khi hover.
- Nội dung hiện dần khi cuộn, vòng tiến độ có animation, confetti khi trả lời đúng.
- Responsive cho điện thoại, có tôn trọng `prefers-reduced-motion`.

## 5. Dữ liệu demo
- File `data/demo.json` chứa: người dùng, giảng viên, khóa học + bài học, câu hỏi, bài kiểm tra, tạp chí, huy hiệu, cảm nhận học viên.
- Website chạy thử hoàn toàn trên dữ liệu này.
