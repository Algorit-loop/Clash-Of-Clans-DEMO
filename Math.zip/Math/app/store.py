"""JSON file store — the whole app reads/writes data/demo.json (no database).

Writes are serialised with a lock and saved atomically (tmp file + rename),
so a crash mid-write never leaves a half-written demo.json.
"""
from __future__ import annotations

import json
import os
import shutil
import threading
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Iterator

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = Path(os.environ.get("MATH_DATA_FILE", BASE_DIR / "data" / "demo.json"))
SEED_FILE = DATA_FILE.with_name("demo.seed.json")


class Store:
    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.RLock()
        if not path.exists() and SEED_FILE.exists():
            shutil.copy(SEED_FILE, path)
        self.data: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))

    # ---- read helpers -------------------------------------------------
    @property
    def db(self) -> dict[str, Any]:
        return self.data

    def find(self, collection: str, **match: Any) -> dict | None:
        for item in self.data.get(collection, []):
            if all(item.get(k) == v for k, v in match.items()):
                return item
        return None

    def filter(self, collection: str, **match: Any) -> list[dict]:
        return [i for i in self.data.get(collection, []) if all(i.get(k) == v for k, v in match.items())]

    def next_id(self, collection: str) -> int:
        items = self.data.get(collection, [])
        return max((int(i.get("id", 0)) for i in items), default=0) + 1

    # ---- write --------------------------------------------------------
    @contextmanager
    def write(self) -> Iterator[dict[str, Any]]:
        with self._lock:
            yield self.data
            self._save()

    def _save(self) -> None:
        tmp = self.path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, self.path)


store = Store(DATA_FILE)


# ---- small shared helpers ---------------------------------------------
def now_iso() -> str:
    return datetime.now().replace(microsecond=0).isoformat()


def today_str() -> str:
    return date.today().isoformat()


def touch_activity(user: dict, xp: int = 0) -> None:
    """Update XP and daily streak for a user (call inside store.write())."""
    today = date.today()
    last = user.get("last_active")
    if last != today.isoformat():
        if last == (today - timedelta(days=1)).isoformat():
            user["streak"] = user.get("streak", 0) + 1
        else:
            user["streak"] = 1
        user["last_active"] = today.isoformat()
    user["xp"] = user.get("xp", 0) + xp


def award_badges(db: dict, user: dict) -> list[str]:
    """Grant any newly earned badges, return their ids."""
    uid = user["id"]
    have = set(user.setdefault("badges", []))
    lessons_done = sum(1 for p in db["progress"] if p["user_id"] == uid)
    attempts = [a for a in db["attempts"] if a["user_id"] == uid]
    rules = {
        "first_step": lessons_done >= 1,
        "scholar": lessons_done >= 10,
        "first_exam": len(attempts) >= 1,
        "perfect": any(a["score"] >= 10 for a in attempts),
        "streak_3": user.get("streak", 0) >= 3,
        "streak_7": user.get("streak", 0) >= 7,
        "xp_500": user.get("xp", 0) >= 500,
    }
    new = [b for b, ok in rules.items() if ok and b not in have]
    user["badges"].extend(new)
    return new
