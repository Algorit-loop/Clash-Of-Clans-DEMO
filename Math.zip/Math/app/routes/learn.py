"""Practice, mock exams, dashboard and the small JSON API used by the pages."""
from __future__ import annotations

import json
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Form, HTTPException, Request
from pydantic import BaseModel

from ..deps import (completed_lessons, course_progress, current_user, is_enrolled, public_question, redirect, render, require_user)
from ..store import award_badges, now_iso, store, touch_activity

router = APIRouter()

XP_LESSON = 20
XP_QUIZ = 5


def badge_names(ids: list[str], request: Request) -> list[str]:
    from ..deps import get_lang
    from ..i18n import pick
    lang = get_lang(request)
    bmap = {b["id"]: b for b in store.db["badges"]}
    return [f"{bmap[i]['icon']} {pick(bmap[i]['name'], lang)}" for i in ids if i in bmap]


def exam_questions(exam: dict) -> list[dict]:
    qmap = {q["id"]: q for q in store.db["questions"]}
    return [qmap[i] for i in exam.get("question_ids", []) if i in qmap]


# ---- practice ----------------------------------------------------------
@router.get("/practice")
def practice(request: Request):
    user = current_user(request)
    exams = [e for e in store.db["exams"] if e.get("published", True) or (user and user["role"] == "admin")]
    best = {}
    if user:
        for a in store.filter("attempts", user_id=user["id"]):
            best[a["exam_id"]] = max(best.get(a["exam_id"], 0), a["score"])
    return render(request, "practice.html", {"exams": exams, "best": best})


@router.get("/exams/{exam_id}")
def exam_take(request: Request, exam_id: int):
    user = require_user(request)
    exam = store.find("exams", id=exam_id)
    if not exam or not (exam.get("published", True) or user["role"] == "admin"):
        raise HTTPException(404)
    qs = [public_question(q) for q in exam_questions(exam)]
    return render(request, "exam_take.html", {"exam": exam, "questions": qs, "started_at": now_iso()})


@router.post("/exams/{exam_id}/submit")
def exam_submit(request: Request, exam_id: int, answers: str = Form("{}"), started_at: str = Form("")):
    user = require_user(request)
    exam = store.find("exams", id=exam_id)
    if not exam:
        raise HTTPException(404)
    try:
        raw = json.loads(answers or "{}")
    except json.JSONDecodeError:
        raw = {}
    qs = exam_questions(exam)
    picked: dict[str, int] = {}
    correct = 0
    for q in qs:
        v = raw.get(str(q["id"]))
        if isinstance(v, int) and 0 <= v < len(q["options"]):
            picked[str(q["id"])] = v
            if v == q["answer"]:
                correct += 1
    total = len(qs) or 1
    score = round(10 * correct / total, 2)
    try:
        dur = int((datetime.now() - datetime.fromisoformat(started_at)).total_seconds())
    except ValueError:
        dur = 0
    dur = max(0, min(dur, exam.get("duration_min", 90) * 60 + 30))
    with store.write() as db:
        aid = store.next_id("attempts")
        db["attempts"].append({"id": aid, "user_id": user["id"], "exam_id": exam_id, "answers": picked,
                               "correct": correct, "total": len(qs), "score": score,
                               "started_at": started_at, "submitted_at": now_iso(), "duration_sec": dur})
        u = store.find("users", id=user["id"])
        # XP FARMING DISABLED (temporary): every retake re-awarded 10 XP per correct answer.
        # Re-enable only after adding "XP once per exam/question" tracking.
        # touch_activity(u, xp=correct * 10)
        touch_activity(u, xp=0)  # still counts toward the daily streak
        new_badges = award_badges(db, u)
    request.session["new_badges"] = new_badges
    return redirect(f"/attempts/{aid}")


@router.get("/attempts/{attempt_id}")
def attempt_result(request: Request, attempt_id: int):
    user = require_user(request)
    att = store.find("attempts", id=attempt_id)
    if not att or (att["user_id"] != user["id"] and user["role"] != "admin"):
        raise HTTPException(404)
    exam = store.find("exams", id=att["exam_id"]) or {"title": "?", "id": att["exam_id"]}
    qs = exam_questions(exam) if "question_ids" in exam else []
    badges = {b["id"]: b for b in store.db["badges"]}
    new_badges = [badges[b] for b in request.session.pop("new_badges", []) if b in badges]
    return render(request, "exam_result.html", {"att": att, "exam": exam, "questions": qs, "new_badges": new_badges})


# ---- dashboard ---------------------------------------------------------
@router.get("/dashboard")
def dashboard(request: Request):
    user = require_user(request)
    db = store.db
    my = [c for c in db["courses"] if is_enrolled(user, c)]
    attempts = sorted(store.filter("attempts", user_id=user["id"]), key=lambda a: a["submitted_at"], reverse=True)
    exams = {e["id"]: e for e in db["exams"]}
    lessons_done = sum(1 for p in db["progress"] if p["user_id"] == user["id"])
    avg = round(sum(a["score"] for a in attempts) / len(attempts), 2) if attempts else 0
    xp = user.get("xp", 0)
    level = xp // 200 + 1
    # activity heat-map: count of actions per day over the last 12 weeks
    activity: dict[str, int] = {}
    for p in db["progress"]:
        if p["user_id"] == user["id"]:
            activity[p["completed_at"][:10]] = activity.get(p["completed_at"][:10], 0) + 1
    for a in attempts:
        activity[a["submitted_at"][:10]] = activity.get(a["submitted_at"][:10], 0) + 1
    recommended = [c for c in db["courses"] if c not in my and c["level"] == user.get("level")][:3]
    # first unfinished lesson in the most recently enrolled course that isn't complete yet
    resume = None
    enrolled_order = sorted((e for e in db["enrollments"] if e["user_id"] == user["id"]), key=lambda e: e["enrolled_at"], reverse=True)
    cmap = {c["id"]: c for c in my}
    for e in enrolled_order:
        c = cmap.get(e["course_id"])
        nxt = next((l for l in c["lessons"] if l["id"] not in completed_lessons(user, c)), None) if c else None
        if nxt:
            resume = {"course": c, "lesson": nxt}
            break
    # 12 weeks, column-major (Mon..Sun) ending this week
    today = date.today()
    start = today - timedelta(days=today.weekday() + 7 * 11)
    heat = []
    for i in range((today - start).days + 1):
        n = activity.get((start + timedelta(days=i)).isoformat(), 0)
        heat.append(0 if n == 0 else 1 if n == 1 else 2 if n <= 3 else 3)
    return render(request, "dashboard.html", {
        "my": my, "progress": {c["id"]: course_progress(user, c) for c in my},
        "attempts": attempts[:6], "exams": exams, "lessons_done": lessons_done, "avg": avg,
        "level": level, "level_pct": round(100 * (xp % 200) / 200), "badges": db["badges"],
        "heat": heat, "recommended": recommended, "resume": resume,
    })


# ---- JSON API ----------------------------------------------------------
class QuizCheck(BaseModel):
    question_id: int
    choice: int


class LessonDone(BaseModel):
    course_id: int
    lesson_id: int


@router.post("/api/quiz/check")
def api_quiz_check(request: Request, body: QuizCheck):
    q = store.find("questions", id=body.question_id)
    if not q:
        raise HTTPException(404)
    ok = body.choice == q["answer"]
    user = current_user(request)
    # XP FARMING DISABLED (temporary): the same correct answer could be re-submitted for +5 XP each time.
    # Re-enable only after tracking which quiz questions already paid out XP per user.
    # if ok and user:
    #     with store.write():
    #         touch_activity(user, xp=XP_QUIZ)
    return {"correct": ok, "xp": 0, "answer": q["answer"] if ok else None,
            "explanation": q.get("explanation", "") if ok else ""}


@router.post("/api/lessons/complete")
def api_lesson_complete(request: Request, body: LessonDone):
    user = current_user(request)
    if not user:
        raise HTTPException(401)
    course = store.find("courses", id=body.course_id)
    if not course or not any(l["id"] == body.lesson_id for l in course["lessons"]):
        raise HTTPException(404)
    if not (is_enrolled(user, course) or user["role"] == "admin"):
        raise HTTPException(403)
    xp = 0
    badges: list[str] = []
    if not store.find("progress", user_id=user["id"], course_id=course["id"], lesson_id=body.lesson_id):
        with store.write() as db:
            db["progress"].append({"user_id": user["id"], "course_id": course["id"], "lesson_id": body.lesson_id,
                                   "completed_at": now_iso()})
            xp = XP_LESSON
            touch_activity(user, xp=xp)
            badges = award_badges(db, user)
    return {"ok": True, "xp": xp, "total_xp": user.get("xp", 0), "progress": course_progress(user, course),
            "badges": badge_names(badges, request)}
