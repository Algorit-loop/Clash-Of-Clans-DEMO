"""Admin panel: courses + lessons, question bank, exam builder, magazine PDFs, users."""
from __future__ import annotations

import re
import secrets
from pathlib import Path

from fastapi import APIRouter, File, Form, HTTPException, Request, UploadFile

from ..deps import APP_DIR, flash, redirect, render, require_admin, t_req, youtube_id
from ..store import now_iso, store

router = APIRouter(prefix="/admin")

UPLOAD_IMG = APP_DIR / "static" / "uploads" / "images"
UPLOAD_PDF = APP_DIR / "static" / "magazine"
IMG_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp"}  # no SVG: it can carry scripts
MAX_IMG = 5 * 1024 * 1024
MAX_PDF = 50 * 1024 * 1024


def slugify(s: str) -> str:
    table = str.maketrans("àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ",
                          "aaaaaaaaaaaaaaaaaeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyyd")
    s = s.lower().translate(table)
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-") or secrets.token_hex(3)


def save_upload(f: UploadFile, folder: Path, allowed: set[str], max_size: int) -> str:
    ext = Path(f.filename or "").suffix.lower()
    if ext not in allowed:
        raise HTTPException(400, f"File type {ext or '?'} not allowed")
    data = f.file.read(max_size + 1)
    if len(data) > max_size:
        raise HTTPException(400, "File too large")
    if ext == ".pdf" and not data.startswith(b"%PDF"):
        raise HTTPException(400, "Not a PDF file")
    name = f"{slugify(Path(f.filename).stem)[:40]}-{secrets.token_hex(4)}{ext}"
    (folder / name).write_bytes(data)
    return "/" + str((folder / name).relative_to(APP_DIR)).replace("\\", "/")


# ---- overview ----------------------------------------------------------
@router.get("")
def admin_home(request: Request):
    require_admin(request)
    db = store.db
    stats = {
        "users": len(db["users"]), "courses": len(db["courses"]), "questions": len(db["questions"]),
        "exams": len(db["exams"]), "enrollments": len(db["enrollments"]), "attempts": len(db["attempts"]),
        "revenue": sum(p["amount"] for p in db["payments"]), "issues": len(db["magazine"]),
    }
    users = {u["id"]: u for u in db["users"]}
    exams = {e["id"]: e for e in db["exams"]}
    recent = sorted(db["attempts"], key=lambda a: a["submitted_at"], reverse=True)[:8]
    by_course = sorted(((c, sum(1 for e in db["enrollments"] if e["course_id"] == c["id"])) for c in db["courses"]),
                       key=lambda x: -x[1])
    return render(request, "admin/index.html", {"stats": stats, "recent": recent, "users": users, "exams": exams,
                                                "by_course": by_course, "section": "overview"})


# ---- courses -----------------------------------------------------------
def _course_form_ctx(course: dict | None) -> dict:
    return {"course": course, "categories": store.db["categories"], "instructors": store.db["instructors"],
            "section": "courses"}


@router.get("/courses")
def admin_courses(request: Request):
    require_admin(request)
    return render(request, "admin/courses.html", {"courses": store.db["courses"], "section": "courses"})


@router.get("/courses/new")
def admin_course_new(request: Request):
    require_admin(request)
    return render(request, "admin/course_form.html", _course_form_ctx(None))


@router.get("/courses/{cid}")
def admin_course_edit(request: Request, cid: int):
    require_admin(request)
    course = store.find("courses", id=cid)
    if not course:
        raise HTTPException(404)
    return render(request, "admin/course_form.html", _course_form_ctx(course))


@router.post("/courses/save")
async def admin_course_save(request: Request):
    require_admin(request)
    f = await request.form()
    cid = int(f.get("id") or 0)
    data = {
        "title": {"vi": f.get("title_vi", "").strip(), "en": f.get("title_en", "").strip()},
        "subtitle": {"vi": f.get("subtitle_vi", "").strip(), "en": f.get("subtitle_en", "").strip()},
        "description": {"vi": f.get("description_vi", ""), "en": f.get("description_en", "")},
        "level": f.get("level", "thpt"), "category": f.get("category", ""),
        "instructor_id": int(f.get("instructor_id") or 1),
        "price": int(f.get("price") or 0), "old_price": int(f.get("old_price") or 0),
        "duration_hours": float(f.get("duration_hours") or 0),
        "color": f.get("color", "#7c5cff"), "icon": f.get("icon", "∑")[:3],    }
    with store.write() as db:
        if cid:
            course = store.find("courses", id=cid)
            if not course:
                raise HTTPException(404)
            course.update(data)
        else:
            cid = store.next_id("courses")
            course = {"id": cid, "slug": f"{slugify(data['title']['vi'])}-{cid}", "rating": 5.0, "students": 0,
                      "lessons": [], "created_at": now_iso(), **data}
            db["courses"].append(course)
    flash(request, t_req(request, "admin.saved"))
    return redirect(f"/admin/courses/{cid}")


@router.post("/courses/{cid}/delete")
def admin_course_delete(request: Request, cid: int):
    require_admin(request)
    with store.write() as db:
        db["courses"] = [c for c in db["courses"] if c["id"] != cid]
        db["enrollments"] = [e for e in db["enrollments"] if e["course_id"] != cid]
        db["progress"] = [p for p in db["progress"] if p["course_id"] != cid]
    flash(request, t_req(request, "admin.deleted"))
    return redirect("/admin/courses")


@router.get("/courses/{cid}/lessons/{lid}")
def admin_lesson_edit(request: Request, cid: int, lid: int):
    require_admin(request)
    course = store.find("courses", id=cid)
    if not course:
        raise HTTPException(404)
    lesson = next((l for l in course["lessons"] if l["id"] == lid), None) if lid else None
    if lid and not lesson:
        raise HTTPException(404)
    return render(request, "admin/lesson_form.html", {"course": course, "lesson": lesson,
                                                      "questions": store.db["questions"], "section": "courses"})


@router.post("/courses/{cid}/lessons/save")
async def admin_lesson_save(request: Request, cid: int):
    require_admin(request)
    f = await request.form()
    lid = int(f.get("id") or 0)
    qids = {q["id"] for q in store.db["questions"]}
    data = {
        "title": {"vi": f.get("title_vi", "").strip(), "en": f.get("title_en", "").strip()},
        "video": youtube_id(f.get("video", "")),
        "duration_min": int(f.get("duration_min") or 0),
        "preview": f.get("preview") == "on",
        "content": {"vi": f.get("content_vi", ""), "en": f.get("content_en", "")},
        "quiz": [int(x) for x in f.getlist("quiz") if x.isdigit() and int(x) in qids],
    }
    with store.write():
        course = store.find("courses", id=cid)
        if not course:
            raise HTTPException(404)
        if lid:
            lesson = next((l for l in course["lessons"] if l["id"] == lid), None)
            if not lesson:
                raise HTTPException(404)
            lesson.update(data)
        else:
            lid = max((l["id"] for c in store.db["courses"] for l in c["lessons"]), default=0) + 1
            course["lessons"].append({"id": lid, **data})
    flash(request, t_req(request, "admin.saved"))
    return redirect(f"/admin/courses/{cid}")


@router.post("/courses/{cid}/lessons/{lid}/delete")
def admin_lesson_delete(request: Request, cid: int, lid: int):
    require_admin(request)
    with store.write() as db:
        course = store.find("courses", id=cid)
        if course:
            course["lessons"] = [l for l in course["lessons"] if l["id"] != lid]
        db["progress"] = [p for p in db["progress"] if not (p["course_id"] == cid and p["lesson_id"] == lid)]
    flash(request, t_req(request, "admin.deleted"))
    return redirect(f"/admin/courses/{cid}")


@router.post("/courses/{cid}/lessons/{lid}/move/{direction}")
def admin_lesson_move(request: Request, cid: int, lid: int, direction: str):
    require_admin(request)
    with store.write():
        course = store.find("courses", id=cid)
        ls = course["lessons"] if course else []
        i = next((k for k, l in enumerate(ls) if l["id"] == lid), None)
        j = (i - 1 if direction == "up" else i + 1) if i is not None else None
        if j is not None and 0 <= j < len(ls):
            ls[i], ls[j] = ls[j], ls[i]
    return redirect(f"/admin/courses/{cid}")


# ---- question bank -----------------------------------------------------
def topics() -> list[str]:
    return sorted({q.get("topic", "") for q in store.db["questions"] if q.get("topic")})


@router.get("/questions")
def admin_questions(request: Request, topic: str = "", difficulty: int = 0, q: str = ""):
    require_admin(request)
    items = store.db["questions"]
    if topic:
        items = [x for x in items if x.get("topic") == topic]
    if difficulty:
        items = [x for x in items if x.get("difficulty") == difficulty]
    if q:
        items = [x for x in items if q.lower() in x["content"].lower()]
    usage = {}
    for e in store.db["exams"]:
        for i in e["question_ids"]:
            usage[i] = usage.get(i, 0) + 1
    return render(request, "admin/questions.html", {"questions": sorted(items, key=lambda x: -x["id"]),
                                                    "topics": topics(), "topic": topic, "difficulty": difficulty,
                                                    "q": q, "usage": usage, "section": "questions"})


@router.get("/questions/{qid}")
def admin_question_edit(request: Request, qid: int):
    require_admin(request)
    question = store.find("questions", id=qid) if qid else None
    if qid and not question:
        raise HTTPException(404)
    return render(request, "admin/question_form.html", {"question": question, "topics": topics(),
                                                        "section": "questions"})


@router.post("/questions/save")
async def admin_question_save(request: Request):
    require_admin(request)
    f = await request.form()
    qid = int(f.get("id") or 0)
    options = [o for o in f.getlist("options")]
    answer = int(f.get("answer") or 0)
    # drop empty trailing options but keep the answer index valid
    cleaned = [o for o in options if o.strip()]
    if len(cleaned) < 2:
        flash(request, "≥ 2 options", "error")
        return redirect(f"/admin/questions/{qid}")
    answer_text = options[answer] if 0 <= answer < len(options) else cleaned[0]
    answer = cleaned.index(answer_text) if answer_text in cleaned else 0
    data = {
        "content": f.get("content", ""), "options": cleaned, "answer": answer,
        "explanation": f.get("explanation", ""), "topic": f.get("topic", "").strip() or "Khác",
        "difficulty": int(f.get("difficulty") or 1), "grade": int(f.get("grade") or 12),    }
    with store.write() as db:
        if qid:
            question = store.find("questions", id=qid)
            if not question:
                raise HTTPException(404)
            question.update(data)
        else:
            qid = store.next_id("questions")
            db["questions"].append({"id": qid, "created_at": now_iso(), **data})
    flash(request, t_req(request, "admin.saved"))
    return redirect("/admin/questions")


@router.post("/questions/{qid}/delete")
def admin_question_delete(request: Request, qid: int):
    require_admin(request)
    used = False
    with store.write() as db:
        db["questions"] = [q for q in db["questions"] if q["id"] != qid]
        for e in db["exams"]:
            if qid in e["question_ids"]:
                e["question_ids"].remove(qid)
                used = True
        for c in db["courses"]:
            for l in c["lessons"]:
                if qid in l.get("quiz", []):
                    l["quiz"].remove(qid)
                    used = True
    flash(request, t_req(request, "admin.in_use" if used else "admin.deleted"), "info" if used else "success")
    return redirect("/admin/questions")


@router.post("/upload/image")
def admin_upload_image(request: Request, file: UploadFile = File(...)):
    require_admin(request)
    url = save_upload(file, UPLOAD_IMG, IMG_EXT, MAX_IMG)
    return {"url": url}


# ---- exams -------------------------------------------------------------
@router.get("/exams")
def admin_exams(request: Request):
    require_admin(request)
    counts = {}
    for a in store.db["attempts"]:
        counts[a["exam_id"]] = counts.get(a["exam_id"], 0) + 1
    return render(request, "admin/exams.html", {"exams": store.db["exams"], "counts": counts, "section": "exams"})


@router.get("/exams/{eid}")
def admin_exam_edit(request: Request, eid: int):
    require_admin(request)
    exam = store.find("exams", id=eid) if eid else None
    if eid and not exam:
        raise HTTPException(404)
    return render(request, "admin/exam_form.html", {"exam": exam, "questions": store.db["questions"],
                                                    "topics": topics(), "section": "exams"})


@router.post("/exams/save")
async def admin_exam_save(request: Request):
    require_admin(request)
    f = await request.form()
    eid = int(f.get("id") or 0)
    valid = {q["id"] for q in store.db["questions"]}
    order = [int(x) for x in f.get("question_ids", "").split(",") if x.strip().isdigit()]
    seen: set[int] = set()
    qids = [x for x in order if x in valid and not (x in seen or seen.add(x))]
    data = {
        "title": {"vi": f.get("title_vi", "").strip(), "en": f.get("title_en", "").strip()},
        "description": {"vi": f.get("description_vi", ""), "en": f.get("description_en", "")},
        "duration_min": int(f.get("duration_min") or 90), "level": f.get("level", "thpt"),
        "published": f.get("published") == "on", "question_ids": qids,
    }
    with store.write() as db:
        if eid:
            exam = store.find("exams", id=eid)
            if not exam:
                raise HTTPException(404)
            exam.update(data)
        else:
            eid = store.next_id("exams")
            db["exams"].append({"id": eid, "created_at": now_iso(), **data})
    flash(request, t_req(request, "admin.saved"))
    return redirect("/admin/exams")


@router.post("/exams/{eid}/delete")
def admin_exam_delete(request: Request, eid: int):
    require_admin(request)
    with store.write() as db:
        db["exams"] = [e for e in db["exams"] if e["id"] != eid]
    flash(request, t_req(request, "admin.deleted"))
    return redirect("/admin/exams")


# ---- magazine ----------------------------------------------------------
@router.get("/magazine")
def admin_magazine(request: Request):
    require_admin(request)
    return render(request, "admin/magazine.html", {"issues": sorted(store.db["magazine"], key=lambda m: -m["issue"]),
                                                   "next_issue": max((m["issue"] for m in store.db["magazine"]), default=0) + 1,
                                                   "section": "magazine"})


@router.post("/magazine/upload")
def admin_magazine_upload(request: Request, pdf: UploadFile = File(...), title_vi: str = Form(""),
                          title_en: str = Form(""), summary_vi: str = Form(""), summary_en: str = Form(""),
                          issue: int = Form(1), published: str = Form(""), color: str = Form("#7c5cff"),
                          symbol: str = Form("π"), topics_: str = Form("", alias="topics")):
    require_admin(request)
    url = save_upload(pdf, UPLOAD_PDF, {".pdf"}, MAX_PDF)
    with store.write() as db:
        mid = store.next_id("magazine")
        db["magazine"].append({
            "id": mid, "issue": issue, "title": {"vi": title_vi, "en": title_en or title_vi},
            "summary": {"vi": summary_vi, "en": summary_en or summary_vi}, "published": published or now_iso()[:10],
            "pdf": url, "pages": None, "color": color, "symbol": symbol[:3] or "π",
            "topics": [t.strip() for t in topics_.split(",") if t.strip()], "articles": [],
        })
    flash(request, t_req(request, "admin.saved"))
    return redirect("/admin/magazine")


@router.post("/magazine/{mid}/delete")
def admin_magazine_delete(request: Request, mid: int):
    require_admin(request)
    with store.write() as db:
        item = store.find("magazine", id=mid)
        db["magazine"] = [m for m in db["magazine"] if m["id"] != mid]
    if item and item.get("pdf", "").startswith("/static/magazine/"):
        p = APP_DIR / item["pdf"].lstrip("/")
        if p.exists() and p.parent == UPLOAD_PDF:
            p.unlink()
    flash(request, t_req(request, "admin.deleted"))
    return redirect("/admin/magazine")


# ---- users -------------------------------------------------------------
@router.get("/users")
def admin_users(request: Request):
    require_admin(request)
    db = store.db
    enroll = {}
    for e in db["enrollments"]:
        enroll[e["user_id"]] = enroll.get(e["user_id"], 0) + 1
    return render(request, "admin/users.html", {"users": db["users"], "enroll": enroll, "section": "users"})


@router.post("/users/{uid}/role")
def admin_user_role(request: Request, uid: int, role: str = Form(...)):
    me = require_admin(request)
    if role in ("student", "university", "admin") and uid != me["id"]:
        with store.write():
            u = store.find("users", id=uid)
            if u:
                u["role"] = role
    flash(request, t_req(request, "admin.saved"))
    return redirect("/admin/users")
