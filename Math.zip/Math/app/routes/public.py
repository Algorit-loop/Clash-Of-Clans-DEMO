"""Public pages: home, courses, checkout, lessons, magazine, auth, language."""
from __future__ import annotations

from fastapi import APIRouter, Form, HTTPException, Request

from ..deps import (completed_lessons, course_progress, current_user, flash, is_enrolled, public_question, redirect,
                    render, require_user, t_req)
from ..i18n import LANGS
from ..security import hash_password, verify_password
from ..store import award_badges, now_iso, store

router = APIRouter()


def get_course(slug: str) -> dict:
    course = store.find("courses", slug=slug)
    if not course:
        raise HTTPException(404)
    return course


# ---- home --------------------------------------------------------------
@router.get("/")
def home(request: Request):
    db = store.db
    courses = db["courses"]
    featured = sorted(courses, key=lambda c: -c.get("students", 0))[:6]
    stats = {
        "students": sum(c.get("students", 0) for c in courses) + len(db["users"]),
        "courses": len(courses),
        "questions": len(db["questions"]),
        "issues": len(db["magazine"]),
    }
    issues = sorted(db["magazine"], key=lambda m: -m["issue"])[:4]
    return render(request, "home.html", {
        "featured": featured, "stats": stats, "issues": issues,
        "testimonials": db["testimonials"], "instructors": {i["id"]: i for i in db["instructors"]},
        "levels": ["thcs", "thpt", "university"],
        "level_counts": {lv: sum(1 for c in courses if c["level"] == lv) for lv in ("thcs", "thpt", "university")},
    })


@router.get("/lang/{lang}")
def set_lang(request: Request, lang: str):
    resp = redirect(request.headers.get("referer") or "/")
    if lang in LANGS:
        resp.set_cookie("lang", lang, max_age=60 * 60 * 24 * 365, samesite="lax")
    return resp


# ---- courses -----------------------------------------------------------
@router.get("/courses")
def courses(request: Request, level: str = "", category: str = "", q: str = ""):
    db = store.db
    user = current_user(request)
    items = db["courses"]
    if level:
        items = [c for c in items if c["level"] == level]
    if category:
        items = [c for c in items if c["category"] == category]
    if q:
        ql = q.lower()
        items = [c for c in items if ql in (str(c["title"]) + str(c.get("subtitle", ""))).lower()]
    return render(request, "courses.html", {
        "courses": items, "categories": db["categories"], "level": level, "category": category, "q": q,
        "instructors": {i["id"]: i for i in db["instructors"]},
        "progress": {c["id"]: course_progress(user, c) for c in items},
        "enrolled": {c["id"] for c in items if is_enrolled(user, c)},
    })


@router.get("/courses/{slug}")
def course_detail(request: Request, slug: str):
    course = get_course(slug)
    user = current_user(request)
    instructor = store.find("instructors", id=course["instructor_id"])
    category = store.find("categories", id=course["category"])
    return render(request, "course_detail.html", {
        "course": course, "instructor": instructor, "category": category,
        "enrolled": is_enrolled(user, course), "progress": course_progress(user, course),
        "done": completed_lessons(user, course),
    })


@router.post("/courses/{slug}/enroll")
def enroll_free(request: Request, slug: str):
    user = require_user(request)
    course = get_course(slug)
    if course.get("price", 0) > 0:
        return redirect(f"/courses/{slug}/checkout")
    if not is_enrolled(user, course):
        with store.write() as db:
            db["enrollments"].append({"user_id": user["id"], "course_id": course["id"], "enrolled_at": now_iso(), "paid": 0})
            course["students"] = course.get("students", 0) + 1
    flash(request, t_req(request, "course.enrolled"), "celebrate")
    first = course["lessons"][0]["id"] if course["lessons"] else None
    return redirect(f"/courses/{slug}/lessons/{first}" if first else f"/courses/{slug}")


@router.get("/courses/{slug}/checkout")
def checkout(request: Request, slug: str):
    user = require_user(request)
    course = get_course(slug)
    if is_enrolled(user, course):
        return redirect(f"/courses/{slug}")
    return render(request, "checkout.html", {"course": course})


@router.post("/courses/{slug}/checkout")
def checkout_pay(request: Request, slug: str, method: str = Form("card")):
    user = require_user(request)
    course = get_course(slug)
    if not is_enrolled(user, course):
        with store.write() as db:
            pid = store.next_id("payments")
            db["payments"].append({"id": pid, "user_id": user["id"], "course_id": course["id"],
                                   "amount": course.get("price", 0), "method": method, "status": "paid (demo)", "created_at": now_iso()})
            db["enrollments"].append({"user_id": user["id"], "course_id": course["id"], "enrolled_at": now_iso(),
                                      "paid": course.get("price", 0)})
            course["students"] = course.get("students", 0) + 1
    flash(request, t_req(request, "checkout.success"), "celebrate")
    first = course["lessons"][0]["id"] if course["lessons"] else None
    return redirect(f"/courses/{slug}/lessons/{first}" if first else f"/courses/{slug}")


@router.get("/courses/{slug}/lessons/{lesson_id}")
def lesson(request: Request, slug: str, lesson_id: int):
    course = get_course(slug)
    user = current_user(request)
    lessons = course["lessons"]
    idx = next((i for i, l in enumerate(lessons) if l["id"] == lesson_id), None)
    if idx is None:
        raise HTTPException(404)
    les = lessons[idx]
    enrolled = is_enrolled(user, course)
    if not (enrolled or les.get("preview") or (user and user["role"] == "admin")):
        flash(request, t_req(request, "course.locked"), "info")
        return redirect(f"/courses/{slug}")
    qmap = {q["id"]: q for q in store.db["questions"]}
    quiz = [public_question(qmap[i]) for i in les.get("quiz", []) if i in qmap]
    return render(request, "lesson.html", {
        "course": course, "lesson": les, "idx": idx, "quiz": quiz, "enrolled": enrolled,
        "prev": lessons[idx - 1] if idx > 0 else None, "next": lessons[idx + 1] if idx + 1 < len(lessons) else None,
        "done": completed_lessons(user, course), "progress": course_progress(user, course),
    })


# ---- magazine ----------------------------------------------------------
@router.get("/magazine")
def magazine(request: Request):
    issues = sorted(store.db["magazine"], key=lambda m: -m["issue"])
    return render(request, "magazine.html", {"issues": issues})


@router.get("/magazine/{issue_id}")
def magazine_issue(request: Request, issue_id: int):
    issue = store.find("magazine", id=issue_id)
    if not issue:
        raise HTTPException(404)
    others = [m for m in sorted(store.db["magazine"], key=lambda m: -m["issue"]) if m["id"] != issue_id][:3]
    return render(request, "magazine_issue.html", {"issue": issue, "others": others})


# ---- auth --------------------------------------------------------------
@router.get("/login")
def login_page(request: Request, next: str = "/dashboard"):
    return render(request, "auth.html", {"mode": "login", "next": next, "demo": True})


@router.post("/login")
def login(request: Request, email: str = Form(""), password: str = Form(""), next: str = Form("/dashboard")):
    user = store.find("users", email=email.strip().lower())
    if not user or not verify_password(password, user.get("password_hash", "")):
        return render(request, "auth.html", {"mode": "login", "next": next, "error": t_req(request, "auth.bad_login"),
                                             "email": email, "demo": True}, status_code=400)
    request.session["uid"] = user["id"]
    with store.write() as db:
        award_badges(db, user)
    flash(request, f"{t_req(request, 'auth.welcome')}, {user['name']}! 👋")
    if user["role"] == "admin" and next == "/dashboard":  # default landing page for admins
        return redirect("/admin")
    return redirect(next if next.startswith("/") and not next.startswith("//") else "/dashboard")


@router.get("/register")
def register_page(request: Request):
    return render(request, "auth.html", {"mode": "register", "next": "/dashboard"})


@router.post("/register")
def register(request: Request, name: str = Form(""), email: str = Form(""), password: str = Form(""),
             role: str = Form("student"), level: str = Form("thpt")):
    email = email.strip().lower()
    ctx = {"mode": "register", "name": name, "email": email, "next": "/dashboard"}
    if not name.strip() or "@" not in email or len(password) < 6:
        return render(request, "auth.html", {**ctx, "error": t_req(request, "auth.invalid")}, status_code=400)
    if store.find("users", email=email):
        return render(request, "auth.html", {**ctx, "error": t_req(request, "auth.email_taken")}, status_code=400)
    role = role if role in ("student", "university") else "student"
    level = level if level in ("thcs", "thpt", "university") else "thpt"
    colors = ["#7c5cff", "#ff6b9a", "#00c2a8", "#ffb020", "#3b82f6", "#f97316"]
    with store.write() as db:
        uid = store.next_id("users")
        db["users"].append({
            "id": uid, "name": name.strip(), "email": email, "password_hash": hash_password(password),
            "role": role, "level": level, "avatar_color": colors[uid % len(colors)],
            "xp": 0, "streak": 0, "last_active": None, "badges": [], "created_at": now_iso(),
        })
    request.session["uid"] = uid
    flash(request, f"{t_req(request, 'auth.welcome')}, {name.strip()}! 🎉", "celebrate")
    return redirect("/dashboard")


@router.post("/logout")
def logout(request: Request):
    request.session.clear()
    return redirect("/")
