"""MathVerse — FastAPI entry point.

Run:  ./run.sh   (or  .venv/bin/uvicorn app.main:app --reload)
"""
from __future__ import annotations

import os
import secrets
from urllib.parse import quote

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.middleware.sessions import SessionMiddleware

from .deps import APP_DIR, LoginRequired, flash, redirect, render, t_req
from .routes import admin, learn, public
from .store import BASE_DIR


def _secret_key() -> str:
    if os.environ.get("MATH_SECRET"):
        return os.environ["MATH_SECRET"]
    f = BASE_DIR / "data" / ".secret_key"
    if not f.exists():
        f.write_text(secrets.token_urlsafe(48))
    return f.read_text().strip()


app = FastAPI(title="MathVerse", description="Học Toán · Thi thử · Tạp chí — API & pages", version="1.0.0")
app.add_middleware(SessionMiddleware, secret_key=_secret_key(), same_site="lax", max_age=60 * 60 * 24 * 14)
app.mount("/static", StaticFiles(directory=APP_DIR / "static"), name="static")

app.include_router(public.router)
app.include_router(learn.router)
app.include_router(admin.router)


@app.exception_handler(LoginRequired)
async def _login_required(request: Request, exc: LoginRequired):
    if request.url.path.startswith("/api/"):
        from fastapi.responses import JSONResponse
        return JSONResponse({"detail": "login required"}, status_code=401)
    flash(request, t_req(request, "auth.need_login"), "info")
    return redirect(f"/login?next={quote(request.url.path)}")


@app.exception_handler(StarletteHTTPException)
async def _http_error(request: Request, exc: StarletteHTTPException):
    if request.url.path.startswith(("/api/", "/static/")) or request.url.path.startswith("/admin/upload"):
        from fastapi.responses import JSONResponse
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)
    return render(request, "error.html", {"code": exc.status_code, "detail": exc.detail}, status_code=exc.status_code)
