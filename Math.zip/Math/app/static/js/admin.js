/* MathVerse admin helpers: live Markdown preview, image upload, options editor, exam picker */
(() => {
  "use strict";
  const { $, $$ } = MV;
  const LETTERS = "ABCDEFGHIJ";
  const debounce = (fn, ms = 200) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  /* ---- live preview: textarea[data-md-input] → nearest [data-md-preview] ---- */
  function bindPreview(ta, out) {
    out.dataset.label = MV.L("Xem trước", "Preview");
    const empty = `<span class="muted small">${MV.L("Gõ nội dung bên trái, kết quả hiện ở đây.", "Type on the left, the result shows here.")}</span>`;
    const draw = () => (out.innerHTML = MV.md(ta.value) || (out.closest(".opt-row") ? "" : empty));
    ta.addEventListener("input", debounce(draw, 150));
    draw();
  }
  function bindAllPreviews(scope = document) {
    $$("[data-md-input]", scope).forEach((ta) => {
      if (ta._bound) return;
      ta._bound = true;
      const out = ta.closest(".md-editor, .opt-row")?.querySelector("[data-md-preview]");
      if (out) bindPreview(ta, out);
    });
  }

  /* ---- image upload: button or paste → inserts ![](url) at cursor ---- */
  function insertAtCursor(ta, text) {
    const s = ta.selectionStart ?? ta.value.length, e = ta.selectionEnd ?? s;
    ta.value = ta.value.slice(0, s) + text + ta.value.slice(e);
    ta.selectionStart = ta.selectionEnd = s + text.length;
    ta.dispatchEvent(new Event("input"));
    ta.focus();
  }
  async function upload(file, ta) {
    const fd = new FormData();
    fd.append("file", file);
    MV.toast(MV.L("Đang tải ảnh…", "Uploading…"), "info", 1500);
    const r = await fetch("/admin/upload/image", { method: "POST", body: fd });
    if (!r.ok) { MV.toast((await r.json().catch(() => ({}))).detail || "Upload failed", "error"); return; }
    const { url } = await r.json();
    insertAtCursor(ta, `\n![${file.name.replace(/\.[^.]+$/, "")}](${url})\n`);
    MV.toast(MV.L("Đã chèn ảnh", "Image inserted"));
  }
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-upload]");
    if (!b) return;
    const ta = b.closest(".md-editor").querySelector("textarea");
    const inp = Object.assign(document.createElement("input"), { type: "file", accept: "image/*" });
    inp.onchange = () => inp.files[0] && upload(inp.files[0], ta);
    inp.click();
  });
  document.addEventListener("paste", (e) => {
    const ta = e.target.closest?.("textarea[data-md-input]");
    const file = [...(e.clipboardData?.files || [])].find((f) => f.type.startsWith("image/"));
    if (ta && file) { e.preventDefault(); upload(file, ta); }
  });

  /* ---- simple list filter: input[data-filter=".selector"] ---- */
  $$("[data-filter]").forEach((inp) => inp.addEventListener("input", () => {
    const q = inp.value.toLowerCase();
    $$(inp.dataset.filter).forEach((el) => el.classList.toggle("hidden", !(el.dataset.text || "").toLowerCase().includes(q)));
  }));

  /* ---- options editor (variable number, default 4 = A B C D) ---- */
  function optionsEditor(box, addBtn, options, answer) {
    function row(val, checked) {
      const r = document.createElement("div");
      r.className = "opt-row";
      r.innerHTML = `<label class="letter"><input type="radio" name="answer"><span></span></label>
        <textarea class="input" name="options" data-md-input rows="1"></textarea>
        <div class="preview" data-md-preview></div>
        <button type="button" class="btn btn-sm btn-ghost" title="✕">✕</button>`;
      $("textarea", r).value = val;
      $("input", r).checked = checked;
      $("button", r).onclick = () => {
        if ($$(".opt-row", box).length <= 2) return MV.toast(MV.L("Cần ít nhất 2 lựa chọn", "At least 2 options"), "error");
        const wasChecked = $("input", r).checked;
        r.remove(); renumber();
        if (wasChecked) $("input", box).checked = true;
      };
      box.appendChild(r);
      bindAllPreviews(r);
    }
    function renumber() {
      $$(".opt-row", box).forEach((r, i) => { $(".letter span", r).textContent = LETTERS[i]; $("input", r).value = i; });
      addBtn.disabled = $$(".opt-row", box).length >= LETTERS.length;
    }
    options.forEach((o, i) => row(o, i === answer));
    renumber();
    addBtn.addEventListener("click", () => { row("", false); renumber(); $$("textarea", box).pop().focus(); });
  }

  /* ---- exam builder: pick questions from the bank, keep order ---- */
  function examPicker() {
    const bank = $("#pk-bank"), sel = $("#pk-selected"), field = $("#qids");
    const items = $$(".pick-item", bank);
    const byId = Object.fromEntries(items.map((el) => [el.dataset.id, el]));
    let chosen = field.value.split(",").filter((x) => byId[x]);

    function render() {
      field.value = chosen.join(",");
      $("#pk-count").textContent = chosen.length;
      items.forEach((el) => el.classList.toggle("on", chosen.includes(el.dataset.id)));
      const mix = [0, 0, 0, 0];
      chosen.forEach((id) => mix[+byId[id].dataset.diff - 1]++);
      $("#pk-mix").textContent = mix.map((n, i) => `●${i + 1}:${n}`).join("  ");
      sel.innerHTML = "";
      chosen.forEach((id, i) => {
        const src = byId[id];
        const d = document.createElement("div");
        d.className = "sel-item";
        d.innerHTML = `<span class="n">${i + 1}.</span><div class="md"></div>
          <button type="button" class="btn btn-sm btn-ghost" data-act="up">↑</button>
          <button type="button" class="btn btn-sm btn-ghost" data-act="down">↓</button>
          <button type="button" class="btn btn-sm btn-ghost" data-act="rm">✕</button>`;
        $(".md", d).innerHTML = $("[data-md], .md", src).innerHTML;
        d.addEventListener("click", (e) => {
          const act = e.target.dataset.act;
          if (!act) return;
          if (act === "rm") chosen.splice(i, 1);
          if (act === "up" && i > 0) [chosen[i - 1], chosen[i]] = [chosen[i], chosen[i - 1]];
          if (act === "down" && i < chosen.length - 1) [chosen[i + 1], chosen[i]] = [chosen[i], chosen[i + 1]];
          render();
        });
        sel.appendChild(d);
      });
      if (!chosen.length) sel.innerHTML = `<div class="empty small">← ${MV.L("Bấm vào câu hỏi để thêm", "Click questions to add")}</div>`;
    }
    items.forEach((el) => el.addEventListener("click", () => {
      const id = el.dataset.id;
      chosen = chosen.includes(id) ? chosen.filter((x) => x !== id) : [...chosen, id];
      render();
    }));
    const visible = () => items.filter((el) => !el.classList.contains("hidden"));
    function filter() {
      const q = $("#pk-search").value.toLowerCase(), tp = $("#pk-topic").value, df = $("#pk-diff").value;
      items.forEach((el) => el.classList.toggle("hidden",
        (q && !el.dataset.text.includes(q) && el.dataset.id !== q.replace("#", "")) || (tp && el.dataset.topic !== tp) || (df && el.dataset.diff !== df)));
      $("#pk-visible").textContent = `${visible().length} ${MV.L("câu phù hợp", "matching")}`;
    }
    ["input", "change"].forEach((ev) => ["#pk-search", "#pk-topic", "#pk-diff"].forEach((s) => $(s).addEventListener(ev, filter)));
    $("#pk-random").addEventListener("click", () => {
      const pool = visible().map((el) => el.dataset.id).filter((id) => !chosen.includes(id));
      for (let i = pool.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [pool[i], pool[j]] = [pool[j], pool[i]]; }
      chosen = [...chosen, ...pool.slice(0, +$("#pk-n").value || 0)];
      render();
    });
    $("#pk-clear").addEventListener("click", () => { chosen = []; render(); });
    $("#exam-form").addEventListener("submit", (e) => {
      if (!chosen.length) { e.preventDefault(); MV.toast(MV.L("Hãy chọn ít nhất 1 câu hỏi", "Pick at least one question"), "error"); }
    });
    document.addEventListener("DOMContentLoaded", () => { render(); filter(); });
  }

  document.addEventListener("DOMContentLoaded", () => bindAllPreviews());
  window.MVAdmin = { optionsEditor, examPicker, bindAllPreviews };
})();
