/* MathVerse — shared front-end behaviour (vanilla JS, no build step) */
(() => {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const LANG = document.documentElement.lang || "vi";
  const MV = (window.MV = window.MV || {});
  MV.$ = $; MV.$$ = $$;
  MV.L = (vi, en) => (LANG === "en" ? en : vi);

  /* ---------- theme ---------- */
  const root = document.documentElement;
  function currentTheme() {
    return root.dataset.theme || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  }
  function setTheme(t) {
    root.dataset.theme = t;
    try { localStorage.setItem("theme", t); } catch (e) {}
    document.cookie = `theme=${t};path=/;max-age=31536000;samesite=lax`;
  }
  root.dataset.theme = currentTheme();
  $$("[data-theme-toggle]").forEach((b) => b.addEventListener("click", () => {
    const next = currentTheme() === "dark" ? "light" : "dark";
    if (document.startViewTransition && !reduce) document.startViewTransition(() => setTheme(next));
    else setTheme(next);
  }));

  /* ---------- markdown + KaTeX ---------- */
  const MATH_RE = /\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]|\\\(([\s\S]+?)\\\)|\$([^\$\n]+?)\$/g;
  MV.md = function (src) {
    if (!src) return "";
    const math = [];
    const text = String(src).replace(MATH_RE, (m, d1, d2, i1, i2) => {
      const display = d1 !== undefined || d2 !== undefined;
      math.push({ tex: d1 ?? d2 ?? i1 ?? i2, display });
      return `MVMATH${math.length - 1}X`;
    });
    let html = window.marked ? marked.parse(text, { breaks: true, gfm: true }) : text;
    if (window.DOMPurify) html = DOMPurify.sanitize(html);
    return html.replace(/MVMATH(\d+)X/g, (m, i) => {
      const { tex, display } = math[+i];
      try { return katex.renderToString(tex, { displayMode: display, throwOnError: false }); }
      catch (e) { return tex; }
    });
  };
  MV.renderMd = function (scope = document) {
    $$("[data-md]", scope).forEach((el) => {
      el.innerHTML = MV.md(el.dataset.md);
      el.classList.add("md");
    });
  };

  /* ---------- toasts / confetti / xp ---------- */
  let toastBox;
  MV.toast = function (msg, kind = "success", ms = 3800) {
    toastBox = toastBox || document.body.appendChild(Object.assign(document.createElement("div"), { className: "toasts" }));
    const icons = { success: "✅", error: "⚠️", info: "💡", celebrate: "🎉" };
    const el = document.createElement("div");
    el.className = `toast ${kind}`;
    el.innerHTML = `<span>${icons[kind] || "•"}</span><span></span>`;
    el.lastChild.textContent = msg;
    toastBox.appendChild(el);
    setTimeout(() => { el.classList.add("out"); setTimeout(() => el.remove(), 400); }, ms);
    if (kind === "celebrate") MV.confetti();
  };
  MV.confetti = function (opts = {}) {
    if (reduce || !window.confetti) return;
    const colors = ["#6d5dfc", "#ff5c8a", "#10c9a5", "#ffb020", "#3b82f6"];
    confetti({ particleCount: 110, spread: 75, origin: { y: 0.7 }, colors, ...opts });
    setTimeout(() => confetti({ particleCount: 60, angle: 60, spread: 60, origin: { x: 0 }, colors }), 180);
    setTimeout(() => confetti({ particleCount: 60, angle: 120, spread: 60, origin: { x: 1 }, colors }), 300);
  };
  MV.xpFloat = function (amount, el) {
    if (!amount) return;
    const r = (el || document.body).getBoundingClientRect();
    const f = document.createElement("div");
    f.className = "xp-float";
    f.textContent = `+${amount} XP`;
    f.style.left = `${r.left + r.width / 2 - 30}px`;
    f.style.top = `${r.top - 10}px`;
    document.body.appendChild(f);
    setTimeout(() => f.remove(), 1500);
    $$("[data-xp]").forEach((x) => { x.textContent = (+x.textContent || 0) + amount; });
  };
  MV.post = async function (url, body) {
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    if (!r.ok) throw Object.assign(new Error(r.statusText), { status: r.status });
    return r.json();
  };

  /* ---------- buttons: ripple + magnetic ---------- */
  document.addEventListener("pointerdown", (e) => {
    const b = e.target.closest(".btn, .opt");
    if (!b || reduce) return;
    const r = b.getBoundingClientRect();
    const s = Math.max(r.width, r.height);
    const c = document.createElement("span");
    c.className = "ripple";
    Object.assign(c.style, { width: `${s}px`, height: `${s}px`, left: `${e.clientX - r.left - s / 2}px`, top: `${e.clientY - r.top - s / 2}px` });
    b.appendChild(c);
    setTimeout(() => c.remove(), 700);
  });
  if (!reduce && matchMedia("(hover:hover)").matches) {
    $$(".magnetic").forEach((b) => {
      b.addEventListener("pointermove", (e) => {
        const r = b.getBoundingClientRect();
        b.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * 0.25}px, ${(e.clientY - r.top - r.height / 2) * 0.35}px)`;
      });
      b.addEventListener("pointerleave", () => (b.style.transform = ""));
    });
    /* 3D tilt + spotlight */
    $$("[data-tilt]").forEach((c) => {
      c.addEventListener("pointermove", (e) => {
        const r = c.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        c.style.transform = `perspective(900px) rotateX(${(0.5 - y) * 8}deg) rotateY(${(x - 0.5) * 10}deg) translateY(-6px)`;
        c.style.setProperty("--mx", `${x * 100}%`);
        c.style.setProperty("--my", `${y * 100}%`);
      });
      c.addEventListener("pointerleave", () => (c.style.transform = ""));
    });
  }

  /* ---------- reveal / counters / progress on scroll ---------- */
  function countUp(el) {
    const target = parseFloat(el.dataset.count);
    const dec = (el.dataset.count.split(".")[1] || "").length;
    const dur = 1600, t0 = performance.now();
    const fmt = (v) => v.toLocaleString(LANG === "en" ? "en-US" : "vi-VN", { minimumFractionDigits: dec, maximumFractionDigits: dec });
    if (reduce) { el.textContent = fmt(target) + (el.dataset.suffix || ""); return; }
    (function step(t) {
      const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 4);
      el.textContent = fmt(target * e) + (el.dataset.suffix || "");
      if (p < 1) requestAnimationFrame(step);
    })(t0);
  }
  const io = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (!en.isIntersecting) return;
      const el = en.target;
      el.classList.add("in");
      if (el.dataset.count !== undefined) countUp(el);
      if (el.dataset.progress !== undefined) el.style.width = `${el.dataset.progress}%`;
      if (el.dataset.ring !== undefined) {
        const c = el.querySelector(".fg"), len = 2 * Math.PI * c.r.baseVal.value;
        c.style.strokeDashoffset = len * (1 - el.dataset.ring / 100);
      }
      if (el.dataset.score !== undefined) el.style.setProperty("--p", el.dataset.score);
      io.unobserve(el);
    });
  }, { threshold: 0, rootMargin: "0px 0px -6% 0px" });
  MV.observe = (scope = document) => {
    $$("[data-reveal],[data-count],[data-progress],[data-ring],[data-score]", scope).forEach((el) => {
      if (el.dataset.ring !== undefined) {
        const c = el.querySelector(".fg"), len = 2 * Math.PI * c.r.baseVal.value;
        c.style.strokeDasharray = len; c.style.strokeDashoffset = len;
      }
      io.observe(el);
    });
  };
  /* stagger children */
  $$("[data-stagger]").forEach((p) => [...p.children].forEach((c, i) => { c.setAttribute("data-reveal", c.dataset.reveal || ""); c.style.setProperty("--d", `${i * 0.08}s`); }));

  /* ---------- nav ---------- */
  const nav = $(".nav");
  const onScroll = () => nav && nav.classList.toggle("scrolled", scrollY > 8);
  addEventListener("scroll", onScroll, { passive: true }); onScroll();
  $$("[data-burger]").forEach((b) => b.addEventListener("click", () => $(".nav-links").classList.toggle("open")));
  $$(".user-menu > button").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); b.parentElement.classList.toggle("open"); }));
  document.addEventListener("click", () => $$(".user-menu.open").forEach((m) => m.classList.remove("open")));

  /* confirm on destructive forms */
  document.addEventListener("submit", (e) => {
    const msg = e.target.dataset.confirm;
    if (msg && !confirm(msg)) e.preventDefault();
  });

  /* soft page-leave transition for internal links */
  document.addEventListener("click", (e) => {
    const a = e.target.closest("a[href]");
    if (!a || reduce || e.metaKey || e.ctrlKey || e.shiftKey || a.target || a.hasAttribute("download")) return;
    const url = new URL(a.href, location.href);
    if (url.origin !== location.origin || url.pathname.startsWith("/static") || url.hash && url.pathname === location.pathname) return;
    e.preventDefault();
    document.body.classList.add("leaving");
    setTimeout(() => (location.href = a.href), 180);
  });
  addEventListener("pageshow", () => document.body.classList.remove("leaving"));

  /* ---------- hero canvas: drifting math symbols ---------- */
  function heroCanvas(cv) {
    const ctx = cv.getContext("2d");
    const syms = ["π", "∑", "∫", "√", "∞", "θ", "Δ", "∂", "λ", "φ", "e", "i", "≈", "≠", "∇", "α", "β", "x²", "ƒ(x)", "n!", "∈", "⊂", "%"];
    let W, H, items = [], mx = 0, my = 0;
    const colors = ["#6d5dfc", "#ff5c8a", "#10c9a5", "#ffb020", "#3b82f6"];
    function resize() {
      const dpr = Math.min(devicePixelRatio || 1, 2);
      W = cv.clientWidth; H = cv.clientHeight; cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const n = Math.round((W * H) / 26000);
      items = Array.from({ length: n }, () => ({
        s: syms[(Math.random() * syms.length) | 0], x: Math.random() * W, y: Math.random() * H, z: 0.3 + Math.random() * 0.9,
        vx: (Math.random() - 0.5) * 0.25, vy: -0.1 - Math.random() * 0.3, r: Math.random() * 6.28, vr: (Math.random() - 0.5) * 0.01,
        c: colors[(Math.random() * colors.length) | 0],
      }));
    }
    function frame() {
      ctx.clearRect(0, 0, W, H);
      for (const p of items) {
        p.x += p.vx * p.z; p.y += p.vy * p.z; p.r += p.vr;
        if (p.y < -40) { p.y = H + 40; p.x = Math.random() * W; }
        if (p.x < -40) p.x = W + 40; if (p.x > W + 40) p.x = -40;
        const ox = (mx - W / 2) * 0.02 * p.z, oy = (my - H / 2) * 0.02 * p.z;
        ctx.save(); ctx.translate(p.x + ox, p.y + oy); ctx.rotate(p.r);
        ctx.globalAlpha = 0.1 + p.z * 0.16; ctx.fillStyle = p.c; ctx.font = `italic ${14 + p.z * 22}px Lora, serif`;
        ctx.fillText(p.s, 0, 0); ctx.restore();
      }
      if (!reduce) requestAnimationFrame(frame);
    }
    addEventListener("resize", resize);
    cv.parentElement.addEventListener("pointermove", (e) => { const r = cv.getBoundingClientRect(); mx = e.clientX - r.left; my = e.clientY - r.top; });
    resize(); frame();
  }

  /* ---------- lesson quiz widget ---------- */
  function initQuiz(box) {
    const qid = +box.dataset.qid;
    const opts = $$(".opt", box), fb = $(".feedback", box);
    let busy = false;
    opts.forEach((o, i) => o.addEventListener("click", async () => {
      if (busy || box.classList.contains("solved")) return;
      busy = true;
      opts.forEach((x) => x.classList.remove("selected", "wrong"));
      o.classList.add("selected");
      try {
        const res = await MV.post("/api/quiz/check", { question_id: qid, choice: i });
        o.classList.remove("selected");
        if (res.correct) {
          o.classList.add("correct");
          box.classList.add("solved");
          opts.forEach((x) => x.classList.add("locked"));
          fb.className = "feedback show ok";
          fb.innerHTML = `<b>🎉 ${MV.L("Chính xác!", "Correct!")}</b>` + (res.explanation ? `<div class="md">${MV.md(res.explanation)}</div>` : "");
          MV.confetti({ particleCount: 80 });
          MV.xpFloat(res.xp ?? (box.dataset.loggedIn ? 5 : 0), o);
        } else {
          o.classList.add("wrong");
          fb.className = "feedback show bad";
          fb.textContent = MV.L("Chưa đúng, thử lại nhé! 💪", "Not quite — try again! 💪");
        }
        (res.badges || []).forEach((b) => MV.toast(MV.L("Huy hiệu mới: ", "New badge: ") + b, "celebrate"));
      } catch (err) {
        MV.toast(MV.L("Có lỗi xảy ra, thử lại sau.", "Something went wrong."), "error");
      } finally { busy = false; }
    }));
  }

  /* ---------- boot ---------- */
  document.addEventListener("DOMContentLoaded", () => {
    MV.renderMd();
    MV.observe();
    $$(".quiz[data-qid]").forEach(initQuiz);
    const cv = $("#hero-canvas"); if (cv) heroCanvas(cv);
    (window.__FLASH__ || []).forEach((f, i) => setTimeout(() => MV.toast(f.msg, f.kind), 250 + i * 200));
  });
})();
