"""Shared request helpers: templates, current user, flash messages, guards."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from fastapi import HTTPException, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates

from .i18n import DEFAULT_LANG, LANGS, pick, translate
from .store import store

APP_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(APP_DIR / "templates"))


def fmt_money(v: Any) -> str:
    try:
        return f"{int(v):,}".replace(",", ".") + "₫"
    except (TypeError, ValueError):
        return str(v)


def youtube_id(v: str | None) -> str:
    if not v:
        return ""
    m = re.search(r"(?:v=|youtu\.be/|embed/|shorts/)([\w-]{11})", v)
    return m.group(1) if m else v.strip()


templates.env.filters["money"] = fmt_money
templates.env.filters["ytid"] = youtube_id


def asset(path: str) -> str:
    """Static URL with the file's mtime as version, so browsers/proxies never serve a stale copy."""
    f = APP_DIR / "static" / path
    v = int(f.stat().st_mtime) if f.exists() else 0
    return f"/static/{path}?v={v}"


templates.env.globals["asset"] = asset


def get_lang(request: Request) -> str:
    lang = request.cookies.get("lang", DEFAULT_LANG)
    return lang if lang in LANGS else DEFAULT_LANG


def current_user(request: Request) -> dict | None:
    uid = request.session.get("uid")
    return store.find("users", id=uid) if uid else None


def flash(request: Request, message: str, kind: str = "success") -> None:
    request.session.setdefault("_flash", []).append({"msg": message, "kind": kind})


def pop_flash(request: Request) -> list[dict]:
    return request.session.pop("_flash", [])


def render(request: Request, name: str, ctx: dict | None = None, status_code: int = 200):
    lang = get_lang(request)
    user = current_user(request)
    base = {
        "request": request,
        "lang": lang,
        "user": user,
        "t": lambda k: translate(k, lang),
        "tr": lambda v: pick(v, lang),
        "flashes": pop_flash(request),
        "theme": request.cookies.get("theme", ""),
        "path": request.url.path,
    }
    base.update(ctx or {})
    return templates.TemplateResponse(request, name, base, status_code=status_code)


class LoginRequired(Exception):
    pass


def require_user(request: Request) -> dict:
    user = current_user(request)
    if not user:
        raise LoginRequired()
    return user


def require_admin(request: Request) -> dict:
    user = require_user(request)
    if user.get("role") != "admin":
        raise HTTPException(status_code=403)
    return user


def redirect(url: str) -> RedirectResponse:
    return RedirectResponse(url, status_code=303)


def t_req(request: Request, key: str) -> str:
    return translate(key, get_lang(request))


# ---- domain helpers used by several routers ---------------------------
def course_lesson_ids(course: dict) -> list[int]:
    return [lesson["id"] for lesson in course.get("lessons", [])]


def is_enrolled(user: dict | None, course: dict) -> bool:
    if not user:
        return False
    return store.find("enrollments", user_id=user["id"], course_id=course["id"]) is not None


def course_progress(user: dict | None, course: dict) -> int:
    """Percentage of lessons completed (0-100)."""
    if not user or not course.get("lessons"):
        return 0
    ids = set(course_lesson_ids(course))
    done = {p["lesson_id"] for p in store.db["progress"] if p["user_id"] == user["id"] and p["course_id"] == course["id"]}
    return round(100 * len(done & ids) / len(ids))


def completed_lessons(user: dict | None, course: dict) -> set[int]:
    if not user:
        return set()
    return {p["lesson_id"] for p in store.db["progress"] if p["user_id"] == user["id"] and p["course_id"] == course["id"]}


def public_question(q: dict) -> dict:
    """Question without its answer/explanation (safe to send to the client)."""
    return {k: q[k] for k in ("id", "content", "options", "topic", "difficulty") if k in q}
