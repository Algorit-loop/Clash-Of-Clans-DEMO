// Hằng số chung của game. Chỉnh độ khó "tổng thể" ở đây.

export const TILE = 48;            // kích thước 1 ô (px)
export const COLS = 20;
export const ROWS = 12;
export const W = COLS * TILE;      // kích thước thế giới game (px)
export const H = ROWS * TILE;
export const RENDER_SCALE = 2;     // canvas vẽ gấp đôi để nét trên màn hình retina

export const MAX_WAVE = 30;        // thắng khi vượt qua đợt này
export const START_GOLD = 220;
export const START_LIVES = 20;
export const SELL_RATIO = 0.7;     // bán tháp nhận lại bao nhiêu % vốn đã đầu tư

export const STEP = 1 / 60;        // bước thời gian cố định của logic (giây)
export const MAX_SPEED = 3;        // x1, x2, x3
