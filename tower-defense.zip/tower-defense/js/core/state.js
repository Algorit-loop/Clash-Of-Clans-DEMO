// Trạng thái của ván chơi. `S` là một object dùng chung; resetState() ghi đè
// nội dung tại chỗ nên mọi module import S đều thấy giá trị mới.

import { START_GOLD, START_LIVES } from '../config.js';

export const S = {};

let id = 1;
export const nextId = () => id++;

export function resetState() {
  Object.assign(S, {
    // tài nguyên & tiến trình
    gold: START_GOLD, lives: START_LIVES, wave: 0, kills: 0,
    waveActive: false, queue: [], spawnT: 0, interval: .8,
    // thực thể
    towers: [], enemies: [], shots: [], fx: [], texts: [],
    // điều khiển thời gian
    t: 0, acc: 0, speed: 1, paused: false, over: false,
    // lựa chọn của người chơi
    selType: null,       // loại tháp đang chọn để xây
    selTower: null,      // tháp đang được chọn để xem/nâng cấp
    hover: null,         // ô chuột đang trỏ vào {c, r}
    previewUpgrade: false, // đang rê chuột vào khung nâng cấp -> hiện tầm bắn mới
  });
}
