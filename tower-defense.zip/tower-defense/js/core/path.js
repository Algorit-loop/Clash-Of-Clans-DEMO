// Hình học của bản đồ: đường đi, các ô bị chiếm (đường, cây, đá).
// Được tính một lần khi nạp module, từ dữ liệu trong data/map.js.

import { TILE, COLS, ROWS } from '../config.js';
import { WAYPOINTS, OBSTACLES } from '../data/map.js';
import { rng } from '../util/random.js';

// Điểm ngoặt theo toạ độ pixel (tâm ô).
export const WP = WAYPOINTS.map(([c, r]) => ({ x: (c + .5) * TILE, y: (r + .5) * TILE }));

const segs = [];
export let totalLen = 0;
for (let i = 0; i < WP.length - 1; i++) {
  const a = WP[i], b = WP[i + 1], len = Math.hypot(b.x - a.x, b.y - a.y);
  segs.push({ a, b, len, start: totalLen });
  totalLen += len;
}

// Vị trí (x, y) tại quãng đường d tính từ điểm bắt đầu.
export function posAt(d) {
  d = Math.max(0, Math.min(totalLen, d));
  for (const s of segs) {
    if (d <= s.start + s.len) {
      const t = (d - s.start) / s.len;
      return { x: s.a.x + (s.b.x - s.a.x) * t, y: s.a.y + (s.b.y - s.a.y) * t };
    }
  }
  const l = WP[WP.length - 1];
  return { x: l.x, y: l.y };
}

// Tập các ô nằm trên đường đi, dạng "cột,hàng".
export const pathCells = new Set();
for (const s of segs) {
  const n = Math.ceil(s.len / 6);
  for (let i = 0; i <= n; i++) {
    const x = s.a.x + (s.b.x - s.a.x) * i / n, y = s.a.y + (s.b.y - s.a.y) * i / n;
    pathCells.add(Math.floor(x / TILE) + ',' + Math.floor(y / TILE));
  }
}

// Ô bị cây/đá chắn: Map "cột,hàng" -> 'tree' | 'rock'. Không đặt sát đường đi.
export const blocked = new Map();
{
  const rnd = rng(OBSTACLES.seed), near = new Set();
  for (const k of pathCells) {
    const [c, r] = k.split(',').map(Number);
    for (let dc = -1; dc <= 1; dc++) for (let dr = -1; dr <= 1; dr++) near.add((c + dc) + ',' + (r + dr));
  }
  let tries = 0;
  while (blocked.size < OBSTACLES.count && tries++ < 500) {
    const c = Math.floor(rnd() * COLS), r = Math.floor(rnd() * ROWS), k = c + ',' + r;
    if (near.has(k) || blocked.has(k)) continue;
    blocked.set(k, rnd() < OBSTACLES.treeChance ? 'tree' : 'rock');
  }
}
