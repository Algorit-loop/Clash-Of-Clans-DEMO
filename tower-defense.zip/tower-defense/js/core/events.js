// Event bus nhỏ: để logic báo cho UI mà không phải import UI (tránh phụ thuộc vòng).
//
// Các sự kiện đang dùng:
//   'toast'    (msg)  thông báo ngắn trên màn hình
//   'gameover' (win)  kết thúc game, win = true/false
//   'reset'           bắt đầu ván mới

const handlers = {};

export function on(name, fn) {
  (handlers[name] ||= []).push(fn);
}

export function emit(name, ...args) {
  for (const fn of handlers[name] || []) fn(...args);
}
