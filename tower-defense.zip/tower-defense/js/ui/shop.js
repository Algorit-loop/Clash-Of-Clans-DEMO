// Cửa hàng tháp (cột bên phải): mỗi tháp một thẻ với các thanh chỉ số.

import { S } from '../core/state.js';
import { TOWERS } from '../data/towers.js';
import { selectType } from '../logic/towers.js';
import { ICONS } from '../render/icons.js';
import { MAXV } from './towerStats.js';
import { $ } from './dom.js';

// Nhãn nổi bật của từng tháp, suy ra từ dữ liệu (không gắn cứng theo tên tháp).
function tagOf(l) {
  if (l.range === MAXV.range) return '🎯 Tầm xa nhất';
  if (1 / l.rate === MAXV.rate) return '⚡ Bắn nhanh nhất';
  if (l.slow) return `❄️ Chậm ${Math.round((1 - l.slow) * 100)}% trong ${l.slowT}s`;
  if (l.splash) return `💥 Nổ lan ${l.splash}`;
  return '';
}

export function renderShop() {
  const el = $('shop');
  el.innerHTML = '';
  for (const [id, d] of Object.entries(TOWERS)) {
    const l = d.levels[0], card = document.createElement('div');
    card.className = 'card'; card.dataset.t = id;
    const cnv = document.createElement('canvas');
    cnv.width = cnv.height = 116; cnv.getContext('2d').drawImage(ICONS[id], 0, 0);
    const info = document.createElement('div');
    const tag = tagOf(l);
    info.innerHTML = `<div class="top"><span class="nm">${d.name}</span><kbd class="key">${d.key}</kbd><span class="cost">💰${d.cost}</span></div>
      <div class="ds">${d.desc}</div>
      <div class="bars">
        <span class="l">Sát thương ${l.dmg}</span><div class="bar d"><i style="width:${l.dmg / MAXV.dmg * 100}%"></i></div>
        <span class="l">Tầm bắn ${l.range}</span><div class="bar"><i style="width:${l.range / MAXV.range * 100}%"></i></div>
        <span class="l">Tốc độ ${(1 / l.rate).toFixed(1)}/s</span><div class="bar s"><i style="width:${(1 / l.rate) / MAXV.rate * 100}%"></i></div>
      </div>${tag ? `<span class="tag">${tag}</span>` : ''}`;
    card.append(cnv, info);
    card.onclick = () => selectType(id);
    el.appendChild(card);
  }
}

// Đánh dấu thẻ đang chọn / không đủ vàng.
export function refreshShop() {
  document.querySelectorAll('.card').forEach(c => {
    const d = TOWERS[c.dataset.t];
    c.classList.toggle('sel', S.selType === c.dataset.t);
    c.classList.toggle('poor', S.gold < d.cost);
  });
}
