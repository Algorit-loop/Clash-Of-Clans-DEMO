// Nhập liệu: chuột trên bản đồ, nút bấm, phím tắt. Chỉ gọi hành động của tầng logic.

import { TILE, W } from '../config.js';
import { S } from '../core/state.js';
import { TOWERS } from '../data/towers.js';
import { placeTower, upgradeTower, sellTower, selectType, selectTower, clearSelection, towerAt } from '../logic/towers.js';
import { startWave } from '../logic/waves.js';
import { restart, togglePause, cycleSpeed } from '../logic/game.js';
import { $ } from './dom.js';

// Đổi toạ độ chuột (px màn hình) sang ô (cột, hàng); canvas có thể bị co giãn bằng CSS.
function cellFromEvent(canvas, ev) {
  const r = canvas.getBoundingClientRect(), k = W / r.width;
  return { c: Math.floor((ev.clientX - r.left) * k / TILE), r: Math.floor((ev.clientY - r.top) * k / TILE) };
}

export function bindInput(canvas) {
  canvas.addEventListener('mousemove', ev => { S.hover = cellFromEvent(canvas, ev); });
  canvas.addEventListener('mouseleave', () => { S.hover = null; });
  canvas.addEventListener('click', ev => {
    if (S.over) return;
    const { c, r } = cellFromEvent(canvas, ev), t = towerAt(c, r);
    if (S.selType && !t) return placeTower(c, r);
    selectTower(t);
  });
  canvas.addEventListener('contextmenu', ev => { ev.preventDefault(); clearSelection(); });

  $('next').onclick = startWave;
  $('pause').onclick = togglePause;
  $('speed').onclick = cycleSpeed;
  $('restart').onclick = restart;

  addEventListener('keydown', ev => {
    const k = ev.key.toLowerCase();
    if (k === ' ') { ev.preventDefault(); startWave(); }
    else if (k === 'p') togglePause();
    else if (k === 'u') upgradeTower();
    else if (k === 's') sellTower();
    else if (k === 'escape') clearSelection();
    else for (const [id, d] of Object.entries(TOWERS)) if (d.key === k) selectType(id);
  });
}
