// Điểm vào của tầng UI: khởi tạo và cập nhật mỗi khung hình.

import { on } from '../core/events.js';
import { makeIcons } from '../render/icons.js';
import { updateHud, resetHud } from './hud.js';
import { renderShop, refreshShop } from './shop.js';
import { renderInspector, inspectorSignature } from './inspector.js';
import { bindInput } from './input.js';

let inspSig;

function rebuildAll() {
  inspSig = null;
  resetHud();
  renderShop();
}

export function initUI(canvas) {
  makeIcons();
  bindInput(canvas);
  on('reset', rebuildAll);
  rebuildAll();
}

// Gọi mỗi khung hình; chỉ vẽ lại phần nào thực sự thay đổi.
export function updateUI() {
  updateHud();
  refreshShop();
  const sig = inspectorSignature();
  if (sig !== inspSig) { inspSig = sig; renderInspector(); }
}
