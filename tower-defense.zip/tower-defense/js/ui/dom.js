// Tiện ích DOM dùng chung cho các module UI.

export const $ = id => document.getElementById(id);

// Chỉ ghi vào DOM khi giá trị thực sự đổi (tránh ghi lại mỗi khung hình).
const cache = {};
export function setText(id, v) {
  if (cache[id] === v) return;
  cache[id] = v;
  $(id).textContent = v;
}
