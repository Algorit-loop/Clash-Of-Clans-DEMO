// Cách hiển thị chỉ số tháp trong cửa hàng và bảng chi tiết.

import { TOWERS } from '../data/towers.js';

// Các dòng chỉ số: nhãn, cách lấy giá trị từ một cấp (level), cách định dạng.
// Dòng nào có giá trị 0 ở cả hai cấp so sánh sẽ bị ẩn (vd. tháp không nổ lan).
export const STAT_DEFS = [
  { label: 'Sát thương',       get: l => l.dmg,                           fmt: v => Math.round(v) },
  { label: 'Tầm bắn',          get: l => l.range,                         fmt: v => Math.round(v) },
  { label: 'Tốc độ bắn',       get: l => 1 / l.rate,                      fmt: v => v.toFixed(2) + '/s' },
  { label: 'DPS (1 mục tiêu)', get: l => l.dmg / l.rate,                  fmt: v => v.toFixed(0) },
  { label: 'Bán kính nổ',      get: l => l.splash || 0,                   fmt: v => Math.round(v) },
  { label: 'Làm chậm',         get: l => l.slow ? (1 - l.slow) * 100 : 0, fmt: v => Math.round(v) + '%' },
  { label: 'Thời gian chậm',   get: l => l.slowT || 0,                    fmt: v => v.toFixed(1) + 's' },
];

// Giá trị lớn nhất của từng chỉ số trong mọi tháp (để vẽ thanh so sánh).
export const MAXV = { dmg: 0, range: 0, rate: 0 };
for (const d of Object.values(TOWERS)) {
  for (const l of d.levels) {
    MAXV.dmg = Math.max(MAXV.dmg, l.dmg);
    MAXV.range = Math.max(MAXV.range, l.range);
    MAXV.rate = Math.max(MAXV.rate, 1 / l.rate);
  }
}

// HTML các dòng chỉ số của cấp lvIdx; nếu có nextIdx thì hiện thêm "→ giá trị mới" ở dòng nào thay đổi.
export function statRows(type, lvIdx, nextIdx) {
  const L = TOWERS[type].levels, cur = L[lvIdx], nxt = nextIdx != null ? L[nextIdx] : null;
  let html = '';
  for (const d of STAT_DEFS) {
    const a = d.get(cur), b = nxt ? d.get(nxt) : null;
    if (!a && !b) continue;
    const changed = b != null && Math.abs(b - a) > 1e-9;
    html += `<div class="k">${d.label}</div><div class="v">${d.fmt(a)}` +
      (changed ? `<span class="arrow">→</span><span class="to">${d.fmt(b)}</span>` : '') + `</div>`;
  }
  return html;
}
