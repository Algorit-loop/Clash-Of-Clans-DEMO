// Khung "Chi tiết": thông tin tháp đang chọn, nâng cấp (kèm xem trước), bán, ưu tiên mục tiêu.

import { S } from '../core/state.js';
import { TOWERS, TARGET_MODES } from '../data/towers.js';
import { upCost, sellValue, upgradeTower, sellTower, setTargetMode } from '../logic/towers.js';
import { ICONS } from '../render/icons.js';
import { STAT_DEFS, statRows } from './towerStats.js';
import { $ } from './dom.js';

export function renderInspector() {
  const el = $('inspector'), t = S.selTower;

  // Chưa chọn tháp nào: hiện hướng dẫn
  if (!t) {
    if (S.selType) {
      const d = TOWERS[S.selType];
      el.innerHTML = `<div class="tips"><p><b>Đang đặt: ${d.name}</b></p><p>Bấm vào một ô cỏ trống để xây. Vòng tròn trắng là tầm bắn.</p><p>Bấm chuột phải hoặc <kbd>Esc</kbd> để huỷ.</p></div>`;
    } else {
      el.innerHTML = `<div class="tips"><p><b>Chọn tháp</b> ở danh sách phía trên rồi bấm vào ô cỏ để xây.</p>
        <p><b>Bấm vào tháp đã xây</b> để xem chi tiết, nâng cấp (xem trước tầm bắn khi rê chuột vào nút nâng cấp) hoặc bán.</p>
        <p>Ô có cây/đá không xây được. Quái lọt vào căn cứ sẽ trừ mạng, quái càng mạnh càng trừ nhiều.</p></div>`;
    }
    return;
  }

  const d = TOWERS[t.type], up = d.upgrades[t.level - 1], c = upCost(t);
  let h = `<div class="insp-head"><img src="${ICONS[t.type].toDataURL()}"><div><div class="nm">${d.name}</div>
    <div class="lvl">${[1, 2, 3, 4].map(i => `<i class="${i <= t.level ? 'on' : ''}"></i>`).join('')}</div></div></div>`;
  h += `<div class="lbl2">Chỉ số hiện tại</div><div class="stats">${statRows(t.type, t.level - 1, null)}</div>`;
  h += `<div class="lbl2">Ưu tiên mục tiêu</div><div class="modes">${TARGET_MODES.map(([k, n]) =>
    `<button data-m="${k}" class="${t.mode === k ? 'on' : ''}">${n}</button>`).join('')}</div>`;

  if (up) {
    const cl = d.levels[t.level - 1], nl = d.levels[t.level], items = [];
    for (const sd of STAT_DEFS) {
      const a = sd.get(cl), b = sd.get(nl);
      if (Math.abs(a - b) > 1e-9) items.push(`<li><span>${sd.label}</span><span>${sd.fmt(a)} → <b>${sd.fmt(b)}</b></span></li>`);
    }
    h += `<div class="upbox" id="upbox"><div class="t">⬆ Lv${t.level + 1}: ${up.name}</div><div class="d">${up.desc}</div><ul>${items.join('')}</ul>
      <button class="primary" id="up" ${S.gold < c ? 'disabled' : ''}>Nâng cấp (U) · 💰${c}</button></div>`;
  } else {
    h += `<div class="upbox"><div class="t">⭐ Cấp tối đa</div><div class="d">Tháp này đã được nâng cấp hết.</div></div>`;
  }
  h += `<button class="danger" id="sell" style="width:100%">Bán (S) · +💰${sellValue(t)}</button>`;
  el.innerHTML = h;

  // Rê chuột vào khung nâng cấp -> bản đồ hiện vòng tầm bắn mới
  const ub = $('upbox');
  if (ub && up) {
    ub.onmouseenter = () => { S.previewUpgrade = true; };
    ub.onmouseleave = () => { S.previewUpgrade = false; };
    S.previewUpgrade = ub.matches(':hover');
    $('up').onclick = upgradeTower;
  } else S.previewUpgrade = false;
  $('sell').onclick = sellTower;
  el.querySelectorAll('[data-m]').forEach(b => b.onclick = () => setTargetMode(t, b.dataset.m));
}

// Chuỗi "chữ ký" của những gì khung này đang hiển thị; đổi thì mới vẽ lại HTML.
export function inspectorSignature() {
  const t = S.selTower, c = t ? upCost(t) : null;
  return [t ? t.id : 0, t ? t.level : 0, t ? t.mode : '', c != null && S.gold >= c, S.selType].join('|');
}
