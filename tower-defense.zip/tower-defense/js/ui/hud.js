// Thanh trên cùng (vàng, mạng, đợt, nút điều khiển), thông báo nhanh và màn hình kết thúc.

import { MAX_WAVE } from '../config.js';
import { S } from '../core/state.js';
import { on } from '../core/events.js';
import { ENEMIES } from '../data/enemies.js';
import { composition } from '../data/waves.js';
import { $, setText } from './dom.js';

// ---------- Thông báo ----------
let toastTimer;
function toast(msg) {
  const el = $('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 1500);
}
on('toast', toast);

// ---------- Màn hình thắng/thua ----------
on('gameover', win => {
  $('ot').textContent = win ? '🏆 Chiến thắng!' : '💀 Thất bại';
  $('os').textContent = (win ? `Bạn đã bảo vệ thành công cả ${MAX_WAVE} đợt` : `Bạn dừng ở đợt ${S.wave}/${MAX_WAVE}`) + ` · Hạ ${S.kills} quái`;
  $('overlay').style.display = 'flex';
});
on('reset', () => { $('overlay').style.display = 'none'; });

// ---------- Xem trước đợt kế tiếp ----------
let previewKey;
function renderPreview() {
  const n = S.wave + 1;
  if (n > MAX_WAVE) { $('preview').innerHTML = ''; return; }
  $('preview').innerHTML = `<span>Đợt ${n}:</span>` + Object.entries(composition(n)).filter(([, v]) => v).map(([k, v]) =>
    `<span class="e" title="${ENEMIES[k].name}"><i style="background:${ENEMIES[k].mid}"></i>×${v}</span>`).join('');
}

export function resetHud() { previewKey = null; }

export function updateHud() {
  setText('gold', S.gold);
  setText('lives', S.lives);
  setText('wave', S.wave);
  setText('maxwave', MAX_WAVE);

  const nb = $('next'), disabled = S.waveActive || S.over || S.wave >= MAX_WAVE;
  if (nb.disabled !== disabled) nb.disabled = disabled;
  setText('next', S.waveActive ? `Còn ${S.queue.length + S.enemies.length} quái` : S.wave === 0 ? '▶ Bắt đầu (Space)' : '▶ Đợt tiếp (Space)');
  setText('pause', S.paused ? '▶ Tiếp tục' : '⏸ Tạm dừng');
  setText('speed', '⏩ x' + S.speed);

  const key = S.wave + '|' + S.waveActive;
  if (key !== previewKey) { previewKey = key; renderPreview(); }
}
