// Vẽ sprite quái + thanh máu. Màu lấy từ data/enemies.js.

import { ENEMIES } from '../data/enemies.js';

export function drawEnemy(c, e, t) {
  const E = ENEMIES[e.type], r = e.r, bob = Math.sin(e.phase + e.d*.13)*1.8;
  const dx = e.dx, dy = e.dy, ang = Math.atan2(dy, dx);
  c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(e.x, e.y+r*.75, r*1.05, r*.5, 0, 0, 7); c.fill();
  c.save(); c.translate(e.x, e.y + bob);
  if (e.type === 'fast') {
    c.strokeStyle = 'rgba(255,255,255,.4)'; c.lineWidth = 2; c.lineCap = 'round';
    for (let i=-1;i<=1;i++) { c.beginPath(); c.moveTo(-dx*(r+3) - dy*i*5, -dy*(r+3) + dx*i*5); c.lineTo(-dx*(r+13) - dy*i*5, -dy*(r+13) + dx*i*5); c.stroke(); }
  }
  if (e.type === 'boss') {
    c.fillStyle = E.lo;
    for (let i=0;i<9;i++) { const a = i/9*Math.PI*2 + t*.4; c.save(); c.rotate(a); c.beginPath(); c.moveTo(r-2,-5); c.lineTo(r+8,0); c.lineTo(r-2,5); c.fill(); c.restore(); }
  }
  const g = c.createRadialGradient(-r*.35,-r*.4,r*.1, 0,0,r*1.1); g.addColorStop(0,E.hi); g.addColorStop(.55,E.mid); g.addColorStop(1,E.lo);
  c.fillStyle = g; c.beginPath(); c.arc(0,0,r,0,7); c.fill();
  c.lineWidth = 2; c.strokeStyle = 'rgba(0,0,0,.45)'; c.stroke();
  if (e.type === 'tank') {
    c.strokeStyle = '#a9afbb'; c.lineWidth = 5; c.lineCap = 'round';
    c.beginPath(); c.arc(0,0,r-1,ang-1.25,ang+1.25); c.stroke();
    c.strokeStyle = '#5b606c'; c.lineWidth = 1.5; c.beginPath(); c.arc(0,0,r+1.5,ang-1.25,ang+1.25); c.stroke();
  }
  // mắt
  const px = -dy, py = dx, ec = r*.38, es = r*.3;
  for (const s of [-1,1]) {
    const ex = dx*ec + px*es*s*1.1, ey = dy*ec + py*es*s*1.1 - 1;
    c.fillStyle = e.type==='boss' ? '#ffd0d0' : '#fff'; c.beginPath(); c.arc(ex,ey,r*.26,0,7); c.fill();
    c.fillStyle = e.type==='boss' ? '#d00' : '#1a1a1a'; c.beginPath(); c.arc(ex+dx*r*.1, ey+dy*r*.1, r*.13, 0, 7); c.fill();
  }
  if (e.type === 'boss') { // vương miện
    c.fillStyle = '#ffd34d'; c.strokeStyle = '#8a6200'; c.lineWidth = 1.2;
    c.beginPath(); c.moveTo(-9,-r+1); c.lineTo(-9,-r-8); c.lineTo(-4.5,-r-3); c.lineTo(0,-r-10); c.lineTo(4.5,-r-3); c.lineTo(9,-r-8); c.lineTo(9,-r+1); c.closePath(); c.fill(); c.stroke();
  }
  if (e.slowT > 0) {
    c.fillStyle = 'rgba(130,215,255,.45)'; c.beginPath(); c.arc(0,0,r,0,7); c.fill();
    c.strokeStyle = '#d4f3ff'; c.lineWidth = 1.5; c.setLineDash([3,3]); c.beginPath(); c.arc(0,0,r+3,0,7); c.stroke(); c.setLineDash([]);
  }
  if (e.flash > 0) { c.fillStyle = `rgba(255,255,255,${Math.min(.8,e.flash*4)})`; c.beginPath(); c.arc(0,0,r,0,7); c.fill(); }
  c.restore();
  if (e.hp < e.max || e.type === 'boss') {
    const w = r*2+8, bx = e.x-w/2, by = e.y - r - (e.type==='boss'?20:10), p = Math.max(0, e.hp/e.max);
    c.fillStyle = 'rgba(0,0,0,.65)'; c.beginPath(); c.roundRect(bx-1,by-1,w+2,7,3); c.fill();
    c.fillStyle = p > .5 ? '#5fe08a' : p > .25 ? '#ffc857' : '#ff6b6b'; c.beginPath(); c.roundRect(bx,by,w*p,5,2.5); c.fill();
  }
}

