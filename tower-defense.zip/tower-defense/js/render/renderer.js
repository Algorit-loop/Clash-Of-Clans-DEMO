// Vẽ một khung hình: nền, tháp, quái, đạn, hiệu ứng, chữ bay.
// Chỉ ĐỌC trạng thái (S), không thay đổi gì của game.

import { TILE, COLS, ROWS, W, H, RENDER_SCALE } from '../config.js';
import { S } from '../core/state.js';
import { TOWERS } from '../data/towers.js';
import { lvOf, cellError } from '../logic/towers.js';
import { buildBackground } from './background.js';
import { drawTower } from './towerSprites.js';
import { drawEnemy } from './enemySprites.js';

let ctx, BG;

export function initRenderer(canvas) {
  canvas.width = W * RENDER_SCALE; canvas.height = H * RENDER_SCALE;
  ctx = canvas.getContext('2d');
  BG = buildBackground();
}

function dashedRing(x, y, r, color, fill) {
  ctx.beginPath(); ctx.arc(x, y, r, 0, 7);
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.setLineDash([7,5]); ctx.stroke(); ctx.setLineDash([]);
}
export function draw() {
  ctx.setTransform(1,0,0,1,0,0); ctx.drawImage(BG, 0, 0);
  ctx.setTransform(RENDER_SCALE,0,0,RENDER_SCALE,0,0);
  const h = S.hover, t0 = S.t;

  if (S.selType && h) { // lưới gợi ý khi đang đặt
    ctx.strokeStyle = 'rgba(255,255,255,.08)'; ctx.lineWidth = 1;
    for (let c=0;c<=COLS;c++) { ctx.beginPath(); ctx.moveTo(c*TILE,0); ctx.lineTo(c*TILE,H); ctx.stroke(); }
    for (let r=0;r<=ROWS;r++) { ctx.beginPath(); ctx.moveTo(0,r*TILE); ctx.lineTo(W,r*TILE); ctx.stroke(); }
  }
  const sel = S.selTower;
  if (sel) { // vòng tầm bắn hiện tại + xem trước khi nâng cấp
    const lv = lvOf(sel), nx = TOWERS[sel.type].levels[sel.level];
    dashedRing(sel.x, sel.y, lv.range, '#ffc857', 'rgba(255,200,87,.1)');
    if (S.previewUpgrade && nx && nx.range !== lv.range) {
      dashedRing(sel.x, sel.y, nx.range, '#5fe08a', 'rgba(95,224,138,.12)');
      ctx.fillStyle = '#5fe08a'; ctx.font = '800 12px Nunito, system-ui'; ctx.textAlign = 'center';
      ctx.fillText(`Tầm ${lv.range} → ${nx.range}`, sel.x, sel.y - nx.range - 6); ctx.textAlign = 'start';
    }
  }
  if (S.selType && h) {
    const err = cellError(h.c, h.r);
    ctx.fillStyle = err ? 'rgba(255,70,70,.4)' : 'rgba(255,255,255,.22)'; ctx.fillRect(h.c*TILE, h.r*TILE, TILE, TILE);
    if (!err) {
      const x = (h.c+.5)*TILE, y = (h.r+.5)*TILE;
      dashedRing(x, y, TOWERS[S.selType].levels[0].range, 'rgba(255,255,255,.7)', 'rgba(255,255,255,.08)');
      drawTower(ctx, S.selType, x, y, 1, -Math.PI/2, 0, t0, .75);
    }
  } else if (h && !S.selType) {
    const hov = S.towers.find(t => t.c===h.c && t.r===h.r);
    if (hov && hov !== sel) { ctx.fillStyle = 'rgba(255,255,255,.14)'; ctx.fillRect(h.c*TILE, h.r*TILE, TILE, TILE); }
  }

  for (const t of S.towers) drawTower(ctx, t.type, t.x, t.y, t.level, t.angle, t.recoil, t0);
  for (const e of [...S.enemies].sort((a,b) => a.y-b.y)) drawEnemy(ctx, e, t0);

  for (const s of S.shots) {
    if (s.type === 'cannon') { // đạn pháo bay theo vòng cung giả
      const p = Math.min(1, s.travelled/s.aimDist), lift = Math.sin(p*Math.PI)*14;
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(s.x, s.y+3, 5, 2.5, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#1d2026'; ctx.beginPath(); ctx.arc(s.x, s.y-lift, 5.5, 0, 7); ctx.fill();
      ctx.fillStyle = '#6b7280'; ctx.beginPath(); ctx.arc(s.x-1.5, s.y-lift-1.5, 1.8, 0, 7); ctx.fill();
    } else if (s.type === 'arrow') {
      ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(s.ang);
      ctx.strokeStyle = '#7a4e26'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-10,0); ctx.lineTo(5,0); ctx.stroke();
      ctx.fillStyle = '#e8e8ee'; ctx.beginPath(); ctx.moveTo(9,0); ctx.lineTo(4,-3); ctx.lineTo(4,3); ctx.fill(); ctx.restore();
    } else if (s.type === 'sniper') {
      ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(s.ang);
      const g = ctx.createLinearGradient(-28,0,4,0); g.addColorStop(0,'rgba(220,160,255,0)'); g.addColorStop(1,'#f0d4ff');
      ctx.strokeStyle = g; ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(-28,0); ctx.lineTo(4,0); ctx.stroke(); ctx.restore();
    } else {
      const g = ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,8); g.addColorStop(0,'#fff'); g.addColorStop(.4,'#9fe6ff'); g.addColorStop(1,'rgba(120,210,255,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(s.x, s.y, 8, 0, 7); ctx.fill();
    }
  }
  for (const f of S.fx) {
    const a = f.life/f.max;
    if (f.ring) { ctx.fillStyle = `rgba(${f.color},${.45*a})`; ctx.strokeStyle = `rgba(255,220,150,${a})`; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(f.x, f.y, f.r*(1-.35*a), 0, 7); ctx.fill(); ctx.stroke(); }
    else { ctx.globalAlpha = a; ctx.fillStyle = f.color; ctx.beginPath(); ctx.arc(f.x, f.y, f.size*a+.5, 0, 7); ctx.fill(); ctx.globalAlpha = 1; }
  }
  ctx.textAlign = 'center'; ctx.lineJoin = 'round';
  for (const x of S.texts) {
    ctx.globalAlpha = Math.min(1, x.life/x.max*1.6); ctx.font = '800 13px Nunito, system-ui';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.7)'; ctx.strokeText(x.txt, x.x, x.y);
    ctx.fillStyle = x.color; ctx.fillText(x.txt, x.x, x.y);
  }
  ctx.globalAlpha = 1; ctx.textAlign = 'start';
  if (S.paused && !S.over) {
    ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#fff'; ctx.font = '800 48px "Baloo 2", system-ui'; ctx.textAlign = 'center';
    ctx.fillText('TẠM DỪNG', W/2, H/2); ctx.textAlign = 'start';
  }
}

