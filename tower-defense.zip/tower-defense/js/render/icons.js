// Icon tháp (canvas nhỏ) dùng trong cửa hàng và bảng chi tiết.

import { TOWERS } from '../data/towers.js';
import { drawTower } from './towerSprites.js';

export const ICONS = {};

export function makeIcons() {
  for (const type of Object.keys(TOWERS)) {
    const c = document.createElement('canvas'); c.width = c.height = 116; const x = c.getContext('2d');
    x.scale(2, 2); drawTower(x, type, 29, 29, 1, -.6, 0, .8); ICONS[type] = c;
  }
}
