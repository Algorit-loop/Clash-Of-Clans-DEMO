// Vẽ sprite tháp (dùng chung cho bản đồ, bản xem trước khi đặt, và icon trong cửa hàng).
// Thêm tháp mới: thêm một nhánh `else if (type === '...')` ở đây.

export function drawTower(c, type, x, y, lvl, ang, recoil, t, alpha) {
  c.save(); c.globalAlpha = alpha == null ? 1 : alpha; c.translate(x, y);
  c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(2, 7, 23, 16, 0, 0, 7); c.fill();
  const ring = ['', '#9aa3b5', '#6fe08a', '#59a9ff', '#ffc857'][lvl];
  let g = c.createRadialGradient(-7,-9,3, 0,0,23); g.addColorStop(0,'#b6bdcc'); g.addColorStop(1,'#4a5162');
  c.fillStyle = g; c.beginPath(); c.arc(0,0,21,0,7); c.fill();
  c.lineWidth = 3; c.strokeStyle = ring; c.stroke();
  c.fillStyle = 'rgba(0,0,0,.2)'; c.beginPath(); c.arc(0,0,15,0,7); c.fill();
  if (lvl === 4) { c.shadowColor = '#ffc857'; c.shadowBlur = 10; c.strokeStyle = '#ffc857'; c.beginPath(); c.arc(0,0,21,0,7); c.stroke(); c.shadowBlur = 0; }

  if (type === 'arrow') {
    c.rotate(ang); c.translate(-recoil*3, 0);
    let w = c.createLinearGradient(0,-4,0,4); w.addColorStop(0,'#c98f55'); w.addColorStop(1,'#7a4e26');
    c.fillStyle = w; c.beginPath(); c.roundRect(-9,-3.5,28,7,3); c.fill();
    c.strokeStyle = '#4e2f14'; c.lineWidth = 4; c.lineCap = 'round';
    c.beginPath(); c.moveTo(6,-14); c.quadraticCurveTo(15,0,6,14); c.stroke();
    c.strokeStyle = '#f1e6c8'; c.lineWidth = 1.2;
    c.beginPath(); c.moveTo(6,-14); c.lineTo(6 - 5*(recoil>.01?0:1) - recoil*0, 0); c.lineTo(6,14); c.stroke();
    c.fillStyle = '#e8e8ee'; c.beginPath(); c.moveTo(24,0); c.lineTo(17,-3); c.lineTo(17,3); c.fill();
    c.fillStyle = '#9b6a3a'; c.beginPath(); c.arc(0,0,7,0,7); c.fill();
  } else if (type === 'cannon') {
    c.rotate(ang); c.translate(-recoil*6, 0);
    let m = c.createLinearGradient(0,-8,0,8); m.addColorStop(0,'#6c7280'); m.addColorStop(.5,'#2b2f38'); m.addColorStop(1,'#15171c');
    c.fillStyle = m; c.beginPath(); c.roundRect(-4,-7.5,28,15,4); c.fill();
    c.fillStyle = '#3d424d'; c.fillRect(19,-9.5,6,19);
    c.fillStyle = '#0b0c0f'; c.beginPath(); c.ellipse(25,0,2,6,0,0,7); c.fill();
    c.fillStyle = '#3a3f4a'; c.beginPath(); c.arc(0,0,9,0,7); c.fill();
    c.fillStyle = '#8b92a1'; c.beginPath(); c.arc(-2,-2,3,0,7); c.fill();
  } else if (type === 'frost') {
    const pulse = .75 + Math.sin(t*3)*.25;
    let gl = c.createRadialGradient(0,0,2, 0,0,26); gl.addColorStop(0,`rgba(140,230,255,${.65*pulse})`); gl.addColorStop(1,'rgba(140,230,255,0)');
    c.fillStyle = gl; c.beginPath(); c.arc(0,0,26,0,7); c.fill();
    c.translate(0, Math.sin(t*2)*1.5 - 2);
    const shard = (rot, s) => { c.save(); c.rotate(rot); c.scale(s,s);
      let ic = c.createLinearGradient(-8,-18,8,18); ic.addColorStop(0,'#f0fdff'); ic.addColorStop(.5,'#7fd8f7'); ic.addColorStop(1,'#2f8fd6');
      c.fillStyle = ic; c.beginPath(); c.moveTo(0,-18); c.lineTo(8,0); c.lineTo(0,18); c.lineTo(-8,0); c.closePath(); c.fill();
      c.strokeStyle = 'rgba(255,255,255,.7)'; c.lineWidth = 1; c.stroke(); c.restore(); };
    shard(-.75,.7); shard(.75,.7); shard(0,1);
    c.fillStyle = '#fff'; for (let i=0;i<3;i++){ const a = t*1.5 + i*2.09; c.beginPath(); c.arc(Math.cos(a)*18, Math.sin(a)*18, 1.8, 0, 7); c.fill(); }
  } else if (type === 'sniper') {
    c.rotate(ang); c.translate(-recoil*7, 0);
    c.fillStyle = '#1b1426'; c.beginPath(); c.roundRect(2,-2.6,36,5.2,2); c.fill();
    c.fillStyle = '#4a3a63'; c.fillRect(2,-2.6,36,1.6);
    c.fillStyle = '#2b2040'; c.fillRect(36,-3.6,4,7.2);
    c.fillStyle = '#2a1f3d'; c.beginPath(); c.roundRect(6,-8.5,13,5,2); c.fill();
    c.fillStyle = '#8ff'; c.beginPath(); c.arc(19,-6,1.8,0,7); c.fill();
    let b = c.createRadialGradient(-3,-3,2,0,0,11); b.addColorStop(0,'#d19cf2'); b.addColorStop(1,'#5b2a85');
    c.fillStyle = b; c.beginPath(); c.arc(0,0,10,0,7); c.fill();
  }
  c.restore();
  // chấm cấp
  c.save(); c.translate(x, y + 27); c.fillStyle = '#ffc857'; c.strokeStyle = 'rgba(0,0,0,.5)'; c.lineWidth = 1;
  for (let i = 0; i < lvl; i++) { c.beginPath(); c.arc((i-(lvl-1)/2)*7, 0, 2.6, 0, 7); c.fill(); c.stroke(); }
  c.restore();
}

