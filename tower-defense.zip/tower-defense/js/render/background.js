// Nền tĩnh (cỏ, đường, cây/đá, lâu đài). Vẽ một lần vào canvas ẩn rồi chép lại mỗi khung hình.

import { TILE, COLS, ROWS, W, H, RENDER_SCALE } from '../config.js';
import { rng } from '../util/random.js';
import { WP, posAt, totalLen, pathCells, blocked } from '../core/path.js';

export function buildBackground() {
  const BG = document.createElement('canvas'); BG.width = W*RENDER_SCALE; BG.height = H*RENDER_SCALE;
  const c = BG.getContext('2d'); c.scale(RENDER_SCALE, RENDER_SCALE);
  const rnd = rng(5);
  const gg = c.createLinearGradient(0,0,0,H); gg.addColorStop(0,'#427f3b'); gg.addColorStop(1,'#356b31');
  c.fillStyle = gg; c.fillRect(0,0,W,H);
  for (let r=0;r<ROWS;r++) for (let col=0;col<COLS;col++) if ((r+col)%2) { c.fillStyle = 'rgba(255,255,255,.035)'; c.fillRect(col*TILE,r*TILE,TILE,TILE); }
  for (let i=0;i<900;i++) { const x = rnd()*W, y = rnd()*H; c.strokeStyle = rnd()<.5 ? 'rgba(20,70,20,.35)' : 'rgba(160,230,120,.28)'; c.lineWidth = 1;
    c.beginPath(); c.moveTo(x,y); c.lineTo(x+(rnd()-.5)*3, y-3-rnd()*3); c.stroke(); }
  for (let i=0;i<40;i++) { const x = rnd()*W, y = rnd()*H; if (pathCells.has(Math.floor(x/TILE)+','+Math.floor(y/TILE))) continue;
    c.fillStyle = ['#fff','#ffd2e1','#ffe38a','#c9b6ff'][Math.floor(rnd()*4)]; c.beginPath(); c.arc(x,y,1.8,0,7); c.fill();
    c.fillStyle = '#ffcc33'; c.beginPath(); c.arc(x,y,.8,0,7); c.fill(); }
  // đường
  c.lineCap = 'round'; c.lineJoin = 'round';
  const trace = () => { c.beginPath(); c.moveTo(WP[0].x, WP[0].y); for (const p of WP) c.lineTo(p.x, p.y); };
  trace(); c.strokeStyle = 'rgba(0,0,0,.28)'; c.lineWidth = TILE+12; c.save(); c.translate(0,3); c.stroke(); c.restore();
  trace(); c.strokeStyle = '#5e4524'; c.lineWidth = TILE+6; c.stroke();
  trace(); c.strokeStyle = '#a58455'; c.lineWidth = TILE-2; c.stroke();
  trace(); c.strokeStyle = '#c4a574'; c.lineWidth = TILE-10; c.stroke();
  for (let i=0;i<260;i++) { const p = posAt(rnd()*totalLen); const a = rnd()*6.28, d = rnd()*TILE*.38;
    c.fillStyle = rnd()<.5 ? 'rgba(110,80,40,.35)' : 'rgba(235,215,170,.4)'; c.beginPath(); c.arc(p.x+Math.cos(a)*d, p.y+Math.sin(a)*d, .8+rnd()*1.6, 0, 7); c.fill(); }
  // cây & đá
  for (const [k, kind] of blocked) {
    const [col, row] = k.split(',').map(Number), x = (col+.5)*TILE, y = (row+.5)*TILE;
    c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(x+3,y+14,18,8,0,0,7); c.fill();
    if (kind === 'tree') {
      c.fillStyle = '#6b4423'; c.fillRect(x-3,y+2,6,13);
      for (const [ox,oy,rad,col2] of [[-8,2,12,'#2f7a35'],[8,2,12,'#2f7a35'],[0,-6,15,'#3b9441'],[-2,-10,8,'#58b055']]) {
        const gr = c.createRadialGradient(x+ox-3,y+oy-4,2,x+ox,y+oy,rad); gr.addColorStop(0,'#6fcf6a'); gr.addColorStop(1,col2);
        c.fillStyle = gr; c.beginPath(); c.arc(x+ox,y+oy,rad,0,7); c.fill(); }
    } else {
      for (const [ox,oy,rad] of [[-6,6,10],[7,8,8],[0,0,12]]) {
        const gr = c.createRadialGradient(x+ox-3,y+oy-3,1,x+ox,y+oy,rad); gr.addColorStop(0,'#b8bdc8'); gr.addColorStop(1,'#5c6270');
        c.fillStyle = gr; c.beginPath(); c.ellipse(x+ox,y+oy,rad,rad*.8,0,0,7); c.fill(); }
    }
  }
  // lâu đài (căn cứ)
  const kx = W-52, ky = 9*TILE-14;
  c.fillStyle = 'rgba(0,0,0,.3)'; c.ellipse && (c.beginPath(), c.ellipse(kx+26,ky+70,34,9,0,0,7), c.fill());
  const wall = c.createLinearGradient(kx,0,kx+52,0); wall.addColorStop(0,'#aeb4c2'); wall.addColorStop(1,'#707789');
  c.fillStyle = wall; c.fillRect(kx,ky+10,52,60);
  for (let i=0;i<4;i++) c.fillRect(kx+i*14,ky,10,12);
  c.fillStyle = '#4b3220'; c.beginPath(); c.moveTo(kx+14,ky+70); c.lineTo(kx+14,ky+48); c.arc(kx+26,ky+48,12,Math.PI,0); c.lineTo(kx+38,ky+70); c.fill();
  c.strokeStyle = '#3d424f'; c.lineWidth = 1; for (let i=0;i<4;i++){ c.beginPath(); c.moveTo(kx,ky+22+i*12); c.lineTo(kx+52,ky+22+i*12); c.stroke(); }
  c.strokeStyle = '#444'; c.lineWidth = 2; c.beginPath(); c.moveTo(kx+26,ky); c.lineTo(kx+26,ky-24); c.stroke();
  c.fillStyle = '#3b82f6'; c.beginPath(); c.moveTo(kx+26,ky-24); c.lineTo(kx+44,ky-18); c.lineTo(kx+26,ky-12); c.fill();
  return BG;
}
