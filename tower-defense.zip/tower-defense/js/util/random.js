// Bộ sinh số ngẫu nhiên có seed (mulberry32): cùng seed cho cùng kết quả.
// Dùng để bản đồ/trang trí luôn giống nhau mỗi lần chơi.
export function rng(seed) {
  return () => {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
