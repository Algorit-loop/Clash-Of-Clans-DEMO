// Dữ liệu quái. Thêm quái mới: thêm một mục ở đây, rồi cho vào js/data/waves.js
// (và vẽ riêng trong js/render/enemySprites.js nếu muốn hình dạng khác).
//   hp      máu gốc (được nhân thêm theo đợt, xem waves.js)
//   speed   px/giây
//   reward  vàng khi hạ
//   cost    số mạng bị trừ nếu lọt vào căn cứ
//   r       bán kính (px)
//   hi/mid/lo  màu sáng/giữa/tối để tô gradient

export const ENEMIES = {
  normal: { name: 'Thường',   hp: 40,   speed: 62,  reward: 6,   r: 11, cost: 1, hi: '#ff8a80', mid: '#e5534b', lo: '#8e2323' },
  fast:   { name: 'Nhanh',    hp: 26,   speed: 118, reward: 7,   r: 9,  cost: 1, hi: '#fff08a', mid: '#f2c744', lo: '#a07a0c' },
  tank:   { name: 'Giáp dày', hp: 180,  speed: 38,  reward: 15,  r: 15, cost: 2, hi: '#b9895a', mid: '#7a5230', lo: '#3f2812' },
  boss:   { name: 'Boss',     hp: 1500, speed: 30,  reward: 130, r: 21, cost: 5, hi: '#d58bff', mid: '#8e2de2', lo: '#4a137f' },
};
