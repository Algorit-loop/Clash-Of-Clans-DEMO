// Dữ liệu tháp. Thêm tháp mới: thêm một mục ở đây + vẽ sprite trong js/render/towerSprites.js
// (+ phím tắt `key`). Logic bắn, nâng cấp, UI tự đọc dữ liệu này.
//
//   cost       giá xây
//   speed      tốc độ đạn (px/giây)
//   muzzle     đạn xuất hiện cách tâm tháp bao xa (px)
//   artillery  true = đạn rơi xuống điểm ngắm rồi nổ (không va chạm giữa đường)
//   levels[i]  chỉ số cấp i+1:
//       dmg, range (px), rate (giây giữa 2 phát),
//       splash (bán kính nổ), slow (hệ số tốc độ còn lại, 0.5 = chậm 50%), slowT (giây)
//   upgrades[i]  nâng từ cấp i+1 lên i+2: cost, name, desc

export const TOWERS = {
  arrow: {
    name: 'Cung thủ', key: '1', cost: 50, speed: 560, muzzle: 22,
    desc: 'Bắn nhanh, giá rẻ. Tốt cho mọi giai đoạn.',
    levels: [
      { dmg: 12, range: 130, rate: .45 },
      { dmg: 18, range: 130, rate: .40 },
      { dmg: 25, range: 150, rate: .34 },
      { dmg: 36, range: 170, rate: .27 },
    ],
    upgrades: [
      { cost: 40,  name: 'Mũi tên sắc',      desc: 'Mũi tên được mài sắc, bắn nhanh hơn một chút.' },
      { cost: 70,  name: 'Cung dài',          desc: 'Cung dài hơn: tăng tầm bắn và sát thương.' },
      { cost: 115, name: 'Xạ thủ tinh nhuệ',  desc: 'Bắn liên thanh, tầm bắn rất xa.' },
    ],
  },
  cannon: {
    name: 'Đại bác', key: '2', cost: 100, speed: 300, muzzle: 22, artillery: true,
    desc: 'Đạn nổ gây sát thương lan. Đạn bay chậm, quái chạy nhanh có thể né.',
    levels: [
      { dmg: 34, range: 105, rate: 1.3,  splash: 55 },
      { dmg: 48, range: 105, rate: 1.3,  splash: 62 },
      { dmg: 64, range: 118, rate: 1.15, splash: 72 },
      { dmg: 90, range: 130, rate: 1.0,  splash: 88 },
    ],
    upgrades: [
      { cost: 80,  name: 'Thuốc súng nén',  desc: 'Tăng sát thương và vùng nổ.' },
      { cost: 135, name: 'Nòng dài',         desc: 'Tăng tầm bắn, sát thương và tốc độ nạp.' },
      { cost: 210, name: 'Đạn xuyên giáp',   desc: 'Nổ cực mạnh trên vùng rộng.' },
    ],
  },
  frost: {
    name: 'Tháp Băng', key: '3', cost: 75, speed: 420, muzzle: 0,
    desc: 'Làm chậm kẻ địch trúng đạn. Sát thương thấp nhưng cực hữu ích.',
    levels: [
      { dmg: 5,  range: 110, rate: .8,  slow: .55, slowT: 1.6 },
      { dmg: 6,  range: 110, rate: .75, slow: .45, slowT: 2.0 },
      { dmg: 9,  range: 125, rate: .7,  slow: .38, slowT: 2.3 },
      { dmg: 14, range: 140, rate: .6,  slow: .28, slowT: 2.8 },
    ],
    upgrades: [
      { cost: 60,  name: 'Băng giá sâu',  desc: 'Làm chậm mạnh hơn và lâu hơn.' },
      { cost: 100, name: 'Tinh thể lớn',   desc: 'Tăng tầm bắn, sát thương và hiệu ứng chậm.' },
      { cost: 160, name: 'Bão tuyết',      desc: 'Gần như đóng băng kẻ địch trong thời gian dài.' },
    ],
  },
  sniper: {
    name: 'Bắn tỉa', key: '4', cost: 150, speed: 1000, muzzle: 38,
    desc: 'Tầm cực xa, một phát rất đau. Bắn chậm.',
    levels: [
      { dmg: 100, range: 270, rate: 2.2 },
      { dmg: 160, range: 270, rate: 2.0 },
      { dmg: 240, range: 310, rate: 1.8 },
      { dmg: 360, range: 360, rate: 1.5 },
    ],
    upgrades: [
      { cost: 120, name: 'Đạn nặng',            desc: 'Tăng mạnh sát thương, nạp đạn nhanh hơn.' },
      { cost: 180, name: 'Ống ngắm tốt',         desc: 'Tăng tầm bắn, sát thương và tốc độ bắn.' },
      { cost: 260, name: 'Xạ thủ huyền thoại',   desc: 'Tầm bắn gần như cả bản đồ, sát thương khủng.' },
    ],
  },
};

// Các chế độ chọn mục tiêu: [id, nhãn hiển thị]
export const TARGET_MODES = [['first', 'Đầu'], ['strong', 'Mạnh'], ['weak', 'Yếu'], ['close', 'Gần']];
