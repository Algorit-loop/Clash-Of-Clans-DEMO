// Dữ liệu bản đồ. Toạ độ tính theo ô (cột, hàng); có thể lẻ (19.5 = giữa ô).
// Muốn đổi đường đi: sửa danh sách điểm này. Điểm đầu nằm ngoài màn hình (-1) để quái chạy vào.

export const WAYPOINTS = [[-1, 2], [15, 2], [15, 5], [3, 5], [3, 9], [19.5, 9]];

// Cây/đá chắn (không xây được), sinh ngẫu nhiên theo seed, tránh các ô sát đường đi.
export const OBSTACLES = { seed: 11, count: 15, treeChance: 0.65 };
