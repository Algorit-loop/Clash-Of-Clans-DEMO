// Công thức cân bằng theo đợt. Muốn game dễ/khó hơn: chỉnh các hàm này.
import { ENEMIES } from './enemies.js';

// Số lượng từng loại quái của đợt n.
export function composition(n) {
  const total = 6 + Math.floor(n * 1.8);
  const fast = n >= 3 ? Math.round(total * 0.25) : 0;
  const tank = n >= 5 ? Math.round(total * 0.2) : 0;
  const boss = n % 5 === 0 ? (n >= 25 ? 2 : 1) : 0;
  return { normal: total - fast - tank, fast, tank, boss };
}

// Máu của quái loại `type` ở đợt n (tăng dần theo đợt).
export const enemyHp = (type, n) => ENEMIES[type].hp * (1 + 0.14 * n) * Math.pow(1.035, n);

// Khoảng cách giữa 2 quái xuất hiện (giây).
export const spawnInterval = n => Math.max(0.3, 0.9 - n * 0.02);

// Thưởng vàng khi hoàn thành đợt n.
export const waveBonus = n => 20 + n * 3;
