// Điểm vào của game: nối các tầng lại và chạy vòng lặp.

import { W, H } from './config.js';
import { resetState } from './core/state.js';
import { advance } from './logic/game.js';
import { initRenderer, draw } from './render/renderer.js';
import { initUI, updateUI } from './ui/index.js';
import { $ } from './ui/dom.js';

const canvas = $('c');

// Co giãn khung game cho vừa cửa sổ, giữ nguyên tỉ lệ (không cần cuộn trang).
function fit() {
  const wrap = $('stagewrap'), k = Math.min(wrap.clientWidth / W, wrap.clientHeight / H), st = $('stage');
  st.style.width = Math.floor(W * k) + 'px';
  st.style.height = Math.floor(H * k) + 'px';
}
new ResizeObserver(fit).observe($('stagewrap'));
addEventListener('resize', fit);
fit();

resetState();
initRenderer(canvas);
initUI(canvas);

let last = performance.now();
function loop(now) {
  advance((now - last) / 1000);
  last = now;
  draw();
  updateUI();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
