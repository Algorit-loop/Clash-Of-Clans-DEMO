// Vòng lặp logic: ghép các hệ thống lại theo thứ tự, điều khiển thời gian.

import { STEP, MAX_SPEED } from '../config.js';
import { S, resetState } from '../core/state.js';
import { emit } from '../core/events.js';
import { updateSpawning, checkWaveCleared } from './waves.js';
import { updateEnemies, updateProjectiles } from './combat.js';
import { updateTowers } from './towers.js';
import { updateEffects } from './effects.js';

function endGame(win) {
  S.over = true;
  emit('gameover', win);
}

// Một bước logic cố định (STEP giây).
function update(dt) {
  S.t += dt;
  updateSpawning(dt);
  updateEnemies(dt);
  if (S.lives <= 0) return endGame(false);
  updateTowers(dt);
  updateProjectiles(dt);
  updateEffects(dt);
  S.enemies = S.enemies.filter(e => !e.dead);
  S.shots = S.shots.filter(s => !s.done);
  if (checkWaveCleared()) endGame(true);
}

// Nhận thời gian thực (giây) từ vòng lặp vẽ, chạy đủ số bước cố định.
// Chạy theo bước cố định nên x1/x2/x3 không làm lệch logic.
export function advance(realDt) {
  S.acc += Math.min(.1, realDt) * S.speed;
  if (S.paused || S.over) S.acc = 0;
  while (S.acc >= STEP && !S.over) { update(STEP); S.acc -= STEP; }
}

export function restart() {
  resetState();
  emit('reset');
}

export const togglePause = () => { S.paused = !S.paused; };
export const cycleSpeed = () => { S.speed = S.speed % MAX_SPEED + 1; };
