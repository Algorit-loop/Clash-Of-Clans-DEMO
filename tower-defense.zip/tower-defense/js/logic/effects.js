// Hiệu ứng thuần hình ảnh: chữ bay, tia lửa, vòng nổ. Không ảnh hưởng gameplay.

import { S } from '../core/state.js';

export function floatText(x, y, txt, color) {
  S.texts.push({ x, y, txt, color, life: .9, max: .9 });
}

export function puff(x, y, color, n) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * 6.28, s = 30 + Math.random() * 90;
    S.fx.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: .45, max: .45, color, size: 2 + Math.random() * 2 });
  }
}

export function ring(x, y, r, color) {
  S.fx.push({ ring: true, x, y, r, life: .3, max: .3, color });
}

export function updateEffects(dt) {
  for (const f of S.fx) {
    f.life -= dt;
    if (!f.ring) { f.x += f.vx * dt; f.y += f.vy * dt; f.vx *= .93; f.vy *= .93; }
  }
  for (const x of S.texts) { x.life -= dt; x.y -= 24 * dt; }
  S.fx = S.fx.filter(f => f.life > 0);
  S.texts = S.texts.filter(x => x.life > 0);
}
