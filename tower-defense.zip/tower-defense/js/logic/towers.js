// Tháp: xây, nâng cấp, bán, chọn mục tiêu và bắn.

import { TILE, COLS, ROWS, SELL_RATIO } from '../config.js';
import { S, nextId } from '../core/state.js';
import { emit } from '../core/events.js';
import { posAt, pathCells, blocked } from '../core/path.js';
import { TOWERS } from '../data/towers.js';
import { puff, floatText } from './effects.js';

// ---------- Truy vấn ----------
export const lvOf = t => TOWERS[t.type].levels[t.level - 1];            // chỉ số cấp hiện tại
export const upCost = t => TOWERS[t.type].upgrades[t.level - 1]?.cost;   // giá nâng cấp (undefined nếu tối đa)
export const sellValue = t => Math.round(t.spent * SELL_RATIO);

// Trả về lý do không xây được ở ô (c, r), hoặc null nếu xây được.
export function cellError(c, r) {
  const k = c + ',' + r;
  if (c < 0 || r < 0 || c >= COLS || r >= ROWS) return 'Ngoài bản đồ';
  if (pathCells.has(k)) return 'Không thể xây trên đường đi';
  if (blocked.has(k)) return 'Ô này bị cây/đá chắn';
  if (S.towers.some(t => t.c === c && t.r === r)) return 'Đã có tháp ở đây';
  return null;
}

export const towerAt = (c, r) => S.towers.find(t => t.c === c && t.r === r);

// ---------- Lựa chọn ----------
export function selectType(id) {
  S.selType = S.selType === id ? null : id;
  S.selTower = null; S.previewUpgrade = false;
}
export function selectTower(t) {
  S.selType = null; S.selTower = t || null; S.previewUpgrade = false;
}
export const clearSelection = () => selectTower(null);

// ---------- Hành động ----------
export function placeTower(c, r) {
  const def = TOWERS[S.selType], err = cellError(c, r);
  if (err) return emit('toast', err);
  if (S.gold < def.cost) return emit('toast', 'Không đủ vàng!');
  S.gold -= def.cost;
  const t = {
    id: nextId(), type: S.selType, c, r, x: (c + .5) * TILE, y: (r + .5) * TILE,
    level: 1, spent: def.cost, mode: 'first',
    cd: 0,                          // thời gian hồi còn lại trước phát bắn kế tiếp
    angle: -Math.PI / 2, recoil: 0, // chỉ để vẽ
  };
  S.towers.push(t);
  selectTower(t);
  puff(t.x, t.y, '#fff', 8);
}

export function upgradeTower() {
  const t = S.selTower;
  if (!t) return;
  const c = upCost(t);
  if (c == null) return emit('toast', 'Đã tối đa');
  if (S.gold < c) return emit('toast', 'Không đủ vàng!');
  S.gold -= c; t.spent += c; t.level++;
  puff(t.x, t.y, '#ffc857', 14);
  floatText(t.x, t.y - 26, 'Lv' + t.level + '!', '#ffc857');
}

export function sellTower() {
  const t = S.selTower;
  if (!t) return;
  const v = sellValue(t);
  S.gold += v;
  floatText(t.x, t.y - 20, '+' + v, '#ffc857');
  S.towers = S.towers.filter(x => x !== t);
  clearSelection();
}

export function setTargetMode(t, mode) { t.mode = mode; }

// ---------- Bắn ----------
// Chọn mục tiêu trong tầm theo chế độ ưu tiên của tháp.
function pickTarget(t, lv) {
  let best = null, bv = 0;
  for (const e of S.enemies) {
    if (e.dead) continue;
    const dist = Math.hypot(e.x - t.x, e.y - t.y);
    if (dist > lv.range + e.r) continue;
    const v = t.mode === 'first' ? e.d : t.mode === 'strong' ? e.hp : t.mode === 'weak' ? -e.hp : -dist;
    if (!best || v > bv) { best = e; bv = v; }
  }
  return best;
}

// Tạo một viên đạn bay về vị trí mà quái sẽ đến (ngắm đón đầu).
// Đạn KHÔNG tự đuổi theo: nếu quái đổi tốc độ hoặc đạn bay chậm thì có thể trượt.
function fire(t, lv, target) {
  const def = TOWERS[t.type], sp = def.speed;
  let ax = target.x, ay = target.y;
  for (let i = 0; i < 5; i++) {
    const tt = Math.hypot(ax - t.x, ay - t.y) / sp;
    const p = posAt(target.d + target.speed * target.slowF * tt);
    ax = p.x; ay = p.y;
  }
  const dist = Math.hypot(ax - t.x, ay - t.y) || 1, ux = (ax - t.x) / dist, uy = (ay - t.y) / dist;
  t.angle = Math.atan2(uy, ux); t.recoil = 1;
  S.shots.push({
    type: t.type, artillery: !!def.artillery, x: t.x + ux * def.muzzle, y: t.y + uy * def.muzzle, vx: ux * sp, vy: uy * sp, speed: sp, ang: t.angle,
    dmg: lv.dmg, splash: lv.splash || 0, slow: lv.slow || 0, slowT: lv.slowT || 0,
    travelled: 0, aimDist: dist, maxDist: lv.range * 1.25 + 40, ox: t.x, oy: t.y,
  });
}

export function updateTowers(dt) {
  for (const t of S.towers) {
    const lv = lvOf(t);
    t.cd -= dt; t.recoil = Math.max(0, t.recoil - dt * 5);
    const target = pickTarget(t, lv);
    if (!target) continue;
    if (t.cd <= 0) { t.cd = lv.rate; fire(t, lv, target); }
    else if (t.type !== 'frost') t.angle = Math.atan2(target.y - t.y, target.x - t.x);
  }
}
