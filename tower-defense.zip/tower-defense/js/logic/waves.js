// Đợt quái: gọi đợt, sinh quái theo hàng đợi, thưởng khi dọn sạch.

import { MAX_WAVE } from '../config.js';
import { S, nextId } from '../core/state.js';
import { emit } from '../core/events.js';
import { WP } from '../core/path.js';
import { ENEMIES } from '../data/enemies.js';
import { composition, enemyHp, spawnInterval, waveBonus } from '../data/waves.js';

export function startWave() {
  if (S.over || S.waveActive || S.wave >= MAX_WAVE) return;
  const n = ++S.wave, comp = composition(n), q = [];
  for (const t of ['normal', 'fast', 'tank']) for (let i = 0; i < comp[t]; i++) q.push(t);
  // xáo trộn quái thường, rồi boss luôn đi sau cùng
  for (let i = q.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [q[i], q[j]] = [q[j], q[i]]; }
  for (let i = 0; i < comp.boss; i++) q.push('boss');
  S.queue = q; S.spawnT = 0; S.waveActive = true; S.interval = spawnInterval(n);
}

function spawn(type) {
  const E = ENEMIES[type], hp = enemyHp(type, S.wave);
  S.enemies.push({
    id: nextId(), type, hp, max: hp, speed: E.speed, r: E.r, reward: E.reward, cost: E.cost,
    d: 0,                          // quãng đường đã đi dọc đường
    slowT: 0, slowF: 1,            // thời gian còn bị chậm / hệ số tốc độ
    x: WP[0].x, y: WP[0].y, dx: 1, dy: 0,   // vị trí & hướng nhìn
    flash: 0, phase: Math.random() * 6,     // chỉ để vẽ
  });
}

// Cho quái trong hàng đợi xuất hiện dần, mỗi con cách nhau S.interval giây.
export function updateSpawning(dt) {
  if (!S.queue.length) return;
  S.spawnT -= dt;
  if (S.spawnT <= 0) { spawn(S.queue.shift()); S.spawnT = S.interval; }
}

// Đợt đã xong khi hết hàng đợi và hết quái trên bản đồ -> thưởng vàng.
// Trả về true nếu vừa dọn xong đợt cuối (thắng).
export function checkWaveCleared() {
  if (S.waveActive && !S.queue.length && !S.enemies.length) {
    S.waveActive = false;
    const bonus = waveBonus(S.wave);
    S.gold += bonus;
    emit('toast', `Hoàn thành đợt ${S.wave}! +${bonus} vàng`);
    return S.wave >= MAX_WAVE;
  }
  return false;
}
