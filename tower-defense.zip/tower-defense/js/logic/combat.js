// Chiến đấu: di chuyển quái, bay đạn, va chạm và sát thương.
// Quy tắc cốt lõi: quái CHỈ mất máu khi một viên đạn thực sự chạm vào nó.

import { S } from '../core/state.js';
import { emit } from '../core/events.js';
import { posAt, totalLen } from '../core/path.js';
import { ENEMIES } from '../data/enemies.js';
import { floatText, puff, ring } from './effects.js';

export function dealDamage(e, dmg, slow, slowT) {
  if (e.dead) return;
  e.hp -= dmg; e.flash = .12;
  floatText(e.x + (Math.random() - .5) * 10, e.y - e.r - 6, Math.round(dmg), '#fff');
  if (slow) {
    // hiệu ứng chậm không cộng dồn: lấy mức mạnh nhất, thời gian dài nhất
    e.slowF = Math.min(e.slowT > 0 ? e.slowF : 1, slow);
    e.slowT = Math.max(e.slowT, slowT);
  }
  if (e.hp <= 0) {
    e.dead = true; S.gold += e.reward; S.kills++;
    floatText(e.x, e.y - e.r - 16, '+' + e.reward, '#ffc857');
    puff(e.x, e.y, ENEMIES[e.type].mid, e.type === 'boss' ? 26 : 9);
  }
}

// Di chuyển quái dọc đường; quái đến cuối đường thì trừ mạng.
export function updateEnemies(dt) {
  for (const e of S.enemies) {
    if (e.slowT > 0) { e.slowT -= dt; if (e.slowT <= 0) e.slowF = 1; }
    e.flash = Math.max(0, e.flash - dt);
    e.d += e.speed * e.slowF * dt;
    const p = posAt(e.d), q = posAt(e.d + 2);
    e.x = p.x; e.y = p.y;
    const l = Math.hypot(q.x - p.x, q.y - p.y);
    if (l > .01) { e.dx = (q.x - p.x) / l; e.dy = (q.y - p.y) / l; }
    if (e.d >= totalLen && !e.dead) {
      e.dead = true;
      S.lives = Math.max(0, S.lives - e.cost);
      emit('toast', 'Quái lọt vào căn cứ! -' + e.cost + ' mạng');
      if (S.lives <= 0) return;   // hết mạng: dừng ngay, không xử lý các quái còn lại
    }
  }
}

// Đoạn thẳng (x1,y1)->(x2,y2) có cắt hình tròn (cx,cy,r) không?
// Trả về vị trí cắt trong đoạn (0..1), hoặc -1 nếu không cắt.
function segCircle(x1, y1, x2, y2, cx, cy, r) {
  const dx = x2 - x1, dy = y2 - y1, l2 = dx * dx + dy * dy || 1;
  const u = Math.max(0, Math.min(1, ((cx - x1) * dx + (cy - y1) * dy) / l2));
  return Math.hypot(x1 + dx * u - cx, y1 + dy * u - cy) <= r ? u : -1;
}

export function updateProjectiles(dt) {
  for (const s of S.shots) {
    const nx = s.x + s.vx * dt, ny = s.y + s.vy * dt;
    s.travelled += s.speed * dt;

    if (s.artillery) {
      // Đạn pháo nổ tại điểm đã ngắm. Quái né được nếu đã chạy khỏi vùng nổ.
      if (s.travelled >= s.aimDist) {
        const cx = s.ox + s.vx / s.speed * s.aimDist, cy = s.oy + s.vy / s.speed * s.aimDist;
        for (const e of S.enemies) {
          if (e.dead) continue;
          const d = Math.hypot(e.x - cx, e.y - cy);
          if (d <= s.splash + e.r * .5) dealDamage(e, s.dmg * (1 - .4 * Math.min(1, d / s.splash)));
        }
        ring(cx, cy, s.splash, '255,170,70');
        puff(cx, cy, '#ffb05a', 8);
        s.done = true;
      } else { s.x = nx; s.y = ny; }
      continue;
    }

    // Đạn thường: trúng con quái đầu tiên mà đường bay cắt qua.
    let hit = null, hu = 2;
    for (const e of S.enemies) {
      if (e.dead) continue;
      const u = segCircle(s.x, s.y, nx, ny, e.x, e.y, e.r + 2);
      if (u >= 0 && u < hu) { hu = u; hit = e; }
    }
    if (hit) {
      dealDamage(hit, s.dmg, s.slow, s.slowT);
      if (s.type === 'frost') puff(hit.x, hit.y, '#aeeaff', 5);
      s.done = true;
    } else if (s.travelled >= s.maxDist) s.done = true;   // bay quá xa -> biến mất
    else { s.x = nx; s.y = ny; }
  }
}
