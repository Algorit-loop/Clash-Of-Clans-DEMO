# 🏰 Tower Defense

Game thủ thành chạy trên trình duyệt, viết bằng JavaScript thuần (ES modules) và Canvas. Không cần cài thư viện hay build.

Đặt tháp dọc đường đi, chặn quái trước khi chúng chạm vào căn cứ. Sống sót qua **30 đợt** là thắng; hết **20 mạng** là thua.

## Chạy game

Game dùng ES modules nên **phải chạy qua web server**, mở thẳng file `index.html` sẽ không chạy.

```bash
cd ~/tower-defense
python3 -m http.server 8080 --bind 127.0.0.1     # chạy ở foreground, Ctrl+C để tắt
```

Rồi mở <http://localhost:8080>.

Chạy nền / tắt:

```bash
nohup python3 -m http.server 8080 --bind 127.0.0.1 > /tmp/td-server.log 2>&1 &
pkill -f "http.server 8080"
```

Muốn chơi trên máy khác cùng mạng LAN thì bỏ `--bind 127.0.0.1` và mở `http://<IP-máy>:8080`.

> Font (Baloo 2, Nunito) tải từ Google Fonts; nếu không có mạng game vẫn chạy với font mặc định.

## Cách chơi

| Thao tác | Cách làm |
|---|---|
| Chọn tháp để xây | Bấm thẻ tháp bên phải, hoặc phím `1`–`4` |
| Xây tháp | Bấm ô cỏ trống (ô nâu là đường, ô có cây/đá không xây được) |
| Xem / nâng cấp / bán | Bấm vào tháp đã xây, rồi dùng nút trong khung **Chi tiết** (hoặc phím `U` / `S`) |
| Xem trước tầm bắn khi nâng cấp | Rê chuột vào khung nâng cấp: vòng xanh trên bản đồ là tầm bắn mới |
| Gọi đợt quái | `Space` hoặc nút ▶ (có thể gọi sớm) |
| Tạm dừng / tốc độ | `P` / nút ⏩ (x1, x2, x3) |
| Bỏ chọn | `Esc` hoặc chuột phải |

**Tháp:** Cung thủ (rẻ, bắn nhanh), Đại bác (nổ lan, đạn chậm), Tháp Băng (làm chậm), Bắn tỉa (tầm xa, sát thương lớn). Mỗi tháp có 4 cấp, mỗi lần nâng cấp có tên và mô tả riêng.

**Quái:** Thường, Nhanh (từ đợt 3), Giáp dày (từ đợt 5), Boss (các đợt chia hết cho 5). Quái lọt vào căn cứ trừ mạng theo độ mạnh (1, 1, 2, 5).

### Quy tắc cốt lõi

- Quái **chỉ mất máu khi bị đạn thực sự chạm vào**. Đạn không tự đuổi theo: tháp ngắm đón đầu vị trí quái sẽ đến, nên đạn vẫn có thể trượt.
- Đại bác nổ tại điểm đã ngắm; quái chạy ra khỏi vùng nổ thì né được.
- Hiệu ứng làm chậm không cộng dồn: lấy mức mạnh nhất và thời gian dài nhất.
- Logic chạy theo bước cố định 1/60 giây, nên x1/x2/x3 không làm lệch kết quả.

## Cấu trúc thư mục

```
tower-defense/
├── index.html            Khung HTML (không có logic)
├── css/style.css         Toàn bộ giao diện
└── js/
    ├── main.js           Điểm vào: nối các tầng, chạy vòng lặp
    ├── config.js         Hằng số chung (kích thước ô, số đợt, vàng/mạng ban đầu...)
    │
    ├── data/             DỮ LIỆU thuần, không có logic. Muốn cân bằng game: sửa ở đây
    │   ├── towers.js       Các loại tháp, chỉ số 4 cấp, giá nâng cấp, phím tắt
    │   ├── enemies.js      Các loại quái: máu, tốc độ, thưởng, màu
    │   ├── waves.js        Công thức đợt: số lượng quái, máu theo đợt, thưởng
    │   └── map.js          Các điểm ngoặt của đường đi, cây/đá
    │
    ├── core/             Nền tảng dùng chung
    │   ├── state.js        Trạng thái ván chơi (object `S`) + resetState()
    │   ├── path.js         Hình học đường đi: posAt(), ô bị chiếm, cây/đá
    │   └── events.js       Event bus nhỏ (logic báo cho UI: toast, gameover, reset)
    │
    ├── logic/            LOGIC game. Không đụng DOM, không đụng canvas
    │   ├── game.js         Một bước cập nhật (thứ tự các hệ thống), tốc độ, tạm dừng, restart
    │   ├── waves.js        Gọi đợt, sinh quái, thưởng khi dọn sạch đợt
    │   ├── towers.js       Xây / nâng cấp / bán, chọn mục tiêu, bắn
    │   ├── combat.js       Quái di chuyển, đạn bay, va chạm, sát thương
    │   └── effects.js      Hiệu ứng hình ảnh (chữ bay, tia lửa, vòng nổ)
    │
    ├── render/           ĐỒ HỌA. Chỉ đọc trạng thái, không đổi gameplay
    │   ├── renderer.js     Vẽ một khung hình
    │   ├── background.js   Nền tĩnh: cỏ, đường, cây/đá, lâu đài
    │   ├── towerSprites.js Hình tháp
    │   ├── enemySprites.js Hình quái + thanh máu
    │   └── icons.js        Icon tháp cho cửa hàng
    │
    ├── ui/               GIAO DIỆN HTML quanh canvas
    │   ├── index.js        Khởi tạo UI và cập nhật mỗi khung hình
    │   ├── hud.js          Vàng/mạng/đợt, nút điều khiển, thông báo, màn hình thắng/thua
    │   ├── shop.js         Danh sách tháp bên phải
    │   ├── inspector.js    Khung chi tiết / nâng cấp / bán
    │   ├── towerStats.js   Định dạng chỉ số hiển thị
    │   ├── input.js        Chuột, nút bấm, phím tắt
    │   └── dom.js          Tiện ích DOM
    │
    └── util/random.js    Bộ sinh số ngẫu nhiên có seed
```

### Quy tắc phụ thuộc

```
data ─┐
      ├─▶ core ─▶ logic ─▶ render ─▶ ui ─▶ main
config ┘
```

Mỗi tầng chỉ được import từ tầng đứng **trước** nó:

- `data/` và `config.js` không import gì (trừ `waves.js` đọc `enemies.js`).
- `logic/` không bao giờ import `render/` hay `ui/`. Khi cần báo cho giao diện, nó phát sự kiện qua `core/events.js` (ví dụ `emit('toast', '...')`).
- `render/` chỉ đọc `S`, không sửa nó.
- `ui/` gọi các hành động của `logic/` (`placeTower`, `upgradeTower`, `startWave`...) chứ không tự sửa trạng thái game.

### Luồng mỗi khung hình

```
main.js loop
  ├─ advance(dt)   logic/game.js: chạy 0..n bước cố định 1/60s, mỗi bước theo thứ tự
  │                  spawn → quái di chuyển → tháp bắn → đạn bay/va chạm → hiệu ứng → dọn rác → kiểm tra hết đợt
  ├─ draw()        render/renderer.js
  └─ updateUI()    ui/index.js (chỉ ghi lại DOM khi giá trị đổi)
```

## Cách mở rộng

**Chỉnh độ khó:** sửa `js/data/waves.js` (số quái, máu theo đợt, thưởng, khoảng cách xuất hiện) hoặc `js/config.js` (vàng/mạng ban đầu, số đợt, tỉ lệ hoàn tiền khi bán).

**Thêm tháp mới:**
1. Thêm một mục vào `TOWERS` trong `js/data/towers.js` (4 cấp + 3 nâng cấp, `key` là phím tắt).
2. Vẽ hình tháp: thêm nhánh `else if (type === '...')` trong `js/render/towerSprites.js`.
3. Vẽ viên đạn: thêm nhánh tương ứng trong vòng `for (const s of S.shots)` ở `js/render/renderer.js`.

Logic bắn, nâng cấp, cửa hàng và khung chi tiết tự đọc từ dữ liệu. `muzzle` là khoảng cách đạn xuất hiện so với tâm tháp; `artillery: true` cho đạn rơi xuống điểm ngắm rồi nổ (như đại bác).

**Thêm quái mới:** thêm mục vào `js/data/enemies.js`, cho nó xuất hiện trong `composition()` ở `js/data/waves.js`, và (nếu muốn hình riêng) thêm nhánh trong `js/render/enemySprites.js`.

**Đổi đường đi:** sửa `WAYPOINTS` trong `js/data/map.js` (toạ độ theo ô `[cột, hàng]`). Cây/đá tự sinh lại tránh đường mới. Lâu đài vẽ ở góc phải-dưới trong `js/render/background.js`; nếu đổi điểm cuối đường thì chỉnh vị trí đó theo.
