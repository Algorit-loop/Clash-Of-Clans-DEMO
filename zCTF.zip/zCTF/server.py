"""Máy chủ FastAPI cho zCTF.

Chạy:  ./run.sh            (hoặc: .venv/bin/python server.py)
Đổi cổng/host:  PORT=9000 HOST=0.0.0.0 ./run.sh

- Trang web: index.html + css/ + js/ + vendor/ (Pyodide, sql.js)
- Script JS được nạp tự động theo thứ tự: js/core → js/data → js/widgets → js/lessons → js/tools.js → js/app.js
- Lab thật (vulnerable-by-design, an toàn): mỗi file labs/<tên>.py khai báo `router = APIRouter()`
  và được gắn tại /lab/<tên>/... Lab KHÔNG được chạy lệnh hệ thống hay đọc file thật trên đĩa.
- /__curl: proxy cho lệnh `curl` trong terminal giả lập, chỉ gửi request vào chính app (đường dẫn /lab/...).
"""

import importlib
import os
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent

app = FastAPI(title="zCTF", docs_url=None, redoc_url=None, openapi_url=None)

# Chỉ phục vụ đúng các thư mục của trang, không lộ .venv, .dev, labs hay mã server.
app.mount("/css", StaticFiles(directory=BASE / "css"), name="css")
app.mount("/js", StaticFiles(directory=BASE / "js"), name="js")
app.mount("/vendor", StaticFiles(directory=BASE / "vendor"), name="vendor")


# ---------------------------------------------------------------- labs
LABS: list[str] = []
for f in sorted((BASE / "labs").glob("*.py")):
    if f.name.startswith("_"):
        continue
    mod = importlib.import_module(f"labs.{f.stem}")
    if hasattr(mod, "router"):
        app.include_router(mod.router, prefix=f"/lab/{f.stem}", include_in_schema=False)
        LABS.append(f.stem)


# ---------------------------------------------------------------- trang
def _scripts() -> str:
    js = BASE / "js"
    order = [*sorted((js / "core").glob("*.js"), key=lambda p: (p.name != "lib.js", p.name != "shell.js", p.name))]
    for sub in ("data", "widgets", "lessons"):
        order += sorted((js / sub).glob("*.js"))
    order += [js / "tools.js", js / "app.js"]
    tags = []
    for p in order:
        if p.exists():
            rel = p.relative_to(BASE).as_posix()
            tags.append(f'<script src="/{rel}?v={int(p.stat().st_mtime)}"></script>')
    return "\n  ".join(tags)


@app.get("/", include_in_schema=False)
def index() -> HTMLResponse:
    html = (BASE / "index.html").read_text(encoding="utf-8")
    css = BASE / "css" / "style.css"
    html = html.replace("css/style.css", f"/css/style.css?v={int(css.stat().st_mtime)}")
    return HTMLResponse(html.replace("<!--SCRIPTS-->", _scripts()), headers={"Cache-Control": "no-cache"})


@app.get("/health", include_in_schema=False)
def health() -> dict:
    return {"status": "ok", "labs": LABS}


# ---------------------------------------------------------------- curl proxy
class CurlReq(BaseModel):
    method: str = "GET"
    path: str
    headers: dict[str, str] = {}
    body: str | None = None
    follow: bool = False


@app.post("/__curl", include_in_schema=False)
async def curl_proxy(r: CurlReq) -> dict:
    if not r.path.startswith("/lab/"):
        raise HTTPException(400, "Terminal chỉ được truy cập đường dẫn /lab/...")
    if r.body and len(r.body) > 100_000:
        raise HTTPException(413, "Body quá lớn")
    headers = {"User-Agent": "curl/8.5.0", "Accept": "*/*", **r.headers}
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://lab.zctf.local", follow_redirects=r.follow, timeout=10) as client:
        resp = await client.request(r.method.upper(), r.path, headers=headers, content=r.body)
    hdrs = [(k, v) for k, v in resp.headers.multi_items() if k.lower() not in ("content-length",)]
    hdrs.append(("content-length", str(len(resp.content))))
    return {"status": resp.status_code, "reason": resp.reason_phrase, "headers": hdrs, "body": resp.text[:200_000]}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "server:app",
        host=os.environ.get("HOST", "0.0.0.0"),
        port=int(os.environ.get("PORT", "9000")),
        reload=os.environ.get("RELOAD") == "1",
    )
