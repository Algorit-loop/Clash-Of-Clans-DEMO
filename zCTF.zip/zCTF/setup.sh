#!/usr/bin/env bash
# Cài môi trường cho zCTF. Mọi thứ được tạo bên trong folder này.
#
#   ./setup.sh           cài thư viện Python vào .venv/ và kiểm tra vendor/
#   ./setup.sh --dev     thêm công cụ kiểm thử (playwright-core trong .dev/)
#   ./setup.sh --force   xoá .venv/ và cài lại từ đầu
set -euo pipefail
cd "$(dirname "$0")"

DEV=0; FORCE=0
for a in "$@"; do
  case "$a" in
    --dev) DEV=1 ;;
    --force) FORCE=1 ;;
    -h|--help) sed -n 2,7p "$0"; exit 0 ;;
    *) echo "Tham số không hợp lệ: $a" >&2; exit 1 ;;
  esac
done

ok()   { printf '\033[32m✓\033[0m %s\n' "$*"; }
info() { printf '\033[36m→\033[0m %s\n' "$*"; }
fail() { printf '\033[31m✗\033[0m %s\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------- Python
command -v python3 >/dev/null || fail "Cần cài python3 (>= 3.10)."
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' \
  || fail "Cần Python >= 3.10, đang có $(python3 -V)."
ok "$(python3 -V)"

[ "$FORCE" = 1 ] && { info "Xoá .venv/ cũ"; rm -rf .venv; }

if [ ! -x .venv/bin/python ]; then
  info "Tạo môi trường ảo .venv/"
  if ! python3 -m venv .venv >/dev/null 2>&1; then
    # Ubuntu/Debian thiếu gói python3-venv (ensurepip) → tạo venv không kèm pip
    rm -rf .venv
    python3 -m venv --without-pip .venv
  fi
fi

if .venv/bin/python -c "import fastapi, uvicorn, httpx" 2>/dev/null && [ "$FORCE" = 0 ]; then
  ok "Thư viện Python đã có sẵn"
else
  info "Cài thư viện từ requirements.txt"
  export PIP_CACHE_DIR="$PWD/.venv/.pip-cache" PIP_DISABLE_PIP_VERSION_CHECK=1
  if [ -x .venv/bin/pip ]; then
    .venv/bin/pip install -q --no-cache-dir -r requirements.txt
  elif python3 -m pip --version >/dev/null 2>&1; then
    # venv không có pip: dùng pip của hệ thống, cài thẳng vào site-packages của .venv
    SITE=$(.venv/bin/python -c "import site; print(site.getsitepackages()[0])")
    python3 -m pip install -q --no-cache-dir --upgrade --target "$SITE" -r requirements.txt
  else
    fail "Không tìm thấy pip. Cài python3-pip hoặc python3-venv rồi chạy lại."
  fi
  rm -rf .venv/.pip-cache
  .venv/bin/python -c "import fastapi, uvicorn, httpx" || fail "Cài thư viện thất bại."
  ok "Đã cài FastAPI, Uvicorn, httpx"
fi

# ---------------------------------------------------------------- vendor (Pyodide, sql.js)
PYODIDE_V=0.27.7
SQLJS_V=1.13.0
PY_FILES="pyodide.js pyodide.mjs pyodide.asm.js pyodide.asm.wasm python_stdlib.zip pyodide-lock.json package.json"
SQL_FILES="sql-wasm.js sql-wasm.wasm"

missing=0
for f in $PY_FILES; do [ -f "vendor/pyodide/$f" ] || missing=1; done
for f in $SQL_FILES; do [ -f "vendor/sqljs/$f" ] || missing=1; done

npm_in_dev() {
  command -v npm >/dev/null || fail "Cần Node.js/npm để tải $*."
  mkdir -p .dev
  [ -f .dev/package.json ] || echo '{"name":"zctf-dev","private":true}' > .dev/package.json
  (cd .dev && npm_config_cache="$PWD/.npm-cache" PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 \
     npm install --no-audit --no-fund --silent "$@")
  rm -rf .dev/.npm-cache
}

if [ "$missing" = 1 ]; then
  info "Tải Pyodide $PYODIDE_V và sql.js $SQLJS_V vào vendor/"
  npm_in_dev "pyodide@$PYODIDE_V" "sql.js@$SQLJS_V"
  mkdir -p vendor/pyodide vendor/sqljs
  for f in $PY_FILES; do cp ".dev/node_modules/pyodide/$f" vendor/pyodide/; done
  for f in $SQL_FILES; do cp ".dev/node_modules/sql.js/dist/$f" vendor/sqljs/; done
  ok "Đã tải vendor/"
else
  ok "vendor/ đầy đủ (Python và SQLite chạy offline)"
fi

# ---------------------------------------------------------------- công cụ dev
if [ "$DEV" = 1 ]; then
  if [ -d .dev/node_modules/playwright-core ]; then
    ok "playwright-core đã có"
  else
    info "Cài playwright-core vào .dev/"
    npm_in_dev playwright-core
    ok "Đã cài playwright-core"
  fi
  ls "$HOME"/.cache/ms-playwright/chromium-*/chrome-linux64/chrome >/dev/null 2>&1 \
    || info "Chưa thấy Chromium của Playwright; validate.mjs cần nó (đường dẫn sửa trong .dev/validate.mjs)."
fi

echo
ok "Xong. Chạy: ./run.sh   (mặc định http://localhost:${PORT:-9000})"
