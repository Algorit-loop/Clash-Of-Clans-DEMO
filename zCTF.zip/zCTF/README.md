# zCTF

Trang web học CTF từ con số 0, chạy bằng FastAPI.

## Cài đặt

```bash
./setup.sh                    # tạo .venv/, cài thư viện Python, kiểm tra vendor/ (Pyodide, sql.js)
./setup.sh --dev              # thêm công cụ kiểm thử (playwright-core trong .dev/)
./setup.sh --force            # cài lại .venv/ từ đầu
```

Cần Python ≥ 3.10 và Node.js/npm (để tải `vendor/`: Pyodide, sql.js — thư mục này không nằm trong git).

## Chạy

```bash
./run.sh                      # http://localhost:9000 (lắng nghe 0.0.0.0, máy khác trong LAN cũng vào được)
PORT=8000 ./run.sh            # đổi cổng
HOST=127.0.0.1 ./run.sh       # chỉ cho máy này truy cập
RELOAD=1 ./run.sh             # tự khởi động lại khi sửa code Python
```

`run.sh` tự gọi `setup.sh` nếu chưa cài. Mọi thứ nằm trong folder này.

## Cấu trúc

| Đường dẫn | Nội dung |
|---|---|
| `server.py` | FastAPI: phục vụ trang, tự nạp script, gắn lab, proxy `/__curl` cho terminal |
| `labs/*.py` | Lab web chạy thật (cố tình có lỗ hổng nhưng an toàn: dữ liệu trong bộ nhớ, không chạy lệnh hệ thống), gắn tại `/lab/<tên>/` |
| `js/core/` | Thư viện dùng chung, engine terminal Linux, runtime Python (Pyodide) / SQL (sql.js) / JS |
| `js/lessons/` | Nội dung bài học theo mảng |
| `js/widgets/` | Widget tương tác của từng mảng |
| `js/data/` | Dữ liệu (thuật ngữ…) |
| `js/tools.js` | Trang Công cụ và Tài nguyên |
| `js/app.js` | Router, tiến độ, thử thách, hiệu ứng |
| `vendor/` | Pyodide và sql.js (chạy offline) |
| `.dev/` | Công cụ phát triển: kiểm thử Playwright, flag đáp án, hướng dẫn viết bài (`AUTHORING.md`) |

## Thêm bài học

Xem `.dev/AUTHORING.md`. Tóm tắt: gọi `lesson({...})` trong `js/lessons/<mảng>.js`, flag lưu dạng SHA-256 (`node .dev/hash.js 'zCTF{...}'`), kiểm tra bằng `node .dev/validate.mjs <port>`.
