"""Lab Crypto — oracle AES thật, gắn tại /lab/crypto/

AES-128 cài đặt thuần Python (stdlib không có AES). Khoá sinh ngẫu nhiên mỗi lần khởi động server.
An toàn: chỉ tính toán trong bộ nhớ, không chạy lệnh hệ thống, không đọc file.
"""
import secrets

from fastapi import APIRouter, Query
from fastapi.responses import HTMLResponse, JSONResponse

router = APIRouter()

# ---------------------------------------------------------------- AES-128
_SBOX = [0] * 256
_INV = [0] * 256


def _init_sbox():
    p = q = 1
    while True:
        p = p ^ ((p << 1) & 0xFF) ^ (0x1B if p & 0x80 else 0)
        q ^= q << 1
        q ^= q << 2
        q ^= q << 4
        q &= 0xFF
        if q & 0x80:
            q ^= 0x09
        x = q ^ ((q << 1 | q >> 7) & 0xFF) ^ ((q << 2 | q >> 6) & 0xFF) ^ ((q << 3 | q >> 5) & 0xFF) ^ ((q << 4 | q >> 4) & 0xFF)
        _SBOX[p] = x ^ 0x63
        if p == 1:
            break
    _SBOX[0] = 0x63
    for i, v in enumerate(_SBOX):
        _INV[v] = i


_init_sbox()


def _xt(a):
    return ((a << 1) ^ 0x1B) & 0xFF if a & 0x80 else a << 1


def _mul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        a = _xt(a)
        b >>= 1
    return r


def _expand(key):
    w = [list(key[i:i + 4]) for i in range(0, 16, 4)]
    rcon = 1
    for i in range(4, 44):
        t = w[i - 1][:]
        if i % 4 == 0:
            t = t[1:] + t[:1]
            t = [_SBOX[x] for x in t]
            t[0] ^= rcon
            rcon = _xt(rcon)
        w.append([a ^ b for a, b in zip(w[i - 4], t)])
    return [sum(w[r * 4:r * 4 + 4], []) for r in range(11)]


def _enc_block(rk, b):
    s = [x ^ k for x, k in zip(b, rk[0])]
    for r in range(1, 11):
        s = [_SBOX[x] for x in s]
        s = [s[(i + 4 * (i % 4)) % 16] for i in range(16)]  # ShiftRows (column-major)
        if r != 10:
            n = []
            for c in range(4):
                a = s[4 * c:4 * c + 4]
                n += [_mul(a[0], 2) ^ _mul(a[1], 3) ^ a[2] ^ a[3], a[0] ^ _mul(a[1], 2) ^ _mul(a[2], 3) ^ a[3],
                      a[0] ^ a[1] ^ _mul(a[2], 2) ^ _mul(a[3], 3), _mul(a[0], 3) ^ a[1] ^ a[2] ^ _mul(a[3], 2)]
            s = n
        s = [x ^ k for x, k in zip(s, rk[r])]
    return bytes(s)


def _dec_block(rk, b):
    s = [x ^ k for x, k in zip(b, rk[10])]
    for r in range(9, -1, -1):
        s = [s[(i - 4 * (i % 4)) % 16] for i in range(16)]  # InvShiftRows
        s = [_INV[x] for x in s]
        s = [x ^ k for x, k in zip(s, rk[r])]
        if r != 0:
            n = []
            for c in range(4):
                a = s[4 * c:4 * c + 4]
                n += [_mul(a[0], 14) ^ _mul(a[1], 11) ^ _mul(a[2], 13) ^ _mul(a[3], 9),
                      _mul(a[0], 9) ^ _mul(a[1], 14) ^ _mul(a[2], 11) ^ _mul(a[3], 13),
                      _mul(a[0], 13) ^ _mul(a[1], 9) ^ _mul(a[2], 14) ^ _mul(a[3], 11),
                      _mul(a[0], 11) ^ _mul(a[1], 13) ^ _mul(a[2], 9) ^ _mul(a[3], 14)]
            s = n
    return bytes(s)


def pad(b, n=16):
    k = n - len(b) % n
    return b + bytes([k]) * k


def unpad(b):
    k = b[-1] if b else 0
    if not 1 <= k <= 16 or b[-k:] != bytes([k]) * k:
        raise ValueError("padding sai")
    return b[:-k]


def ecb_enc(rk, pt):
    pt = pad(pt)
    return b"".join(_enc_block(rk, pt[i:i + 16]) for i in range(0, len(pt), 16))


def ecb_dec(rk, ct):
    return unpad(b"".join(_dec_block(rk, ct[i:i + 16]) for i in range(0, len(ct), 16)))


def cbc_enc(rk, iv, pt):
    pt, prev, out = pad(pt), iv, b""
    for i in range(0, len(pt), 16):
        prev = _enc_block(rk, bytes(a ^ b for a, b in zip(pt[i:i + 16], prev)))
        out += prev
    return out


def cbc_dec(rk, iv, ct):
    prev, out = iv, b""
    for i in range(0, len(ct), 16):
        blk = ct[i:i + 16]
        out += bytes(a ^ b for a, b in zip(_dec_block(rk, blk), prev))
        prev = blk
    return unpad(out)


# Kiểm tra với vector chuẩn FIPS-197
assert _enc_block(_expand(bytes.fromhex("000102030405060708090a0b0c0d0e0f")), bytes.fromhex("00112233445566778899aabbccddeeff")).hex() == "69c4e0d86a7b0430d8cdb78070b4c55a"

# ---------------------------------------------------------------- khoá & flag
K_CUT = _expand(secrets.token_bytes(16))
K_BYTE = _expand(secrets.token_bytes(16))
K_CBC = _expand(secrets.token_bytes(16))
FLAG_CUT = "zCTF{c4t_d4n_kh0i_ecb}"
FLAG_BYTE = b"zCTF{tung_byte_mot}"
FLAG_CBC = "zCTF{l4t_b1t_cbc_d0i_qu4n}"


def _hex(s: str) -> bytes:
    s = s.strip().lower().replace(" ", "")
    if len(s) % 2 or any(c not in "0123456789abcdef" for c in s):
        raise ValueError("cần chuỗi hex hợp lệ")
    return bytes.fromhex(s)


def _err(msg, code=400):
    return JSONResponse({"error": msg}, status_code=code)


@router.get("/", response_class=HTMLResponse)
def index():
    return """<!doctype html><meta charset="utf-8"><title>Crypto lab</title>
<body style="font-family:monospace;background:#0b0f15;color:#ddd;padding:24px;line-height:1.7">
<h2>zCTF Crypto lab</h2>
<b>ECB cắt dán</b><br>
GET /lab/crypto/ecb/profile?email=you@mail.com → token = AES-ECB(k, "email=...&amp;uid=10&amp;role=user")<br>
GET /lab/crypto/ecb/login?token=&lt;hex&gt;<br><br>
<b>ECB oracle từng byte</b><br>
GET /lab/crypto/ecb/oracle?p=&lt;hex&gt; → AES-ECB(k, p || FLAG). Gửi nhiều input một lúc: p=hex1,hex2,...<br><br>
<b>CBC lật bit</b><br>
GET /lab/crypto/cbc/token → iv||ct của "admin=0;user=guest;note=hello"<br>
GET /lab/crypto/cbc/check?token=&lt;hex&gt;
</body>"""


# ---- ECB cut-and-paste
@router.get("/ecb/profile")
def ecb_profile(email: str = Query(..., max_length=200)):
    clean = email.replace("&", "").replace("=", "")
    pt = f"email={clean}&uid=10&role=user".encode()
    return {"profile": pt.decode(), "token": ecb_enc(K_CUT, pt).hex()}


@router.get("/ecb/login")
def ecb_login(token: str = Query(..., max_length=2000)):
    try:
        ct = _hex(token)
        if len(ct) % 16 or not ct:
            return _err("token phải là bội số của 16 byte")
        pt = ecb_dec(K_CUT, ct)
    except ValueError as e:
        return _err(f"giải mã lỗi: {e}")
    fields = {}
    for kv in pt.split(b"&"):
        if b"=" in kv:
            k, v = kv.split(b"=", 1)
            fields[k.decode("latin1")] = v.decode("latin1")
    if fields.get("role") == "admin":
        return {"msg": "Xin chào admin!", "profile": fields, "flag": FLAG_CUT}
    return {"msg": f"Bạn là '{fields.get('role')}'. Chỉ admin mới có flag.", "profile": fields}


# ---- ECB byte-at-a-time
@router.get("/ecb/oracle")
def ecb_oracle(p: str = Query("", max_length=40000)):
    try:
        inputs = [_hex(x) for x in p.split(",")] if p else [b""]
    except ValueError as e:
        return _err(str(e))
    if len(inputs) > 300:
        return _err("tối đa 300 input mỗi lần")
    out = [ecb_enc(K_BYTE, x + FLAG_BYTE).hex() for x in inputs]
    return {"ct": out if len(out) > 1 else out[0]}


# ---- CBC bit flipping
@router.get("/cbc/token")
def cbc_token():
    iv = secrets.token_bytes(16)
    ct = cbc_enc(K_CBC, iv, b"admin=0;user=guest;note=hello")
    return {"plaintext": "admin=0;user=guest;note=hello", "token": (iv + ct).hex(), "format": "iv (16 byte) || ciphertext"}


@router.get("/cbc/check")
def cbc_check(token: str = Query(..., max_length=2000)):
    try:
        raw = _hex(token)
        if len(raw) < 32 or len(raw) % 16:
            return _err("token = iv(16) || ct (bội số 16)")
        pt = cbc_dec(K_CBC, raw[:16], raw[16:])
    except ValueError as e:
        return _err(f"giải mã lỗi: {e}")
    fields = dict(kv.split(b"=", 1) for kv in pt.split(b";") if b"=" in kv)
    if fields.get(b"admin") == b"1":
        return {"msg": "admin=1, chào sếp!", "flag": FLAG_CBC}
    return {"msg": "Không phải admin.", "decrypted": pt.decode("latin1")}
