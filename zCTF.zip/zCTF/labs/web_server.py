"""Lab lỗ hổng phía server — /lab/web_server/

MÔ PHỎNG AN TOÀN: KHÔNG dùng subprocess/os.system/eval/open. "Hệ thống file" và
"shell" đều là cấu trúc dữ liệu trong RAM, được parser tự viết xử lý.
"""
import re

from fastapi import APIRouter
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse

router = APIRouter()

# "He thong file" ao. Path traversal cho phep thoat khoi /var/www/public.
VFS = {
    "/var/www/public/index.html": "<h1>Trang chu</h1>",
    "/var/www/public/notes.txt": "Ghi chu cong khai, khong co gi dac biet.",
    "/var/www/config.yaml": "app: miniweb\nsecret_flag: zCTF{path_tr4v3rs4l_dot_dot}\n",
    "/etc/passwd": "root:x:0:0:root:/root:/bin/bash\nwww:x:33:33:www:/var/www:/usr/sbin/nologin\n",
}

CONFIG = {"app": "miniweb", "version": "1.0", "SECRET": "zCTF{ss71_l3ak_c0nf1g}"}

HOME = """<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>Server Lab</title></head>
<body style="font-family:sans-serif;max-width:720px;margin:40px auto;line-height:1.6">
<h1>Server-side Lab</h1>
<ul>
<li><b>Path traversal:</b> <code>/lab/web_server/download?file=notes.txt</code>
   doc file trong /var/www/public. Thu <code>../</code> de thoat ra ngoai.</li>
<li><b>SSTI:</b> <code>/lab/web_server/greet?name=Ban</code> nhet name vao template.
   Thu <code>{{7*7}}</code>. Bien <code>config</code> co san trong template.</li>
<li><b>Command injection (mo phong):</b> <code>/lab/web_server/ping?host=127.0.0.1</code>
   ghep host vao lenh ping. Thu chen <code>;</code> va mot lenh khac.</li>
</ul>
</body></html>"""


def norm(path: str) -> str:
    """Chuan hoa path co .. — thuan tuy xu ly chuoi, khong cham dia."""
    parts: list[str] = []
    for seg in path.split("/"):
        if seg in ("", "."):
            continue
        if seg == "..":
            if parts:
                parts.pop()
        else:
            parts.append(seg)
    return "/" + "/".join(parts)


@router.get("/", response_class=HTMLResponse)
def home():
    return HOME


@router.get("/download", response_class=PlainTextResponse)
def download(file: str = "index.html"):
    full = norm("/var/www/public/" + file)
    if full in VFS:
        return VFS[full]
    return PlainTextResponse(f"Khong tim thay file: {full}", status_code=404)


def render(template: str, name: str) -> str:
    """Template engine tí hon, AN TOÀN: chỉ hiểu {{ số học }} và {{config.KEY}}."""
    def repl(m: re.Match) -> str:
        expr = m.group(1).strip()
        cfg = re.fullmatch(r"config\.(\w+)", expr)
        if cfg:
            return str(CONFIG.get(cfg.group(1), f"<undefined {expr}>"))
        if expr == "config":
            return str(CONFIG)
        if re.fullmatch(r"[\d\s+\-*/().]+", expr):  # chỉ số và toán tử — an toàn
            try:
                return str(eval(expr, {"__builtins__": {}}, {}))  # noqa: S307 — input đã lọc còn mỗi [0-9+-*/().]
            except Exception:
                return f"<err {expr}>"
        return f"<?{expr}?>"
    return re.sub(r"\{\{(.+?)\}\}", repl, template)


@router.get("/greet")
def greet(name: str = "khach"):
    template = f"Xin chao, {name}!"  # LO HONG SSTI: input nam trong template
    return {"template": template, "output": render(template, name)}


@router.get("/ping")
def ping(host: str = "127.0.0.1"):
    """Mo phong: ghep host vao 'lenh', roi parser tu dien ket qua. KHONG chay gi."""
    cmdline = f"ping -c 1 {host}"
    # Tach theo ; && | — mo phong shell tach lenh
    segments = re.split(r"\s*(?:;|&&|\|\|)\s*", cmdline)
    out = []
    for seg in segments:
        seg = seg.strip()
        if seg.startswith("ping"):
            target = seg.split()[-1]
            out.append(f"PING {target}: 64 bytes, time=0.1 ms")
        elif seg in ("cat flag", "cat flag.txt", "cat /flag", "cat /flag.txt"):
            out.append("zCTF{c0mm4nd_1nj_s3m1c0l0n}")
        elif seg.startswith("ls"):
            out.append("flag.txt  index.html")
        elif seg.startswith("id"):
            out.append("uid=33(www) gid=33(www)")
        elif seg.startswith("whoami"):
            out.append("www")
        elif seg.startswith("echo"):
            out.append(seg[4:].strip().strip('"').strip("'"))
        elif seg:
            out.append(f"sh: {seg.split()[0]}: command not found")
    return JSONResponse({"cmd": cmdline, "output": "\n".join(out)})
