"""Lab Trinh sát — /lab/web_recon/

Dạy: robots.txt, đường dẫn ẩn, file backup/.env lộ do cấu hình sai.
AN TOÀN: mọi "file" chỉ là chuỗi trong bộ nhớ.
"""
from fastapi import APIRouter
from fastapi.responses import HTMLResponse, PlainTextResponse

router = APIRouter()

HOME = """<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>MiniBlog</title></head>
<body style="font-family:sans-serif;max-width:680px;margin:40px auto;line-height:1.6">
<h1>MiniBlog</h1>
<p>Chào mừng tới blog. Chưa có bài viết nào.</p>
<!-- TODO: nhớ chặn mấy đường dẫn nhạy cảm trong robots.txt trước khi lên production -->
</body></html>"""

ROBOTS = """User-agent: *
Disallow: /lab/web_recon/quan-tri-bi-mat-k3y
Disallow: /lab/web_recon/.env
Disallow: /lab/web_recon/backup/
"""

ENV = """# cau hinh ung dung — KHONG duoc de public!
APP_ENV=production
DB_HOST=127.0.0.1
DB_USER=blog
DB_PASS=sup3rs3cr3t
SECRET_FLAG=zCTF{backup_f1l3_l0_b1_m4t}
"""


@router.get("/", response_class=HTMLResponse)
def home():
    return HOME


@router.get("/robots.txt", response_class=PlainTextResponse)
def robots():
    return ROBOTS


@router.get("/quan-tri-bi-mat-k3y", response_class=HTMLResponse)
def admin():
    return """<!doctype html><html><head><meta charset="utf-8"><title>Admin</title></head>
<body style="font-family:sans-serif;max-width:680px;margin:40px auto">
<h1>Trang quản trị ẩn</h1>
<p>robots.txt chỉ "xin" bot đừng vào, chứ không hề chặn. Bạn tìm ra đường dẫn này nhờ đọc nó.</p>
<p><b>zCTF{robots_txt_ch1_duong}</b></p>
</body></html>"""


@router.get("/.env", response_class=PlainTextResponse)
def env():
    return ENV


@router.get("/backup/config.php.bak", response_class=PlainTextResponse)
def backup():
    return ENV
