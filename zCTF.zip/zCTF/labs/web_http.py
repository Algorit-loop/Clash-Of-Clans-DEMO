"""Lab HTTP căn bản — /lab/web_http/

Dạy: method, status code, header, cookie, redirect. AN TOÀN: chỉ đọc request,
trả về chuỗi; không chạy lệnh, không đụng file thật.
"""
from fastapi import APIRouter, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse

router = APIRouter()

PAGE = """<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>HTTP Lab</title></head>
<body style="font-family:sans-serif;max-width:680px;margin:40px auto;line-height:1.6">
<h1>HTTP Lab</h1>
<p>Bốn endpoint để luyện dùng <code>curl</code>:</p>
<ul>
<li><code>/lab/web_http/headers</code> — có một header bí mật trong <b>response</b>. Dùng <code>curl -i</code>.</li>
<li><code>/lab/web_http/method</code> — chỉ chấp nhận đúng một HTTP method. Thử <code>-X POST</code>.</li>
<li><code>/lab/web_http/vip</code> — cần gửi cookie <code>role=vip</code>. Thử <code>-b "role=vip"</code>.</li>
<li><code>/lab/web_http/start</code> — chuyển hướng (301). Thử <code>-L</code> để theo chân.</li>
</ul>
</body></html>"""


@router.get("/", response_class=HTMLResponse)
def home():
    return PAGE


@router.get("/headers")
def headers():
    # Flag giấu trong header — chỉ thấy khi xem header (curl -i / -I)
    return JSONResponse(
        {"msg": "Chẳng có gì trong body cả. Header thì sao?"},
        headers={"X-Flag": "zCTF{d0c_k9_http_h34d3r}", "Server": "zCTF-httpd/1.0"},
    )


@router.api_route("/method", methods=["GET", "POST", "PUT", "DELETE"])
def method(request: Request):
    if request.method != "POST":
        return JSONResponse(
            {"error": f"405 — {request.method} không được phép ở đây.", "hint": "Thử POST: curl -X POST ..."},
            status_code=405,
            headers={"Allow": "POST"},
        )
    return {"flag": "zCTF{p0st_kh0ng_ph41_g3t}", "msg": "Đúng method rồi!"}


@router.get("/vip")
def vip(request: Request):
    role = request.cookies.get("role", "")
    if role != "vip":
        return JSONResponse(
            {"error": "Khu vực VIP. Cookie role hiện tại: " + (role or "(không có)"), "hint": 'curl -b "role=vip" ...'},
            status_code=403,
        )
    return {"flag": "zCTF{curl_b_g1_c00k13}", "msg": "Chào thành viên VIP!"}


@router.get("/start")
def start():
    # 301 → /treasure. curl phải dùng -L mới tới nơi.
    return RedirectResponse("/lab/web_http/treasure", status_code=301)


@router.get("/treasure", response_class=PlainTextResponse)
def treasure():
    return "Bạn đã theo chân redirect tới đây!\nzCTF{theo_ch4n_r3d1r3ct}\n"
