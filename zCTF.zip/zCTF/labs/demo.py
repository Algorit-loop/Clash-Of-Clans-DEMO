"""Lab mẫu cho sân chơi terminal: curl http://lab.zctf.local/lab/demo/

Quy ước cho mọi lab:
- router = APIRouter(); file labs/<tên>.py được gắn tại /lab/<tên>/
- Lab cố tình có lỗ hổng nhưng AN TOÀN: không chạy lệnh hệ thống, không đọc/ghi file thật,
  dữ liệu chỉ nằm trong bộ nhớ (dict, sqlite :memory:).
"""
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse

router = APIRouter()


@router.get("/", response_class=HTMLResponse)
def home():
    return """<!doctype html><html><head><title>Demo lab</title></head><body>
<h1>Demo lab</h1>
<p>Thử: <code>curl -i</code> để xem header, <code>curl -A "zCTF-Agent"</code>, hoặc xem /lab/demo/robots.txt</p>
<!-- comment ẩn: zCTF{curl_th4y_c0mm3nt} -->
</body></html>"""


@router.get("/robots.txt", response_class=PlainTextResponse)
def robots():
    return "User-agent: *\nDisallow: /lab/demo/hidden-admin\n"


@router.get("/hidden-admin")
def hidden(request: Request):
    ua = request.headers.get("user-agent", "")
    if ua != "zCTF-Agent":
        return JSONResponse({"error": "Chỉ trình duyệt zCTF-Agent mới được vào", "your_user_agent": ua}, status_code=403)
    resp = JSONResponse({"msg": "Chào zCTF-Agent!", "hint": "xem header của response"})
    resp.headers["X-Flag"] = "zCTF{us3r_4g3nt_g14_m4o}"
    resp.set_cookie("visited", "yes")
    return resp
