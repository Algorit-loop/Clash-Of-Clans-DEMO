"""Lab Xác thực & phân quyền — /lab/web_auth/

Dạy: IDOR, JWT alg=none, JWT secret yếu. AN TOÀN: tự xử lý JWT bằng hmac/hashlib,
dữ liệu người dùng là dict trong RAM.
"""
import base64
import hashlib
import hmac
import json

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse

router = APIRouter()

ACCOUNTS = {
    1: {"user": "ban", "role": "user", "note": "Tai khoan cua ban."},
    2: {"user": "admin", "role": "admin", "note": "zCTF{1d0r_d01_s0_la_th4y}"},
    3: {"user": "sysop", "role": "admin", "note": "Mot admin khac."},
}

# Secret yeu — xuat hien trong nhieu wordlist. Dung de ky JWT user.
JWT_SECRET = b"secret123"


def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def b64url_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def make_token(payload: dict) -> str:
    head = b64url(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    body = b64url(json.dumps(payload).encode())
    sig = b64url(hmac.new(JWT_SECRET, f"{head}.{body}".encode(), hashlib.sha256).digest())
    return f"{head}.{body}.{sig}"


def verify(token: str):
    try:
        head_b, body_b, sig_b = token.split(".")
        head = json.loads(b64url_dec(head_b))
        body = json.loads(b64url_dec(body_b))
    except Exception:
        return None
    alg = head.get("alg", "")
    if alg == "none":  # LO HONG: chap nhan token khong chu ky
        return body
    if alg == "HS256":
        want = b64url(hmac.new(JWT_SECRET, f"{head_b}.{body_b}".encode(), hashlib.sha256).digest())
        if hmac.compare_digest(want, sig_b):
            return body
    return None


HOME = """<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>Auth Lab</title></head>
<body style="font-family:sans-serif;max-width:720px;margin:40px auto;line-height:1.6">
<h1>Auth Lab</h1>
<ul>
<li><b>IDOR:</b> <code>/lab/web_auth/account/1</code> la ban. Thu doi so ID.</li>
<li><b>JWT:</b> lay token user o <code>/lab/web_auth/token</code>, gui toi
   <code>/lab/web_auth/me</code> qua header <code>Authorization: Bearer &lt;token&gt;</code>.
   Chi token co <code>role=admin</code> moi thay flag. Server co hai diem yeu: chap nhan
   <code>alg=none</code>, va secret HS256 rat yeu.</li>
</ul>
</body></html>"""


@router.get("/", response_class=HTMLResponse)
def home():
    return HOME


@router.get("/account/{account_id}")
def account(account_id: int):
    acc = ACCOUNTS.get(account_id)
    if not acc:
        return JSONResponse({"error": "Khong co tai khoan nay"}, status_code=404)
    # LO HONG IDOR: khong kiem tra ban co quyen xem tai khoan nay khong
    return acc


@router.get("/token")
def token():
    return {"token": make_token({"user": "ban", "role": "user"}), "hint": "Giai ma 3 phan base64url de xem ben trong."}


@router.get("/me")
def me(request: Request):
    auth = request.headers.get("authorization", "")
    if not auth.startswith("Bearer "):
        return JSONResponse({"error": "Thieu header Authorization: Bearer <token>"}, status_code=401)
    data = verify(auth[7:])
    if data is None:
        return JSONResponse({"error": "Token khong hop le (chu ky sai hoac hong)"}, status_code=401)
    if data.get("role") == "admin":
        return {"user": data.get("user"), "role": "admin", "flag": "zCTF{jwt_4lg_n0n3_g14_m4o}"}
    return {"user": data.get("user"), "role": data.get("role"), "msg": "Ban chua phai admin."}
