"""Lab SQL Injection — /lab/web_sqli/  (sqlite3 :memory: thật)

Cố tình nối chuỗi vào câu SQL để dạy injection. AN TOÀN: CSDL nằm hoàn toàn
trong RAM, chỉ chứa dữ liệu giả; không có bảng/quyền nào ngoài lab này.
"""
import sqlite3

from urllib.parse import parse_qs

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse

router = APIRouter()


def db() -> sqlite3.Connection:
    con = sqlite3.connect(":memory:")
    con.executescript(
        """
        CREATE TABLE products (id INTEGER, name TEXT, price INTEGER);
        INSERT INTO products VALUES (1,'Ba lo',250000),(2,'Binh nuoc',90000),(3,'But bi',5000);
        CREATE TABLE users (id INTEGER, username TEXT, password TEXT);
        INSERT INTO users VALUES (1,'admin','Qu4n_Tr1_9x!'),(2,'khach','khach');
        CREATE TABLE secret (id INTEGER, flag TEXT);
        INSERT INTO secret VALUES (1,'zCTF{un10n_s3l3ct_l0_d4ta}');
        """
    )
    return con


PAGE = """<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>SQLi Lab</title></head>
<body style="font-family:sans-serif;max-width:720px;margin:40px auto;line-height:1.6">
<h1>Cua hang (co lo hong SQLi)</h1>
<ul>
<li><code>/lab/web_sqli/search?q=ba</code> — tim san pham. Cau SQL noi chuoi truc tiep.
    Bang <code>products</code> co 3 cot (id, name, price). Co bang <code>secret(id, flag)</code> o dau do...</li>
<li><code>/lab/web_sqli/login</code> — POST username &amp; password. Dang nhap bang admin de lay flag.</li>
</ul>
<p>Goi y UNION: so cot phai khop. Thu <code>q=x' UNION SELECT 1,2,3-- -</code> truoc.</p>
</body></html>"""


@router.get("/", response_class=HTMLResponse)
def home():
    return PAGE


@router.get("/search")
def search(q: str = ""):
    con = db()
    sql = f"SELECT id, name, price FROM products WHERE name LIKE '%{q}%'"
    try:
        rows = con.execute(sql).fetchall()
    except sqlite3.Error as e:
        return JSONResponse({"sql": sql, "error": f"SQL error: {e}"}, status_code=500)
    finally:
        con.close()
    return {"sql": sql, "rows": rows}


@router.post("/login")
async def login(request: Request):
    body = (await request.body()).decode("utf-8", "replace")
    form = parse_qs(body, keep_blank_values=True)
    username = form.get("username", [""])[0]
    password = form.get("password", [""])[0]
    con = db()
    # Lo hong kinh dien: noi thang input vao SQL
    sql = f"SELECT username FROM users WHERE username='{username}' AND password='{password}'"
    try:
        row = con.execute(sql).fetchone()
    except sqlite3.Error as e:
        return JSONResponse({"sql": sql, "error": f"SQL error: {e}"}, status_code=500)
    finally:
        con.close()
    if row and row[0] == "admin":
        return {"sql": sql, "msg": "Dang nhap thanh cong voi admin!", "flag": "zCTF{sql1_tr3n_backend_th4t}"}
    if row:
        return {"sql": sql, "msg": f"Dang nhap voi {row[0]} — khong co flag o day."}
    return JSONResponse({"sql": sql, "msg": "Sai thong tin dang nhap."}, status_code=401)
