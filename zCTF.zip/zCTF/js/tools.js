/* =====================================================================
   Trang Công cụ (#/tools/<tab>) và Tài nguyên (#/resources)
   ===================================================================== */
const enc = new TextEncoder();
const dec = new TextDecoder("utf-8", { fatal: true });
const toStr = (b) => { try { return dec.decode(b); } catch { return [...b].map((x) => (x >= 32 && x < 127) || x === 10 ? String.fromCharCode(x) : "\\x" + x.toString(16).padStart(2, "0")).join(""); } };
const parseKey = (k) => {
  k = k.trim();
  if (/^(0x)?[0-9a-f]+$/i.test(k) && k.replace(/^0x/i, "").length % 2 === 0) return [...k.replace(/^0x/i, "").match(/../g)].map((x) => parseInt(x, 16));
  return [...enc.encode(k)];
};
const rot = (b, n) => b.map((x) => (x >= 65 && x <= 90 ? ((x - 65 + n + 26 * 10) % 26) + 65 : x >= 97 && x <= 122 ? ((x - 97 + n + 26 * 10) % 26) + 97 : x));
const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

const OPS = {
  "From Base64": (b) => { const s = toStr(b).replace(/\s+/g, "").replace(/-/g, "+").replace(/_/g, "/"); return Uint8Array.from(atob(s + "===".slice((s.length + 3) % 4)), (x) => x.charCodeAt(0)); },
  "To Base64": (b) => enc.encode(btoa(String.fromCharCode(...b))),
  "From Base32": (b) => { const t = toStr(b).replace(/[\s=]/g, "").toUpperCase(); let bits = ""; for (const ch of t) { const v = B32.indexOf(ch); if (v < 0) throw "Ký tự không thuộc Base32: " + ch; bits += v.toString(2).padStart(5, "0"); } return Uint8Array.from(bits.match(/.{8}/g) || [], (x) => parseInt(x, 2)); },
  "To Base32": (b) => { const bits = [...b].map((x) => x.toString(2).padStart(8, "0")).join(""); let r = ""; for (let i = 0; i < bits.length; i += 5) r += B32[parseInt(bits.slice(i, i + 5).padEnd(5, "0"), 2)]; return enc.encode(r + "=".repeat((8 - (r.length % 8)) % 8)); },
  "From Hex": (b) => { const s = toStr(b).replace(/0x|\\x|[\s,:]/gi, ""); if (!/^[0-9a-f]*$/i.test(s)) throw "Có ký tự không phải hex"; return Uint8Array.from(s.match(/../g) || [], (x) => parseInt(x, 16)); },
  "To Hex": (b) => enc.encode([...b].map((x) => x.toString(16).padStart(2, "0")).join(" ")),
  "From Binary": (b) => { const s = toStr(b).replace(/[^01]/g, ""); return Uint8Array.from(s.match(/.{8}/g) || [], (x) => parseInt(x, 2)); },
  "To Binary": (b) => enc.encode([...b].map((x) => x.toString(2).padStart(8, "0")).join(" ")),
  "From Decimal": (b) => Uint8Array.from(toStr(b).split(/[^0-9]+/).filter(Boolean), Number),
  "To Decimal": (b) => enc.encode([...b].join(" ")),
  "From Octal": (b) => Uint8Array.from(toStr(b).split(/[^0-7]+/).filter(Boolean), (x) => parseInt(x, 8)),
  "URL Decode": (b) => enc.encode(decodeURIComponent(toStr(b).replace(/\+/g, " "))),
  "URL Encode": (b) => enc.encode(encodeURIComponent(toStr(b))),
  "HTML Entity Decode": (b) => { const t = document.createElement("textarea"); t.innerHTML = toStr(b); return enc.encode(t.value); },
  "ROT-N": (b, p) => rot(b, Number(p.n) || 0),
  "ROT47": (b) => b.map((x) => (x >= 33 && x <= 126 ? 33 + ((x - 33 + 47) % 94) : x)),
  Atbash: (b) => b.map((x) => (x >= 65 && x <= 90 ? 155 - x : x >= 97 && x <= 122 ? 219 - x : x)),
  XOR: (b, p) => { const k = parseKey(p.key || "00"); return b.map((x, i) => x ^ k[i % k.length]); },
  Reverse: (b) => Uint8Array.from([...b].reverse()),
  "Remove Whitespace": (b) => Uint8Array.from([...b].filter((x) => ![9, 10, 13, 32].includes(x))),
  "Morse Decode": (b) => {
    const M = { ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E", "..-.": "F", "--.": "G", "....": "H", "..": "I", ".---": "J", "-.-": "K", ".-..": "L", "--": "M", "-.": "N", "---": "O", ".--.": "P", "--.-": "Q", ".-.": "R", "...": "S", "-": "T", "..-": "U", "...-": "V", ".--": "W", "-..-": "X", "-.--": "Y", "--..": "Z", "-----": "0", ".----": "1", "..---": "2", "...--": "3", "....-": "4", ".....": "5", "-....": "6", "--...": "7", "---..": "8", "----.": "9", "..--.-": "_", "-.--.": "{", "-.--.-": "}" };
    return enc.encode(toStr(b).trim().split(/\s*\/\s*|\s{2,}/).map((w) => w.split(/\s+/).map((x) => M[x] ?? "?").join("")).join(" "));
  },
};

function guess(s) {
  const t = s.trim();
  if (!t) return "";
  if (/^zCTF\{.*\}$/.test(t)) return "✓ Đây là flag!";
  if (/^[01\s]+$/.test(t) && t.replace(/\s/g, "").length % 8 === 0) return "Có vẻ là Binary → From Binary";
  if (/^(0x)?[0-9a-f\s:]+$/i.test(t) && t.replace(/0x|[\s:]/gi, "").length % 2 === 0 && /[a-f]/i.test(t) || /^([0-9a-f]{2}\s)+[0-9a-f]{2}$/i.test(t)) return "Có vẻ là Hex → From Hex";
  if (/^[\d\s,]+$/.test(t)) return "Có vẻ là mã ASCII thập phân → From Decimal";
  if (/^[.\-\s/]+$/.test(t)) return "Có vẻ là Morse → Morse Decode";
  if (/%[0-9a-f]{2}/i.test(t)) return "Có ký tự %XX → URL Decode";
  if (/&(#\d+|#x[0-9a-f]+|[a-z]+);/i.test(t)) return "Có HTML entity → HTML Entity Decode";
  if (/^[A-Z2-7]+=*$/.test(t) && t.length % 8 === 0) return "Có vẻ là Base32 (chỉ A-Z, 2-7) → From Base32";
  if (/^[A-Za-z0-9+/_-]+={0,2}$/.test(t) && t.length >= 8 && (t.length % 4 === 0 || /[a-z]/.test(t))) return "Có vẻ là Base64 → From Base64";
  if (/^[a-z]{4}\{.*\}$/i.test(t)) return "Dạng xxxx{...}: có thể là ROT/Caesar/Atbash của zCTF{...}";
  return "";
}

const TOOL_TABS = [
  ["decode", "Giải mã"], ["shell", "Terminal"], ["python", "Python"], ["sql", "SQL"], ["js", "JavaScript"],
  ["hash", "Hash"], ["convert", "Chuyển đổi số"], ["cipher", "Mật mã cổ điển"], ["ascii", "Bảng ASCII"],
];

function renderTools(container, tab = "decode") {
  if (!TOOL_TABS.some(([k]) => k === tab)) tab = "decode";
  container.innerHTML = `
  <div class="container page">
    <div class="section-head" style="padding-top:44px;margin-bottom:20px">
      <h2>Công cụ</h2>
      <p>Mọi thứ chạy ngay trong trình duyệt. Dữ liệu bạn nhập không được gửi đi đâu.</p>
    </div>
    <div class="tabs">${TOOL_TABS.map(([k, v]) => `<a class="tab ${k === tab ? "on" : ""}" href="#/tools/${k}">${v}</a>`).join("")}</div>
    <div class="tab-body"></div>
  </div>`;
  const body = container.querySelector(".tab-body");
  ({ decode: toolDecode, shell: toolShell, python: toolPython, sql: toolSql, js: toolJs, hash: toolHash, convert: toolConvert, cipher: toolCipher, ascii: toolAscii })[tab](body);
  mountWidgets(body);
  enhanceCode(body);
}

/* ---------- Giải mã ---------- */
function toolDecode(body) {
  body.innerHTML = `
    <div class="tools-layout">
      <div class="tool-panel">
        <label>INPUT</label>
        <textarea id="t-in" spellcheck="false" placeholder="Dán dữ liệu vào đây…">ekNURnt0aGFtX2dpYV9DVEZ9</textarea>
        <label>THAO TÁC (bấm để thêm vào công thức)</label>
        <div class="ops" id="t-ops"></div>
        <div class="op-params">
          <label>ROT n <input type="number" id="p-n" value="13"></label>
          <label>XOR key <input type="text" id="p-key" value="2a" title="Hex (vd 2a, 0x2a41) hoặc chữ"></label>
        </div>
        <label>CÔNG THỨC (bấm một bước để xoá)</label>
        <div class="recipe" id="t-recipe"></div>
      </div>
      <div class="tool-panel">
        <label>OUTPUT</label>
        <textarea id="t-out" readonly spellcheck="false"></textarea>
        <div class="magic-hint" id="t-hint"></div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn sm" id="t-swap">Đưa output về input</button>
          <button class="btn sm" id="t-clear">Xoá công thức</button>
        </div>
      </div>
    </div>
    <section class="block">
      <div class="section-head"><h2>Caesar brute force</h2><p>Thử cả 25 khoá cùng lúc. Dòng nào đọc được là đáp án.</p></div>
      <div class="tool-panel">
        <input id="c-in" class="field" value="gJAM{jhlzhy_xbh_kl_woh}" spellcheck="false">
        <div id="c-out" class="brute"></div>
      </div>
    </section>
    <section class="block">
      <div class="section-head"><h2>XOR brute force 1 byte</h2><p>Nhập hex. Thử cả 256 khoá, hiện các kết quả toàn ký tự in được.</p></div>
      <div class="tool-panel">
        <input id="x-in" class="field" value="50697e6c51521a58755c1a437541421a4b754e454457" spellcheck="false">
        <div id="x-out" class="brute"></div>
      </div>
    </section>`;
  const inEl = body.querySelector("#t-in"), outEl = body.querySelector("#t-out"), hint = body.querySelector("#t-hint");
  const recipeEl = body.querySelector("#t-recipe"), opsEl = body.querySelector("#t-ops");
  let recipe = ["From Base64"];
  Object.keys(OPS).forEach((name) => {
    const b = document.createElement("button");
    b.className = "op"; b.textContent = name;
    b.onclick = () => { recipe.push(name); run(); };
    opsEl.appendChild(b);
  });
  function run() {
    recipeEl.innerHTML = recipe.length ? recipe.map((r, i) => `<span class="chip" data-i="${i}">${i + 1}. ${r}</span>`).join("") : '<span class="ph">Chưa có thao tác nào</span>';
    recipeEl.querySelectorAll(".chip").forEach((x) => (x.onclick = () => { recipe.splice(+x.dataset.i, 1); run(); }));
    const params = { n: body.querySelector("#p-n").value, key: body.querySelector("#p-key").value };
    let data = enc.encode(inEl.value);
    try {
      for (const r of recipe) data = OPS[r](data, params);
      const s = toStr(data);
      outEl.value = s; outEl.style.color = ""; hint.textContent = guess(s);
    } catch (e) {
      outEl.value = "Lỗi: " + (e.message || e); outEl.style.color = "var(--red)"; hint.textContent = guess(inEl.value);
    }
  }
  inEl.addEventListener("input", run);
  body.querySelectorAll(".op-params input").forEach((i) => i.addEventListener("input", run));
  body.querySelector("#t-swap").onclick = () => { inEl.value = outEl.value; recipe = []; run(); };
  body.querySelector("#t-clear").onclick = () => { recipe = []; run(); };
  run();

  const cIn = body.querySelector("#c-in"), cOut = body.querySelector("#c-out");
  const caes = () => {
    const b = enc.encode(cIn.value);
    cOut.innerHTML = Array.from({ length: 25 }, (_, i) => {
      const s = toStr(rot(b, -(i + 1)));
      return `<div class="${/zCTF\{/.test(s) ? "hit" : ""}"><span class="k">-${String(i + 1).padStart(2, "0")}</span> ${esc(s)}</div>`;
    }).join("");
  };
  cIn.addEventListener("input", caes); caes();

  const xIn = body.querySelector("#x-in"), xOut = body.querySelector("#x-out");
  const xb = () => {
    const s = xIn.value.replace(/0x|[\s,:]/gi, "");
    if (!/^([0-9a-f]{2})+$/i.test(s)) { xOut.innerHTML = '<div class="e">Cần hex hợp lệ (số ký tự chẵn).</div>'; return; }
    const bytes = s.match(/../g).map((x) => parseInt(x, 16));
    const rows = [];
    for (let k = 0; k < 256; k++) {
      const o = bytes.map((x) => x ^ k);
      if (o.every((x) => (x >= 32 && x < 127) || x === 10)) rows.push(`<div class="${/zCTF\{/.test(String.fromCharCode(...o)) ? "hit" : ""}"><span class="k">0x${k.toString(16).padStart(2, "0")}</span> ${esc(String.fromCharCode(...o))}</div>`);
    }
    xOut.innerHTML = rows.join("") || '<div class="m">Không có khoá nào cho kết quả toàn ký tự in được.</div>';
  };
  xIn.addEventListener("input", xb); xb();
}

/* ---------- Terminal ---------- */
SHELL_FS.playground = {
  user: "hacker",
  host: "playground",
  motd: 'Sân chơi tự do. Đọc <span class="hl">cat README.txt</span> để có bài tập. Gõ <span class="hl">help</span> xem lệnh. Mọi thay đổi mất khi tải lại trang.',
  sudo: null,
  fs: () => {
    const f = (c2, m) => SH.file(c2, { owner: "hacker", ...m });
    const png = "\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x10\x00\x00\x00\x10\x08\x02\x00\x00\x00\x90\x91h6" + "\x00\x13\x7f\xa0\xe2".repeat(6) + "tEXtComment\x00zCTF{str1ngs_th4y_h3t}" + "\x00\x00\x00\x00IEND\xaeB`\x82";
    const users = ["alice", "bob", "carol", "dave", "eve"], ips = ["10.0.0.5", "10.0.0.9", "203.0.113.66", "198.51.100.7"];
    let seed = 42; const r = (n) => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) % n);
    const auth = Array.from({ length: 300 }, (_, i) => {
      const ip = i % 7 === 3 ? "203.0.113.66" : ips[r(4)];
      const ok = ip !== "203.0.113.66" && r(10) > 0;
      return `Nov 10 0${1 + Math.floor(i / 60)}:${String(i % 60).padStart(2, "0")}:${String(r(60)).padStart(2, "0")} playground sshd[${1000 + i}]: ${ok ? "Accepted password" : "Failed password"} for ${users[r(5)]} from ${ip} port ${40000 + r(20000)} ssh2`;
    }).join("\n") + "\n";
    const csv = "name,team,points\n" + Array.from({ length: 40 }, (_, i) => `${["an", "binh", "chi", "dung", "giang", "huy", "khanh", "linh"][i % 8]}${i},${["red", "blue", "green", "black"][r(4)]},${r(500)}`).join("\n") + "\n";
    const checker = SH.exe(async () => ({
      interactive: {
        banner: "=== License checker v1.0 ===",
        prompt: "Nhập license key: ",
        onLine: (l) => (l.trim() === "ZCTF-4242-B4BY" ? { out: "Hợp lệ! zCTF{l1c3ns3_tr0ng_str1ngs}", close: true } : { out: "Sai key.", close: true }),
      },
    }), { owner: "hacker" });
    checker.c += "\x00\x00/lib64/ld-linux-x86-64.so.2\x00libc.so.6\x00puts\x00strcmp\x00fgets\x00ZCTF-4242-B4BY\x00Nh\xe1p license key: \x00GCC: (Ubuntu 13.2.0) 13.2.0\x00";
    const backup = SH.exe(async (args, ctx) => {
      if (!args[0]) throw "Usage: backup <file>  (in nội dung file để sao lưu)";
      return { text: ctx.readFile(args[0]) };
    }, { owner: "root", mode: "-rwsr-xr-x" });
    return SH.base({
      "README.txt": f(`Bài tập sân chơi (không tính điểm, cứ thoải mái phá):

 1. Có một file ẩn trong thư mục này. Tìm và đọc nó.
 2. challenges/image.png không mở được. Dùng file, xxd, strings để tìm flag giấu bên trong.
 3. challenges/layers.txt bị encode nhiều lớp. Gợi ý: base64 -d, rồi xxd -r? Không có -r đâu, hãy thử tab Giải mã.
 4. challenges/rot.txt: dùng tr để giải ROT13.
 5. logs/auth.log: IP nào đăng nhập thất bại nhiều nhất?
    grep Failed logs/auth.log | cut -d' ' -f11 | sort | uniq -c | sort -n
 6. challenges/checker hỏi license key. Đọc nó bằng strings trước khi đoán.
 7. Tìm file có bit SUID:  find / -perm -4000 2>/dev/null  rồi dùng nó đọc /root/flag.txt
 8. Kết nối dịch vụ:  nc lab.zctf.local 1337   (giải toán nhanh)
`),
      ".ghi_chu_bi_mat": f("Bạn tìm thấy file ẩn! zCTF{d0t_f1l3s_4r3_h1dd3n}\n"),
      challenges: SH.dir({
        "image.png": f(png, { bin: true }),
        "layers.txt": f(btoa(btoa("zCTF{t4ng_l0p_b4s364}")) + "\n"),
        "rot.txt": f("mPGS{ebg13_ib_qvpu}\n"),
        "data.csv": f(csv),
        "hashes.txt": f("5f4dcc3b5aa765d61d8327deb882cf99\ne10adc3949ba59abbe56e057f20f883e\nd8578edf8458ce06fbc5bb76a58c5ca4\n"),
        checker,
      }, { owner: "hacker" }),
      logs: SH.dir({ "auth.log": f(auth) }, { owner: "hacker" }),
    }, "hacker", {
      usr: SH.dir({ bin: SH.dir({}), local: SH.dir({ bin: SH.dir({ backup }) }) }),
      root: SH.dir({ "flag.txt": SH.file("zCTF{su1d_b4ckup_l3ak}\n", { mode: "-r--------" }) }, { mode: "drwx------" }),
    });
  },
};

NC_SERVICES["lab.zctf.local:1337"] = () => {
  let round = 0, a, b, op, ans, t0;
  const ask = () => { a = 10 + Math.floor(Math.random() * 90); b = 2 + Math.floor(Math.random() * 20); op = ["+", "-", "*"][round % 3]; ans = op === "+" ? a + b : op === "-" ? a - b : a * b; t0 = Date.now(); return `[${round + 1}/5] ${a} ${op} ${b} = ?`; };
  return {
    banner: "=== Speed Math ===\nTrả lời 5 phép tính, mỗi câu dưới 10 giây.\n" + ask(),
    prompt: "> ",
    onLine: (l) => {
      if (Date.now() - t0 > 10000) return { out: "Quá chậm! Bye.", close: true };
      if (parseInt(l) !== ans) return { out: `Sai! Đáp án là ${ans}. Bye.`, close: true };
      round++;
      if (round === 5) return { out: "Giỏi lắm! zCTF{n3tc4t_sp33d_m4th}\n(Bài thật sẽ yêu cầu 1000 câu trong 30 giây → phải viết script bằng pwntools.)", close: true };
      return ask();
    },
  };
};
NC_SERVICES["lab.zctf.local:7"] = () => ({ banner: "echo server — gõ gì trả nấy. Ctrl+C để thoát.", prompt: "", onLine: (l) => l });

function toolShell(body) {
  body.innerHTML = `
    <div data-widget="shell" data-fs="playground" data-height="460"></div>
    <div class="grid-3">
      <div class="card"><h4>Mẹo</h4><p><kbd>Tab</kbd> gợi ý tên lệnh/file, <kbd>↑</kbd> <kbd>↓</kbd> lịch sử, <kbd>Ctrl</kbd>+<kbd>L</kbd> xoá màn hình, <kbd>Ctrl</kbd>+<kbd>C</kbd> ngắt.</p></div>
      <div class="card"><h4>HTTP tới lab</h4><p><code>curl -i http://lab.zctf.local/lab/...</code> gửi request thật tới các lab web chạy trên server FastAPI.</p></div>
      <div class="card"><h4>Dịch vụ TCP</h4><p><code>nc lab.zctf.local 1337</code> (giải toán), <code>nc lab.zctf.local 7</code> (echo). Các bài học có thêm dịch vụ riêng.</p></div>
    </div>`;
}

/* ---------- Python / SQL / JS ---------- */
function toolPython(body) {
  body.innerHTML = `
    <div class="tools-layout">
      <div><h3 class="tool-h">REPL</h3><div data-widget="python" data-height="420"></div></div>
      <div><h3 class="tool-h">Script</h3><div data-widget="python"><template>
# Script mẫu: giải nhiều lớp encoding
import base64

data = "Wld0T1ZWSnVkSGRsVmpselRrY3habVJ0YTNwWk1UbDFZVVJTZFdGSU1EMD0="
for i in range(5):
    try:
        data = base64.b64decode(data).decode()
        print(f"Lớp {i + 1}:", data)
    except Exception:
        break

# Chuyển số lớn sang bytes (dùng nhiều trong RSA)
print(long_to_bytes(0x7a4354467b70797468306e7d))
print(xor(b"secret", 0x2a).hex())
</template></div></div>
    </div>
    <div class="callout tip"><b>Có sẵn</b><p>Thư viện chuẩn Python (base64, hashlib, struct, itertools, re…) và các hàm tiện ích: <code>long_to_bytes</code>, <code>bytes_to_long</code>, <code>xor(a, b)</code>, <code>p32</code>, <code>p64</code>, <code>u32</code>, <code>u64</code>. Không có mạng và thư viện ngoài như pwntools.</p></div>`;
}
function toolSql(body) {
  body.innerHTML = `<div data-widget="sql" data-db="shop"></div>
    <div class="callout tip"><b>Dữ liệu mẫu</b><p>Bảng <code>users</code>, <code>products</code>, <code>orders</code>, <code>secrets</code>. Thử câu UNION ở các ví dụ: đây chính là cách SQL injection lấy dữ liệu từ bảng khác.</p></div>`;
}
function toolJs(body) {
  body.innerHTML = `<div data-widget="jsconsole" data-height="420"></div>
    <div class="callout tip"><b>Dùng khi nào?</b><p>Rất nhiều bài web và reverse có code JavaScript. Chạy thử từng đoạn ở đây để hiểu nó làm gì, mà không ảnh hưởng tới trang.</p></div>`;
}

/* ---------- Hash ---------- */
const WORDLIST = "123456 password 123456789 12345678 12345 qwerty 1234567 111111 123123 abc123 password1 1234 iloveyou 1q2w3e4r 000000 qwerty123 zaq12wsx dragon sunshine princess letmein 654321 monkey 27653 1qaz2wsx 123321 qwertyuiop superman asdfghjkl trustno1 football baseball welcome admin admin123 root toor hello master shadow michael jennifer login passw0rd starwars hunter2 freedom whatever qazwsx ninja azerty solo loveme batman access flower hottie charlie donald 696969 mustang secret pass test guest changeme default letmein123 p@ssw0rd password123 hacker matrix computer internet killer pokemon summer winter spring autumn cookie chocolate banana orange apple yellow purple".split(" ");
function identifyHash(s) {
  s = s.trim();
  const r = [];
  if (/^\$2[aby]\$\d\d\$/.test(s)) r.push("bcrypt");
  if (/^\$6\$/.test(s)) r.push("SHA-512 crypt (Linux /etc/shadow)");
  if (/^\$5\$/.test(s)) r.push("SHA-256 crypt");
  if (/^\$1\$/.test(s)) r.push("MD5 crypt");
  if (/^\$argon2/.test(s)) r.push("Argon2");
  if (/^[a-f0-9]+$/i.test(s)) r.push(...({ 32: ["MD5", "NTLM", "MD4"], 40: ["SHA-1", "RIPEMD-160"], 56: ["SHA-224"], 64: ["SHA-256", "SHA3-256"], 96: ["SHA-384"], 128: ["SHA-512", "SHA3-512"], 8: ["CRC32"] }[s.length] || []));
  if (/^[A-Za-z0-9+/]+=*$/.test(s) && !/^[a-f0-9]+$/i.test(s) && s.length % 4 === 0) r.push("có thể là hash dạng Base64");
  return r;
}
function toolHash(body) {
  body.innerHTML = `
    <div class="tools-layout">
      <div class="tool-panel">
        <label>TÍNH HASH</label>
        <textarea id="h-in" spellcheck="false">password</textarea>
        <div class="kv" id="h-out"></div>
      </div>
      <div class="tool-panel">
        <label>NHẬN DIỆN & BẺ HASH BẰNG TỪ ĐIỂN</label>
        <input id="h-id" class="field" value="5f4dcc3b5aa765d61d8327deb882cf99" spellcheck="false">
        <div class="kv" id="h-type"></div>
        <button class="btn sm" id="h-crack">Thử ${WORDLIST.length} mật khẩu phổ biến</button>
        <div class="kv" id="h-crack-out"></div>
        <p class="note">Thực tế dùng <code>hashcat</code> hoặc <code>john</code> với <code>rockyou.txt</code> (14 triệu mật khẩu), hoặc tra trên CrackStation.</p>
      </div>
    </div>`;
  const inp = body.querySelector("#h-in"), out = body.querySelector("#h-out");
  const calc = () => {
    const b = utf8.encode(inp.value);
    out.innerHTML = [["MD5", md5Hex(b)], ["SHA-1", sha1Hex(b)], ["SHA-256", sha256Bytes(b)], ["Độ dài", b.length + " byte"]].map(([k, v]) => `<div><span>${k}</span><code>${v}</code></div>`).join("");
  };
  inp.addEventListener("input", calc); calc();
  const idIn = body.querySelector("#h-id"), tp = body.querySelector("#h-type"), co = body.querySelector("#h-crack-out");
  const ident = () => { const r = identifyHash(idIn.value); tp.innerHTML = `<div><span>Có thể là</span><code>${r.length ? r.join(", ") : "không nhận ra"}</code></div><div><span>Độ dài</span><code>${idIn.value.trim().length} ký tự</code></div>`; co.innerHTML = ""; };
  idIn.addEventListener("input", ident); ident();
  body.querySelector("#h-crack").onclick = () => {
    const target = idIn.value.trim().toLowerCase();
    const fns = { MD5: md5Hex, "SHA-1": sha1Hex, "SHA-256": sha256Hex };
    for (const w of WORDLIST) for (const [n, fn] of Object.entries(fns)) if (fn(w) === target) { co.innerHTML = `<div class="ok"><span>Tìm thấy</span><code>${esc(w)}</code></div><div><span>Thuật toán</span><code>${n}</code></div>`; return; }
    co.innerHTML = '<div class="e"><span>Kết quả</span><code>Không có trong từ điển nhỏ này</code></div>';
  };
}

/* ---------- Chuyển đổi số ---------- */
function toolConvert(body) {
  body.innerHTML = `
    <div class="tools-layout">
      <div class="tool-panel">
        <label>SỐ (thập phân, 0x hex, 0b nhị phân, 0o bát phân; hỗ trợ số rất lớn)</label>
        <input id="n-in" class="field" value="0x7a435446" spellcheck="false">
        <div class="kv" id="n-out"></div>
      </div>
      <div class="tool-panel">
        <label>CHỮ / BYTES → SỐ (bytes_to_long)</label>
        <input id="b-in" class="field" value="zCTF" spellcheck="false">
        <div class="kv" id="b-out"></div>
      </div>
    </div>
    <div class="callout tip"><b>Dùng ở đâu?</b><p>Crypto (RSA trả về một số nguyên khổng lồ, đổi sang bytes là ra flag), Pwn (địa chỉ, little-endian), Reverse (hằng số trong assembly như <code>0x67616c66</code> chính là "flag" viết ngược).</p></div>`;
  const nIn = body.querySelector("#n-in"), nOut = body.querySelector("#n-out");
  const toBytesBE = (n) => { const hx = n.toString(16); return (hx.length % 2 ? "0" + hx : hx).match(/../g).map((x) => parseInt(x, 16)); };
  const printable = (arr) => arr.map((x) => (x >= 32 && x < 127 ? String.fromCharCode(x) : ".")).join("");
  const conv = () => {
    let s = nIn.value.trim().replace(/_/g, ""), n;
    try {
      if (/^-/.test(s)) throw 0;
      n = /^0x/i.test(s) ? BigInt(s) : /^0b/i.test(s) ? BigInt(s) : /^0o/i.test(s) ? BigInt(s) : BigInt(s);
    } catch { nOut.innerHTML = '<div class="e"><span>Lỗi</span><code>Không phải số hợp lệ</code></div>'; return; }
    const be = toBytesBE(n), le = [...be].reverse();
    nOut.innerHTML = [["Thập phân", n.toString()], ["Hex", "0x" + n.toString(16)], ["Nhị phân", (() => { const b2 = n.toString(2); return b2.padStart(Math.ceil(b2.length / 8) * 8, "0").match(/.{8}/g).join(" "); })()], ["Bát phân", "0o" + n.toString(8)], ["Số bit", n.toString(2).length], ["Bytes (big-endian)", be.map((x) => x.toString(16).padStart(2, "0")).join(" ")], ["→ chữ (big-endian)", esc(printable(be))], ["→ chữ (little-endian)", esc(printable(le))]].map(([k, v]) => `<div><span>${k}</span><code>${v}</code></div>`).join("");
  };
  nIn.addEventListener("input", conv); conv();
  const bIn = body.querySelector("#b-in"), bOut = body.querySelector("#b-out");
  const conv2 = () => {
    const b = [...utf8.encode(bIn.value)];
    if (!b.length) { bOut.innerHTML = ""; return; }
    const hx = b.map((x) => x.toString(16).padStart(2, "0")).join("");
    const n = BigInt("0x" + hx);
    const le = BigInt("0x" + [...b].reverse().map((x) => x.toString(16).padStart(2, "0")).join(""));
    bOut.innerHTML = [["Hex", hx], ["Số (big-endian)", n.toString()], ["Số (little-endian)", "0x" + le.toString(16)], ["Mã từng ký tự", b.join(" ")]].map(([k, v]) => `<div><span>${k}</span><code>${v}</code></div>`).join("");
  };
  bIn.addEventListener("input", conv2); conv2();
}

/* ---------- Mật mã cổ điển ---------- */
const EN_FREQ = { e: 12.7, t: 9.1, a: 8.2, o: 7.5, i: 7.0, n: 6.7, s: 6.3, h: 6.1, r: 6.0, d: 4.3, l: 4.0, c: 2.8, u: 2.8, m: 2.4, w: 2.4, f: 2.2, g: 2.0, y: 2.0, p: 1.9, b: 1.5, v: 1.0, k: 0.8, j: 0.15, x: 0.15, q: 0.1, z: 0.07 };
function vigenere(s, key, sign) {
  const k = key.toLowerCase().replace(/[^a-z]/g, "");
  if (!k) return s;
  let j = 0;
  return [...s].map((ch) => {
    const up = ch >= "A" && ch <= "Z", lo = ch >= "a" && ch <= "z";
    if (!up && !lo) return ch;
    const base = up ? 65 : 97;
    const shift = (k.charCodeAt(j++ % k.length) - 97) * sign;
    return String.fromCharCode(((ch.charCodeAt(0) - base + shift + 26 * 10) % 26) + base);
  }).join("");
}
function toolCipher(body) {
  body.innerHTML = `
    <div class="tools-layout">
      <div class="tool-panel">
        <label>VIGENÈRE</label>
        <textarea id="v-in" spellcheck="false">jGRP{zgqilovc_ulm_rsl_meccep}</textarea>
        <div class="op-params"><label>Khoá <input type="text" id="v-key" value="key"></label>
          <label><input type="radio" name="vm" value="-1" checked> Giải mã</label><label><input type="radio" name="vm" value="1"> Mã hoá</label></div>
        <textarea id="v-out" readonly></textarea>
      </div>
      <div class="tool-panel">
        <label>PHÂN TÍCH TẦN SUẤT CHỮ CÁI</label>
        <textarea id="f-in" spellcheck="false">Wkh txlfn eurzq ira mxpsv ryhu wkh odcb grj. Wklv lv d whvw ri iuhtxhqfb dqdobvlv. Wkh ohwwhu h lv wkh prvw frpprq lq Hqjolvk.</textarea>
        <div class="freq" id="f-out"></div>
        <p class="note">Cột màu là tần suất trong văn bản, vạch xám là tần suất chuẩn tiếng Anh. Nếu cả biểu đồ bị "dịch ngang", đó là Caesar.</p>
      </div>
    </div>`;
  const vIn = body.querySelector("#v-in"), vKey = body.querySelector("#v-key"), vOut = body.querySelector("#v-out");
  const vg = () => { const m = +body.querySelector('input[name="vm"]:checked').value; vOut.value = vigenere(vIn.value, vKey.value, m); };
  [vIn, vKey, ...body.querySelectorAll('input[name="vm"]')].forEach((x) => x.addEventListener("input", vg)); vg();
  const fIn = body.querySelector("#f-in"), fOut = body.querySelector("#f-out");
  const fq = () => {
    const letters = fIn.value.toLowerCase().replace(/[^a-z]/g, "");
    const cnt = {}; for (const ch of letters) cnt[ch] = (cnt[ch] || 0) + 1;
    const max = Math.max(13, ...Object.values(cnt).map((x) => (x / letters.length) * 100));
    fOut.innerHTML = "abcdefghijklmnopqrstuvwxyz".split("").map((ch) => {
      const p = letters.length ? ((cnt[ch] || 0) / letters.length) * 100 : 0;
      return `<div class="fcol" title="${ch}: ${p.toFixed(1)}% (chuẩn ${EN_FREQ[ch]}%)"><div class="fbar" style="height:${(p / max) * 100}%"></div><div class="fref" style="bottom:${(EN_FREQ[ch] / max) * 100}%"></div><span>${ch}</span></div>`;
    }).join("");
  };
  fIn.addEventListener("input", fq); fq();
}

/* ---------- ASCII ---------- */
function toolAscii(body) {
  body.innerHTML = `<div class="ascii-table" id="ascii"></div>`;
  const ascii = body.querySelector("#ascii");
  const names = { 0: "NUL", 9: "TAB", 10: "LF \\n", 13: "CR \\r", 27: "ESC", 32: "space", 127: "DEL" };
  for (let i = 0; i < 128; i++) {
    if (i < 32 && !names[i]) continue;
    ascii.insertAdjacentHTML("beforeend", `<div><b>${names[i] ? `<small>${names[i]}</small>` : esc(String.fromCharCode(i))}</b><span>${i}</span><span>0x${i.toString(16).padStart(2, "0")}</span><span class="bin">${i.toString(2).padStart(8, "0")}</span></div>`);
  }
}


const RESOURCES = [
  { cat: "Luyện tập", name: "picoCTF", url: "https://picoctf.org/", desc: "Điểm khởi đầu tốt nhất cho người mới. Kho bài picoGym mở quanh năm, có gợi ý." },
  { cat: "Luyện tập", name: "OverTheWire", url: "https://overthewire.org/wargames/", desc: "Wargame qua SSH. Bandit dạy Linux, Natas dạy web, Krypton dạy crypto." },
  { cat: "Luyện tập", name: "TryHackMe", url: "https://tryhackme.com/", desc: "Phòng học có hướng dẫn từng bước, chạy máy ảo ngay trên trình duyệt." },
  { cat: "Luyện tập", name: "Hack The Box", url: "https://www.hackthebox.com/", desc: "Máy và thử thách thực tế hơn, phù hợp khi đã vững căn bản." },
  { cat: "Luyện tập", name: "CryptoHack", url: "https://cryptohack.org/", desc: "Học mật mã học qua bài tập, từ XOR đến RSA và ECC." },
  { cat: "Luyện tập", name: "pwn.college", url: "https://pwn.college/", desc: "Khoá học binary exploitation bài bản, miễn phí." },
  { cat: "Luyện tập", name: "PortSwigger Academy", url: "https://portswigger.net/web-security", desc: "Bài giảng và lab cho từng loại lỗ hổng web." },
  { cat: "Luyện tập", name: "Root Me", url: "https://www.root-me.org/", desc: "Hàng trăm thử thách chia theo mảng và độ khó." },
  { cat: "Tài liệu", name: "CTF101", url: "https://ctf101.org/", desc: "Sổ tay giới thiệu từng mảng CTF, ngắn gọn, dễ đọc." },
  { cat: "Tài liệu", name: "CTF Wiki", url: "https://ctf-wiki.org/", desc: "Bách khoa toàn thư về kỹ thuật CTF, rất chi tiết." },
  { cat: "Tài liệu", name: "HackTricks", url: "https://book.hacktricks.wiki/", desc: "Tổng hợp kỹ thuật tấn công theo từng công nghệ." },
  { cat: "Tài liệu", name: "PayloadsAllTheThings", url: "https://github.com/swisskyrepo/PayloadsAllTheThings", desc: "Danh sách payload cho mọi loại lỗ hổng web." },
  { cat: "Tài liệu", name: "GTFOBins", url: "https://gtfobins.github.io/", desc: "Cách lạm dụng các lệnh Unix để leo thang đặc quyền." },
  { cat: "Tài liệu", name: "LiveOverflow (YouTube)", url: "https://www.youtube.com/@LiveOverflow", desc: "Video giải thích sâu về pwn, reverse và tư duy hacker." },
  { cat: "Tài liệu", name: "John Hammond (YouTube)", url: "https://www.youtube.com/@_JohnHammond", desc: "Video giải bài CTF đủ mọi mảng." },
  { cat: "Công cụ", name: "CyberChef", url: "https://gchq.github.io/CyberChef/", desc: "Giải mã, chuyển đổi, phân tích dữ liệu. Có chức năng Magic." },
  { cat: "Công cụ", name: "dCode", url: "https://www.dcode.fr/", desc: "Nhận diện và giải hàng trăm loại mật mã cổ điển." },
  { cat: "Công cụ", name: "CrackStation", url: "https://crackstation.net/", desc: "Tra hash MD5/SHA trong bảng khổng lồ." },
  { cat: "Công cụ", name: "FactorDB", url: "http://factordb.com/", desc: "Tra phân tích thừa số nguyên tố, dùng cho RSA." },
  { cat: "Công cụ", name: "Ghidra", url: "https://ghidra-sre.org/", desc: "Bộ công cụ dịch ngược miễn phí với decompiler mạnh." },
  { cat: "Công cụ", name: "Dogbolt", url: "https://dogbolt.org/", desc: "So sánh kết quả của nhiều decompiler cùng lúc, online." },
  { cat: "Công cụ", name: "Burp Suite", url: "https://portswigger.net/burp/communitydownload", desc: "Proxy chặn và sửa request HTTP. Công cụ số một cho web." },
  { cat: "Công cụ", name: "Wireshark", url: "https://www.wireshark.org/", desc: "Phân tích gói tin mạng (.pcap)." },
  { cat: "Công cụ", name: "pwntools", url: "https://docs.pwntools.com/", desc: "Thư viện Python để viết exploit." },
  { cat: "Công cụ", name: "Aperi'Solve", url: "https://www.aperisolve.com/", desc: "Chạy hàng loạt công cụ stego trên ảnh của bạn." },
  { cat: "Cộng đồng", name: "CTFtime", url: "https://ctftime.org/", desc: "Lịch giải, bảng xếp hạng đội và writeup toàn cầu." },
  { cat: "Luyện tập", name: "pwnable.kr", url: "https://pwnable.kr/", desc: "Bài pwn kinh điển, từ dễ đến rất khó." },
  { cat: "Luyện tập", name: "HackTheBox Academy", url: "https://academy.hackthebox.com/", desc: "Khoá học có lý thuyết và lab, nhiều module miễn phí." },
  { cat: "Luyện tập", name: "Crackmes.one", url: "https://crackmes.one/", desc: "Kho bài reverse (crackme) do cộng đồng đóng góp." },
  { cat: "Tài liệu", name: "OWASP Top 10", url: "https://owasp.org/www-project-top-ten/", desc: "10 rủi ro bảo mật web phổ biến nhất." },
  { cat: "Tài liệu", name: "Nightmare", url: "https://guyinatuxedo.github.io/", desc: "Giáo trình pwn/reverse qua các bài CTF thật." },
  { cat: "Tài liệu", name: "ir0nstone Notes", url: "https://ir0nstone.gitbook.io/notes", desc: "Ghi chú binary exploitation dễ hiểu cho người mới." },
  { cat: "Công cụ", name: "Volatility", url: "https://volatilityfoundation.org/", desc: "Phân tích bản dump bộ nhớ RAM." },
  { cat: "Công cụ", name: "RsaCtfTool", url: "https://github.com/RsaCtfTool/RsaCtfTool", desc: "Thử tự động hàng loạt tấn công RSA." },
  { cat: "Công cụ", name: "jwt.io", url: "https://jwt.io/", desc: "Giải mã và xem nội dung JSON Web Token." },
];

function renderResources(container) {
  const cats = ["Tất cả", ...new Set(RESOURCES.map((r) => r.cat))];
  container.innerHTML = `
  <div class="container page">
    <div class="section-head" style="padding-top:48px">
      <h2>Tài nguyên</h2>
      <p>Nền tảng luyện tập, tài liệu và công cụ mà người chơi CTF dùng hằng ngày.</p>
    </div>
    <div class="filter-row">${cats.map((c2, i) => `<button class="op ${i ? "" : "on"}" data-c="${c2}">${c2}</button>`).join("")}</div>
    <div class="res-grid"></div>
  </div>`;
  const grid = container.querySelector(".res-grid");
  const draw = (cat) => {
    grid.innerHTML = RESOURCES.filter((r) => cat === "Tất cả" || r.cat === cat)
      .map((r, i) => `
      <a class="res-card reveal" style="transition-delay:${Math.min(i * 30, 400)}ms" href="${r.url}" target="_blank" rel="noopener">
        <div class="top"><h4>${r.name}</h4><span class="tag">${r.cat}</span><span class="ext">↗</span></div>
        <span class="url">${r.url.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "")}</span>
        <p>${r.desc}</p>
      </a>`).join("");
    observeReveal(grid);
  };
  container.querySelectorAll(".filter-row .op").forEach((b) =>
    b.addEventListener("click", () => {
      container.querySelectorAll(".filter-row .op").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
      draw(b.dataset.c);
    })
  );
  draw("Tất cả");
}
