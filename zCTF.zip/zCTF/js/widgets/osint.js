/* Widget cho track OSINT — mọi tổ chức, người, domain đều hư cấu (.example) */
const OS_SECRETS = {
  txt: "ekNURntkbnNfdHh0X2wwX3RoMG5nX3Qxbn0=",
  wb: "ekNURnt3NHliNGNrX25oMF9oM3R9",
  dork: "ekNURntkMHJrX3QxbV9mMWwzX2wwfQ==",
};

/* ---------------- Shell OSINT ---------------- */
SHELL_FS["osint-recon"] = {
  host: "recon",
  motd: 'Mục tiêu (hư cấu): công ty <span class="hl">Cà Phê Mây</span>, domain <span class="hl">caphemay.example</span>. Lệnh: <span class="hl">whois</span>, <span class="hl">dig</span>, <span class="hl">crtsh</span>, <span class="hl">sherlock</span>, <span class="hl">wayback</span>, <span class="hl">exiftool</span>.',
  fs: () => {
    const f = (c2, m) => SH.file(c2, { owner: "guest", ...m });
    const pdf = "%PDF-1.6\n%\xe2\xe3\xcf\xd3\n1 0 obj\n<</Type/Catalog>>\nendobj\n" + "x".repeat(300) + "\n%%EOF\n";
    return SH.base({
      downloads: SH.dir({
        "bao-cao-2025.pdf": f(pdf, { bin: true, exif: { "PDF Version": "1.6", Title: "Báo cáo thường niên 2025", Author: "maitt.dev", Creator: "Microsoft Word for Microsoft 365", Producer: "Microsoft Word", "Create Date": "2025:12:02 09:14:37+07:00", "Modify Date": "2025:12:02 09:20:05+07:00", Company: "Cà Phê Mây JSC" } }),
        "menu.pdf": f(pdf, { bin: true, exif: { "PDF Version": "1.6", Title: "Thực đơn", Author: "Marketing", Creator: "Canva" } }),
      }, { owner: "guest" }),
      "notes.txt": f("Phạm vi: chỉ thu thập thông tin CÔNG KHAI về caphemay.example (lab hư cấu).\nKhông đăng nhập, không tấn công, không liên hệ người thật.\n"),
    });
  },
  cmds: {
    exiftool: (...a) => foExiftoolCmd(...a),
    whois: (a) => {
      const d = (a[0] || "").toLowerCase();
      if (!d) throw "Usage: whois <domain>";
      if (!/caphemay\.example$/.test(d)) return `No match for domain "${d.toUpperCase()}".`;
      return `Domain Name: CAPHEMAY.EXAMPLE
Registrar: Example Registrar, Inc.
Creation Date: 2019-04-18T03:12:44Z
Registry Expiry Date: 2027-04-18T03:12:44Z
Registrant Organization: REDACTED FOR PRIVACY
Registrant Country: VN
Name Server: NS1.CAPHEMAY.EXAMPLE
Name Server: NS2.CAPHEMAY.EXAMPLE
DNSSEC: unsigned
>>> Last update of WHOIS database: 2026-11-10T00:00:00Z <<<`;
    },
    dig: (a) => {
      const args = a.filter((x) => !x.startsWith("+") && !x.startsWith("@"));
      const short = a.includes("+short");
      let type = "A", name = null;
      for (const x of args) { if (/^(A|AAAA|MX|TXT|NS|CNAME|SOA|ANY)$/i.test(x)) type = x.toUpperCase(); else name = x.toLowerCase().replace(/\.$/, ""); }
      if (!name) throw "Usage: dig [type] <name> [+short]";
      const Z = {
        "caphemay.example": { A: ["203.0.113.120"], MX: ["10 mail.caphemay.example."], NS: ["ns1.caphemay.example.", "ns2.caphemay.example."], TXT: ['"v=spf1 include:_spf.mail.example ~all"', '"site-verification=8f2a91c0d7"', `"internal-note=${d64(OS_SECRETS.txt)}"`] },
        "www.caphemay.example": { CNAME: ["caphemay.example."], A: ["203.0.113.120"] },
        "mail.caphemay.example": { A: ["203.0.113.121"] },
        "dev.caphemay.example": { A: ["198.51.100.77"], TXT: ['"staging - do not index"'] },
        "vpn.caphemay.example": { A: ["198.51.100.78"] },
        "shop.caphemay.example": { CNAME: ["caphemay.example."], A: ["203.0.113.120"] },
      };
      const rec = Z[name];
      const types = type === "ANY" ? Object.keys(rec || {}) : [type];
      const ans = rec ? types.flatMap((t) => (rec[t] || []).map((v) => [t, v])) : [];
      if (short) return ans.map(([, v]) => v).join("\n");
      return `; <<>> DiG 9.18.24 <<>> ${type} ${name}\n;; ->>HEADER<<- opcode: QUERY, status: ${rec ? "NOERROR" : "NXDOMAIN"}\n\n;; QUESTION SECTION:\n;${name}.\t\tIN\t${type}\n` +
        (ans.length ? `\n;; ANSWER SECTION:\n` + ans.map(([t, v]) => `${name}.\t300\tIN\t${t}\t${v}`).join("\n") : "") + `\n\n;; Query time: 12 msec`;
    },
    crtsh: (a) => {
      const d = (a[0] || "").toLowerCase();
      if (!d) throw "Usage: crtsh <domain>   (tra Certificate Transparency log, như https://crt.sh/?q=%25.domain)";
      if (!/caphemay\.example$/.test(d)) return "(không có chứng chỉ nào)";
      return ["crt.sh ID   Not Before   Common Name", "9134402210  2025-01-03   caphemay.example", "9134402210  2025-01-03   www.caphemay.example", "9512277341  2025-06-11   mail.caphemay.example", "9871100452  2025-09-20   dev.caphemay.example", "9871100453  2025-09-20   vpn.caphemay.example", "9990012001  2026-01-04   shop.caphemay.example"].join("\n");
    },
    sherlock: (a) => {
      const u = a.find((x) => !x.startsWith("-"));
      if (!u) throw "Usage: sherlock <username>";
      const sites = ["GitHub", "GitLab", "Reddit", "Social", "Pastebin", "Keybase", "Medium", "Twitch"];
      const found = u === "maitt.dev" ? { GitHub: "https://github.example/maitt.dev", Social: "https://social.example/@maitt.dev", Medium: "https://medium.example/@maitt.dev" } : u === "caphemay" ? { Social: "https://social.example/@caphemay" } : {};
      return `[*] Checking username ${u} on:\n\n` + sites.map((s) => (found[s] ? `[+] ${s}: ${found[s]}` : `[-] ${s}: Not Found!`)).join("\n") + `\n\n[*] Search completed with ${Object.keys(found).length} results`;
    },
    wayback: (a) => {
      if (!a[0]) throw "Usage: wayback <url> [timestamp]   — liệt kê / xem bản lưu trên Wayback Machine";
      const url = a[0].replace(/^https?:\/\//, "").replace(/\/$/, "").toLowerCase();
      const ARCH = {
        "github.example/maitt.dev": {
          "20230115083012": "maitt.dev · GitHub\n\nMai T. — Backend dev @ Cà Phê Mây ☕\nBio: tạm ghi đây kẻo quên: " + d64(OS_SECRETS.wb) + "\nRepositories: dotfiles, caphemay-api (private)",
          "20240302101544": "maitt.dev · GitHub\n\nMai T. — Backend dev @ Cà Phê Mây ☕\nBio: Đã xoá thông tin cá nhân.\nRepositories: dotfiles",
          "20251020174402": "maitt.dev · GitHub\n\nMai T.\nRepositories: dotfiles",
        },
        "caphemay.example": {
          "20190601120000": "Cà Phê Mây — Sắp khai trương!\nLiên hệ: owner@caphemay.example",
          "20250101090000": "Cà Phê Mây — Trang chủ\nMenu | Tuyển dụng | Blog",
        },
      };
      const snaps = ARCH[url];
      if (!snaps) return `Không có bản lưu nào cho ${url}`;
      if (!a[1]) return `Bản lưu của ${url}:\n` + Object.keys(snaps).map((t) => `  ${t}  https://web.archive.org/web/${t}/${url}`).join("\n") + `\n\nXem: wayback ${url} <timestamp>`;
      const ts = Object.keys(snaps).find((t) => t.startsWith(a[1]));
      if (!ts) return `Không có bản lưu ${a[1]}`;
      return `── web.archive.org/web/${ts}/${url} ──\n` + snaps[ts];
    },
  },
};

/* ---------------- Máy tìm kiếm hỗ trợ dork ---------------- */
WIDGETS.dork = (el) => {
  addStyle("os-dork", `
  .dork{margin:16px 0;border:1px solid var(--border-2);border-radius:12px;overflow:hidden;background:#fff;color:#202124}
  .dork .dk-top{display:flex;gap:10px;align-items:center;padding:14px 16px;border-bottom:1px solid #e3e6ea;flex-wrap:wrap}
  .dork .dk-logo{font-weight:800;font-size:20px;letter-spacing:-.5px;color:#2e6bff}
  .dork .dk-logo b{color:#e8453c}
  .dork input{flex:1;min-width:220px;padding:10px 16px;border-radius:999px;border:1px solid #dfe1e5;font-size:15px;font-family:var(--mono);outline:none;color:#202124;background:#fff}
  .dork input:focus{box-shadow:0 1px 6px rgba(32,33,36,.28);border-color:transparent}
  .dork button{padding:9px 18px;border-radius:999px;border:none;background:#2e6bff;color:#fff;font-weight:600;cursor:pointer}
  .dork .dk-res{padding:10px 18px 18px;min-height:120px;max-height:460px;overflow:auto}
  .dork .dk-stat{font-size:13px;color:#70757a;margin:4px 0 12px}
  .dork .dk-item{margin:0 0 18px}
  .dork .dk-url{font-size:13px;color:#4d5156;font-family:var(--mono)}
  .dork .dk-t{font-size:18px;color:#1a0dab;margin:2px 0}
  .dork .dk-s{font-size:14px;color:#4d5156;line-height:1.55;white-space:pre-wrap}
  .dork .dk-ft{display:inline-block;font-size:11px;font-weight:700;padding:1px 5px;border-radius:3px;background:#e8eaed;color:#3c4043;margin-right:6px}
  .dork mark{background:none;font-weight:700;color:inherit}
  `);
  const PAGES = [
    { url: "caphemay.example/", title: "Cà Phê Mây — Cà phê rang xay mỗi ngày", ft: "html", text: "Cà Phê Mây phục vụ cà phê phin, cold brew và bánh ngọt. Cửa hàng mở cửa 7:00–22:00. Xem thực đơn và tuyển dụng." },
    { url: "caphemay.example/tuyen-dung", title: "Tuyển dụng — Cà Phê Mây", ft: "html", text: "Tuyển barista và lập trình viên backend (Python, FastAPI). Gửi CV về hr@caphemay.example. Hệ thống staging tại dev.caphemay.example." },
    { url: "caphemay.example/blog/khai-truong-chi-nhanh-2", title: "Khai trương chi nhánh 2", ft: "html", text: "Chi nhánh mới của Cà Phê Mây chính thức mở cửa. Ảnh do đội marketing thực hiện." },
    { url: "caphemay.example/files/bao-cao-2025.pdf", title: "Báo cáo thường niên 2025", ft: "pdf", text: "Báo cáo thường niên Cà Phê Mây 2025. Doanh thu, kế hoạch mở rộng, chuyển đổi số." },
    { url: "caphemay.example/files/menu.pdf", title: "Thực đơn Cà Phê Mây", ft: "pdf", text: "Cà phê sữa đá, bạc xỉu, cold brew cam sả, bánh mì que." },
    { url: "caphemay.example/files/noi-quy-nhan-vien.docx", title: "Nội quy nhân viên", ft: "docx", text: "Nội quy làm việc, ca kíp, đồng phục cho nhân viên Cà Phê Mây." },
    { url: "dev.caphemay.example/", title: "Staging — Cà Phê Mây API", ft: "html", text: "Môi trường thử nghiệm. Không dành cho khách hàng.", hidden: true },
    { url: "dev.caphemay.example/backup/", title: "Index of /backup", ft: "html", text: "Index of /backup\n  db-2025-09-01.sql.gz   12M\n  www.tar.gz             48M", hidden: true },
    { url: "dev.caphemay.example/.env", title: "dev.caphemay.example/.env", ft: "env", text: `APP_ENV=staging\nDB_HOST=10.10.0.5\nDB_USER=caphemay\nDB_PASSWORD=${d64(OS_SECRETS.dork)}\nMAIL_FROM=no-reply@caphemay.example`, hidden: true },
    { url: "forum.example/t/ai-biet-ca-phe-may-tuyen-dung", title: "Ai từng phỏng vấn ở Cà Phê Mây chưa?", ft: "html", text: "Mình được chị maitt.dev bên tech phỏng vấn, hỏi khá kỹ về SQL và Docker." },
    { url: "news.example/kinh-te/chuoi-ca-phe-noi-dia-2025", title: "Các chuỗi cà phê nội địa tăng trưởng mạnh", ft: "html", text: "Nhiều thương hiệu như Cà Phê Mây mở rộng nhanh trong năm 2025." },
    { url: "weather.example/may-mua-hom-nay", title: "Dự báo mây mưa hôm nay", ft: "html", text: "Trời nhiều mây, có mưa rào vào chiều tối." },
    { url: "recipes.example/cach-pha-ca-phe-phin", title: "Cách pha cà phê phin ngon", ft: "html", text: "Hướng dẫn pha cà phê phin truyền thống tại nhà." },
  ];
  const norm = (s) => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").toLowerCase();
  const root = h(`<div class="dork"><div class="window-bar" style="background:#f1f3f4;border-bottom:1px solid #e3e6ea"><i></i><i></i><i></i><span style="color:#5f6368">search.example</span></div>
    <div class="dk-top"><span class="dk-logo">Tìm<b>Kiếm</b></span><input value="cà phê mây" spellcheck="false" aria-label="Truy vấn"><button>Tìm</button></div>
    <div class="dk-res"></div></div>`);
  el.replaceWith(root);
  const inp = root.querySelector("input"), res = root.querySelector(".dk-res");
  function parse(q) {
    const terms = [], ops = [], neg = [];
    const re = /(-?)(?:(site|filetype|ext|intitle|inurl|intext):)?("([^"]*)"|\S+)/gi;
    let m;
    while ((m = re.exec(q))) {
      const val = m[4] != null ? m[4] : m[3];
      if (!val) continue;
      if (m[2]) (m[1] ? neg : ops).push([m[2].toLowerCase(), norm(val)]);
      else if (m[1]) neg.push(["word", norm(val)]);
      else terms.push(norm(val));
    }
    return { terms, ops, neg };
  }
  const test = (p, [op, v]) => {
    const host = p.url.split("/")[0];
    switch (op) {
      case "site": return host === v || host.endsWith("." + v) || norm(p.url).startsWith(v);
      case "filetype": case "ext": return p.ft === v.replace(/^\./, "");
      case "intitle": return norm(p.title).includes(v);
      case "inurl": return norm(p.url).includes(v);
      case "intext": return norm(p.text).includes(v);
      case "word": return norm(p.title + " " + p.text + " " + p.url).includes(v);
    }
    return false;
  };
  function run() {
    const q = parse(inp.value);
    const out = PAGES.filter((p) => {
      if (p.hidden && !q.ops.some((o) => o[0] !== "intext" && test(p, o))) return false;
      const hay = norm(p.title + " " + p.text + " " + p.url);
      return q.terms.every((t) => hay.includes(t)) && q.ops.every((o) => test(p, o)) && !q.neg.some((o) => test(p, o));
    });
    if (!q.terms.length && !q.ops.length) { res.innerHTML = '<div class="dk-stat">Nhập truy vấn.</div>'; return; }
    const mark = (s) => { let r = esc(s); for (const t of q.terms) if (t.length > 1) r = r.replace(new RegExp(t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi"), (x) => `<mark>${x}</mark>`); return r; };
    res.innerHTML = `<div class="dk-stat">Khoảng ${out.length} kết quả</div>` + (out.map((p) => `<div class="dk-item"><div class="dk-url">https://${esc(p.url)}</div><div class="dk-t">${p.ft !== "html" ? `<span class="dk-ft">${p.ft.toUpperCase()}</span>` : ""}${mark(p.title)}</div><div class="dk-s">${mark(p.text.length > 220 && !p.hidden ? p.text.slice(0, 220) + "…" : p.text)}</div></div>`).join("") || "<p>Không tìm thấy kết quả nào phù hợp.</p>");
  }
  root.querySelector("button").onclick = run;
  inp.addEventListener("keydown", (e) => { if (e.key === "Enter") run(); });
  run();
};
