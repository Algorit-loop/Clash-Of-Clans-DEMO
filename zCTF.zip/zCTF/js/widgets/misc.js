/* Widget cho track Misc */
const MISC_S = {
  p1: "ekNURntzY3IxcHRfbmg0bmhfaDBuX25ndTAxfQ==",
  p2: "ekNURntiMW40cnlfczM0cmNoXzIwX2w0bn0=",
  j1: "ekNURntuaDEzdV9jNGNoX2QwY19mMWwzfQ==",
  j2: "ekNURntnM3Q0dHRyX3Y0X24waV9jaHUwMX0=",
  j3: "ekNURnttcjBfc3ViY2w0c3Mzc190aDA0dF9qNDFsfQ==",
  g1: "ekNURntnMXRfa2gwbmdfcXUzbl9nMV9jNH0=",
  g2: "ekNURntuaDRuaF9kM3ZfbDBfYjFfbTR0fQ==",
  g3: "ekNURntzdDRzaF9jdW5nX2w0X2wxY2hfc3V9",
};

/* ===================== 1. Dịch vụ nc ===================== */
/* 100 phép tính một lúc, trả lời trên một dòng trong 120 giây */
NC_SERVICES["lab.zctf.local:4000"] = () => {
  const qs = [];
  for (let i = 0; i < 100; i++) {
    const op = ["+", "-", "*", "%"][Math.floor(Math.random() * 4)];
    const a = 1000 + Math.floor(Math.random() * 90000);
    const b = op === "*" ? 10 + Math.floor(Math.random() * 990) : 2 + Math.floor(Math.random() * 9000);
    const ans = op === "+" ? a + b : op === "-" ? a - b : op === "*" ? a * b : a % b;
    qs.push({ text: `${i + 1}) ${a} ${op} ${b}`, ans });
  }
  const t0 = Date.now();
  return {
    banner: "=== Speed Math 100 ===\nTính 100 phép tính sau. Gửi 100 đáp án trên MỘT dòng, cách nhau bởi dấu cách.\nGiới hạn: 120 giây kể từ lúc kết nối. % là phép chia lấy dư.\n\n" + qs.map((q) => q.text).join("\n") + "\n",
    prompt: "answers> ",
    onLine: (line) => {
      const sec = (Date.now() - t0) / 1000;
      if (sec > 120) return { out: `Hết giờ (${sec.toFixed(0)} giây). Kết nối lại để nhận đề mới.`, close: true };
      const nums = line.trim().split(/[\s,]+/).filter(Boolean).map(Number);
      if (nums.length !== 100) return { out: `Cần đúng 100 đáp án, bạn gửi ${nums.length}. Thử lại (đồng hồ vẫn chạy).` };
      const wrong = qs.findIndex((q, i) => q.ans !== nums[i]);
      if (wrong >= 0) return { out: `Câu ${wrong + 1} sai: ${qs[wrong].text} = ${qs[wrong].ans}, bạn trả lời ${nums[wrong]}. Bye.`, close: true };
      return { out: `Đúng cả 100 câu trong ${sec.toFixed(1)} giây!\n${d64(MISC_S.p1)}`, close: true };
    },
  };
};

/* Đoán số 1..1 000 000 trong 20 lượt */
NC_SERVICES["lab.zctf.local:4001"] = () => {
  const secret = 1 + Math.floor(Math.random() * 1000000);
  let tries = 0;
  return {
    banner: "=== Đoán số ===\nTôi nghĩ một số nguyên từ 1 đến 1000000. Bạn có 20 lượt.\nSau mỗi lượt tôi trả lời: LỚN HƠN (số bí mật lớn hơn) / NHỎ HƠN / ĐÚNG.",
    prompt: "[lượt 1/20] số> ",
    onLine: (line) => {
      const g = parseInt(line.trim(), 10);
      if (!Number.isFinite(g)) return { out: "Nhập một số nguyên." };
      tries++;
      if (g === secret) return { out: `ĐÚNG sau ${tries} lượt!\n${d64(MISC_S.p2)}`, close: true };
      if (tries >= 20) return { out: `Hết 20 lượt. Số bí mật là ${secret}. Bye.`, close: true };
      return { out: g < secret ? "LỚN HƠN" : "NHỎ HƠN", prompt: `[lượt ${tries + 1}/20] số> ` };
    },
  };
};

/* ===================== 2. Brainfuck / Ook! ===================== */
const OOK_MAP = { "Ook. Ook?": ">", "Ook? Ook.": "<", "Ook. Ook.": "+", "Ook! Ook!": "-", "Ook! Ook.": ".", "Ook. Ook!": ",", "Ook! Ook?": "[", "Ook? Ook!": "]" };
function ookToBf(src) {
  const t = src.match(/Ook[.?!]/g) || [];
  if (t.length % 2) throw new Error("Số token Ook lẻ, thiếu một nửa lệnh");
  let r = "";
  for (let i = 0; i < t.length; i += 2) r += OOK_MAP[t[i] + " " + t[i + 1]] ?? "";
  return r;
}
function textToBf(s) {
  let out = "", v = 0;
  for (const b of utf8.encode(s)) {
    const d = b - v, sg = d > 0 ? "+" : "-", a = Math.abs(d);
    if (a <= 10) out += sg.repeat(a);
    else { const k = Math.floor(Math.sqrt(a)), q = Math.floor(a / k), r = a % k; out += ">" + "+".repeat(q) + "[<" + sg.repeat(k) + ">-]<" + sg.repeat(r); }
    out += "."; v = b;
  }
  return out;
}
function runBf(code, input, maxSteps = 5e6) {
  const prog = code.replace(/[^<>+\-.,[\]]/g, "");
  const jump = {}, st = [];
  for (let i = 0; i < prog.length; i++) {
    if (prog[i] === "[") st.push(i);
    else if (prog[i] === "]") { if (!st.length) throw new Error(`Dấu ] thừa ở vị trí ${i}`); const j = st.pop(); jump[i] = j; jump[j] = i; }
  }
  if (st.length) throw new Error(`Thiếu ] cho [ ở vị trí ${st.pop()}`);
  const tape = new Uint8Array(30000), inp = [...utf8.encode(input)], out = [];
  let p = 0, ip = 0, steps = 0, ii = 0;
  while (ip < prog.length) {
    if (++steps > maxSteps) throw new Error(`Quá ${maxSteps.toLocaleString()} bước, có thể bị lặp vô hạn`);
    switch (prog[ip]) {
      case ">": p++; if (p >= tape.length) throw new Error("Con trỏ vượt quá băng nhớ"); break;
      case "<": p--; if (p < 0) throw new Error("Con trỏ âm (đi quá bên trái ô 0)"); break;
      case "+": tape[p]++; break;
      case "-": tape[p]--; break;
      case ".": out.push(tape[p]); break;
      case ",": tape[p] = ii < inp.length ? inp[ii++] : 0; break;
      case "[": if (!tape[p]) ip = jump[ip]; break;
      case "]": if (tape[p]) ip = jump[ip]; break;
    }
    ip++;
  }
  return { out: new TextDecoder().decode(new Uint8Array(out)), tape, p, steps, len: prog.length };
}

WIDGETS.brainfuck = (el) => {
  addStyle("bf", `
    .bf-box .bf-tape{display:flex;gap:4px;flex-wrap:wrap;padding:12px 14px;border-bottom:1px solid var(--border)}
    .bf-box .bf-cell{min-width:42px;text-align:center;padding:5px 4px;border-radius:7px;border:1px solid var(--border);background:#06080b;font-family:var(--mono);font-size:12px;color:var(--muted)}
    .bf-box .bf-cell small{display:block;font-size:10px;color:var(--dim)}
    .bf-box .bf-cell.cur{border-color:var(--accent);color:var(--accent);box-shadow:0 0 10px rgba(var(--accent-rgb),.3)}
    .bf-box select,.bf-box .bf-in{padding:6px 10px;border-radius:8px;background:#06080b;border:1px solid var(--border-2);color:var(--text);font-family:var(--mono);font-size:13px}
    .bf-box .bf-in{width:160px}
    .bf-box textarea{white-space:pre-wrap!important;word-break:break-all;overflow-wrap:anywhere}`);
  const root = h(`
    <div class="py-editor window bf-box">
      <div class="window-bar"><i></i><i></i><i></i><span>Trình thông dịch Brainfuck / Ook!</span></div>
      <textarea spellcheck="false" placeholder="Dán code Brainfuck hoặc Ook! vào đây"></textarea>
      <div class="py-bar">
        <select aria-label="Ngôn ngữ"><option value="bf">Brainfuck</option><option value="ook">Ook!</option></select>
        <input class="bf-in" placeholder="input cho lệnh ," spellcheck="false">
        <button class="btn primary sm" data-a="run">▶ Chạy</button>
        <button class="btn sm" data-a="gen">Chữ → Brainfuck</button>
        <span class="py-status"></span>
      </div>
      <div class="bf-tape"></div>
      <pre class="py-out"></pre>
    </div>`);
  el.replaceWith(root);
  const ta = root.querySelector("textarea"), out = root.querySelector(".py-out"), st = root.querySelector(".py-status");
  const mode = root.querySelector("select"), inp = root.querySelector(".bf-in"), tapeEl = root.querySelector(".bf-tape");
  ta.value = "++++++++[>++++++++<-]>+.+.+.   in ra ABC: ô 1 = 8*8+1 = 65 = 'A'";
  const showTape = (tape, p) => {
    const s = Math.max(0, p - 5);
    tapeEl.innerHTML = Array.from({ length: 12 }, (_, i) => s + i).map((i) => `<div class="bf-cell ${i === p ? "cur" : ""}"><small>#${i}</small>${tape[i]}</div>`).join("");
  };
  showTape(new Uint8Array(12), 0);
  root.querySelector('[data-a="run"]').onclick = () => {
    out.classList.remove("err");
    try {
      const code = mode.value === "ook" ? ookToBf(ta.value) : ta.value;
      const t0 = performance.now();
      const r = runBf(code, inp.value);
      out.textContent = r.out || "(không in ra gì)";
      st.textContent = `${r.len} lệnh · ${r.steps.toLocaleString()} bước · ${Math.round(performance.now() - t0)} ms · con trỏ ở ô ${r.p}`;
      showTape(r.tape, r.p);
    } catch (e) { out.textContent = "Lỗi: " + e.message; out.classList.add("err"); st.textContent = ""; }
  };
  root.querySelector('[data-a="gen"]').onclick = () => {
    const s = prompt("Chữ cần chuyển thành Brainfuck:", "Xin chao!");
    if (s == null) return;
    mode.value = "bf"; ta.value = textToBf(s); out.textContent = "Đã sinh code. Bấm Chạy để kiểm tra."; st.textContent = `${ta.value.length} ký tự`;
  };
};

/* ===================== 3. Jail ===================== */
/* Python jail chạy thật bằng Pyodide. data-level="1" (có builtins, chặn từ khoá) | "2" (không builtins) */
const PYJAIL_SRC = `
def __jail(src, level):
    src = str(src)
    bl = ["import", "open", "flag", "exec", "eval", "system", "compile"]
    if len(src) > 400:
        return "Bị chặn: payload dài quá 400 ký tự"
    low = src.lower()
    for w in bl:
        if w in low:
            return "Bị chặn: phát hiện từ khoá " + repr(w)
    import builtins as _b
    g = {"__builtins__": _b} if level == 1 else {"__builtins__": {}}
    try:
        r = eval(src, g)
    except SyntaxError as e:
        return "SyntaxError: chỉ nhận MỘT biểu thức Python (" + str(e.msg) + ")"
    except Exception as e:
        return type(e).__name__ + ": " + str(e)
    s = repr(r)
    return s if len(s) <= 3000 else s[:3000] + " …(cắt bớt, tổng " + str(len(s)) + " ký tự)"
`;
WIDGETS.pyjail = (el) => {
  const level = +(el.dataset.level || 1);
  const dir = level === 1 ? "/tmp/jail1" : "/tmp/jail2";
  const flag = d64(level === 1 ? MISC_S.j2 : MISC_S.j3);
  let st = null;
  const con = createConsole(el, {
    title: `pyjail level ${level} — nc lab.zctf.local ${9000 + level}`,
    prompt: "jail> ",
    height: 300,
    banner:
      level === 1
        ? `== PyJail 1 ==\nServer chạy: print(eval(input("jail> ")))\nTừ bị cấm: import open flag exec eval system compile\nFlag nằm ở ${dir}/flag.txt`
        : `== PyJail 2 ==\nServer chạy: print(eval(input("jail> "), {"__builtins__": {}}))\nKhông có builtins nào (open, print, len… đều không tồn tại).\nTừ bị cấm: import open flag exec eval system compile\nFlag nằm ở ${dir}/flag.txt`,
    onLine: async (line, api) => {
      if (!line.trim()) return;
      if (!st) {
        const m = api.print("Đang khởi động Python (lần đầu khoảng 10MB)…", "m");
        try {
          const py = await getPyodide((s) => (m.textContent = s));
          py.FS.mkdirTree(dir);
          py.FS.writeFile(dir + "/flag.txt", flag + "\n");
          py.FS.writeFile(dir + "/README", "Chúc may mắn!\n");
          const ns = py.globals.get("dict")();
          py.runPython(PYJAIL_SRC, { globals: ns });
          st = { fn: ns.get("__jail") };
          m.textContent = "Jail sẵn sàng.";
        } catch (e) { m.textContent = "Không tải được Python: " + (e.message || e); m.className = "e"; return; }
      }
      const r = st.fn(line, level);
      api.print(String(r), /^(Bị chặn|[A-Z]\w*Error)/.test(r) ? "e" : "");
    },
  });
};

/* Bash jail: chặn các lệnh đọc file quen thuộc */
SHELL_FS["misc-rbash"] = {
  user: "prisoner",
  host: "jail",
  motd: '<span class="hl">rbash</span> — các lệnh cat, head, tail, more, less, grep, vi, nano, cd, python bị cấm. Flag nằm trong <span class="hl">flag.txt</span>. Hãy đọc nó bằng cách khác.',
  fs: () => SH.base({
    "flag.txt": SH.file(d64(MISC_S.j1) + "\n", { owner: "prisoner" }),
    "note.txt": SH.file("Admin: jail này chặn hết rồi, không ai đọc được flag đâu.\n", { owner: "prisoner" }),
  }, "prisoner"),
  cmds: Object.fromEntries(["cat", "head", "tail", "more", "less", "grep", "vi", "vim", "nano", "cd", "python", "python3", "find", "sudo"].map((n) => [n, () => { throw `rbash: ${n}: lệnh bị cấm trong jail`; }])),
};

/* ===================== 4. Git ===================== */
SHELL_FS["misc-git"] = (() => {
  const B = {
    app1: 'from flask import Flask, request\nfrom config import DB_HOST\n\napp = Flask(__name__)\n\n@app.route("/login", methods=["POST"])\ndef login():\n    user = request.form["user"]\n    return "Xin chào " + user\n',
    app2: 'from flask import Flask, request\nfrom config import DB_HOST\n\napp = Flask(__name__)\n\n@app.route("/login", methods=["POST"])\ndef login():\n    user = request.form.get("user", "")\n    if not user:\n        return "Thiếu user", 400\n    return "Xin chào " + user\n',
    readme: "# Shop nội bộ\n\nỨng dụng Flask demo. Chạy: python app.py\n",
    cfg1: 'DB_HOST = "10.0.0.12"\nDB_USER = "shop"\nDB_PASSWORD = "' + d64(MISC_S.g1) + '"\n',
    cfg2: 'import os\n\nDB_HOST = "10.0.0.12"\nDB_USER = "shop"\nDB_PASSWORD = os.environ["DB_PASSWORD"]\n',
    gi: "__pycache__/\n.env\n",
    todo: "TODO tính năng admin:\n- trang /admin\n- tài khoản thử nghiệm: admin / " + d64(MISC_S.g2) + "\n- nhớ xoá file này trước khi merge!\n",
    dbg: 'DEBUG = True\nTOKEN = "' + d64(MISC_S.g3) + '"\n',
  };
  const C = [
    { id: "4f1c9a2e8b7d6c5a4f3e2d1c0b9a8f7e6d5c4b3a", msg: "Initial commit", author: "Minh Tran <minh@shop.local>", date: "Mon Oct 6 09:12:44 2026 +0700", parent: null, tree: { "README.md": B.readme, "app.py": B.app1, ".gitignore": B.gi } },
    { id: "a83b02f19c4d7e6a5b3c2d1e0f9a8b7c6d5e4f30", msg: "Thêm cấu hình database", author: "Minh Tran <minh@shop.local>", date: "Tue Oct 7 14:03:10 2026 +0700", parent: 0, tree: { "README.md": B.readme, "app.py": B.app1, ".gitignore": B.gi, "config.py": B.cfg1 } },
    { id: "c7e5d4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8d7", msg: "Xoá mật khẩu khỏi config, đọc từ biến môi trường", author: "Lan Pham <lan@shop.local>", date: "Wed Oct 8 10:45:51 2026 +0700", parent: 1, tree: { "README.md": B.readme, "app.py": B.app1, ".gitignore": B.gi, "config.py": B.cfg2 } },
    { id: "e2d9f0a1b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8", msg: "Sửa lỗi đăng nhập khi thiếu user", author: "Minh Tran <minh@shop.local>", date: "Thu Oct 9 16:20:02 2026 +0700", parent: 2, tree: { "README.md": B.readme, "app.py": B.app2, ".gitignore": B.gi, "config.py": B.cfg2 } },
    { id: "91b4c6d8e0f2a4b6c8d0e2f4a6b8c0d2e4f6a8b0", msg: "WIP: tính năng admin", author: "Lan Pham <lan@shop.local>", date: "Fri Oct 10 23:58:37 2026 +0700", parent: 3, tree: { "README.md": B.readme, "app.py": B.app2, ".gitignore": B.gi, "config.py": B.cfg2, "admin_todo.txt": B.todo } },
  ];
  const branches = { main: 3, dev: 4 };
  const stash = { id: "5d3e1f7a9b2c4d6e8f0a1b3c5d7e9f1a3b5c7d9e", base: 3, msg: "WIP on main: e2d9f0a Sửa lỗi đăng nhập khi thiếu user", tree: { ...C[3].tree, "debug.py": B.dbg } };
  let head = "main";

  const short = (id) => id.slice(0, 7);
  const findCommit = (ref) => {
    if (ref == null || ref === "HEAD") return C[branches[head]];
    let m = ref.match(/^(.+?)(~(\d*)|\^+)$/);
    let base = m ? m[1] : ref, back = m ? (m[2].startsWith("~") ? +(m[3] || 1) : m[2].length) : 0;
    let c = base === "HEAD" ? C[branches[head]] : branches[base] != null ? C[branches[base]] : base.length >= 4 ? C.find((x) => x.id.startsWith(base)) : null;
    if (base.startsWith("stash")) return { ...stash, isStash: true };
    while (c && back-- > 0) c = c.parent == null ? null : C[c.parent];
    return c || null;
  };
  // diff dòng đơn giản dựa trên LCS
  const diffLines = (a, b) => {
    const A = a ? a.replace(/\n$/, "").split("\n") : [], Bl = b ? b.replace(/\n$/, "").split("\n") : [];
    const dp = Array.from({ length: A.length + 1 }, () => new Array(Bl.length + 1).fill(0));
    for (let i = A.length - 1; i >= 0; i--) for (let j = Bl.length - 1; j >= 0; j--) dp[i][j] = A[i] === Bl[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    const out = []; let i = 0, j = 0;
    while (i < A.length || j < Bl.length) {
      if (i < A.length && j < Bl.length && A[i] === Bl[j]) { out.push(" " + A[i]); i++; j++; }
      else if (i < A.length && (j >= Bl.length || dp[i + 1][j] >= dp[i][j + 1])) out.push("-" + A[i++]);
      else out.push("+" + Bl[j++]);
    }
    return out;
  };
  const fileDiff = (path, a, b) => {
    if (a === b) return "";
    let s = `<span class="hl">diff --git a/${esc(path)} b/${esc(path)}</span>\n`;
    if (a == null) s += "new file mode 100644\n";
    if (b == null) s += "deleted file mode 100644\n";
    s += `--- ${a == null ? "/dev/null" : "a/" + esc(path)}\n+++ ${b == null ? "/dev/null" : "b/" + esc(path)}\n`;
    s += diffLines(a, b).map((l) => (l[0] === "+" ? `<span class="d">${esc(l)}</span>` : l[0] === "-" ? `<span class="e">${esc(l)}</span>` : esc(l))).join("\n");
    return s;
  };
  const treeDiff = (t1, t2) => [...new Set([...Object.keys(t1 || {}), ...Object.keys(t2 || {})])].sort().map((p) => fileDiff(p, t1 ? t1[p] : null, t2 ? t2[p] : null)).filter(Boolean).join("\n");
  const fmtCommit = (c, patch) => {
    const refs = Object.entries(branches).filter(([, v]) => C[v] === c).map(([k]) => (k === head ? `HEAD -> ${k}` : k));
    let s = `<span class="hl">commit ${c.id}</span>${refs.length ? ` <span class="x">(${esc(refs.join(", "))})</span>` : ""}\nAuthor: ${esc(c.author)}\nDate:   ${c.date}\n\n    ${esc(c.msg)}\n`;
    if (patch) s += "\n" + treeDiff(c.parent == null ? {} : C[c.parent].tree, c.tree) + "\n";
    return s;
  };
  const inRepo = (ctx) => /\/webapp(\/|$)/.test(ctx.cwd);
  const syncWorktree = (ctx, tree) => {
    const dir = ctx.node(ctx.resolve("~/webapp"));
    for (const k of Object.keys(dir.c)) if (k !== ".git") delete dir.c[k];
    for (const [k, v] of Object.entries(tree)) dir.c[k] = SH.file(v, { owner: "dev" });
  };

  const git = async (a, stdin, ctx) => {
    const sub = a[0];
    if (!sub || sub === "help" || sub === "--help") return "Lệnh git hỗ trợ: status, log [--oneline] [-p] [--all] [ref], show <ref>[:file], diff <ref1> <ref2>, branch [-a], checkout <nhánh>, stash list, stash show -p, reflog, cat-file -p <ref>";
    if (!inRepo(ctx)) throw "fatal: not a git repository (or any of the parent directories): .git";
    const args = a.slice(1);
    const fl = args.filter((x) => x.startsWith("-"));
    const refs = args.filter((x) => !x.startsWith("-"));
    switch (sub) {
      case "status":
        return `On branch ${head}\nnothing to commit, working tree clean`;
      case "branch":
        return { html: Object.keys(branches).map((b) => (b === head ? `* <span class="d">${b}</span>` : "  " + b)).join("\n") + (fl.includes("-a") ? '\n  <span class="e">remotes/origin/main</span>\n  <span class="e">remotes/origin/dev</span>' : "") };
      case "checkout":
      case "switch": {
        const b = refs[0];
        if (branches[b] == null) throw `error: pathspec '${b ?? ""}' did not match any file(s) known to git`;
        head = b;
        syncWorktree(ctx, C[branches[b]].tree);
        ctx.node(ctx.resolve("~/webapp/.git")).c.HEAD.c = `ref: refs/heads/${b}\n`;
        return `Switched to branch '${b}'`;
      }
      case "log": {
        let list;
        if (fl.includes("--all")) list = [...C].reverse();
        else {
          const start = findCommit(refs[0]);
          if (!start || start.isStash) throw `fatal: ambiguous argument '${refs[0]}': unknown revision`;
          list = []; let c = start;
          while (c) { list.push(c); c = c.parent == null ? null : C[c.parent]; }
        }
        if (fl.includes("--oneline")) return { html: list.map((c) => { const r = Object.entries(branches).filter(([, v]) => C[v] === c).map(([k]) => (k === head ? `HEAD -> ${k}` : k)); return `<span class="hl">${short(c.id)}</span>${r.length ? ` <span class="x">(${esc(r.join(", "))})</span>` : ""} ${esc(c.msg)}`; }).join("\n") };
        return { html: list.map((c) => fmtCommit(c, fl.includes("-p") || fl.includes("--patch"))).join("\n") };
      }
      case "show": {
        const ref = refs[0] || "HEAD";
        const [r, file] = ref.split(":");
        const c = findCommit(r || "HEAD");
        if (!c) throw `fatal: ambiguous argument '${ref}': unknown revision or path not in the working tree.`;
        if (file != null) {
          if (!(file in c.tree)) throw `fatal: path '${file}' does not exist in '${r}'`;
          return { text: c.tree[file] };
        }
        if (c.isStash) return { html: `<span class="hl">commit ${stash.id}</span> (refs/stash)\nMerge: ${short(C[stash.base].id)}\n\n    ${esc(stash.msg)}\n\n` + treeDiff(C[stash.base].tree, stash.tree) };
        return { html: fmtCommit(c, true) };
      }
      case "diff": {
        if (refs.length < 2) return "";
        const x = findCommit(refs[0]), y = findCommit(refs[1]);
        if (!x || !y) throw "fatal: bad revision";
        return { html: treeDiff(x.tree, y.tree) || "" };
      }
      case "stash": {
        const op = refs[0] || "list";
        if (op === "list") return `stash@{0}: ${stash.msg}`;
        if (op === "show") return fl.includes("-p") ? { html: treeDiff(C[stash.base].tree, stash.tree) } : " debug.py | 2 ++\n 1 file changed, 2 insertions(+)";
        if (op === "pop" || op === "apply") { syncWorktree(ctx, stash.tree); return "Đã áp dụng stash@{0} vào thư mục làm việc.\nChanges not staged for commit:\n\tnew file:   debug.py"; }
        throw `git stash: lệnh con '${op}' không hỗ trợ (dùng list, show -p, apply)`;
      }
      case "reflog":
        return { html: [[3, "checkout: moving from dev to main"], [4, "commit: WIP: tính năng admin"], [3, "checkout: moving from main to dev"], [3, "commit: Sửa lỗi đăng nhập khi thiếu user"], [2, "commit: Xoá mật khẩu khỏi config, đọc từ biến môi trường"], [1, "commit: Thêm cấu hình database"], [0, "commit (initial): Initial commit"]].map(([i, m], k) => `<span class="hl">${short(C[i].id)}</span> HEAD@{${k}}: ${esc(m)}`).join("\n") };
      case "cat-file": {
        const c = findCommit(refs[0]);
        if (!c || c.isStash) throw `fatal: Not a valid object name ${refs[0]}`;
        return `tree ${c.id.split("").reverse().join("")}\n${c.parent != null ? "parent " + C[c.parent].id + "\n" : ""}author ${c.author}\ncommitter ${c.author}\n\n${c.msg}`;
      }
      default:
        throw `git: '${sub}' is not a git command. Gõ 'git help'.`;
    }
  };

  return {
    user: "dev",
    host: "build-server",
    motd: 'Repo nằm ở <span class="hl">~/webapp</span>. Lệnh <span class="hl">git</span> được mô phỏng (gõ <span class="hl">git help</span>).',
    cmds: { git },
    fs: () => {
      head = "main";
      const tree = C[branches.main].tree;
      const files = Object.fromEntries(Object.entries(tree).map(([k, v]) => [k, SH.file(v, { owner: "dev" })]));
      files[".git"] = SH.dir({
        HEAD: SH.file("ref: refs/heads/main\n", { owner: "dev" }),
        config: SH.file('[core]\n\trepositoryformatversion = 0\n[remote "origin"]\n\turl = git@git.shop.local:shop/webapp.git\n[branch "main"]\n\tremote = origin\n', { owner: "dev" }),
        refs: SH.dir({ heads: SH.dir({ main: SH.file(C[3].id + "\n", { owner: "dev" }), dev: SH.file(C[4].id + "\n", { owner: "dev" }) }, { owner: "dev" }), stash: SH.file(stash.id + "\n", { owner: "dev" }) }, { owner: "dev" }),
        objects: SH.dir({ pack: SH.dir({}, { owner: "dev" }) }, { owner: "dev" }),
      }, { owner: "dev" });
      return SH.base({ webapp: SH.dir(files, { owner: "dev" }) }, "dev");
    },
  };
})();

/* Terminal cho bài lập trình */
SHELL_FS["misc-prog"] = {
  user: "player",
  host: "ctf",
  motd: 'Dịch vụ: <span class="hl">nc lab.zctf.local 4000</span> (Speed Math 100), <span class="hl">nc lab.zctf.local 4001</span> (Đoán số). Ctrl+C để ngắt kết nối.',
  fs: () => SH.base({ "notes.txt": SH.file("Quy trình: nc → chép đề → tính bằng Python → dán đáp án.\n", { owner: "player" }) }, "player"),
};
