/* Widget cho track Forensics (và helper dùng lại ở OSINT) */
const FO_SECRETS = {
  fo2: "ekNURnt0YW5nX3R1b25nX3BoYW59",
  file2: "ekNURnt1dGYxNl90cjBuX2toMDFfc3RyMW5nc30=",
  file3: "ekNURntoMzRkM3JfczRjaF9zM30=",
  file4: "ekNURnt6MXBfdHIwbmdfNG5oX2pwM2d9",
  stego2: "ekNURntiMXRfcGw0bjNfeDRuaH0=",
  stego3: "ekNURntsNWJfcmdiX2Q0dV90MTNufQ==",
  stego4: "ekNURntkNHQ0X3M0dV8xM25kfQ==",
  net1: "ekNURntodHRwX2toMG5nX200X2gwYX0=",
  net2: "ekNURntmdHBfZDR0NF9zdHIzNG19",
  net3: "ekNURntkbnNfM3hmMWxfdDFuaF92MX0=",
  mem2: "ekNURnt2MGw0dDFsMXR5X2R1bXBfZjFsM30=",
  mem4: "ekNURntkM2wzdDNkX25oNG5nX2Mwbl9kMH0=",
};

/* ---------------- helper bytes / định dạng file ---------------- */
const FO = (() => {
  const T = [];
  for (let n = 0; n < 256; n++) { let c2 = n; for (let k = 0; k < 8; k++) c2 = c2 & 1 ? 0xedb88320 ^ (c2 >>> 1) : c2 >>> 1; T[n] = c2 >>> 0; }
  const crc32 = (b) => { let c2 = ~0; for (const x of b) c2 = T[(c2 ^ x) & 255] ^ (c2 >>> 8); return (~c2) >>> 0; };
  const le16 = (n) => String.fromCharCode(n & 255, (n >>> 8) & 255);
  const le32 = (n) => String.fromCharCode(n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255);
  const be32 = (n) => String.fromCharCode((n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255);
  const rng = (seed) => () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
  /** n byte ngẫu nhiên (latin1), tránh vô tình tạo chữ ký file */
  const noise = (n, seed = 7) => { const r = rng(seed); let s = ""; for (let i = 0; i < n; i++) { let v = Math.floor(r() * 256); if (v === 0x50 || v === 0xff || v === 0x89 || v === 0x25) v ^= 0x11; s += String.fromCharCode(v); } return s; };
  /** ZIP lưu (stored, không nén) — đủ chuẩn để unzip thật mở được */
  function zip(files) {
    let local = "", central = "", off = 0;
    for (const [name, data] of files) {
      const crc = crc32(latin1ToBytes(data));
      const lh = "PK\x03\x04" + le16(20) + le16(0) + le16(0) + le16(0) + le16(0x5b21) + le32(crc) + le32(data.length) + le32(data.length) + le16(name.length) + le16(0) + name + data;
      central += "PK\x01\x02" + le16(20) + le16(20) + le16(0) + le16(0) + le16(0) + le16(0x5b21) + le32(crc) + le32(data.length) + le32(data.length) + le16(name.length) + le16(0) + le16(0) + le16(0) + le16(0) + le32(0) + le32(off) + name;
      local += lh; off += lh.length;
    }
    return local + central + "PK\x05\x06" + le16(0) + le16(0) + le16(files.length) + le16(files.length) + le32(central.length) + le32(off) + le16(0);
  }
  const rd16 = (s, i) => s.charCodeAt(i) | (s.charCodeAt(i + 1) << 8);
  const rd32 = (s, i) => (rd16(s, i) | (rd16(s, i + 2) << 16)) >>> 0;
  /** Đọc các entry stored trong một chuỗi chứa ZIP (có thể có dữ liệu thừa phía trước) */
  function unzip(s) {
    const out = [];
    let i = s.indexOf("PK\x03\x04");
    while (i >= 0) {
      const method = rd16(s, i + 8), size = rd32(s, i + 18), nl = rd16(s, i + 26), xl = rd16(s, i + 28);
      const name = s.substr(i + 30, nl);
      const data = s.substr(i + 30 + nl + xl, size);
      out.push({ name, data, method, offset: i });
      i = s.indexOf("PK\x03\x04", i + 30 + nl + xl + size);
    }
    return out;
  }
  function png(chunks) {
    const ch = (type, data) => be32(data.length) + type + data + be32(crc32(latin1ToBytes(type + data)));
    return "\x89PNG\r\n\x1a\n" + chunks.map(([t, d]) => ch(t, d)).join("");
  }
  function sigs(s) {
    const res = [];
    const add = (i, d) => res.push([i, d]);
    const scan = (needle, fn) => { let i = s.indexOf(needle); while (i >= 0) { const d = fn(i); if (d) add(i, d); i = s.indexOf(needle, i + 1); } };
    scan("\xff\xd8\xff", () => "JPEG image data, JFIF standard 1.01");
    scan("\x89PNG\r\n\x1a\n", (i) => `PNG image, ${rd32be(s, i + 16)} x ${rd32be(s, i + 20)}, 8-bit/color RGB, non-interlaced`);
    scan("%PDF-", (i) => "PDF document, version " + s.substr(i + 5, 3));
    scan("PK\x03\x04", (i) => `Zip archive data, at least v2.0 to extract, compressed size: ${rd32(s, i + 18)}, uncompressed size: ${rd32(s, i + 22)}, name: ${s.substr(i + 30, rd16(s, i + 26))}`);
    scan("PK\x05\x06", () => "End of Zip archive, footer length: 22");
    scan("\x1f\x8b\x08", () => "gzip compressed data, from Unix");
    scan("\x7fELF", () => "ELF, 64-bit LSB executable, AMD x86-64");
    return res.sort((a, b) => a[0] - b[0]);
  }
  const rd32be = (s, i) => ((s.charCodeAt(i) << 24) | (s.charCodeAt(i + 1) << 16) | (s.charCodeAt(i + 2) << 8) | s.charCodeAt(i + 3)) >>> 0;
  const kind = (s) => {
    if (s.startsWith("\x89PNG")) return ["PNG", "image/png"];
    if (s.startsWith("\xff\xd8\xff")) return ["JPEG", "image/jpeg"];
    if (s.startsWith("%PDF")) return ["PDF", "application/pdf"];
    if (s.startsWith("PK\x03\x04")) return ["ZIP", "application/zip"];
    if (s.startsWith("GIF8")) return ["GIF", "image/gif"];
    return ["TXT", "text/plain"];
  };
  return { crc32, le16, le32, be32, rng, noise, zip, unzip, png, sigs, kind };
})();

/** Lệnh exiftool dùng chung: đọc node.exif (object) của file */
function foExiftoolCmd(args, stdin, ctx) {
  const files = args.filter((a) => !a.startsWith("-"));
  if (!files.length) throw "Syntax: exiftool [OPTIONS] FILE";
  return files.map((p) => {
    const n = ctx.readNode(p);
    const [t, mime] = FO.kind(n.c);
    const size = n.bin ? n.c.length : utf8.encode(n.c).length;
    const rows = [["ExifTool Version Number", "12.76"], ["File Name", p.split("/").pop()], ["File Size", size < 1024 ? size + " bytes" : (size / 1024).toFixed(1) + " kB"], ["File Type", t], ["MIME Type", mime], ...Object.entries(n.exif || {})];
    return (files.length > 1 ? `======== ${p}\n` : "") + rows.map(([k, v]) => k.padEnd(32) + ": " + v).join("\n");
  }).join("\n");
}

/* ---------------- Shell bài 1: phân tích file ---------------- */
SHELL_FS["fo-files"] = {
  host: "lab",
  motd: 'Thư mục <span class="hl">evidence/</span> chứa file thu được. Lệnh thêm: <span class="hl">binwalk [-e]</span>, <span class="hl">dd</span>, <span class="hl">unzip</span>, <span class="hl">exiftool</span>, <span class="hl">strings -e l</span>.',
  fs: () => {
    const f = (c2, m) => SH.file(c2, { owner: "guest", ...m });
    // firmware: chuỗi ASCII + chuỗi UTF-16LE chứa flag
    const u16 = (s) => [...s].map((ch) => ch + "\x00").join("");
    const fw = "\x7fELF\x02\x01\x01\x00" + FO.noise(300, 3) + "U-Boot 2019.07 (Mar 02 2024)\x00" + FO.noise(220, 4) + "Linux version 4.14.180\x00" + FO.noise(180, 5) +
      "root:$1$Xb2$k9Q.ZrFp:0:0:root:/root:/bin/sh\x00" + FO.noise(260, 6) + "admin_password=changeme\x00" + FO.noise(140, 8) +
      u16("BackupKey=" + d64(FO_SECRETS.file2)) + "\x00\x00" + FO.noise(300, 9) + "GCC: (crosstool-NG) 8.3.0\x00" + FO.noise(120, 10);
    // jpeg + zip nối đuôi
    const jpg = "\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00" + "\xff\xfe\x00\x1aCreated with GIMP 2.10\x00\x00" + FO.noise(5100, 11);
    const z = FO.zip([["flag.txt", d64(FO_SECRETS.file4) + "\n"], ["note.txt", "Giấu file trong ảnh là trò cũ nhất trong sách.\n"]]);
    const vac = jpg.slice(0, 5118) + "\xff\xd9" + z;
    const pdfLike = "%PDF-1.7\n%\xe2\xe3\xcf\xd3\n1 0 obj\n<</Type/Catalog/Pages 2 0 R>>\nendobj\n" + FO.noise(400, 12) + "\n%%EOF\n";
    return SH.base({
      evidence: SH.dir({
        "meme.png": f(pdfLike, { bin: true, exif: { "PDF Version": "1.7", Linearized: "No", Author: "an.nguyen", Creator: "Microsoft Word 2019" } }),
        "firmware.bin": f(fw, { bin: true }),
        "vacation.jpg": f(vac, { bin: true, exif: { "JFIF Version": "1.01", Comment: "Created with GIMP 2.10", "Image Width": 1920, "Image Height": 1080, Warning: "[minor] Trailer data after JPEG EOI marker" } }),
        "README.txt": f("evidence/ gồm 3 file thu từ máy nghi phạm.\nĐừng tin đuôi file. Hãy tin magic bytes.\n"),
      }, { owner: "guest" }),
    });
  },
  cmds: {
    strings: (a, stdin, ctx) => {
      let n = 4, encL = false;
      const files = [];
      for (let i = 0; i < a.length; i++) {
        if (a[i] === "-n") n = parseInt(a[++i]) || 4;
        else if (a[i] === "-e") encL = a[++i] === "l";
        else if (a[i] === "-el") encL = true;
        else files.push(a[i]);
      }
      const b = files.length ? ctx.readBytes(files[0]) : ctx.stdinBytes || utf8.encode(stdin || "");
      const res = [];
      let cur = "";
      const step = encL ? 2 : 1;
      for (let off = 0; off < step; off++) {
        cur = "";
        for (let i = off; i < b.length; i += step) {
          const x = b[i], ok = x >= 32 && x < 127 && (!encL || b[i + 1] === 0);
          if (ok) cur += String.fromCharCode(x);
          else { if (cur.length >= n) res.push(cur); cur = ""; }
        }
        if (cur.length >= n) res.push(cur);
        if (!encL) break;
      }
      return res.join("\n");
    },
    exiftool: foExiftoolCmd,
    binwalk: (a, stdin, ctx) => {
      const ex = a.includes("-e") || a.includes("--extract");
      const p = a.find((x) => !x.startsWith("-"));
      if (!p) throw "Usage: binwalk [-e] <file>";
      const n = ctx.readNode(p);
      const s = n.c;
      const sg = FO.sigs(s);
      let out = "\nDECIMAL       HEXADECIMAL     DESCRIPTION\n" + "-".repeat(80) + "\n" + sg.map(([i, d]) => String(i).padEnd(14) + ("0x" + i.toString(16).toUpperCase()).padEnd(16) + d).join("\n") + "\n";
      if (ex) {
        const entries = FO.unzip(s);
        if (entries.length) {
          const base = p.split("/").pop();
          const parent = ctx.node(ctx.resolve(p).slice(0, -1));
          const dir = SH.dir({}, { owner: ctx.user });
          const zs = s.indexOf("PK\x03\x04");
          dir.c[zs.toString(16).toUpperCase() + ".zip"] = SH.file(s.slice(zs), { owner: ctx.user, bin: true });
          for (const e of entries) dir.c[e.name] = SH.file(e.data, { owner: ctx.user });
          parent.c["_" + base + ".extracted"] = dir;
          out += `\nĐã giải nén vào _${base}.extracted/`;
        }
      }
      return out;
    },
    dd: (a, stdin, ctx) => {
      const o = Object.fromEntries(a.map((x) => x.split("=")));
      if (!o.if || !o.of) throw "dd: cần if=<vào> of=<ra> [bs=1] [skip=N] [count=N]";
      const s = ctx.readNode(o.if).c;
      const bs = parseInt(o.bs || "512"), skip = parseInt(o.skip || "0") * bs, cnt = o.count ? parseInt(o.count) * bs : s.length;
      const part = s.substr(skip, cnt);
      ctx.writeFile(o.of, part, { bin: true });
      return `${Math.ceil(part.length / bs)}+0 records in\n${Math.ceil(part.length / bs)}+0 records out\n${part.length} bytes copied, 0.0012 s`;
    },
    unzip: (a, stdin, ctx) => {
      const p = a.find((x) => !x.startsWith("-"));
      if (!p) throw "Usage: unzip <file.zip>";
      const s = ctx.readNode(p).c;
      const es = FO.unzip(s);
      if (!es.length) throw `End-of-central-directory signature not found. ${p} không phải file zip.`;
      const warn = es[0].offset > 0 ? `warning [${p}]:  ${es[0].offset} extra bytes at beginning or within zipfile\n  (attempting to process anyway)\n` : "";
      es.forEach((e) => ctx.writeFile(e.name, e.data));
      return `Archive:  ${p}\n${warn}` + es.map((e) => ` extracting: ${e.name}`).join("\n");
    },
  },
};

/* ---------------- Hex editor: sửa header PNG ---------------- */
WIDGETS["png-fix"] = (el) => {
  addStyle("fo-hex", `
  .hexed{margin:14px 0;border:1px solid var(--border-2);border-radius:12px;overflow:hidden;background:#080b10}
  .hexed .hx-grid{padding:12px 14px;font-family:var(--mono);font-size:13px;overflow-x:auto}
  .hexed .hx-row{display:flex;gap:10px;align-items:center;white-space:nowrap}
  .hexed .hx-off{color:var(--dim);width:72px;flex:none}
  .hexed .hx-b{width:2.1em;padding:2px 0;text-align:center;background:none;border:1px solid transparent;border-radius:4px;color:#d1dae4;font-family:var(--mono);font-size:13px;outline:none}
  .hexed .hx-b:focus{border-color:var(--accent);background:rgba(61,255,162,.08)}
  .hexed .hx-b.ch{color:var(--amber)}
  .hexed .hx-asc{color:var(--muted);margin-left:8px;letter-spacing:.5px}
  .hexed .hx-bar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;padding:10px 14px;border-top:1px solid var(--border)}
  .hexed .hx-st{font-family:var(--mono);font-size:12.5px}
  .hexed .hx-view{padding:14px;border-top:1px solid var(--border);min-height:40px}
  .hexed .hx-view img{max-width:100%;border-radius:8px;display:block}
  `);
  const root = h(`<div class="hexed"><div class="window-bar"><i></i><i></i><i></i><span>hexedit broken.png — 64 byte đầu (có thể sửa)</span></div>
    <div class="hx-grid"></div>
    <div class="hx-bar"><button class="btn primary sm" data-a="render">Mở ảnh</button><button class="btn sm" data-a="reset">Khôi phục bản hỏng</button><span class="hx-st"></span></div>
    <div class="hx-view"><span style="color:var(--dim);font-size:14px">Ảnh sẽ hiện ở đây nếu file hợp lệ.</span></div></div>`);
  el.replaceWith(root);
  const grid = root.querySelector(".hx-grid"), st = root.querySelector(".hx-st"), view = root.querySelector(".hx-view");
  let good = null, bytes = null;
  const cv = document.createElement("canvas");
  cv.width = 560; cv.height = 150;
  const g = cv.getContext("2d");
  const grd = g.createLinearGradient(0, 0, 560, 150); grd.addColorStop(0, "#10202a"); grd.addColorStop(1, "#1c1030");
  g.fillStyle = grd; g.fillRect(0, 0, 560, 150);
  g.fillStyle = "#3dffa2"; g.font = "bold 28px 'JetBrains Mono', monospace"; g.textAlign = "center";
  g.fillText(d64(FO_SECRETS.file3), 280, 88);
  g.fillStyle = "#8b98a9"; g.font = "14px sans-serif"; g.fillText("Header đã được sửa đúng!", 280, 122);
  cv.toBlob(async (blob) => {
    good = new Uint8Array(await blob.arrayBuffer());
    reset();
  }, "image/png");
  function corrupt(b) {
    const x = new Uint8Array(b);
    x.set([0x2e, 0x2e, 0x2e, 0x2e], 0);         // ".PNG" → "...."
    x.set([0x69, 0x68, 0x64, 0x72], 12);       // "IHDR" → "ihdr"
    return x;
  }
  function reset() { bytes = corrupt(good); draw(); view.innerHTML = '<span style="color:var(--dim);font-size:14px">Ảnh sẽ hiện ở đây nếu file hợp lệ.</span>'; check(); }
  function check() {
    const ok = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a].every((v, i) => bytes[i] === v);
    st.innerHTML = ok ? '<span style="color:var(--accent)">file: PNG image data</span>' : '<span style="color:var(--red)">file: data (không nhận ra định dạng)</span>';
  }
  function draw() {
    grid.innerHTML = "";
    for (let o = 0; o < 64; o += 16) {
      const row = document.createElement("div"); row.className = "hx-row";
      row.innerHTML = `<span class="hx-off">${o.toString(16).padStart(8, "0")}</span>`;
      for (let i = o; i < o + 16; i++) {
        const inp = document.createElement("input");
        inp.className = "hx-b"; inp.maxLength = 2; inp.spellcheck = false;
        inp.value = bytes[i].toString(16).padStart(2, "0");
        inp.dataset.i = i;
        inp.addEventListener("input", () => {
          if (/^[0-9a-fA-F]{2}$/.test(inp.value)) {
            bytes[i] = parseInt(inp.value, 16);
            inp.classList.toggle("ch", bytes[i] !== corrupt(good)[i]);
            asc.textContent = asciiOf(o); check();
            const nx = row.querySelectorAll(".hx-b")[i - o + 1] || grid.querySelectorAll(".hx-row")[o / 16 + 1]?.querySelector(".hx-b");
            nx && nx.focus() && nx.select();
          }
        });
        inp.addEventListener("focus", () => inp.select());
        row.appendChild(inp);
      }
      const asc = document.createElement("span"); asc.className = "hx-asc"; asc.textContent = asciiOf(o);
      row.appendChild(asc);
      grid.appendChild(row);
    }
  }
  const asciiOf = (o) => [...bytes.slice(o, o + 16)].map((x) => (x >= 32 && x < 127 ? String.fromCharCode(x) : ".")).join("");
  root.querySelector('[data-a="reset"]').onclick = reset;
  root.querySelector('[data-a="render"]').onclick = () => {
    const url = URL.createObjectURL(new Blob([bytes], { type: "image/png" }));
    const img = new Image();
    img.onload = () => { view.innerHTML = ""; view.appendChild(img); };
    img.onerror = () => { view.innerHTML = '<span style="color:var(--red);font-family:var(--mono);font-size:13px">Lỗi: trình xem ảnh không đọc được file (header hoặc chunk hỏng).</span>'; URL.revokeObjectURL(url); };
    img.src = url;
  };
};

/* ---------------- Ảnh chữ trùng màu nền (fo2) ---------------- */
function mountStego(el) {
  const root = h(`
    <div class="stego-wrap">
      <canvas width="560" height="220"></canvas>
      <div class="range-row">
        <label>Khuếch đại độ sáng <input type="range" min="1" max="40" value="1" step="1" data-k="g"></label>
        <span class="gv">1x</span>
        <label><input type="checkbox" data-k="i"> Đảo màu</label>
      </div>
    </div>`);
  el.replaceWith(root);
  const cv = root.querySelector("canvas");
  const ctx = cv.getContext("2d");
  ctx.fillStyle = "rgb(5,5,5)";
  ctx.fillRect(0, 0, cv.width, cv.height);
  let s = 7;
  for (let i = 0; i < 5000; i++) {
    s = (s * 16807) % 2147483647; const x = s % cv.width;
    s = (s * 16807) % 2147483647; const y = s % cv.height;
    const v = 4 + (s % 4);
    ctx.fillStyle = `rgb(${v},${v},${v})`;
    ctx.fillRect(x, y, 2, 2);
  }
  ctx.fillStyle = "rgb(12,12,12)";
  ctx.font = "bold 30px 'JetBrains Mono', monospace";
  ctx.textAlign = "center";
  ctx.fillText(d64(FO_SECRETS.fo2), cv.width / 2, cv.height / 2 + 10);
  const orig = ctx.getImageData(0, 0, cv.width, cv.height);
  const upd = () => {
    const g = +root.querySelector('[data-k="g"]').value;
    const inv = root.querySelector('[data-k="i"]').checked;
    root.querySelector(".gv").textContent = g + "x";
    const out = new ImageData(new Uint8ClampedArray(orig.data), orig.width, orig.height);
    const d = out.data;
    for (let i = 0; i < d.length; i += 4) for (let k = 0; k < 3; k++) { const v = Math.min(255, d[i + k] * g); d[i + k] = inv ? 255 - v : v; }
    ctx.putImageData(out, 0, 0);
  };
  root.querySelectorAll("input").forEach((i) => i.addEventListener("input", upd));
}
WIDGETS.stego = mountStego;

/* ---------------- LSB / bit plane (kiểu StegSolve + zsteg) ---------------- */
WIDGETS.lsb = (el) => {
  addStyle("fo-lsb", `
  .lsb{margin:14px 0;border:1px solid var(--border-2);border-radius:12px;overflow:hidden;background:#080b10}
  .lsb .lsb-main{display:grid;grid-template-columns:minmax(0,1fr) 260px;gap:0}
  .lsb canvas{width:100%;display:block;image-rendering:pixelated;background:#000}
  .lsb .lsb-side{padding:14px;border-left:1px solid var(--border);display:flex;flex-direction:column;gap:12px;font-size:13.5px}
  .lsb .lsb-side label{font-family:var(--mono);font-size:12px;color:var(--dim)}
  .lsb .seg{display:flex;gap:4px;flex-wrap:wrap}
  .lsb .seg button{padding:5px 10px;border-radius:7px;border:1px solid var(--border-2);background:var(--bg-2);color:var(--muted);font-family:var(--mono);font-size:12px;cursor:pointer}
  .lsb .seg button.on{background:var(--accent);color:#03140b;border-color:var(--accent)}
  .lsb .lsb-ex{border-top:1px solid var(--border);padding:12px 14px;display:flex;flex-direction:column;gap:10px}
  .lsb .lsb-ex .row{display:flex;gap:14px;align-items:center;flex-wrap:wrap;font-family:var(--mono);font-size:12.5px;color:var(--muted)}
  .lsb pre{margin:0;padding:10px 12px;border-radius:8px;background:#05070a;border:1px solid var(--border);font-family:var(--mono);font-size:12.5px;color:#d1dae4;white-space:pre-wrap;word-break:break-all;max-height:180px;overflow:auto}
  @media(max-width:760px){.lsb .lsb-main{grid-template-columns:1fr}.lsb .lsb-side{border-left:none;border-top:1px solid var(--border)}}
  `);
  const W = 320, H = 200;
  const root = h(`<div class="lsb"><div class="window-bar"><i></i><i></i><i></i><span>stegsolve — sunset.png (${W}×${H})</span></div>
    <div class="lsb-main"><canvas width="${W}" height="${H}"></canvas>
      <div class="lsb-side">
        <div><label>CHẾ ĐỘ XEM</label><div class="seg" data-g="mode"><button data-v="orig" class="on">Ảnh gốc</button><button data-v="plane">Bit plane</button></div></div>
        <div><label>KÊNH MÀU</label><div class="seg" data-g="ch"><button data-v="0" class="on">Red</button><button data-v="1">Green</button><button data-v="2">Blue</button></div></div>
        <div><label>BIT (0 = LSB, 7 = MSB): <span class="bv">0</span></label><input type="range" min="0" max="7" value="0" data-k="bit" style="width:100%"></div>
        <div style="color:var(--dim);font-size:12.5px">Bit plane: điểm trắng = bit đó bằng 1. Bit cao giống ảnh gốc, bit thấp thường là nhiễu, trừ khi có ai giấu gì đó.</div>
      </div></div>
    <div class="lsb-ex">
      <div class="row"><b style="color:var(--text)">Trích xuất dữ liệu</b>
        <label><input type="checkbox" data-x="0" checked> R</label><label><input type="checkbox" data-x="1" checked> G</label><label><input type="checkbox" data-x="2" checked> B</label>
        <label>bit <select data-k="xbit">${[0, 1, 2, 3, 4, 5, 6, 7].map((i) => `<option>${i}</option>`).join("")}</select></label>
        <button class="btn sm primary" data-a="ex">Trích xuất</button><span class="xcfg"></span></div>
      <pre class="xout">Chọn kênh và bit rồi bấm Trích xuất. Thứ tự: từng điểm ảnh từ trái sang phải, trên xuống dưới; trong mỗi điểm ảnh lấy R rồi G rồi B; 8 bit ghép thành 1 byte (bit đầu là bit cao).</pre>
    </div></div>`);
  el.replaceWith(root);
  const cv = root.querySelector("canvas"), g = cv.getContext("2d");
  // vẽ ảnh nền
  const sky = g.createLinearGradient(0, 0, 0, H); sky.addColorStop(0, "#2b1055"); sky.addColorStop(0.55, "#d75a4a"); sky.addColorStop(1, "#f5b971");
  g.fillStyle = sky; g.fillRect(0, 0, W, H);
  g.fillStyle = "#ffd98a"; g.beginPath(); g.arc(220, 120, 34, 0, 7); g.fill();
  g.fillStyle = "#3a2147"; g.beginPath(); g.moveTo(0, 160); g.lineTo(70, 105); g.lineTo(130, 150); g.lineTo(200, 95); g.lineTo(270, 145); g.lineTo(320, 120); g.lineTo(320, 200); g.lineTo(0, 200); g.fill();
  g.fillStyle = "#1d1028"; g.beginPath(); g.moveTo(0, 185); g.lineTo(90, 150); g.lineTo(170, 182); g.lineTo(250, 160); g.lineTo(320, 178); g.lineTo(320, 200); g.lineTo(0, 200); g.fill();
  const img = g.getImageData(0, 0, W, H);
  const d = img.data;
  // 1) chữ ở bit 1 của kênh Green
  const m = document.createElement("canvas"); m.width = W; m.height = H;
  const mg = m.getContext("2d"); mg.fillStyle = "#000"; mg.fillRect(0, 0, W, H);
  mg.fillStyle = "#fff"; mg.font = "bold 19px 'JetBrains Mono', monospace"; mg.textAlign = "center"; mg.fillText(d64(FO_SECRETS.stego2), W / 2, 70);
  const md = mg.getImageData(0, 0, W, H).data;
  for (let i = 0; i < d.length; i += 4) d[i + 1] = (d[i + 1] & ~2) | (md[i] > 127 ? 2 : 0);
  // 2) thông điệp LSB, b1,rgb,msb-first, kết thúc bằng byte 0
  const msg = [...utf8.encode("Hello analyst! " + d64(FO_SECRETS.stego3)), 0];
  const bits = msg.flatMap((b) => [7, 6, 5, 4, 3, 2, 1, 0].map((k) => (b >> k) & 1));
  for (let j = 0; j < bits.length; j++) { const px = Math.floor(j / 3), c2 = j % 3; d[px * 4 + c2] = (d[px * 4 + c2] & ~1) | bits[j]; }
  const orig = new Uint8ClampedArray(d);
  const st = { mode: "orig", ch: 0, bit: 0 };
  function render() {
    if (st.mode === "orig") { g.putImageData(new ImageData(new Uint8ClampedArray(orig), W, H), 0, 0); return; }
    const out = new ImageData(W, H), o = out.data;
    for (let i = 0; i < o.length; i += 4) { const v = (orig[i + st.ch] >> st.bit) & 1 ? 255 : 0; o[i] = o[i + 1] = o[i + 2] = v; o[i + 3] = 255; }
    g.putImageData(out, 0, 0);
  }
  root.querySelectorAll(".seg").forEach((sg) => sg.addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    sg.querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
    st[sg.dataset.g] = sg.dataset.g === "ch" ? +b.dataset.v : b.dataset.v;
    if (sg.dataset.g === "ch") { st.mode = "plane"; root.querySelectorAll('[data-g="mode"] button').forEach((x) => x.classList.toggle("on", x.dataset.v === "plane")); }
    render();
  }));
  root.querySelector('[data-k="bit"]').addEventListener("input", (e) => {
    st.bit = +e.target.value; root.querySelector(".bv").textContent = st.bit;
    st.mode = "plane"; root.querySelectorAll('[data-g="mode"] button').forEach((x) => x.classList.toggle("on", x.dataset.v === "plane"));
    render();
  });
  root.querySelector('[data-a="ex"]').onclick = () => {
    const chs = [0, 1, 2].filter((k) => root.querySelector(`[data-x="${k}"]`).checked);
    const bit = +root.querySelector('[data-k="xbit"]').value;
    const out = [];
    let cur = 0, n = 0;
    for (let px = 0; px < W * H && out.length < 400; px++) for (const k of chs) { cur = (cur << 1) | ((orig[px * 4 + k] >> bit) & 1); if (++n === 8) { out.push(cur); cur = 0; n = 0; } }
    root.querySelector(".xcfg").textContent = `b${bit + 1},${chs.map((k) => "rgb"[k]).join("")},msb,xy`;
    const txt = out.map((x) => (x >= 32 && x < 127 ? String.fromCharCode(x) : ".")).join("");
    const hex = out.slice(0, 48).map((x) => x.toString(16).padStart(2, "0")).join(" ");
    root.querySelector(".xout").textContent = `ASCII: ${txt}\n\nHEX (48 byte đầu): ${hex}`;
  };
  render();
};

/* ---------------- Shell bài 2: dữ liệu sau IEND, steghide ---------------- */
SHELL_FS["fo-stego"] = {
  host: "lab",
  motd: 'Lệnh thêm: <span class="hl">exiftool</span>, <span class="hl">binwalk</span>, <span class="hl">steghide extract -sf &lt;file&gt; -p &lt;mật khẩu&gt;</span>.',
  fs: () => {
    const f = (c2, m) => SH.file(c2, { owner: "guest", ...m });
    const idat = FO.noise(900, 21);
    const cat = FO.png([["IHDR", FO.be32(400) + FO.be32(300) + "\x08\x02\x00\x00\x00"], ["IDAT", idat], ["IEND", ""]]) + "\n--appended--\n" + btoa(d64(FO_SECRETS.stego4)) + "\n";
    const beach = "\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00" + FO.noise(2400, 22) + "\xff\xd9";
    return SH.base({
      "cat.png": f(cat, { bin: true, exif: { "Image Width": 400, "Image Height": 300, "Bit Depth": 8, "Color Type": "RGB", Warning: "[minor] Trailer data after PNG IEND chunk" } }),
      "beach.jpg": f(beach, { bin: true, exif: { "JFIF Version": "1.01", Comment: "mat khau la: songbien2024", "Image Width": 1280, "Image Height": 720 } }),
    });
  },
  cmds: {
    exiftool: foExiftoolCmd,
    binwalk: (a, stdin, ctx) => SHELL_FS["fo-files"].cmds.binwalk(a.filter((x) => x !== "-e"), stdin, ctx),
    steghide: (a, stdin, ctx) => {
      if (a[0] !== "extract" && a[0] !== "info") throw "steghide: dùng 'steghide extract -sf <file> -p <mật khẩu>' hoặc 'steghide info <file>'";
      const sf = a[a.indexOf("-sf") + 1] || a[1];
      const n = ctx.readNode(sf);
      if (!/beach\.jpg$/.test(sf)) return `steghide: could not extract any data with that passphrase!`;
      if (a[0] === "info") return `"${sf}":\n  format: jpeg\n  capacity: 1.2 KB\nTry to get information about embedded data ? (y/n) — cần mật khẩu.`;
      const pi = a.indexOf("-p");
      if (pi < 0) throw "Enter passphrase: (dùng -p <mật khẩu>)";
      if (a[pi + 1] !== "songbien2024") return "steghide: could not extract any data with that passphrase!";
      ctx.writeFile("note.txt", "Steghide giấu dữ liệu trong hệ số DCT của JPEG, cần mật khẩu.\nMật khẩu thường nằm đâu đó gần ảnh: metadata, tên file, đề bài.\n");
      void n;
      return 'wrote extracted data to "note.txt".';
    },
  },
};

/* ---------------- Wireshark mô phỏng ---------------- */
function foCapture() {
  const P = [];
  let t = 0;
  const C = "192.168.1.23", DNS = "192.168.1.1", WEB = "203.0.113.80", FTP = "198.51.100.21", PC2 = "192.168.1.31";
  let stream = 0;
  const add = (o) => { t += o.dt ?? 0.012 + ((P.length * 37) % 11) / 1000; P.push({ no: P.length + 1, t, ...o }); };
  const dns = (src, q, ans, type = "A") => {
    const id = (0x1a2b + P.length * 97) & 0xffff;
    add({ src, dst: DNS, proto: "DNS", sport: 50000 + (P.length % 900), dport: 53, info: `Standard query 0x${id.toString(16)} ${type} ${q}`, dns: { qry: q }, payload: "" });
    add({ src: DNS, dst: src, proto: "DNS", sport: 53, dport: P[P.length - 1].sport, info: `Standard query response 0x${id.toString(16)} ${type} ${q} ${type} ${ans}`, dns: { qry: q, ans }, payload: "", dt: 0.004 });
  };
  const tcp = (cli, srv, sport, dport, proto, exchange) => {
    const s = stream++;
    let seqC = 0, seqS = 0;
    const seg = (fromC, flags, data = "", app = {}) => {
      const [src, dst, sp, dp] = fromC ? [cli, srv, sport, dport] : [srv, cli, dport, sport];
      const len = data.length;
      const info = app.info || `${sp} → ${dp} [${flags}] Seq=${fromC ? seqC : seqS} ${flags.includes("ACK") ? "Ack=" + (fromC ? seqS : seqC) + " " : ""}Win=64240 Len=${len}`;
      add({ src, dst, proto: len && proto ? proto : "TCP", sport: sp, dport: dp, info, stream: s, flags, payload: data, dir: fromC ? "c" : "s", ...app.extra });
      if (fromC) seqC += len || (flags.includes("SYN") || flags.includes("FIN") ? 1 : 0); else seqS += len || (flags.includes("SYN") || flags.includes("FIN") ? 1 : 0);
    };
    seg(true, "SYN"); seg(false, "SYN, ACK"); seg(true, "ACK");
    for (const [fromC, data, app] of exchange) { seg(fromC, "PSH, ACK", data, app || {}); seg(!fromC, "ACK"); }
    seg(true, "FIN, ACK"); seg(false, "FIN, ACK"); seg(true, "ACK");
  };
  // duyệt web bình thường
  dns(C, "news.example", "203.0.113.10");
  tcp(C, "203.0.113.10", 51200, 80, "HTTP", [
    [true, "GET / HTTP/1.1\r\nHost: news.example\r\nUser-Agent: Mozilla/5.0\r\nAccept: */*\r\n\r\n", { info: "GET / HTTP/1.1", extra: { http: { method: "GET", host: "news.example", uri: "/" } } }],
    [false, "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 58\r\n\r\n<html><body><h1>Tin nóng hôm nay</h1>...</body></html>", { info: "HTTP/1.1 200 OK  (text/html)", extra: { http: { status: 200 } } }],
  ]);
  dns(PC2, "update.os.example", "198.51.100.5");
  // đăng nhập HTTP không mã hoá
  dns(C, "intranet.corp.example", WEB);
  const pw = d64(FO_SECRETS.net1);
  const body = `username=an.nguyen&password=${encodeURIComponent(pw)}`;
  tcp(C, WEB, 51288, 80, "HTTP", [
    [true, "GET /login HTTP/1.1\r\nHost: intranet.corp.example\r\nUser-Agent: Mozilla/5.0\r\n\r\n", { info: "GET /login HTTP/1.1", extra: { http: { method: "GET", host: "intranet.corp.example", uri: "/login" } } }],
    [false, "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n<form method=post>...</form>", { info: "HTTP/1.1 200 OK  (text/html)", extra: { http: { status: 200 } } }],
    [true, `POST /login HTTP/1.1\r\nHost: intranet.corp.example\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: ${body.length}\r\n\r\n${body}`, { info: "POST /login HTTP/1.1  (application/x-www-form-urlencoded)", extra: { http: { method: "POST", host: "intranet.corp.example", uri: "/login" } } }],
    [false, "HTTP/1.1 302 Found\r\nLocation: /dashboard\r\nSet-Cookie: sid=9f1c2e7a\r\n\r\n", { info: "HTTP/1.1 302 Found", extra: { http: { status: 302 } } }],
  ]);
  dns(PC2, "mail.corp.example", "203.0.113.25", "MX");
  // FTP: điều khiển + dữ liệu
  tcp(C, FTP, 51302, 21, "FTP", [
    [false, "220 (vsFTPd 3.0.5)\r\n", { info: "Response: 220 (vsFTPd 3.0.5)" }],
    [true, "USER backup\r\n", { info: "Request: USER backup", extra: { ftp: { cmd: "USER" } } }],
    [false, "331 Please specify the password.\r\n", { info: "Response: 331 Please specify the password." }],
    [true, "PASS Backup@2024\r\n", { info: "Request: PASS Backup@2024", extra: { ftp: { cmd: "PASS" } } }],
    [false, "230 Login successful.\r\n", { info: "Response: 230 Login successful." }],
    [true, "PASV\r\n", { info: "Request: PASV", extra: { ftp: { cmd: "PASV" } } }],
    [false, "227 Entering Passive Mode (198,51,100,21,195,81).\r\n", { info: "Response: 227 Entering Passive Mode (198,51,100,21,195,81)." }],
    [true, "RETR secret_plan.txt\r\n", { info: "Request: RETR secret_plan.txt", extra: { ftp: { cmd: "RETR" } } }],
    [false, "150 Opening BINARY mode data connection for secret_plan.txt (61 bytes).\r\n226 Transfer complete.\r\n", { info: "Response: 150 Opening BINARY mode data connection" }],
    [true, "QUIT\r\n", { info: "Request: QUIT", extra: { ftp: { cmd: "QUIT" } } }],
  ]);
  tcp(C, FTP, 51304, 50001, "FTP-DATA", [
    [false, `KE HOACH Q4\n- Doi mat khau may chu\n- Ma xac nhan: ${d64(FO_SECRETS.net2)}\n`, { info: "FTP Data: 61 bytes (PASV) (RETR secret_plan.txt)" }],
  ]);
  // DNS exfiltration từ máy bị nhiễm
  const hex = hexOf(utf8.encode(d64(FO_SECRETS.net3)));
  const chunks = hex.match(/.{1,10}/g);
  const noiseQ = ["cdn.jsdelivr.example", "time.os.example", "ads.tracker.example", "api.weather.example"];
  chunks.forEach((ck, i) => {
    dns(C, `${i}-${ck}.x.cdn-update.example`, '"ack"', "TXT");
    if (i % 2 === 0) dns(PC2, noiseQ[i % noiseQ.length], "198.51.100." + (40 + i));
  });
  dns(C, `done.x.cdn-update.example`, '"ack"', "TXT");
  P.forEach((p) => (p.len = 54 + p.payload.length + (p.proto === "DNS" ? 30 + (p.dns.qry.length) : 0)));
  return P;
}

function foFilter(expr) {
  const src = expr.trim();
  if (!src) return () => true;
  const toks = [];
  const re = /\s*(\(|\)|&&|\|\||!=|==|>=|<=|>|<|!|"[^"]*"|[A-Za-z_][\w.-]*|\d+(?:\.\d+){0,3})/y;
  let m, i = 0;
  while (i < src.length) {
    re.lastIndex = i; m = re.exec(src);
    if (!m) throw "Ký tự không hợp lệ ở vị trí " + i;
    toks.push(m[1]); i = re.lastIndex;
    while (src[i] === " ") i++;
  }
  let p = 0;
  const peek = () => toks[p], next = () => toks[p++];
  const PROTOS = ["tcp", "udp", "http", "dns", "ftp", "ftp-data", "ip", "frame"];
  const field = (pk, f) => {
    const tcpish = pk.proto !== "DNS";
    switch (f) {
      case "ip.src": return [pk.src]; case "ip.dst": return [pk.dst]; case "ip.addr": return [pk.src, pk.dst];
      case "tcp.port": return tcpish ? [pk.sport, pk.dport] : []; case "tcp.srcport": return tcpish ? [pk.sport] : []; case "tcp.dstport": return tcpish ? [pk.dport] : [];
      case "udp.port": return tcpish ? [] : [pk.sport, pk.dport]; case "tcp.stream": return tcpish ? [pk.stream] : [];
      case "tcp.len": return tcpish ? [pk.payload.length] : []; case "frame.len": return [pk.len]; case "frame.number": return [pk.no];
      case "http.request.method": return pk.http && pk.http.method ? [pk.http.method] : []; case "http.host": return pk.http && pk.http.host ? [pk.http.host] : [];
      case "http.request.uri": return pk.http && pk.http.uri ? [pk.http.uri] : []; case "http.response.code": return pk.http && pk.http.status ? [pk.http.status] : [];
      case "dns.qry.name": return pk.dns ? [pk.dns.qry] : []; case "ftp.request.command": return pk.ftp ? [pk.ftp.cmd] : [];
      case "frame": return [pk.info + "\n" + pk.payload + (pk.dns ? pk.dns.qry : "")];
      case "tcp": return tcpish ? [1] : []; case "udp": return tcpish ? [] : [1]; case "ip": return [1];
      case "http": return pk.proto === "HTTP" ? [1] : []; case "dns": return pk.proto === "DNS" ? [1] : [];
      case "ftp": return pk.proto === "FTP" ? [1] : []; case "ftp-data": return pk.proto === "FTP-DATA" ? [1] : [];
      case "tcp.flags.syn": return tcpish ? [pk.flags && pk.flags.includes("SYN") ? 1 : 0] : [];
      default: throw `"${f}" không phải trường được hỗ trợ`;
    }
  };
  const lit = (t) => (t[0] === '"' ? t.slice(1, -1) : /^\d+$/.test(t) ? Number(t) : t);
  function or() { let l = and(); while (peek() === "||" || peek() === "or") { next(); const r = and(); const L = l; l = (pk) => L(pk) || r(pk); } return l; }
  function and() { let l = not(); while (peek() === "&&" || peek() === "and") { next(); const r = not(); const L = l; l = (pk) => L(pk) && r(pk); } return l; }
  function not() { if (peek() === "!" || peek() === "not") { next(); const e = not(); return (pk) => !e(pk); } return cmp(); }
  function cmp() {
    if (peek() === "(") { next(); const e = or(); if (next() !== ")") throw "Thiếu dấu )"; return e; }
    const f = next();
    if (!f || !/^[A-Za-z]/.test(f)) throw "Cần tên trường hoặc giao thức";
    field({ proto: "TCP", payload: "", info: "", src: "", dst: "" }, f);
    const op = peek();
    if (["==", "!=", ">", "<", ">=", "<=", "contains", "matches", "eq"].includes(op)) {
      next();
      const v = next();
      if (v == null) throw "Thiếu giá trị sau " + op;
      const val = lit(v);
      return (pk) => {
        const vals = field(pk, f);
        if (op === "contains") return vals.some((x) => String(x).toLowerCase().includes(String(val).toLowerCase()));
        if (op === "matches") return vals.some((x) => new RegExp(String(val), "i").test(String(x)));
        if (op === "!=") return vals.length > 0 && vals.every((x) => x != val);
        return vals.some((x) => ({ "==": x == val, eq: x == val, ">": x > val, "<": x < val, ">=": x >= val, "<=": x <= val })[op]);
      };
    }
    if (!PROTOS.includes(f) && !f.includes(".")) throw `"${f}" không phải giao thức`;
    return (pk) => field(pk, f).length > 0 && field(pk, f)[0] !== 0;
  }
  const e = or();
  if (p < toks.length) throw `Không hiểu "${toks[p]}"`;
  return e;
}

WIDGETS.wireshark = (el) => {
  addStyle("fo-ws", `
  .ws{margin:16px 0;border:1px solid var(--border-2);border-radius:12px;overflow:hidden;background:#080b10;font-family:var(--mono);font-size:12.5px}
  .ws .ws-bar{display:flex;gap:8px;padding:8px 10px;border-bottom:1px solid var(--border);align-items:center;flex-wrap:wrap}
  .ws .ws-f{flex:1;min-width:220px;padding:7px 10px;border-radius:8px;border:1px solid var(--border-2);background:#05070a;color:var(--text);font-family:var(--mono);font-size:13px;outline:none}
  .ws .ws-f.ok{border-color:rgba(61,255,162,.6);background:rgba(61,255,162,.05)}
  .ws .ws-f.bad{border-color:rgba(255,92,122,.7);background:rgba(255,92,122,.06)}
  .ws .ws-list{max-height:280px;overflow:auto}
  .ws table{width:100%;border-collapse:collapse;margin:0;display:table}
  .ws th{position:sticky;top:0;background:var(--surface-2);color:var(--muted);text-align:left;padding:5px 8px;font-weight:500;font-size:12px;border-bottom:1px solid var(--border)}
  .ws td{padding:3px 8px;white-space:nowrap;border:none;color:#cfd8e2;max-width:520px;overflow:hidden;text-overflow:ellipsis}
  .ws tr.pk{cursor:pointer}
  .ws tr.pk.HTTP td{background:rgba(120,220,120,.07)} .ws tr.pk.DNS td{background:rgba(92,200,255,.07)} .ws tr.pk.FTP td,.ws tr.pk.FTP-DATA td{background:rgba(255,200,87,.07)}
  .ws tr.pk.sel td{background:rgba(165,139,255,.25)!important;color:#fff}
  .ws .ws-det{display:grid;grid-template-columns:1fr 1fr;border-top:1px solid var(--border)}
  .ws .ws-tree,.ws .ws-hex{padding:10px 12px;white-space:pre-wrap;word-break:break-all;max-height:240px;overflow:auto;color:#cfd8e2}
  .ws .ws-hex{border-left:1px solid var(--border);color:var(--muted)}
  .ws .ws-stat{padding:5px 10px;border-top:1px solid var(--border);color:var(--dim);font-size:11.5px}
  .ws .ws-follow{border-top:1px solid var(--border);padding:10px 12px;max-height:320px;overflow:auto;white-space:pre-wrap;word-break:break-all}
  .ws .ws-follow .c{color:#ff8c8c}.ws .ws-follow .s{color:#7cb8ff}
  @media(max-width:760px){.ws .ws-det{grid-template-columns:1fr}.ws .ws-hex{border-left:none;border-top:1px solid var(--border)}}
  `);
  const P = foCapture();
  const root = h(`<div class="ws"><div class="window-bar"><i></i><i></i><i></i><span>Wireshark — capture.pcapng (${P.length} gói)</span></div>
    <div class="ws-bar"><input class="ws-f" placeholder="Apply a display filter … (vd: http, dns, ip.addr == 198.51.100.21, frame contains &quot;pass&quot;)" spellcheck="false"><button class="btn sm" data-a="apply">Lọc</button><button class="btn sm" data-a="follow" disabled>Follow TCP Stream</button></div>
    <div class="ws-list"><table><thead><tr><th>No.</th><th>Time</th><th>Source</th><th>Destination</th><th>Protocol</th><th>Length</th><th>Info</th></tr></thead><tbody></tbody></table></div>
    <div class="ws-det"><div class="ws-tree">Chọn một gói tin để xem chi tiết.</div><div class="ws-hex"></div></div>
    <div class="ws-follow" hidden></div>
    <div class="ws-stat"></div></div>`);
  el.replaceWith(root);
  const tb = root.querySelector("tbody"), fi = root.querySelector(".ws-f"), stat = root.querySelector(".ws-stat");
  const tree = root.querySelector(".ws-tree"), hexv = root.querySelector(".ws-hex"), fol = root.querySelector(".ws-follow"), fbtn = root.querySelector('[data-a="follow"]');
  let sel = null;
  function show(filter) {
    let fn;
    try { fn = foFilter(filter); fi.classList.toggle("ok", !!filter.trim()); fi.classList.remove("bad"); }
    catch (e) { fi.classList.add("bad"); fi.classList.remove("ok"); stat.textContent = "Lỗi filter: " + e; return; }
    const rows = P.filter(fn);
    tb.innerHTML = rows.map((p) => `<tr class="pk ${p.proto}" data-n="${p.no}"><td>${p.no}</td><td>${p.t.toFixed(6)}</td><td>${p.src}</td><td>${p.dst}</td><td>${p.proto}</td><td>${p.len}</td><td>${esc(p.info)}</td></tr>`).join("");
    stat.textContent = `Packets: ${P.length} · Displayed: ${rows.length} (${((rows.length / P.length) * 100).toFixed(1)}%)`;
  }
  const hexdump = (s) => {
    const b = utf8.encode(s), L = [];
    for (let o = 0; o < b.length; o += 16) { const r = b.slice(o, o + 16); L.push(o.toString(16).padStart(4, "0") + "  " + [...r].map((x) => x.toString(16).padStart(2, "0")).join(" ").padEnd(48) + "  " + [...r].map((x) => (x >= 32 && x < 127 ? String.fromCharCode(x) : ".")).join("")); }
    return L.join("\n");
  };
  function detail(p) {
    const tcpish = p.proto !== "DNS";
    let t = `▸ Frame ${p.no}: ${p.len} bytes on wire (${p.len * 8} bits)\n▸ Ethernet II, Src: 08:00:27:3a:1c:${(p.no % 90 + 10).toString(16)}, Dst: 52:54:00:12:35:02\n▸ Internet Protocol Version 4, Src: ${p.src}, Dst: ${p.dst}\n`;
    t += tcpish ? `▸ Transmission Control Protocol, Src Port: ${p.sport}, Dst Port: ${p.dport}, Len: ${p.payload.length}\n    [Stream index: ${p.stream}]\n    Flags: [${p.flags}]\n` : `▸ User Datagram Protocol, Src Port: ${p.sport}, Dst Port: ${p.dport}\n`;
    if (p.proto === "DNS") t += `▾ Domain Name System (${p.dns.ans ? "response" : "query"})\n    Queries\n        ${p.dns.qry}: type ${p.info.includes(" TXT ") ? "TXT" : p.info.includes(" MX ") ? "MX" : "A"}, class IN\n${p.dns.ans ? "    Answers\n        " + p.dns.qry + ": " + p.dns.ans + "\n" : ""}`;
    else if (p.payload) t += `▾ ${p.proto === "HTTP" ? "Hypertext Transfer Protocol" : p.proto === "FTP" ? "File Transfer Protocol (FTP)" : p.proto === "FTP-DATA" ? "FTP Data" : "Data"}\n` + p.payload.split(/\r?\n/).map((l) => "    " + l).join("\n");
    tree.textContent = t;
    hexv.textContent = p.payload ? hexdump(p.payload) : p.proto === "DNS" ? hexdump(p.dns.qry) : "(không có payload)";
  }
  tb.addEventListener("click", (e) => {
    const tr = e.target.closest("tr.pk"); if (!tr) return;
    tb.querySelectorAll(".sel").forEach((x) => x.classList.remove("sel"));
    tr.classList.add("sel");
    sel = P[+tr.dataset.n - 1];
    detail(sel);
    fbtn.disabled = sel.stream == null;
  });
  fbtn.onclick = () => {
    if (!sel || sel.stream == null) return;
    const ps = P.filter((p) => p.stream === sel.stream && p.payload);
    fol.hidden = false;
    fol.innerHTML = `<div style="color:var(--dim);margin-bottom:6px">Follow TCP Stream (tcp.stream eq ${sel.stream}) — <span class="c">client</span> / <span class="s">server</span> · <a href="javascript:void 0" data-close>đóng</a></div>` + (ps.map((p) => `<span class="${p.dir}">${esc(p.payload)}</span>`).join("") || "(stream không có dữ liệu)");
    fol.querySelector("[data-close]").onclick = () => (fol.hidden = true);
    fi.value = "tcp.stream eq " + sel.stream; show(fi.value);
  };
  root.querySelector('[data-a="apply"]').onclick = () => show(fi.value);
  fi.addEventListener("keydown", (e) => { if (e.key === "Enter") show(fi.value); });
  fi.addEventListener("input", () => { try { foFilter(fi.value); fi.classList.remove("bad"); } catch { fi.classList.add("bad"); } });
  show("");
};

/* ---------------- Shell bài 4: Volatility, log, Sleuth Kit ---------------- */
SHELL_FS["fo-dfir"] = {
  host: "dfir",
  user: "analyst",
  motd: 'Máy phân tích sự cố. <span class="hl">ls case/</span> để xem chứng cứ. Lệnh thêm: <span class="hl">vol</span> (Volatility 3), <span class="hl">fls</span>/<span class="hl">icat</span> (Sleuth Kit), <span class="hl">iconv</span>.',
  fs: () => {
    const f = (c2, m) => SH.file(c2, { owner: "analyst", ...m });
    // auth.log: brute force rồi đăng nhập thành công
    const r = FO.rng(77);
    const L = [];
    const users = ["root", "admin", "test", "oracle", "ubuntu", "git", "postgres", "backup", "ftp", "guest"];
    let sec = 0;
    const ts = () => { sec += 1 + Math.floor(r() * 20); const hh = 2 + Math.floor(sec / 3600), mm = Math.floor((sec % 3600) / 60), ss = sec % 60; return `Nov  9 ${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`; };
    for (let i = 0; i < 260; i++) {
      const roll = r();
      if (roll < 0.18) L.push(`${ts()} web01 sshd[${2000 + i}]: Accepted publickey for deploy from 10.0.0.${5 + (i % 3)} port ${40000 + i} ssh2`);
      else if (roll < 0.3) L.push(`${ts()} web01 CRON[${3000 + i}]: pam_unix(cron:session): session opened for user root by (uid=0)`);
      else if (roll < 0.38) L.push(`${ts()} web01 sshd[${2000 + i}]: Failed password for an from 10.0.0.9 port ${41000 + i} ssh2`);
      else { const u = users[Math.floor(r() * users.length)]; L.push(`${ts()} web01 sshd[${2000 + i}]: Failed password for ${u === "backup" || u === "root" ? "" : "invalid user "}${u} from 203.0.113.77 port ${50000 + i} ssh2`); }
    }
    L.push(`${ts()} web01 sshd[2999]: Accepted password for backup from 203.0.113.77 port 51999 ssh2`);
    L.push(`${ts()} web01 sshd[2999]: pam_unix(sshd:session): session opened for user backup by (uid=0)`);
    for (let i = 0; i < 30; i++) L.push(`${ts()} web01 sshd[${4000 + i}]: Accepted publickey for deploy from 10.0.0.6 port ${42000 + i} ssh2`);
    const access = [
      '10.0.0.6 - - [09/Nov/2026:02:10:01 +0700] "GET / HTTP/1.1" 200 5120 "-" "Mozilla/5.0"',
      '198.51.100.9 - - [09/Nov/2026:02:11:15 +0700] "GET /products.php?id=1%27 HTTP/1.1" 500 312 "-" "sqlmap/1.7.2#stable"',
      '198.51.100.9 - - [09/Nov/2026:02:11:16 +0700] "GET /products.php?id=1%20UNION%20SELECT%201,2,3-- HTTP/1.1" 200 4410 "-" "sqlmap/1.7.2#stable"',
      '198.51.100.9 - - [09/Nov/2026:02:14:02 +0700] "POST /upload.php HTTP/1.1" 200 88 "-" "curl/8.5.0"',
      '198.51.100.9 - - [09/Nov/2026:02:14:30 +0700] "GET /uploads/shell.php?cmd=id HTTP/1.1" 200 54 "-" "curl/8.5.0"',
      '10.0.0.7 - - [09/Nov/2026:02:20:44 +0700] "GET /about HTTP/1.1" 200 2210 "-" "Mozilla/5.0"',
    ];
    return SH.base({
      case: SH.dir({
        "memdump.raw": f("\x00".repeat(64) + "PAGEDUMP" + FO.noise(500, 31), { bin: true }),
        "disk.img": f("\xeb\x52\x90NTFS    " + FO.noise(600, 32), { bin: true }),
        logs: SH.dir({ "auth.log": f(L.join("\n") + "\n"), "access.log": f(access.join("\n") + "\n") }, { owner: "analyst" }),
        "NOTES.txt": f("Sự cố 09/11: máy WS-AN-01 có kết nối lạ lúc 02:30.\nĐã thu: case/memdump.raw (RAM), case/disk.img (USB của nghi phạm), case/logs/ (từ web01).\n"),
      }, { owner: "analyst" }),
    }, "analyst");
  },
  cmds: (() => {
    const PROCS = [
      [4, 0, "System", "2026-11-09 01:58:02"], [312, 4, "smss.exe", "2026-11-09 01:58:02"], [420, 412, "csrss.exe", "2026-11-09 01:58:05"], [512, 412, "wininit.exe", "2026-11-09 01:58:05"],
      [640, 512, "services.exe", "2026-11-09 01:58:06"], [652, 512, "lsass.exe", "2026-11-09 01:58:06"], [780, 640, "svchost.exe", "2026-11-09 01:58:07"], [892, 640, "svchost.exe", "2026-11-09 01:58:07"],
      [2140, 2088, "explorer.exe", "2026-11-09 02:01:44"], [3012, 2140, "chrome.exe", "2026-11-09 02:05:10"], [3920, 2140, "WINWORD.EXE", "2026-11-09 02:27:31"],
      [4488, 3920, "powershell.exe", "2026-11-09 02:28:02"], [5120, 4488, "svch0st.exe", "2026-11-09 02:28:09"], [5208, 2140, "notepad.exe", "2026-11-09 02:40:12"],
    ];
    const enc = "SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABOAGUAdAAuAFcAZQBiAEMAbABpAGUAbgB0ACkALgBEAG8AdwBuAGwAbwBhAGQAUwB0AHIAaQBuAGcAKAAiAGgAdAB0AHAAOgAvAC8AMgAwADMALgAwAC4AMQAxADMALgA2ADYALwBhAC4AcABzADEAIgApACAAIwAgAHoAQwBUAEYAewBwADAAdwAzAHIAcwBoADMAbABsAF8AMwBuAGMAMABkADMAZAB9AA==";
    const CMD = { 4: "-", 640: "C:\\Windows\\system32\\services.exe", 652: "C:\\Windows\\system32\\lsass.exe", 780: "C:\\Windows\\system32\\svchost.exe -k DcomLaunch", 892: "C:\\Windows\\system32\\svchost.exe -k netsvcs", 2140: "C:\\Windows\\Explorer.EXE", 3012: '"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"', 3920: '"C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE" /n "C:\\Users\\an\\Downloads\\HoaDon_T11.docm"', 4488: "powershell.exe -nop -w hidden -enc " + enc, 5120: "C:\\Users\\an\\AppData\\Local\\Temp\\svch0st.exe", 5208: '"C:\\Windows\\system32\\notepad.exe" C:\\Users\\an\\Desktop\\ke_hoach_mat.txt' };
    const FILES = [
      ["0xe0001a2a1f20", "\\Windows\\System32\\drivers\\etc\\hosts"], ["0xe0001a2a8840", "\\Users\\an\\Downloads\\HoaDon_T11.docm"], ["0xe0001a2b0010", "\\Users\\an\\AppData\\Local\\Temp\\svch0st.exe"],
      ["0xe0001a2b3c40", "\\Users\\an\\Desktop\\ke_hoach_mat.txt"], ["0xe0001a2b5e00", "\\Users\\an\\Desktop\\anh_meo.jpg"], ["0xe0001a2c0a90", "\\Windows\\Prefetch\\POWERSHELL.EXE-022A1004.pf"],
    ];
    const vol = (a, stdin, ctx) => {
      const fi = a.indexOf("-f");
      if (fi < 0) throw "usage: vol -f <memory image> <plugin> [options]\n  plugins: windows.info windows.pslist windows.pstree windows.cmdline windows.netscan windows.filescan windows.dumpfiles";
      ctx.readNode(a[fi + 1]);
      const plug = a.find((x, i) => i !== fi + 1 && !x.startsWith("-"));
      const head = "Volatility 3 Framework 2.7.0\nProgress:  100.00\t\tPDB scanning finished\n\n";
      const tbl = (cols, rows) => [cols.join("\t"), "", ...rows.map((r2) => r2.join("\t"))].join("\n");
      switch (plug) {
        case "windows.info": return head + tbl(["Variable", "Value"], [["Kernel Base", "0xf80652e00000"], ["NtMajorVersion", "10"], ["NtBuildLab", "19041.1.amd64fre.vb_release"], ["SystemTime", "2026-11-09 02:41:03"], ["MachineName", "WS-AN-01"]]);
        case "windows.pslist": return head + tbl(["PID", "PPID", "ImageFileName", "Threads", "CreateTime"], PROCS.map(([p, pp, n, t]) => [p, pp, n, 4 + (p % 17), t]));
        case "windows.pstree": {
          const kids = (pp, d) => PROCS.filter((x) => x[1] === pp).flatMap((x) => [["*".repeat(d + 1) + " " + x[0], x[1], x[2], x[3]], ...kids(x[0], d + 1)]);
          return head + tbl(["PID", "PPID", "ImageFileName", "CreateTime"], [...kids(0, 0), ...kids(412, 0), ...kids(2088, 0)]);
        }
        case "windows.cmdline": {
          const pi = a.indexOf("--pid");
          const list = pi >= 0 ? PROCS.filter((x) => x[0] === +a[pi + 1]) : PROCS;
          return head + tbl(["PID", "Process", "Args"], list.map(([p, , n]) => [p, n, CMD[p] || "-"]));
        }
        case "windows.netscan": return head + tbl(["Offset", "Proto", "LocalAddr", "LocalPort", "ForeignAddr", "ForeignPort", "State", "PID", "Owner"], [
          ["0xe0001b001010", "TCPv4", "0.0.0.0", 135, "0.0.0.0", 0, "LISTENING", 780, "svchost.exe"],
          ["0xe0001b0042a0", "TCPv4", "192.168.1.23", 49712, "142.250.66.78", 443, "ESTABLISHED", 3012, "chrome.exe"],
          ["0xe0001b009c70", "TCPv4", "192.168.1.23", 49731, "203.0.113.66", 80, "CLOSED", 4488, "powershell.exe"],
          ["0xe0001b00a110", "TCPv4", "192.168.1.23", 49733, "203.0.113.66", 4444, "ESTABLISHED", 5120, "svch0st.exe"],
        ]);
        case "windows.filescan": return head + tbl(["Offset", "Name", "Size"], FILES.map(([o, n]) => [o, n, 216]));
        case "windows.dumpfiles": {
          const vi = a.indexOf("--virtaddr") >= 0 ? a.indexOf("--virtaddr") : a.indexOf("--physaddr");
          if (vi < 0) throw "windows.dumpfiles: cần --virtaddr <offset> (lấy từ windows.filescan)";
          const off = a[vi + 1];
          const fe = FILES.find(([o]) => o === off);
          if (!fe) return head + "Cache\tFileObject\tFileName\tResult\n\n(không tìm thấy file ở offset này)";
          const name = `file.${off}.0xe0001c5a3270.DataSectionObject.${fe[1].split("\\").pop()}.dat`;
          const content = fe[0] === "0xe0001a2b3c40" ? `KE HOACH (khong duoc chia se)\n1. Chuyen du lieu ra ngoai qua cong 4444\n2. Xoa log\nMa: ${d64(FO_SECRETS.mem2)}\n`
            : fe[0] === "0xe0001a2a1f20" ? "127.0.0.1 localhost\n203.0.113.66 update.microsoft.com\n" : FO.noise(200, 40);
          ctx.writeFile(name, content, { bin: !/\.txt$|hosts$/.test(fe[1]) });
          return head + tbl(["Cache", "FileObject", "FileName", "Result"], [["DataSectionObject", off, fe[1].split("\\").pop(), name]]);
        }
        default: throw `vol: plugin không hỗ trợ: ${plug || "(trống)"}. Có: windows.info windows.pslist windows.pstree windows.cmdline windows.netscan windows.filescan windows.dumpfiles`;
      }
    };
    const FS_ENTRIES = [
      ["r/r", "4", "README.txt", "USB của An. Đừng mở.\n"], ["d/d", "5", "anh/", null], ["r/r", "17", "anh/cho.jpg", null], ["r/r", "18", "anh/meo.jpg", null],
      ["r/r", "22", "todo.txt", "- mua sữa\n- trả sách\n"], ["r/r * 23(realloc)", "23", "passwords.txt", `email: an.nguyen@corp.example / Mua2024!\nvpn: an / ${d64(FO_SECRETS.mem4)}\n`],
      ["r/r * 31", "31", "~$keHoach.docx", "PK\x03\x04(tạm)"],
    ];
    return {
      vol, "vol.py": vol, volatility3: vol,
      iconv: (a, stdin, ctx) => {
        const from = (a[a.indexOf("-f") + 1] || "").toUpperCase();
        const b = ctx.stdinBytes || latin1ToBytes(stdin || "");
        if (/UTF-?16(LE)?/.test(from)) return new TextDecoder("utf-16le").decode(b);
        if (/UTF-?16BE/.test(from)) return new TextDecoder("utf-16be").decode(b);
        return new TextDecoder().decode(b);
      },
      fls: (a, stdin, ctx) => {
        const img = a.find((x) => !x.startsWith("-"));
        if (!img) throw "usage: fls [-r] [-d] <image>   (-d: chỉ file đã xoá)";
        ctx.readNode(img);
        const onlyDel = a.includes("-d");
        return FS_ENTRIES.filter((e) => !onlyDel || e[0].includes("*")).filter((e) => a.includes("-r") || !e[2].includes("/") || e[2].endsWith("/")).map(([t, i, n]) => `${t.padEnd(18)} ${i}:\t${n.replace(/\/$/, "")}`).join("\n");
      },
      icat: (a, stdin, ctx) => {
        const [img, inode] = a.filter((x) => !x.startsWith("-"));
        if (!img || !inode) throw "usage: icat <image> <inode>";
        ctx.readNode(img);
        const e = FS_ENTRIES.find((x) => x[1] === inode);
        if (!e) throw `icat: inode ${inode} không tồn tại`;
        if (e[3] == null) return { text: FO.noise(120, +inode), bin: true };
        return e[3];
      },
    };
  })(),
};
