/* =====================================================================
   Widget cho track Reverse Engineering
     - SHELL_FS["rev-intro"] : crackme, vault, answer + ltrace/strace/objdump/readelf
     - SHELL_FS["rev-dyn"]   : lockbox, trial, guard + gdb (mô phỏng), dd, printf, objdump
     - WIDGETS.asmsim        : trình mô phỏng x86-64 (tập con), data-prog="tên trong ASM_PROGS"
   ===================================================================== */

const REV_B64 = {
  i1: "ekNURntzdHIxbmdzX2w0X2J1b2NfZDR1fQ==",
  i2: "ekNURntsdHI0YzNfYjR0X3F1NF90YW5nfQ==",
  a3: "ekNURns0c21fa2gwbmdfZDRuZ19zMH0=",
  d1: "ekNURntnZGJfZDBjX2JvX25oMH0=",
  d2: "ekNURntwNHRjaF9qZV90aDRuaF9qbmV9",
  d3: "ekNURns0bnQxX2QzYnVnX3YwX2QxY2h9",
};

/* ---------- ELF giả: header + chuỗi (để strings / file hoạt động) ---------- */
function revElf(strs, extra = "") {
  let s = "\x7fELF\x02\x01\x01\x00" + "\x00".repeat(8) + "\x03\x00\x3e\x00\x01\x00\x00\x00\x60\x10\x00\x00\x00\x00\x00\x00\x40\x00";
  s += "\x00".repeat(40);
  const junk = "\x48\x89\xe5\x48\x83\xec\x10\xe8\x00\x00\x00\x00\xc9\xc3\x90\x0f\x1f\x44\x00";
  s += junk.repeat(4);
  s += "\x00/lib64/ld-linux-x86-64.so.2\x00libc.so.6\x00" + strs.join("\x00") + "\x00";
  s += junk.repeat(2) + extra + "\x00GCC: (Ubuntu 13.2.0-23ubuntu4) 13.2.0\x00crtstuff.c\x00main\x00.symtab\x00.strtab\x00.text\x00.rodata\x00.data\x00.bss\x00";
  return s;
}
const revProg = (run, strs, props = {}, meta = {}) => {
  const n = SH.exe(run, { owner: "guest", ...meta });
  n.c = revElf(strs, props.extra || "");
  return Object.assign(n, props);
};
const revNode = (ctx, p) => {
  if (!p) throw "thiếu tên chương trình";
  const n = ctx.node(ctx.resolve(p));
  if (!n) throw `${p}: No such file or directory`;
  if (n.t === "d") throw `${p}: Is a directory`;
  return n;
};

/* ---------- lệnh phân tích dùng chung ---------- */
const REV_CMDS = {
  ltrace: async (a, stdin, ctx) => {
    const args = a.filter((x) => !x.startsWith("-"));
    const n = revNode(ctx, args[0]);
    if (!n.ltrace) return n.run ? "+++ exited (status 0) +++" : `ltrace: ${args[0]}: không phải file thực thi`;
    return n.ltrace(args.slice(1), ctx).join("\n");
  },
  strace: async (a, stdin, ctx) => {
    const args = a.filter((x) => !x.startsWith("-"));
    const n = revNode(ctx, args[0]);
    const base = [`execve("${args[0]}", [${args.map((x) => JSON.stringify(x)).join(", ")}], 0x7ffd5e4c3a18 /* 12 vars */) = 0`, "brk(NULL)                               = 0x55d1c2a5e000", 'openat(AT_FDCWD, "/lib/x86_64-linux-gnu/libc.so.6", O_RDONLY|O_CLOEXEC) = 3', "mmap(NULL, 2170256, PROT_READ, MAP_PRIVATE|MAP_DENYWRITE, 3, 0) = 0x7f2a1c200000", "close(3)                                = 0"];
    const body = n.strace ? n.strace(args.slice(1), ctx) : ["exit_group(0)                           = ?"];
    return [...base, ...body, "+++ exited with " + (n.exitCode ?? 0) + " +++"].join("\n");
  },
  objdump: async (a, stdin, ctx) => {
    const f = a.filter((x) => !x.startsWith("-"));
    if (!a.some((x) => /^-\w*d/.test(x))) throw "Usage: objdump -d [-M intel] <file>";
    const n = revNode(ctx, f[0]);
    if (!n.objdump) return `\n${f[0]}:     file format elf64-x86-64\n\n(objdump mô phỏng: chương trình này không có phần disassembly để xem)`;
    return `\n${f[0]}:     file format elf64-x86-64\n\n\nDisassembly of section .text:\n\n` + (typeof n.objdump === "function" ? n.objdump(n) : n.objdump);
  },
  readelf: async (a, stdin, ctx) => {
    const f = a.filter((x) => !x.startsWith("-"));
    revNode(ctx, f[0]);
    return `ELF Header:
  Magic:   7f 45 4c 46 02 01 01 00 00 00 00 00 00 00 00 00
  Class:                             ELF64
  Data:                              2's complement, little endian
  Version:                           1 (current)
  OS/ABI:                            UNIX - System V
  Type:                              DYN (Position-Independent Executable file)
  Machine:                           Advanced Micro Devices X86-64
  Entry point address:               0x1060
  Start of program headers:          64 (bytes into file)
  Number of section headers:         31`;
  },
  printf: async (a) => {
    const fmt = a[0] ?? "";
    const s = fmt.replace(/\\x([0-9a-fA-F]{1,2})/g, (_, x) => String.fromCharCode(parseInt(x, 16))).replace(/\\n/g, "\n").replace(/\\t/g, "\t").replace(/\\\\/g, "\\");
    let i = 1;
    return { text: s.replace(/%[sd]/g, () => a[i++] ?? ""), bin: true, raw: true };
  },
  dd: async (a, stdin, ctx) => {
    const o = {};
    a.forEach((x) => { const m = x.match(/^(\w+)=(.*)$/); if (m) o[m[1]] = m[2]; });
    if (!o.of) throw "dd: thiếu of=<file> (bản mô phỏng chỉ hỗ trợ ghi từ stdin vào file)";
    const num = (v) => { if (v == null) return 0; const m = String(v).match(/^\$\(\((.*)\)\)$/); const s = m ? m[1] : String(v); const n = Number(s); if (!Number.isFinite(n)) throw `dd: invalid number: '${v}'`; return n; };
    const bs = num(o.bs || 512) || 1, seek = num(o.seek) * bs;
    let data = stdin ?? "";
    if (ctx.stdinBytes) data = bytesToLatin1(ctx.stdinBytes);
    if ([...data].some((ch) => ch.charCodeAt(0) > 255)) data = bytesToLatin1(utf8.encode(data));
    if (o.count) data = data.slice(0, num(o.count) * bs);
    const n = revNode(ctx, o.of);
    if (!/w/.test((n.mode || "").slice(1, 4)) && ctx.user !== "root") throw `dd: failed to open '${o.of}': Permission denied`;
    let content = n.c;
    if (!/notrunc/.test(o.conv || "")) content = content.slice(0, seek);
    if (content.length < seek) content = content.padEnd(seek, "\x00");
    n.c = content.slice(0, seek) + data + content.slice(seek + data.length);
    n.bin = true;
    return `${Math.ceil(data.length / bs)}+0 records in\n${Math.ceil(data.length / bs)}+0 records out\n${data.length} byte${data.length === 1 ? "" : "s"} copied, 0.0001 s, 10 kB/s`;
  },
};

/* =====================================================================
   1. Bài nhập môn: crackme / vault / answer
   ===================================================================== */
SHELL_FS["rev-intro"] = {
  host: "re-lab",
  motd: 'Có 3 chương trình trong thư mục: <span class="hl">crackme</span>, <span class="hl">vault</span>, <span class="hl">answer</span>. Thêm lệnh: <span class="hl">ltrace</span>, <span class="hl">strace</span>, <span class="hl">objdump -d</span>, <span class="hl">readelf -h</span>.',
  cmds: REV_CMDS,
  fs: () => {
    const flagEnc = (b64) => bytesToLatin1(latin1ToBytes(atob(b64)).map((x) => x ^ 0xa5));
    const crackme = revProg(async () => ({
      interactive: {
        banner: "=== CrackMe v1 ===",
        prompt: "Password: ",
        onLine: (l) => (l === "s1mpl3_p4ss" ? { out: "Correct! Flag: " + d64(REV_B64.i1), close: true } : { out: "Wrong password.", close: true }),
      },
    }), ["=== CrackMe v1 ===", "Password: ", "s1mpl3_p4ss", "Correct! Flag: ", "Wrong password.", "puts", "fgets", "strcmp", "stdin"], {
      extra: flagEnc(REV_B64.i1),
      ltrace: () => ['puts("=== CrackMe v1 ===")                       = 18', 'printf("Password: ")                         = 10', 'fgets("AAAA\\n", 64, 0x7f3c1e81aaa0)         = 0x7ffd2b0c4a10', 'strcspn("AAAA\\n", "\\n")                     = 4', 'strcmp("AAAA", "s1mpl3_p4ss")                = -18', 'puts("Wrong password.")                      = 16', "+++ exited (status 1) +++", "(mô phỏng: input giả định là AAAA)"],
      strace: () => ['write(1, "=== CrackMe v1 ===\\n", 19)    = 19', 'write(1, "Password: ", 10)               = 10', 'read(0, "AAAA\\n", 1024)                 = 5', 'write(1, "Wrong password.\\n", 16)       = 16', "exit_group(1)                           = ?"],
      exitCode: 1,
    });
    const vault = revProg(async (args) => {
      if (!args.length) throw "Usage: ./vault <password>";
      return args[0] === "d0nt_p4n1c" ? "Access granted. " + d64(REV_B64.i2) : "Access denied.";
    }, ["Usage: ./vault <password>", "d0nt", "p4n1c", "%s_%s", "Access granted. ", "Access denied.", "strlen", "malloc", "sprintf", "strcmp", "puts"], {
      extra: flagEnc(REV_B64.i2),
      ltrace: (args) => {
        const inp = args[0];
        if (inp == null) return ['puts("Usage: ./vault <password>")             = 26', "+++ exited (status 1) +++"];
        const ok = inp === "d0nt_p4n1c";
        const cmp = ok ? 0 : (inp.charCodeAt(0) || 0) - 100;
        return [`strlen("${inp}")${" ".repeat(Math.max(1, 30 - inp.length))}= ${inp.length}`, "malloc(32)                                   = 0x5626e0a1f2a0", 'sprintf("d0nt_p4n1c", "%s_%s", "d0nt", "p4n1c") = 10', `strcmp("${inp}", "d0nt_p4n1c")${" ".repeat(Math.max(1, 20 - inp.length))}= ${cmp}`, `puts("${ok ? "Access granted. ..." : "Access denied."}")${" ".repeat(10)}= 15`, `+++ exited (status ${ok ? 0 : 1}) +++`];
      },
    });
    const answer = revProg(async () => null, ["answer.c"], {
      objdump: `0000000000001129 <main>:
    1129:	55                   	push   rbp
    112a:	48 89 e5             	mov    rbp,rsp
    112d:	c7 45 fc 0a 00 00 00 	mov    DWORD PTR [rbp-0x4],0xa
    1134:	8b 45 fc             	mov    eax,DWORD PTR [rbp-0x4]
    1137:	6b c0 07             	imul   eax,eax,0x7
    113a:	83 c0 03             	add    eax,0x3
    113d:	5d                   	pop    rbp
    113e:	c3                   	ret`,
      ltrace: () => ["+++ exited (status 73) +++"],
      strace: () => ["exit_group(73)                          = ?"],
      exitCode: 73,
    });
    crackme.objdump = `0000000000001189 <main>:
    1189:	55                   	push   rbp
    118a:	48 89 e5             	mov    rbp,rsp
    118d:	48 83 ec 50          	sub    rsp,0x50
    ...
    11d0:	48 8d 15 3d 0e 00 00 	lea    rdx,[rip+0xe3d]        # 2014 <_IO_stdin_used+0x14>  "s1mpl3_p4ss"
    11d7:	48 8d 45 b0          	lea    rax,[rbp-0x50]
    11db:	48 89 d6             	mov    rsi,rdx
    11de:	48 89 c7             	mov    rdi,rax
    11e1:	e8 9a fe ff ff       	call   1080 <strcmp@plt>
    11e6:	85 c0                	test   eax,eax
    11e8:	75 16                	jne    1200 <main+0x77>
    ...`;
    return SH.base({
      crackme,
      vault,
      answer,
      "README.txt": SH.file("Ba chương trình nhỏ để luyện phân tích cơ bản.\nThử: file crackme, strings crackme, ltrace ./vault test, objdump -d answer\n", { owner: "guest" }),
    });
  },
};

/* =====================================================================
   2. Phân tích động: lockbox / trial / guard + gdb mô phỏng
   ===================================================================== */
const REV_HEX = (n) => (n < 0 ? "0x" + (BigInt.asUintN(64, BigInt(n))).toString(16) : "0x" + n.toString(16));

/* Mô hình chương trình cho gdb: exec là generator, yield {ev:"call"|"ret", sym}. rt = {regs, mem, out, underGdb} */
const LOCKBOX_SECRET = (() => { const a = [0x37, 0x2c, 0x2e, 0x72, 0x21, 0x29, 0x1d, 0x2f, 0x71, 0x1d, 0x2c, 0x72, 0x35]; const k = 0x42; return a.map((x) => String.fromCharCode(x ^ k)).join(""); })();
const GDB_MODELS = {
  lockbox: {
    syms: { main: 0x401196, check: 0x401236, my_cmp: 0x401176, puts: 0x401030, strlen: 0x401040 },
    disas: {
      main: `Dump of assembler code for function main:
   0x0000000000401196 <+0>:	push   rbp
   0x0000000000401197 <+1>:	mov    rbp,rsp
   0x000000000040119a <+4>:	sub    rsp,0x10
   0x000000000040119e <+8>:	mov    DWORD PTR [rbp-0x4],edi
   0x00000000004011a1 <+11>:	mov    QWORD PTR [rbp-0x10],rsi
   0x00000000004011a5 <+15>:	cmp    DWORD PTR [rbp-0x4],0x2
   0x00000000004011a9 <+19>:	je     0x4011bc <main+38>
   ...
   0x00000000004011c4 <+46>:	mov    rdi,rax
   0x00000000004011c7 <+49>:	call   0x401236 <check>
   0x00000000004011cc <+54>:	test   eax,eax
   0x00000000004011ce <+56>:	jne    0x4011e2 <main+76>
   0x00000000004011d0 <+58>:	call   0x401256 <print_flag>
   ...
End of assembler dump.`,
      check: `Dump of assembler code for function check:
   0x0000000000401236 <+0>:	push   rbp
   0x0000000000401237 <+1>:	mov    rbp,rsp
   0x000000000040123a <+4>:	sub    rsp,0x30
   0x000000000040123e <+8>:	mov    QWORD PTR [rbp-0x28],rdi
   0x0000000000401242 <+12>:	lea    rax,[rbp-0x20]
   0x0000000000401246 <+16>:	mov    rdi,rax
   0x0000000000401249 <+19>:	call   0x401150 <build_secret>    ; giải mã khoá ra stack
   0x000000000040124e <+24>:	lea    rsi,[rbp-0x20]
   0x0000000000401252 <+28>:	mov    rdi,QWORD PTR [rbp-0x28]
   0x0000000000401256 <+32>:	call   0x401176 <my_cmp>
   0x000000000040125b <+37>:	leave
   0x000000000040125c <+38>:	ret
End of assembler dump.`,
      my_cmp: `Dump of assembler code for function my_cmp:
   0x0000000000401176 <+0>:	movzx  eax,BYTE PTR [rdi]
   0x0000000000401179 <+3>:	movzx  edx,BYTE PTR [rsi]
   0x000000000040117c <+6>:	cmp    al,dl
   0x000000000040117e <+8>:	jne    0x40118e <my_cmp+24>
   ...
End of assembler dump.`,
    },
    *exec(args, rt) {
      if (args.length < 1) { rt.out("Usage: ./lockbox <password>"); return 1; }
      rt.mem[0x7fffffffe6a2] = args[0];
      rt.regs.rdi = 0x7fffffffe6a2;
      yield { ev: "call", sym: "check" };
      rt.mem[0x7fffffffe3c0] = LOCKBOX_SECRET;
      rt.regs.rdi = 0x7fffffffe6a2; rt.regs.rsi = 0x7fffffffe3c0;
      yield { ev: "call", sym: "my_cmp" };
      rt.regs.rax = args[0] === LOCKBOX_SECRET ? 0 : 1;
      yield { ev: "ret", sym: "my_cmp" };
      yield { ev: "ret", sym: "check" };
      if (rt.regs.rax === 0) rt.out("Access granted! " + d64(REV_B64.d1));
      else rt.out("Wrong password.");
      return 0;
    },
  },
  guard: {
    syms: { main: 0x4011d6, ptrace: 0x401050, decrypt: 0x401176, memset: 0x401040, puts: 0x401030 },
    disas: {
      main: `Dump of assembler code for function main:
   0x00000000004011d6 <+0>:	push   rbp
   0x00000000004011d7 <+1>:	mov    rbp,rsp
   0x00000000004011da <+4>:	mov    ecx,0x0
   0x00000000004011df <+9>:	mov    edx,0x0
   0x00000000004011e4 <+14>:	mov    esi,0x0
   0x00000000004011e9 <+19>:	mov    edi,0x0                 ; PTRACE_TRACEME
   0x00000000004011ee <+24>:	call   0x401050 <ptrace@plt>
   0x00000000004011f3 <+29>:	cmp    rax,0xffffffffffffffff
   0x00000000004011f7 <+33>:	jne    0x40120f <main+57>
   0x00000000004011f9 <+35>:	lea    rdi,[rip+0xe08]         ; "Debugger detected! Bye."
   0x0000000000401200 <+42>:	call   0x401030 <puts@plt>
   0x0000000000401205 <+47>:	mov    eax,0x1
   0x000000000040120a <+52>:	jmp    0x40124a <main+116>
   0x000000000040120f <+57>:	lea    rdi,[rip+0x2eaa]        ; buf @ 0x4040c0
   0x0000000000401216 <+64>:	call   0x401176 <decrypt>
   0x000000000040121b <+69>:	mov    edx,0x18
   0x0000000000401220 <+74>:	mov    esi,0x0
   0x0000000000401225 <+79>:	lea    rdi,[rip+0x2e94]        ; buf @ 0x4040c0
   0x000000000040122c <+86>:	call   0x401040 <memset@plt>
   0x0000000000401231 <+91>:	lea    rdi,[rip+0xdd8]         ; "Flag đã được giải mã rồi xoá. Bye!"
   0x0000000000401238 <+98>:	call   0x401030 <puts@plt>
   ...
End of assembler dump.`,
    },
    *exec(args, rt) {
      rt.regs.rdi = 0; rt.regs.rsi = 0; rt.regs.rdx = 0; rt.regs.rcx = 0;
      yield { ev: "call", sym: "ptrace" };
      rt.regs.rax = rt.underGdb ? -1 : 0;
      yield { ev: "ret", sym: "ptrace" };
      if (rt.regs.rax === -1) { rt.out("Debugger detected! Bye."); return 1; }
      rt.regs.rdi = 0x4040c0;
      yield { ev: "call", sym: "decrypt" };
      rt.mem[0x4040c0] = d64(REV_B64.d3);
      yield { ev: "ret", sym: "decrypt" };
      rt.regs.rdi = 0x4040c0; rt.regs.rsi = 0; rt.regs.rdx = 0x18;
      yield { ev: "call", sym: "memset" };
      rt.mem[0x4040c0] = "\x00".repeat(24);
      yield { ev: "ret", sym: "memset" };
      rt.out("Flag đã được giải mã rồi xoá. Bye!");
      return 0;
    },
  },
};

function gdbRunPlain(model, args) {
  const outs = [];
  const rt = { regs: { rax: 0, rdi: 0, rsi: 0, rdx: 0, rcx: 0 }, mem: {}, out: (s) => outs.push(s), underGdb: false };
  const g = model.exec(args, rt);
  while (!g.next().done);
  return outs.join("\n");
}

function gdbService(model, progName) {
  const REGS = ["rax", "rbx", "rcx", "rdx", "rsi", "rdi", "rbp", "rsp", "r8", "r9", "rip", "eflags"];
  let bps = [];
  let proc = null; // { gen, rt, stack: [sym], finishing }
  let pid = 4120;
  const symAt = (addr) => Object.entries(model.syms).find(([, a]) => a === addr)?.[0];
  const memRead = (rt, addr) => {
    for (const [k, v] of Object.entries(rt.mem)) { const base = +k; if (addr >= base && addr < base + v.length) return v.slice(addr - base); }
    return null;
  };
  const parseVal = (s) => {
    s = s.trim();
    if (/^\$\w+$/.test(s)) { if (!proc) throw "No registers."; const r = s.slice(1); if (!(r in proc.rt.regs)) throw `Invalid register \`${r}'`; return proc.rt.regs[r]; }
    if (/^-?(0x[0-9a-f]+|\d+)$/i.test(s)) return s.startsWith("-") ? -Number(s.slice(1)) : Number(s);
    if (model.syms[s] != null) return model.syms[s];
    throw `No symbol "${s}" in current context.`;
  };
  const lines = [];
  const P = (s) => lines.push(s);
  function advance() {
    while (true) {
      const r = proc.gen.next();
      proc.rt.flush();
      if (r.done) {
        P(`[Inferior 1 (process ${pid}) exited ${r.value ? "with code 0" + r.value : "normally"}]`);
        proc = null;
        return;
      }
      const { ev, sym } = r.value;
      if (ev === "call") {
        proc.stack.push(sym);
        proc.rt.regs.rip = model.syms[sym] || 0x401000;
        const bi = bps.findIndex((b) => b === sym);
        if (bi >= 0) { P(`\nBreakpoint ${bi + 1}, ${REV_HEX(proc.rt.regs.rip)} in ${sym} ()`); return; }
      } else if (ev === "ret") {
        proc.stack.pop();
        const caller = proc.stack[proc.stack.length - 1] || "main";
        proc.rt.regs.rip = (model.syms[caller] || model.syms.main) + 0x25;
        if (proc.finishing === sym) {
          proc.finishing = null;
          const v = proc.rt.regs.rax;
          P(`Run till exit from #0  ${sym} ()\n${REV_HEX(proc.rt.regs.rip)} in ${caller} ()\nValue returned is $1 = ${v}`);
          return;
        }
      }
    }
  }
  function start(args) {
    const rt = { regs: { rax: 0x1c, rbx: 0, rcx: 0, rdx: 0x7fffffffe4b8, rsi: 0x7fffffffe4a8, rdi: 1, rbp: 0x7fffffffe390, rsp: 0x7fffffffe380, r8: 0, r9: 0x7ffff7fcf680, rip: model.syms.main, eflags: 0x246 }, mem: {}, underGdb: true, buf: [] };
    rt.out = (s) => rt.buf.push(s);
    rt.flush = () => { rt.buf.forEach(P); rt.buf = []; };
    pid++;
    proc = { gen: model.exec(args, rt), rt, stack: ["main"], finishing: null };
    P(`Starting program: /home/guest/${progName} ${args.join(" ")}`.trimEnd());
    advance();
  }
  const help = `Lệnh gdb hỗ trợ (bản mô phỏng):
  break <hàm>        (b)   đặt breakpoint ở đầu hàm
  run [tham số]      (r)   chạy chương trình
  continue           (c)   chạy tiếp
  finish                   chạy đến khi hàm hiện tại return (in giá trị rax)
  info registers     (i r) xem thanh ghi
  info breakpoints         danh sách breakpoint
  x/s <địa chỉ|$reg>       in chuỗi tại địa chỉ
  x/<n>xb <địa chỉ|$reg>   in n byte dạng hex
  print $reg         (p)   in giá trị
  set $reg = <giá trị>     sửa thanh ghi
  disassemble <hàm>        xem mã asm
  backtrace          (bt)  call stack
  delete                   xoá mọi breakpoint
  quit               (q)`;
  return {
    banner: `GNU gdb (Ubuntu 15.0.50) 15.0.50.20240403-git\nReading symbols from ${progName}...\n(No debugging symbols found in ${progName})`,
    prompt: "(gdb) ",
    onLine(line) {
      lines.length = 0;
      const l = line.trim();
      const [cmd, ...rest] = l.split(/\s+/);
      const arg = rest.join(" ");
      try {
        if (!l) return null;
        if (["q", "quit", "exit"].includes(cmd)) return { out: proc ? "A debugging session is active. Quit anyway? (y) y" : "", close: true };
        if (cmd === "help" || cmd === "h") P(help);
        else if (cmd === "b" || cmd === "break" || cmd === "br") {
          const s = arg.replace(/^\*/, "");
          if (!s) throw "Argument required (location).";
          const sym = model.syms[s] != null ? s : symAt(Number(s));
          if (!sym) throw `Function "${s}" not defined.`;
          bps.push(sym);
          P(`Breakpoint ${bps.length} at ${REV_HEX(model.syms[sym])}`);
        } else if (cmd === "delete" || cmd === "d") { bps = []; P("Đã xoá mọi breakpoint."); }
        else if (cmd === "r" || cmd === "run" || cmd === "start") {
          if (cmd === "start") bps.push("main");
          start(rest);
        } else if (cmd === "c" || cmd === "continue") { if (!proc) throw "The program is not being run."; P("Continuing."); advance(); }
        else if (cmd === "finish" || cmd === "fin") {
          if (!proc) throw "The program is not being run.";
          const top = proc.stack[proc.stack.length - 1];
          if (top === "main") throw '"finish" not meaningful in the outermost frame.';
          proc.finishing = top; advance();
        } else if (["ni", "si", "nexti", "stepi", "next", "step", "n", "s"].includes(cmd)) {
          throw "(Bản mô phỏng không hỗ trợ bước từng lệnh. Dùng break / continue / finish.)";
        } else if ((cmd === "info" || cmd === "i") && /^r/.test(rest[0] || "")) {
          if (!proc) throw "The program has no registers now.";
          const want = rest.slice(1);
          (want.length ? want.map((x) => x.replace(/^\$/, "")) : REGS).forEach((r) => {
            const v = proc.rt.regs[r] ?? 0;
            P(`${r.padEnd(15)}${REV_HEX(v).padEnd(19)}${r === "rip" ? REV_HEX(v) + " <" + (proc.stack[proc.stack.length - 1]) + ">" : r === "eflags" ? "[ ZF PF IF ]" : v}`);
          });
        } else if ((cmd === "info" || cmd === "i") && /^b/.test(rest[0] || "")) {
          P(bps.length ? "Num     Type           Disp Enb Address            What\n" + bps.map((s, i) => `${String(i + 1).padEnd(8)}breakpoint     keep y   ${REV_HEX(model.syms[s]).padStart(18, " ")} <${s}>`).join("\n") : "No breakpoints or watchpoints.");
        } else if (cmd === "bt" || cmd === "backtrace" || cmd === "where") {
          if (!proc) throw "No stack.";
          [...proc.stack].reverse().forEach((s, i) => P(`#${i}  ${REV_HEX(model.syms[s] || 0)} in ${s} ()`));
        } else if (cmd === "p" || cmd === "print") {
          const v = parseVal(arg.replace(/^\/x\s*/, ""));
          P(`$1 = ${/^\/x/.test(arg) ? REV_HEX(v) : v}`);
        } else if (cmd === "set") {
          const m = arg.match(/^(?:var\s+)?\$(\w+)\s*=\s*(.+)$/);
          if (!m) throw "Cú pháp: set $rax = 0";
          if (!proc) throw "No registers.";
          if (!(m[1] in proc.rt.regs)) throw `Invalid register \`${m[1]}'`;
          proc.rt.regs[m[1]] = parseVal(m[2]);
        } else if (cmd === "disassemble" || cmd === "disas") {
          const s = arg || (proc ? proc.stack[proc.stack.length - 1] : "main");
          if (!model.disas[s]) throw model.syms[s] ? `(Bản mô phỏng không có mã của ${s} — đây là hàm thư viện)` : `No symbol "${s}" in current context.`;
          P(model.disas[s]);
        } else if (/^x(\/|$)/.test(cmd)) {
          if (!proc) throw "Cannot access memory: chương trình chưa chạy.";
          const fm = cmd.match(/^x\/(\d*)([sxdc]?)([bhwg]?)$/) || ["", "1", "x", "b"];
          const addr = parseVal(arg);
          const data = memRead(proc.rt, addr);
          if (data == null) throw `Cannot access memory at address ${REV_HEX(addr)}`;
          if (fm[2] === "s") { const z = data.indexOf("\x00"); P(`${REV_HEX(addr)}:\t"${(z < 0 ? data : data.slice(0, z))}"`); }
          else {
            const n = +(fm[1] || 8);
            const bytes = latin1ToBytes(data.slice(0, n));
            for (let i = 0; i < bytes.length; i += 8) P(`${REV_HEX(addr + i)}:\t` + [...bytes.slice(i, i + 8)].map((b) => (fm[2] === "c" ? `${b} '${String.fromCharCode(b)}'` : "0x" + b.toString(16).padStart(2, "0"))).join("\t"));
          }
        } else throw `Undefined command: "${cmd}".  Try "help".`;
      } catch (e) {
        P(String(e));
      }
      return lines.join("\n");
    },
  };
}

SHELL_FS["rev-dyn"] = {
  host: "re-lab",
  motd: 'Chương trình: <span class="hl">lockbox</span>, <span class="hl">trial</span>, <span class="hl">guard</span>. Thêm lệnh: <span class="hl">gdb</span> (mô phỏng), <span class="hl">objdump -d</span>, <span class="hl">ltrace</span>, <span class="hl">printf</span>, <span class="hl">dd</span>.',
  cmds: {
    ...REV_CMDS,
    gdb: async (a, stdin, ctx) => {
      const f = a.filter((x) => !x.startsWith("-"))[0];
      if (!f) throw "gdb: cần tên chương trình, vd: gdb ./lockbox";
      const n = revNode(ctx, f);
      if (!n.gdbModel) throw `"${f}": not in executable format (bản mô phỏng chỉ hỗ trợ lockbox và guard)`;
      return { interactive: gdbService(n.gdbModel, f.replace(/^\.\//, "")) };
    },
  },
  fs: () => {
    const lockbox = revProg(async (args) => gdbRunPlain(GDB_MODELS.lockbox, args), ["Usage: ./lockbox <password>", "Access granted! ", "Wrong password.", "check", "my_cmp", "build_secret", "print_flag", "puts", "strlen"], {
      gdbModel: GDB_MODELS.lockbox,
      ltrace: (args) => (args.length ? [`strlen("${args[0]}")                 = ${args[0].length}`, `puts("${args[0] === LOCKBOX_SECRET ? "Access granted! ..." : "Wrong password."}") = 16`, "+++ exited (status 0) +++", "(không có strcmp: chương trình tự so sánh bằng hàm my_cmp)"] : ['puts("Usage: ./lockbox <password>") = 28', "+++ exited (status 1) +++"]),
    });
    const guard = revProg(async () => gdbRunPlain(GDB_MODELS.guard, []), ["Debugger detected! Bye.", "ptrace", "decrypt", "memset", "puts"], {
      gdbModel: GDB_MODELS.guard,
      ltrace: () => ["ptrace(0, 0, 0, 0)                          = -1", 'puts("Debugger detected! Bye.")              = 24', "+++ exited (status 1) +++", "(ltrace cũng dùng ptrace nên bị phát hiện)"],
    });
    // trial: byte tại offset 0x11c4 quyết định nhánh
    const OFF = 0x11c4;
    const code = [0x55, 0x48, 0x89, 0xe5, 0x48, 0x83, 0xec, 0x10, 0xe8, 0x73, 0xff, 0xff, 0xff, 0x89, 0x45, 0xfc, 0x83, 0x7d, 0xfc, 0x00, 0x74, 0x07, 0xe8, 0x85, 0xfe, 0xff, 0xff, 0xeb, 0x0c, 0x48, 0x8d, 0x3d, 0x2c, 0x0e, 0x00, 0x00, 0xe8, 0x57, 0xfe, 0xff, 0xff, 0xb8, 0x00, 0x00, 0x00, 0x00, 0xc9, 0xc3];
    let body = revElf(["Trial expired. Mua license để dùng tiếp.", "license_valid", "print_flag", "puts"]);
    body = body.padEnd(0x11b0, "\x00") + bytesToLatin1(code);
    body = body.padEnd(0x1300, "\x00");
    const hx = (arr) => arr.map((x) => x.toString(16).padStart(2, "0")).join(" ");
    const trial = SH.exe(async (args, ctx) => {
      const n = trial;
      const b1 = n.c.charCodeAt(OFF), b2 = n.c.charCodeAt(OFF + 1);
      if (b1 === 0x74 && b2 === 0x07) return "Trial expired. Mua license để dùng tiếp.";
      if ((b1 === 0x75 && b2 === 0x07) || (b1 === 0x90 && b2 === 0x90)) return "License OK (?!) " + d64(REV_B64.d2);
      if (b1 === 0xeb) return "Trial expired. Mua license để dùng tiếp.";
      return "Segmentation fault (core dumped)";
    }, { owner: "guest", mode: "-rwxr-xr-x" });
    trial.c = body;
    trial.bin = true;
    trial.ltrace = () => ['puts("Trial expired. Mua license để dùng tiếp.") = 41', "+++ exited (status 0) +++"];
    trial.objdump = (n) => {
      const b = [n.c.charCodeAt(OFF), n.c.charCodeAt(OFF + 1)];
      const ins = b[0] === 0x74 ? `je     ${(OFF + 2 + b[1]).toString(16)} <main+0x1d>` : b[0] === 0x75 ? `jne    ${(OFF + 2 + b[1]).toString(16)} <main+0x1d>` : b[0] === 0xeb ? `jmp    ${(OFF + 2 + b[1]).toString(16)} <main+0x1d>` : b[0] === 0x90 && b[1] === 0x90 ? "nop\n    11c5:\t90                   \tnop" : "(bad)";
      const insHex = b[0] === 0x90 && b[1] === 0x90 ? "90" : hx(b);
      return `0000000000001130 <license_valid>:
    1130:	31 c0                	xor    eax,eax
    1132:	c3                   	ret

00000000000011b0 <main>:
    11b0:	55                   	push   rbp
    11b1:	48 89 e5             	mov    rbp,rsp
    11b4:	48 83 ec 10          	sub    rsp,0x10
    11b8:	e8 73 ff ff ff       	call   1130 <license_valid>
    11bd:	89 45 fc             	mov    DWORD PTR [rbp-0x4],eax
    11c0:	83 7d fc 00          	cmp    DWORD PTR [rbp-0x4],0x0
    11c4:	${insHex.padEnd(21)}	${ins}
    11c6:	e8 85 fe ff ff       	call   1050 <print_flag>
    11cb:	eb 0c                	jmp    11d9 <main+0x29>
    11cd:	48 8d 3d 2c 0e 00 00 	lea    rdi,[rip+0xe2c]        # 2000 "Trial expired..."
    11d4:	e8 57 fe ff ff       	call   1030 <puts@plt>
    11d9:	b8 00 00 00 00       	mov    eax,0x0
    11de:	c9                   	leave
    11df:	c3                   	ret`;
    };
    return SH.base({ lockbox, trial, guard, "README.txt": SH.file("lockbox: tìm mật khẩu bằng gdb.\ntrial: patch 1 byte để bỏ kiểm tra license.\nguard: có chống debug. Vượt qua nó trong gdb.\n", { owner: "guest" }) });
  },
};

/* =====================================================================
   3. Trình mô phỏng x86-64 (tập con, cú pháp Intel)
   ===================================================================== */
const ASM_PROGS = {
  "asm-basic": {
    title: "Bài 1 — số học cơ bản",
    code: `; Giá trị cuối của rax là bao nhiêu?
    mov rax, 0x10
    mov rbx, 0x22
    add rax, rbx        ; rax = rax + rbx
    shl rax, 2          ; dịch trái 2 bit = nhân 4
    xor rax, 0xff
    sub rax, 1
    hlt`,
  },
  "asm-loop": {
    title: "Bài 2 — vòng lặp",
    code: `; eax cuối cùng (thập phân) là bao nhiêu?
    xor eax, eax        ; eax = 0
    mov ecx, 1
loop:
    add eax, ecx
    inc ecx
    cmp ecx, 11
    jl loop             ; lặp khi ecx < 11 (có dấu)
    lea eax, [rax+rax*2]
    hlt`,
  },
  "asm-check": {
    title: "Bài 3 — hàm kiểm tra",
    inputs: ["rdi"],
    win: "win",
    fail: "fail",
    flag: REV_B64.a3,
    code: `; Tìm giá trị rdi (tham số thứ nhất) để chương trình tới nhãn win.
main:
    push rbp
    mov rbp, rsp
    call check          ; check(rdi)
    pop rbp
    test eax, eax
    jz fail
win:
    hlt
fail:
    hlt

check:
    mov rax, rdi
    xor rax, 0x1337
    add rax, 0x100
    cmp rax, 0x5442
    jne .bad
    mov eax, 1
    ret
.bad:
    xor eax, eax
    ret`,
  },
  "asm-free": {
    title: "Sân chơi — tự viết code",
    inputs: ["rdi", "rsi"],
    code: `; Sửa code tuỳ ý rồi bấm "Áp dụng". Hỗ trợ: mov movzx lea add sub imul inc dec neg not
; and or xor shl shr sar cmp test jmp jcc call ret push pop leave nop hlt
    mov rax, rdi
    imul rax, rsi
    push rax
    pop rbx
    hlt`,
  },
};

const ASM_R64 = ["rax", "rbx", "rcx", "rdx", "rsi", "rdi", "rbp", "rsp", "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15"];
const ASM_ALIAS = (() => {
  const m = {};
  const leg = { rax: ["eax", "ax", "al"], rbx: ["ebx", "bx", "bl"], rcx: ["ecx", "cx", "cl"], rdx: ["edx", "dx", "dl"], rsi: ["esi", "si", "sil"], rdi: ["edi", "di", "dil"], rbp: ["ebp", "bp", "bpl"], rsp: ["esp", "sp", "spl"] };
  for (const r of ASM_R64) {
    m[r] = [r, 64];
    const names = leg[r] || [r + "d", r + "w", r + "b"];
    m[names[0]] = [r, 32]; m[names[1]] = [r, 16]; m[names[2]] = [r, 8];
  }
  return m;
})();
const M64 = (1n << 64n) - 1n;
const maskW = (w) => (1n << BigInt(w)) - 1n;
const signW = (v, w) => (v >> BigInt(w - 1)) & 1n;
const toSigned = (v, w) => (signW(v, w) ? v - (1n << BigInt(w)) : v);

function asmParse(src) {
  const ins = [], labels = {}, lineOf = [];
  src.split("\n").forEach((raw, ln) => {
    let s = raw.replace(/;.*$/, "").trim();
    let m;
    while ((m = s.match(/^([.\w]+):\s*(.*)$/))) { labels[m[1]] = ins.length; s = m[2].trim(); }
    if (!s) return;
    const sp = s.search(/\s/);
    const op = (sp < 0 ? s : s.slice(0, sp)).toLowerCase();
    const rest = sp < 0 ? "" : s.slice(sp + 1).trim();
    const args = [];
    let depth = 0, cur = "";
    for (const ch of rest) { if (ch === "[") depth++; if (ch === "]") depth--; if (ch === "," && !depth) { args.push(cur.trim()); cur = ""; } else cur += ch; }
    if (cur.trim()) args.push(cur.trim());
    ins.push({ op, args, ln });
  });
  return { ins, labels };
}

function asmMachine(prog, init) {
  const BASE = 0x401000, STACK = 0x7fffffffe400, END = 0xdeadbeefn;
  const regs = Object.fromEntries(ASM_R64.map((r) => [r, 0n]));
  Object.entries(init || {}).forEach(([k, v]) => (regs[k] = BigInt.asUintN(64, BigInt(v))));
  regs.rsp = BigInt(STACK);
  const mem = new Map();
  const fl = { ZF: 0, SF: 0, CF: 0, OF: 0 };
  const st = { ip: 0, halted: false, steps: 0, msg: "" };
  const wmem = (addr, w, v) => { for (let i = 0; i < w / 8; i++) mem.set(addr + i, Number((v >> BigInt(8 * i)) & 0xffn)); };
  const rmem = (addr, w) => { let v = 0n; for (let i = 0; i < w / 8; i++) v |= BigInt(mem.get(addr + i) ?? 0) << BigInt(8 * i); return v; };
  // ô stack đầu tiên = địa chỉ trả về "kết thúc"
  regs.rsp -= 8n; wmem(Number(regs.rsp), 64, END);
  const addrOf = (i) => BASE + i * 4;
  const parseImm = (s) => {
    s = s.trim();
    if (/^'.'$/.test(s)) return BigInt(s.charCodeAt(1));
    if (/^-?0x[0-9a-f]+$/i.test(s)) return s.startsWith("-") ? -BigInt(s.slice(1)) : BigInt(s);
    if (/^-?[0-9a-f]+h$/i.test(s)) return BigInt("0x" + s.replace(/h$/i, "").replace("-", "")) * (s.startsWith("-") ? -1n : 1n);
    if (/^-?\d+$/.test(s)) return BigInt(s);
    return null;
  };
  const operand = (s, hint) => {
    s = s.trim();
    let size = null;
    const pm = s.match(/^(byte|word|dword|qword)\s+(ptr\s+)?(.*)$/i);
    if (pm) { size = { byte: 8, word: 16, dword: 32, qword: 64 }[pm[1].toLowerCase()]; s = pm[3].trim(); }
    const lw = s.toLowerCase();
    if (ASM_ALIAS[lw]) return { t: "reg", r: ASM_ALIAS[lw][0], w: ASM_ALIAS[lw][1] };
    if (s.startsWith("[")) {
      if (!s.endsWith("]")) throw "Thiếu dấu ]";
      let addr = 0n;
      s.slice(1, -1).replace(/\s+/g, "").replace(/-/g, "+-").split("+").filter(Boolean).forEach((term) => {
        const neg = term.startsWith("-"); const tt = neg ? term.slice(1) : term;
        let v;
        const mm = tt.match(/^(\w+)\*(\d)$/) || tt.match(/^(\d)\*(\w+)$/);
        if (mm) { const [rn, sc] = ASM_ALIAS[mm[1].toLowerCase()] ? [mm[1], mm[2]] : [mm[2], mm[1]]; const a = ASM_ALIAS[rn.toLowerCase()]; if (!a) throw `Thanh ghi lạ: ${rn}`; v = regs[a[0]] * BigInt(sc); }
        else if (ASM_ALIAS[tt.toLowerCase()]) v = regs[ASM_ALIAS[tt.toLowerCase()][0]];
        else { v = parseImm(tt); if (v == null) throw `Không hiểu "${tt}" trong địa chỉ`; }
        addr += neg ? -v : v;
      });
      return { t: "mem", a: Number(BigInt.asUintN(64, addr)), w: size || hint || 64, rawSize: size };
    }
    const iv = parseImm(s);
    if (iv != null) return { t: "imm", v: iv };
    if (prog.labels[s] != null) return { t: "lbl", i: prog.labels[s] };
    throw `Không hiểu toán hạng "${s}"`;
  };
  const read = (o, w) => {
    if (o.t === "reg") { const v = regs[o.r]; return o.w === 64 ? v : v & maskW(o.w); }
    if (o.t === "mem") return rmem(o.a, w || o.w);
    if (o.t === "imm") return BigInt.asUintN(w || 64, o.v);
    if (o.t === "lbl") return BigInt(addrOf(o.i));
  };
  const write = (o, v, w) => {
    if (o.t === "reg") {
      v &= maskW(o.w);
      if (o.w === 64) regs[o.r] = v;
      else if (o.w === 32) regs[o.r] = v; // ghi 32 bit xoá 32 bit cao
      else regs[o.r] = (regs[o.r] & ~maskW(o.w) & M64) | v;
    } else if (o.t === "mem") wmem(o.a, w || o.w, v & maskW(w || o.w));
    else throw "Không ghi được vào hằng số";
  };
  const setZS = (r, w) => { fl.ZF = r === 0n ? 1 : 0; fl.SF = Number(signW(r, w)); };
  const two = (ins) => {
    if (ins.args.length !== 2) throw `${ins.op} cần 2 toán hạng`;
    let d = operand(ins.args[0]);
    const s = operand(ins.args[1], d.t === "reg" ? d.w : undefined);
    if (d.t === "mem" && !d.rawSize && s.t === "reg") d = { ...d, w: s.w };
    const w = d.t === "reg" ? d.w : d.w;
    return [d, s, w];
  };
  const cond = (cc) => ({
    e: fl.ZF, z: fl.ZF, ne: !fl.ZF, nz: !fl.ZF, g: !fl.ZF && fl.SF === fl.OF, nle: !fl.ZF && fl.SF === fl.OF, ge: fl.SF === fl.OF, nl: fl.SF === fl.OF,
    l: fl.SF !== fl.OF, nge: fl.SF !== fl.OF, le: fl.ZF || fl.SF !== fl.OF, ng: fl.ZF || fl.SF !== fl.OF, a: !fl.CF && !fl.ZF, nbe: !fl.CF && !fl.ZF,
    ae: !fl.CF, nb: !fl.CF, nc: !fl.CF, b: fl.CF, c: fl.CF, nae: fl.CF, be: fl.CF || fl.ZF, na: fl.CF || fl.ZF, s: fl.SF, ns: !fl.SF,
  })[cc];
  const push = (v) => { regs.rsp = (regs.rsp - 8n) & M64; wmem(Number(regs.rsp), 64, v); };
  const pop = () => { const v = rmem(Number(regs.rsp), 64); regs.rsp = (regs.rsp + 8n) & M64; return v; };
  const jumpTo = (ins) => { const o = operand(ins.args[0]); if (o.t !== "lbl") throw "Đích nhảy phải là nhãn"; st.ip = o.i; };

  function step() {
    if (st.halted) return;
    if (st.ip >= prog.ins.length) { st.halted = true; st.msg = "Hết chương trình."; return; }
    const ins = prog.ins[st.ip];
    st.steps++;
    let next = st.ip + 1;
    const op = ins.op;
    const arith = (kind) => {
      const [d, s, w] = two(ins);
      const a = read(d, w), b = read(s, w) & maskW(w);
      let r;
      if (kind === "add") { r = (a + b) & maskW(w); fl.CF = a + b > maskW(w) ? 1 : 0; fl.OF = signW(a, w) === signW(b, w) && signW(r, w) !== signW(a, w) ? 1 : 0; }
      else { r = (a - b) & maskW(w); fl.CF = a < b ? 1 : 0; fl.OF = signW(a, w) !== signW(b, w) && signW(r, w) !== signW(a, w) ? 1 : 0; }
      setZS(r, w);
      if (kind !== "cmp") write(d, r, w);
    };
    const logic = (kind) => {
      const [d, s, w] = two(ins);
      const a = read(d, w), b = read(s, w) & maskW(w);
      const r = kind === "and" || kind === "test" ? a & b : kind === "or" ? a | b : a ^ b;
      fl.CF = 0; fl.OF = 0; setZS(r, w);
      if (kind !== "test") write(d, r, w);
    };
    if (op === "mov") { const [d, s, w] = two(ins); write(d, read(s, w), w); }
    else if (op === "movzx") { const d = operand(ins.args[0]); const s = operand(ins.args[1], 8); write(d, read(s, s.w), d.w); }
    else if (op === "lea") { const d = operand(ins.args[0]); const s = operand(ins.args[1]); if (s.t !== "mem") throw "lea cần toán hạng [địa chỉ]"; write(d, BigInt(s.a), d.w); }
    else if (op === "add" || op === "sub" || op === "cmp") arith(op);
    else if (["and", "or", "xor", "test"].includes(op)) logic(op);
    else if (op === "inc" || op === "dec") { const d = operand(ins.args[0]); const w = d.w; const a = read(d, w); const r = (op === "inc" ? a + 1n : a - 1n) & maskW(w); fl.OF = op === "inc" ? (r === 1n << BigInt(w - 1) ? 1 : 0) : (a === 1n << BigInt(w - 1) ? 1 : 0); setZS(r, w); write(d, r, w); }
    else if (op === "neg") { const d = operand(ins.args[0]); const w = d.w; const a = read(d, w); const r = (0n - a) & maskW(w); fl.CF = a === 0n ? 0 : 1; setZS(r, w); write(d, r, w); }
    else if (op === "not") { const d = operand(ins.args[0]); write(d, ~read(d, d.w) & maskW(d.w), d.w); }
    else if (["shl", "sal", "shr", "sar"].includes(op)) {
      const d = operand(ins.args[0]); const w = d.w; const n = Number(read(operand(ins.args[1] ?? "1"), 8) & 63n);
      let a = read(d, w), r;
      if (!n) { next = st.ip + 1; }
      else {
        if (op === "shl" || op === "sal") { fl.CF = Number((a >> BigInt(w - n)) & 1n); r = (a << BigInt(n)) & maskW(w); }
        else if (op === "shr") { fl.CF = Number((a >> BigInt(n - 1)) & 1n); r = a >> BigInt(n); }
        else { fl.CF = Number((a >> BigInt(n - 1)) & 1n); r = BigInt.asUintN(w, toSigned(a, w) >> BigInt(n)); }
        setZS(r, w); write(d, r, w);
      }
    }
    else if (op === "imul") {
      const d = operand(ins.args[0]); const w = d.w;
      const s = operand(ins.args[1], w);
      const x = ins.args.length === 3 ? toSigned(read(s, w), w) * toSigned(read(operand(ins.args[2]), w), w) : toSigned(read(d, w), w) * toSigned(read(s, w), w);
      const r = BigInt.asUintN(w, x);
      fl.CF = fl.OF = toSigned(r, w) !== x ? 1 : 0;
      write(d, r, w);
    }
    else if (op === "jmp") { jumpTo(ins); next = st.ip; }
    else if (op[0] === "j" && cond(op.slice(1)) !== undefined) { if (cond(op.slice(1))) { jumpTo(ins); next = st.ip; } }
    else if (op === "call") { const o = operand(ins.args[0]); if (o.t !== "lbl") throw "call cần nhãn"; push(BigInt(addrOf(st.ip + 1))); next = o.i; }
    else if (op === "ret") { const v = pop(); if (v === END) { st.halted = true; st.msg = "main đã return."; return; } const i = (Number(v) - BASE) / 4; if (!Number.isInteger(i) || i < 0 || i > prog.ins.length) { st.halted = true; st.msg = `Segmentation fault: ret tới ${REV_HEX(Number(v))}`; return; } next = i; }
    else if (op === "push") { const o = operand(ins.args[0], 64); push(read(o, 64)); }
    else if (op === "pop") { write(operand(ins.args[0]), pop(), 64); }
    else if (op === "leave") { regs.rsp = regs.rbp; regs.rbp = pop(); }
    else if (op === "nop") {}
    else if (op === "hlt") { st.halted = true; st.msg = "hlt — dừng."; return; }
    else throw `Lệnh không hỗ trợ: ${op}`;
    st.ip = next;
  }
  return { regs, fl, st, mem, step, addrOf, rmem, STACK };
}

WIDGETS.asmsim = (el) => {
  addStyle("asmsim", `
.asm-sim { margin: 18px 0; }
.asm-top { display:flex; gap:8px; flex-wrap:wrap; align-items:center; padding:10px 14px; border-bottom:1px solid var(--border); }
.asm-top .ttl { font-family:var(--mono); font-size:13px; color:var(--muted); margin-right:auto; }
.asm-main { display:grid; grid-template-columns: minmax(0,1.25fr) minmax(0,1fr); }
.asm-code { font-family:var(--mono); font-size:13px; line-height:1.65; padding:10px 0; max-height:430px; overflow:auto; border-right:1px solid var(--border); }
.asm-code div { padding:0 14px; white-space:pre; color:#c9d4df; }
.asm-code .ad { color:var(--dim); margin-right:12px; user-select:none; }
.asm-code .lb { color:var(--violet); }
.asm-code .cm { color:var(--dim); }
.asm-code .cur { background:rgba(61,255,162,.1); box-shadow: inset 3px 0 0 var(--accent); }
.asm-code textarea { width:100%; min-height:380px; background:#06080b; color:#d1dae4; border:none; outline:none; padding:4px 14px; font-family:var(--mono); font-size:13px; line-height:1.65; white-space:pre; resize:vertical; }
.asm-side { padding:12px 14px; font-family:var(--mono); font-size:12.5px; display:flex; flex-direction:column; gap:12px; min-width:0; }
.asm-regs { display:grid; grid-template-columns: 1fr 1fr; gap:2px 14px; }
.asm-regs div { display:flex; justify-content:space-between; gap:8px; }
.asm-regs b { color:var(--muted); font-weight:500; }
.asm-regs span { color:#d1dae4; transition: color .3s; }
.asm-regs .chg span { color:var(--amber); }
.asm-flags { display:flex; gap:6px; }
.asm-flags span { padding:2px 8px; border-radius:6px; border:1px solid var(--border-2); color:var(--dim); }
.asm-flags .on { color:#03140b; background:var(--accent); border-color:var(--accent); }
.asm-stack div { display:flex; gap:10px; color:var(--muted); }
.asm-stack .sp { color:var(--cyan); }
.asm-stack em { color:var(--dim); font-style:normal; }
.asm-h { color:var(--dim); font-size:11px; letter-spacing:.06em; }
.asm-in { display:flex; gap:10px; flex-wrap:wrap; align-items:center; padding:10px 14px; border-top:1px solid var(--border); font-family:var(--mono); font-size:13px; color:var(--muted); }
.asm-in input { width:170px; padding:6px 9px; border-radius:8px; background:#06080b; border:1px solid var(--border-2); color:var(--text); font-family:var(--mono); }
.asm-status { padding:10px 14px; border-top:1px solid var(--border); font-family:var(--mono); font-size:13px; color:var(--muted); min-height:20px; }
.asm-status .ok { color:var(--accent); } .asm-status .e { color:var(--red); }
@media (max-width: 800px) { .asm-main { grid-template-columns: 1fr; } .asm-code { border-right:none; border-bottom:1px solid var(--border); } }
`);
  const spec = ASM_PROGS[el.dataset.prog] || ASM_PROGS["asm-free"];
  let src = spec.code;
  const inputs = spec.inputs || [];
  const root = h(`
    <div class="asm-sim window">
      <div class="window-bar"><i></i><i></i><i></i><span>x86-64 simulator · ${esc(spec.title)}</span></div>
      <div class="asm-top"><span class="ttl">Intel syntax · mỗi lệnh coi như dài 4 byte</span>
        <button class="btn sm primary" data-a="step">Step ⏭</button>
        <button class="btn sm" data-a="run">Run ▶</button>
        <button class="btn sm" data-a="reset">Reset ⟲</button>
        <button class="btn sm" data-a="edit">Sửa code ✎</button></div>
      <div class="asm-main"><div class="asm-code"></div><div class="asm-side"></div></div>
      ${inputs.length ? `<div class="asm-in">Giá trị ban đầu: ${inputs.map((r) => `<label>${r} = <input data-r="${r}" value="0" spellcheck="false"></label>`).join("")}<span>(nhập rồi bấm Reset)</span></div>` : ""}
      <div class="asm-status"></div>
    </div>`);
  el.replaceWith(root);
  const codeEl = root.querySelector(".asm-code"), side = root.querySelector(".asm-side"), status = root.querySelector(".asm-status");
  let prog, m, prev = {}, editing = false;
  const initVals = () => {
    const o = {};
    root.querySelectorAll(".asm-in input").forEach((i) => {
      const v = i.value.trim();
      try { o[i.dataset.r] = /^-/.test(v) ? -BigInt(v.slice(1)) : BigInt(v || "0"); i.style.borderColor = ""; }
      catch { i.style.borderColor = "var(--red)"; o[i.dataset.r] = 0n; }
    });
    return o;
  };
  function reset() {
    try { prog = asmParse(src); } catch (e) { status.innerHTML = `<span class="e">${esc(e)}</span>`; return; }
    m = asmMachine(prog, initVals());
    prev = { ...m.regs };
    status.textContent = "Sẵn sàng. Bấm Step để chạy từng lệnh.";
    render();
  }
  function render() {
    if (editing) return;
    const lines = src.split("\n");
    const insByLn = {}; prog.ins.forEach((x, i) => (insByLn[x.ln] = i));
    const curLn = !m.st.halted && prog.ins[m.st.ip] ? prog.ins[m.st.ip].ln : -1;
    codeEl.innerHTML = lines.map((l, ln) => {
      const i = insByLn[ln];
      const ad = i != null ? `<span class="ad">${m.addrOf(i).toString(16)}</span>` : `<span class="ad">${" ".repeat(6)}</span>`;
      const body = esc(l).replace(/^(\s*)([.\w]+:)/, '$1<span class="lb">$2</span>').replace(/(;.*)$/, '<span class="cm">$1</span>');
      return `<div class="${ln === curLn ? "cur" : ""}">${ad}${body || " "}</div>`;
    }).join("");
    codeEl.querySelector(".cur")?.scrollIntoView({ block: "nearest" });
    const show = ["rax", "rbx", "rcx", "rdx", "rsi", "rdi", "rbp", "rsp"];
    const rip = m.st.halted || !prog.ins[m.st.ip] ? "—" : "0x" + m.addrOf(m.st.ip).toString(16);
    const sp = Number(m.regs.rsp);
    const rows = [];
    for (let a = sp; a < Math.min(sp + 6 * 8, m.STACK); a += 8) {
      const v = m.rmem(a, 64);
      rows.push(`<div class="${a === sp ? "sp" : ""}"><em>${a.toString(16)}</em><span>0x${v.toString(16).padStart(16, "0")}</span>${a === sp ? "← rsp" : ""}${v === 0xdeadbeefn ? " <em>(ret về OS)</em>" : ""}</div>`);
    }
    side.innerHTML = `
      <div class="asm-h">THANH GHI</div>
      <div class="asm-regs">${show.map((r) => `<div class="${prev[r] !== m.regs[r] ? "chg" : ""}"><b>${r}</b><span>0x${m.regs[r].toString(16)}</span></div>`).join("")}<div><b>rip</b><span>${rip}</span></div></div>
      <div class="asm-h">CỜ (RFLAGS)</div>
      <div class="asm-flags">${["ZF", "SF", "CF", "OF"].map((f) => `<span class="${m.fl[f] ? "on" : ""}">${f}=${m.fl[f]}</span>`).join("")}</div>
      <div class="asm-h">STACK (đỉnh ở trên)</div>
      <div class="asm-stack">${rows.join("") || "<em>(trống)</em>"}</div>
      <div class="asm-h">rax thập phân: <span style="color:var(--text)">${m.regs.rax.toString()}</span> · có dấu: <span style="color:var(--text)">${toSigned(m.regs.rax, 64).toString()}</span></div>`;
  }
  function after() {
    if (m.st.halted) {
      const at = prog.ins.findIndex((_, i) => i === m.st.ip);
      const lbl = Object.entries(prog.labels).find(([, i]) => i === at)?.[0];
      if (spec.win && lbl === spec.win) status.innerHTML = `<span class="ok">✓ Tới nhãn win! Flag: ${esc(d64(spec.flag))}</span>`;
      else if (spec.fail && lbl === spec.fail) status.innerHTML = `<span class="e">✗ Rơi vào nhãn fail. Thử giá trị khác.</span>`;
      else status.innerHTML = `${esc(m.st.msg)} Đã chạy ${m.st.steps} lệnh. rax = 0x${m.regs.rax.toString(16)} (${m.regs.rax})`;
    } else status.textContent = `Đã chạy ${m.st.steps} lệnh.`;
  }
  const doStep = () => { prev = { ...m.regs }; try { m.step(); } catch (e) { m.st.halted = true; status.innerHTML = `<span class="e">Lỗi ở dòng ${prog.ins[m.st.ip].ln + 1}: ${esc(e)}</span>`; render(); return false; } render(); after(); return !m.st.halted; };
  root.querySelector('[data-a="step"]').onclick = () => { if (editing) return; if (m.st.halted) reset(); doStep(); };
  root.querySelector('[data-a="run"]').onclick = () => {
    if (editing) return;
    if (m.st.halted) reset();
    prev = { ...m.regs };
    try { let n = 0; while (!m.st.halted && n++ < 20000) m.step(); if (n >= 20000) { status.innerHTML = '<span class="e">Dừng sau 20000 lệnh (vòng lặp vô hạn?)</span>'; render(); return; } }
    catch (e) { m.st.halted = true; render(); status.innerHTML = `<span class="e">Lỗi: ${esc(e)}</span>`; return; }
    render(); after();
  };
  root.querySelector('[data-a="reset"]').onclick = () => { if (!editing) reset(); };
  const editBtn = root.querySelector('[data-a="edit"]');
  editBtn.onclick = () => {
    if (!editing) {
      editing = true; editBtn.textContent = "Áp dụng ✓";
      codeEl.innerHTML = "<textarea spellcheck=\"false\"></textarea>";
      codeEl.querySelector("textarea").value = src;
    } else {
      src = codeEl.querySelector("textarea").value;
      editing = false; editBtn.textContent = "Sửa code ✎";
      reset();
    }
  };
  reset();
};
