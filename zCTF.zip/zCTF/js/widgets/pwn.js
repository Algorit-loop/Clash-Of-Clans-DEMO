/* Widget cho track Pwn */
const PWN_SECRETS = {
  pw1: "ekNURnt0cjRuX2IwX2QzbX0=",
  pw2: "ekNURntsMXR0bDNfM25kMTRufQ==",
  ret1: "ekNURntyM3QydzFuX2w0X2tob2lfZGF1fQ==",
  ret2: "ekNURntjeWNsaWNfdDFtX29mZnMzdF80MH0=",
  fmt1: "ekNURntsMzRrX3N0YWNrX3ZvaV9wfQ==",
  fmt2: "ekNURntmb3JtNHRfc3RyMW5nX2QwY19iMV9tNHR9",
  rop1: "ekNURntwMHBfcmQxX3IzdF9jMF9iNG59",
  rop2: "ekNURntyM3QybGliY19nMG1fc3lzdGVtfQ==",
  heap1: "ekNURnt1czNfNGZ0M3JfZnIzM190Y2FjaGV9",
};

addStyle("pwn", `
.pwn-term { margin: 18px 0; }
.pwn-term input.pwn-in { width: 100%; box-sizing: border-box; padding: 11px 13px; border-radius: 10px; background: #06080b; border: 1px solid var(--border-2); color: var(--text); font-family: var(--mono); font-size: 13.5px; outline: none; }
.pwn-term input.pwn-in:focus { border-color: var(--accent); }
.pwn-term input.pwn-in.bad { border-color: var(--red); }
.pwn-cols { display: grid; grid-template-columns: 1.15fr 1fr; gap: 20px; margin-top: 14px; }
.pwn-rows { font-family: var(--mono); font-size: 12.5px; display: flex; flex-direction: column; gap: 4px; }
.pwn-row { display: grid; grid-template-columns: 112px 1fr; gap: 10px; align-items: center; }
.pwn-row .addr { color: var(--dim); }
.pwn-cells { display: grid; grid-template-columns: repeat(8, 1fr); gap: 3px; }
.pwn-cell { aspect-ratio: 1; display: grid; place-items: center; border-radius: 6px; border: 1px solid var(--border); background: #06080b; color: var(--dim); font-size: 11px; transition: background .2s, border-color .2s, color .2s, transform .2s; }
.pwn-cell.buf { background: rgba(92,200,255,.1); border-color: rgba(92,200,255,.4); color: var(--cyan); }
.pwn-cell.canary { background: rgba(165,139,255,.14); border-color: var(--violet); color: var(--violet); }
.pwn-cell.rbp { background: rgba(255,200,87,.12); border-color: var(--amber); color: var(--amber); }
.pwn-cell.ret { background: rgba(61,255,162,.12); border-color: var(--accent); color: var(--accent); }
.pwn-cell.hit { transform: scale(1.06); }
.pwn-cell.over { background: rgba(255,92,122,.16); border-color: var(--red); color: var(--red); }
.pwn-cell.empty { opacity: .45; }
.pwn-state { padding: 14px; border-radius: 10px; background: #06080b; border: 1px solid var(--border); font-family: var(--mono); font-size: 13px; line-height: 1.75; align-self: start; }
.pwn-state .bad { color: var(--red); }
.pwn-state .good { color: var(--accent); }
.pwn-state .dim { color: var(--dim); }
.pwn-state .warn { color: var(--amber); }
.pwn-state .lk { color: var(--cyan); }
.pwn-state hr { border: none; border-top: 1px dashed var(--border); margin: 8px 0; }
.pwn-reg { color: var(--violet); }
.pwn-chips { display: flex; flex-wrap: wrap; gap: 6px; margin: 8px 0; }
.pwn-chip { padding: 5px 10px; border-radius: 8px; font-family: var(--mono); font-size: 12px; border: 1px solid var(--border-2); background: var(--surface); color: var(--muted); cursor: pointer; transition: all .15s; }
.pwn-chip:hover { border-color: var(--dim); color: var(--text); }
.pwn-rop { display: flex; flex-direction: column; gap: 6px; margin-top: 8px; }
.pwn-rop-slot { display: grid; grid-template-columns: 110px 1fr auto; gap: 10px; align-items: center; font-family: var(--mono); font-size: 12.5px; padding: 7px 10px; border-radius: 8px; border: 1px solid var(--border); background: #06080b; }
.pwn-rop-slot .ra { color: var(--dim); }
.pwn-rop-slot .rx { color: var(--red); cursor: pointer; }
.pwn-heap { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 10px; margin: 10px 0; }
.pwn-blk { padding: 12px; border-radius: 10px; border: 1px solid var(--border); background: #06080b; font-family: var(--mono); font-size: 12px; }
.pwn-blk.freed { border-style: dashed; border-color: var(--amber); }
.pwn-blk.target { border-color: var(--accent); }
.pwn-blk b { display: block; color: var(--muted); margin-bottom: 4px; }
@media (max-width: 720px) { .pwn-cols { grid-template-columns: 1fr; } }
`);

/* ---------------------------------------------------------------------------
   Parser payload: "A"*40 + p64(0x401196) + b"\xef\xbe" + cyclic(8)
   Trả về mảng số (byte). Ném lỗi chuỗi nếu cú pháp sai.
---------------------------------------------------------------------------- */
function parsePayload(src) {
  src = src.trim();
  if (!src) return [];
  const bytes = [];
  // tách theo dấu + ở mức ngoài cùng (không nằm trong ngoặc / chuỗi)
  const terms = [];
  let depth = 0, q = null, cur = "";
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (q) { cur += ch; if (ch === "\\") { cur += src[++i] || ""; } else if (ch === q) q = null; continue; }
    if (ch === '"' || ch === "'") { q = ch; cur += ch; continue; }
    if (ch === "(") depth++;
    if (ch === ")") depth--;
    if (ch === "+" && depth === 0) { terms.push(cur); cur = ""; continue; }
    cur += ch;
  }
  terms.push(cur);
  if (q) throw "thiếu dấu nháy đóng";
  if (depth !== 0) throw "ngoặc () không khớp";

  const parseStr = (t) => {
    // bỏ tiền tố b, rb…
    t = t.replace(/^[a-z]*(['"])/, "$1");
    const quote = t[0];
    const body = t.slice(1, -1);
    const out = [];
    for (let i = 0; i < body.length; i++) {
      if (body[i] === "\\") {
        const n = body[i + 1];
        if (n === "x") { out.push(parseInt(body.substr(i + 2, 2), 16)); i += 3; }
        else if (n === "n") { out.push(10); i++; }
        else if (n === "t") { out.push(9); i++; }
        else if (n === "r") { out.push(13); i++; }
        else if (n === "0") { out.push(0); i++; }
        else if (n === "\\") { out.push(92); i++; }
        else { out.push(n.charCodeAt(0)); i++; }
      } else out.push(body.charCodeAt(i) & 0xff);
    }
    return out;
  };
  const toInt = (s) => {
    s = s.trim();
    if (/^0x[0-9a-f]+$/i.test(s)) return parseInt(s, 16);
    if (/^-?\d+$/.test(s)) return parseInt(s, 10);
    throw "số không hợp lệ: " + s;
  };
  const pack = (val, n) => { const r = []; let v = BigInt(val) & ((1n << BigInt(8 * n)) - 1n); for (let i = 0; i < n; i++) { r.push(Number(v & 0xffn)); v >>= 8n; } return r; };

  for (let term of terms) {
    term = term.trim();
    if (!term) continue;
    let m;
    if ((m = term.match(/^(\d+)\s*\*\s*(.+)$/)) || (m = term.match(/^(.+?)\s*\*\s*(\d+)$/))) {
      // lặp: số * chuỗi  hoặc  chuỗi * số
      const [a, b] = /^\d+$/.test(m[1].trim()) ? [m[1], m[2]] : [m[2], m[1]];
      const count = parseInt(a, 10);
      const unit = b.trim();
      let chunk;
      if (/^[a-z]*['"]/.test(unit)) chunk = parseStr(unit);
      else if ((m = unit.match(/^(["'])(.*)\1$/))) chunk = parseStr(unit);
      else throw "không lặp được: " + unit;
      for (let i = 0; i < count; i++) bytes.push(...chunk);
    } else if ((m = term.match(/^(?:p|pack)?p?(8|16|32|64)\s*\(\s*(.+?)\s*\)$/)) || (m = term.match(/^p(32|64)\s*\(\s*(.+?)\s*\)$/))) {
      const n = parseInt(m[1], 10) / 8;
      bytes.push(...pack(toInt(m[2]), n));
    } else if ((m = term.match(/^cyclic\s*\(\s*(\d+)\s*\)$/))) {
      const n = parseInt(m[1], 10);
      const pat = cyclicPattern(n);
      bytes.push(...pat);
    } else if (/^[a-z]*['"]/.test(term)) {
      bytes.push(...parseStr(term));
    } else {
      throw "không hiểu: " + term;
    }
  }
  return bytes;
}
function cyclicPattern(n) {
  const al = "abcdefghijklmnopqrstuvwxyz";
  const out = [];
  outer: for (const a of al) for (const b of al) for (const c of al) for (const d of al) {
    for (const ch of [a, b, c, d]) { out.push(ch.charCodeAt(0)); if (out.length >= n) break outer; }
  }
  return out.slice(0, n);
}
const hexB = (v) => v.toString(16).padStart(2, "0");
const printCh = (v) => (v >= 32 && v < 127 ? String.fromCharCode(v) : ".");

/* ===========================================================================
   1) Widget "stack" — is_admin overflow (bài 1, giữ nguyên hành vi, nâng cấp nhẹ)
=========================================================================== */
function mountStack(el) {
  const root = h(`
    <div class="window pwn-term">
      <div class="window-bar"><i></i><i></i><i></i><span>./login</span></div>
      <div style="padding:18px">
        <div class="pwn-term"><input class="pwn-in" placeholder="Nhập dữ liệu cho gets(buf)…  thử: AAAAAAAAAAAAAAAAB" spellcheck="false" maxlength="40"></div>
        <div class="pwn-cols" style="margin-top:14px">
          <div class="pwn-rows">
            <div class="stack-label"><span>char buf[16]</span><span class="cnt">0/16</span></div>
            <div class="pwn-cells c-buf"></div>
            <div class="stack-label" style="margin-top:10px"><span>int is_admin</span><span>4 byte</span></div>
            <div class="pwn-cells c-adm" style="grid-template-columns:repeat(4,1fr);max-width:50%"></div>
            <div class="stack-label" style="margin-top:10px"><span>saved rbp / ret</span></div>
            <div class="pwn-cells c-ret"></div>
          </div>
          <div class="pwn-state"></div>
        </div>
      </div>
    </div>`);
  el.replaceWith(root);
  const inp = root.querySelector("input");
  const mk = (sel, n, cls) => { const c = root.querySelector(sel); const a = []; for (let i = 0; i < n; i++) { const d = h(`<div class="pwn-cell ${cls}">00</div>`); c.appendChild(d); a.push(d); } return a; };
  const buf = mk(".c-buf", 16, "buf"), adm = mk(".c-adm", 4, "rbp"), ret = mk(".c-ret", 8, "ret");
  const retInit = [0x5d, 0x11, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00];
  const state = root.querySelector(".pwn-state");
  const cnt = root.querySelector(".cnt");
  const render = () => {
    const bytes = [...new TextEncoder().encode(inp.value)];
    [...buf, ...adm, ...ret].forEach((cell, i) => {
      const filled = i < bytes.length;
      const v = filled ? bytes[i] : i >= 20 ? retInit[i - 20] : 0;
      cell.textContent = hexB(v);
      cell.classList.toggle("over", filled && i >= 16 && i < 20);
      cell.classList.toggle("empty", !filled && i < 20);
      cell.title = filled ? JSON.stringify(String.fromCharCode(v)) : "";
    });
    cnt.textContent = `${Math.min(bytes.length, 16)}/16`;
    const val = ([0, 1, 2, 3].reduce((a, i) => a | ((bytes[16 + i] ?? 0) << (i * 8)), 0)) >>> 0;
    let html = `is_admin = <span class="${val ? "good" : "bad"}">0x${val.toString(16).padStart(8, "0")}</span> (${val})`;
    html += `<hr><span class="dim">── output ──</span><br>`;
    if (bytes.length >= 24) html += `<span class="bad">Segmentation fault (core dumped)</span><br><span class="dim">(đã tràn qua cả saved rbp / ret)</span>`;
    else if (val === 0x41424344) html += `<span class="good">Welcome, super admin!</span><br><span class="good">${d64(PWN_SECRETS.pw1)}</span><br><span class="good">${d64(PWN_SECRETS.pw2)}</span>`;
    else if (val !== 0) html += `<span class="good">Welcome, admin!</span><br><span class="good">${d64(PWN_SECRETS.pw1)}</span><br><span class="dim">Flag 2 cần is_admin == 0x41424344</span>`;
    else html += `<span class="dim">Access denied. You are not admin.</span>`;
    state.innerHTML = html;
  };
  inp.addEventListener("input", render);
  render();
}
WIDGETS.stack = mountStack;

/* ===========================================================================
   2) Widget "ret2win" — stack frame đầy đủ, nhập payload, xem rip nhảy đâu
   data-offset: số byte đệm tới ret (mặc định 40). data-win: địa chỉ hàm win.
   data-flag: khoá trong PWN_SECRETS in ra khi rip == win. data-align: cần ret-slide?
=========================================================================== */
function mountRet2win(el) {
  const offset = +(el.dataset.offset || 40);
  const winAddr = BigInt(el.dataset.win || "0x401196");
  const flagKey = el.dataset.flag || "ret1";
  const needAlign = el.dataset.align === "1";
  const retGadget = BigInt(el.dataset.retg || "0x40101a");
  const bufStart = 0x7fffffffdd00n;
  const slots = Math.ceil(offset / 8);
  const funcs = [
    ["main", "0x401152"], ["vuln", "0x401176"], ["win", "0x" + winAddr.toString(16)],
    ["system@plt", "0x401040"], ["ret gadget", "0x" + retGadget.toString(16)],
  ];
  const root = h(`
    <div class="window pwn-term">
      <div class="window-bar"><i></i><i></i><i></i><span>./ret2win — read(0, buf, 256) rồi return</span></div>
      <div style="padding:18px">
        <div class="pwn-chips">${funcs.map((f) => `<span class="pwn-chip" data-v="${f[1]}">${f[0]} = ${f[1]}</span>`).join("")}</div>
        <div class="pwn-term"><input class="pwn-in" placeholder='payload, ví dụ:  "A"*${offset} + p64(0x401176)' spellcheck="false"></div>
        <div class="pwn-cols" style="margin-top:14px">
          <div class="pwn-rows c-rows"></div>
          <div class="pwn-state"></div>
        </div>
      </div>
    </div>`);
  el.replaceWith(root);
  const inp = root.querySelector("input");
  const rowsEl = root.querySelector(".c-rows");
  const state = root.querySelector(".pwn-state");
  root.querySelectorAll(".pwn-chip").forEach((ch) => ch.addEventListener("click", () => {
    const sel = inp.selectionStart ?? inp.value.length;
    inp.value = inp.value.slice(0, sel) + ch.dataset.v + inp.value.slice(sel);
    inp.focus(); render();
  }));

  // offset = số byte đệm (buf + saved rbp) để chạm return address. slots hàng đệm, rồi ret, rồi stack trên ret.
  // byte offset của return address = `offset` (trùng slots*8 khi offset chia hết 8).
  const retOff = offset;
  const rowDefs = [];
  for (let i = 0; i < slots; i++) rowDefs.push({ label: i === 0 ? "buf" : (i === slots - 1 ? "saved rbp" : ""), cls: i === slots - 1 ? "rbp" : "buf", off: i * 8 });
  rowDefs.push({ label: "return addr", cls: "ret", off: retOff });
  rowDefs.push({ label: "ret+8", cls: "ret", off: retOff + 8 });
  rowDefs.push({ label: "ret+16", cls: "ret", off: retOff + 16 });
  rowDefs.forEach((rd) => {
    const row = h(`<div class="pwn-row"><span class="addr" title="${rd.label}">${rd.label || "…"}</span><div class="pwn-cells" style="grid-template-columns:repeat(8,1fr)"></div></div>`);
    rd.cells = [];
    for (let i = 0; i < 8; i++) { const d = h(`<div class="pwn-cell ${rd.cls} empty">00</div>`); row.querySelector(".pwn-cells").appendChild(d); rd.cells.push(d); }
    rowsEl.appendChild(row);
  });

  const render = () => {
    let bytes;
    try { bytes = parsePayload(inp.value); inp.classList.remove("bad"); }
    catch (e) { inp.classList.add("bad"); state.innerHTML = `<span class="bad">Lỗi cú pháp payload:</span><br>${esc(String(e))}<br><hr><span class="dim">Cú pháp: "A"*${offset} + p64(0x...) , nối bằng +, \\xNN trong chuỗi đều được.</span>`; return; }
    rowDefs.forEach((rd) => rd.cells.forEach((cell, ci) => {
      const idx = rd.off + ci;
      const filled = idx < bytes.length;
      const v = filled ? bytes[idx] : 0;
      cell.textContent = hexB(v);
      cell.classList.toggle("empty", !filled);
      cell.title = filled ? `offset ${idx} = ${JSON.stringify(String.fromCharCode(v))}` : "";
    }));
    const readQ = (off) => { let v = 0n; for (let i = 0; i < 8; i++) v |= BigInt(bytes[off + i] ?? 0) << BigInt(i * 8); return v; };
    const len = bytes.length;
    let html = `<span class="dim">read() đọc ${len} byte vào buf</span><hr>`;
    html += `<span class="dim">cần đệm <b>${offset}</b> byte (buf + saved rbp) để chạm return address</span><hr>`;
    if (len < retOff + 8) {
      html += `<span class="warn">Payload chưa chạm hết return address.</span><br><span class="dim">Hiện mới ${len}/${retOff + 8} byte (cần đủ ${retOff}+8).</span>`;
      state.innerHTML = html; return;
    }
    const first = readQ(retOff);        // giá trị tại return address
    const second = readQ(retOff + 8);   // ô kế tiếp trên stack
    html += `<span class="pwn-reg">rip</span> ← 0x${first.toString(16)}<br>`;
    const name = funcs.find((f) => BigInt(f[1]) === first);
    html += name ? `<span class="dim">nhảy tới <b>${name[0]}</b></span><br>` : `<span class="dim">địa chỉ không khớp hàm nào</span><br>`;
    const printable = (v) => v >= 0x20n && v <= 0x7effffffffffn && v > 0x404040n;
    if (!needAlign) {
      if (first === winAddr) html += `<hr><span class="good">Chương trình nhảy vào win() → in flag:</span><br><span class="good">${d64(PWN_SECRETS[flagKey])}</span>`;
      else if (printable(first)) html += `<hr><span class="bad">SIGSEGV tại 0x${first.toString(16)}</span><br><span class="dim">return address chứa dữ liệu đệm "AAAA…" → bạn chưa đặt đúng p64(địa chỉ win).</span>`;
      else html += `<hr><span class="bad">SIGSEGV tại 0x${first.toString(16)}</span><br><span class="dim">Đặt p64(địa chỉ hàm win) ngay sau ${offset} byte đệm.</span>`;
    } else {
      if (first === retGadget && second === winAddr) html += `<hr><span class="good">ret gadget căn rsp về bội số 16, rồi win() chạy mượt:</span><br><span class="good">${d64(PWN_SECRETS[flagKey])}</span>`;
      else if (first === winAddr) html += `<hr><span class="warn">rip tới win() nhưng tại lệnh <code>call</code> bên trong, rsp lệch 16 byte → movaps gây SIGSEGV.</span><br><span class="dim">Chèn một "ret gadget" (0x${retGadget.toString(16)}) NGAY TRƯỚC địa chỉ win để đẩy rsp thêm 8 byte.</span>`;
      else if (first === retGadget) html += `<hr><span class="dim">ret gadget sẽ nhảy tiếp tới 0x${second.toString(16)}… đặt p64(win) ngay sau nó.</span>`;
      else html += `<hr><span class="bad">SIGSEGV tại 0x${first.toString(16)}</span>`;
    }
    state.innerHTML = html;
  };
  inp.addEventListener("input", render);
  render();
}
WIDGETS.ret2win = mountRet2win;

/* ===========================================================================
   3) Widget "fmtstr" — mô phỏng printf(user_input) với stack giả có bí mật
   Người học nhập format string, xem %p/%x/%s/%n đọc được gì.
=========================================================================== */
function mountFmt(el) {
  const flagKey = el.dataset.flag || "fmt1";
  const goal = el.dataset.goal || "canary"; // "canary" = leak canary bằng %N$p ; "secret" = deref con trỏ bằng %N$s
  const canary = 0x3b8f71a2c4d90000n; // byte thấp = 00 (đặc trưng canary)
  const secretStr = "SECRET=opensesame";
  // tham số thứ k của printf ↔ stack[k-1]. Con trỏ tới chuỗi bí mật ở slot 5, canary ở slot 6.
  const stack = [
    { v: 0x7fffffffdc50n, note: "con trỏ buf (chuỗi của bạn)", self: true },
    { v: 0x0000000000000000n, note: "0" },
    { v: 0x0000000a2e323125n, note: "rác" },
    { v: 0x00000000004052a0n, note: "con trỏ thường" },
    { v: 0x0000000000404090n, note: "→ chuỗi bí mật", ptrTo: "secret" },
    { v: canary, note: "stack canary", canary: true },
    { v: 0x00007ffff7a1c083n, note: "địa chỉ libc (saved)" },
    { v: 0x00000000004011b6n, note: "return addr" },
  ];
  const chips = goal === "canary"
    ? [["%p", "%p"], ["%p.%p.%p.%p.%p.%p", "%p ×6"], ["%6$p", "%6$p"], ["AAAA.%p.%p.%p", "định vị input"]]
    : [["%s", "%s"], ["%p", "%p"], ["%5$s", "%5$s (deref)"], ["%5$p", "%5$p (địa chỉ)"]];
  const root = h(`
    <div class="window pwn-term">
      <div class="window-bar"><i></i><i></i><i></i><span>./echo — printf(buf) truyền thẳng input làm format</span></div>
      <div style="padding:18px">
        <div class="pwn-chips">${chips.map(([v, t]) => `<span class="pwn-chip" data-v="${esc(v)}">${esc(t)}</span>`).join("")}</div>
        <div class="pwn-term"><input class="pwn-in" placeholder="Nhập format string… thử %p.%p.%p" spellcheck="false" value="${goal === "canary" ? "%p.%p.%p" : "%s"}"></div>
        <div class="pwn-cols" style="margin-top:14px">
          <div class="pwn-rows c-stack"></div>
          <div class="pwn-state"></div>
        </div>
      </div>
    </div>`);
  el.replaceWith(root);
  const inp = root.querySelector("input");
  const stackEl = root.querySelector(".c-stack");
  const state = root.querySelector(".pwn-state");
  root.querySelectorAll(".pwn-chip").forEach((ch) => ch.addEventListener("click", () => { inp.value = ch.dataset.v; inp.focus(); render(); }));

  stackEl.innerHTML = `<div class="stack-label"><span>stack (tham số của printf)</span></div>` +
    stack.map((s, i) => `<div class="pwn-row"><span class="addr">%${i + 1}$</span><div style="font-family:var(--mono);font-size:11.5px;color:${s.canary ? "var(--violet)" : s.ptrTo ? "var(--cyan)" : "var(--muted)"}">0x${s.v.toString(16).padStart(16, "0")} <span class="dim">; ${s.note}</span></div></div>`).join("");

  const render = () => {
    const fmt = inp.value;
    let out = "", argPos = 0, leakedCanary = false, leakedSecret = false, crash = false;
    for (let i = 0; i < fmt.length; i++) {
      if (fmt[i] !== "%") { out += fmt[i]; continue; }
      const m = fmt.slice(i).match(/^%(\d+\$)?([pxsnd%])/);
      if (!m) { out += fmt[i]; continue; }
      i += m[0].length - 1;
      const spec = m[2];
      if (spec === "%") { out += "%"; continue; }
      const idx = m[1] ? parseInt(m[1]) - 1 : argPos++;
      const slot = stack[idx];
      if (!slot) { out += "(nil)"; continue; }
      if (spec === "p") out += "0x" + slot.v.toString(16);
      else if (spec === "x") out += (slot.v & 0xffffffffn).toString(16);
      else if (spec === "d") out += BigInt.asIntN(64, slot.v).toString();
      else if (spec === "s") {
        if (slot.ptrTo === "secret") { out += secretStr; leakedSecret = true; }
        else if (slot.self) { out += fmt.slice(0, 8); }
        else if (slot.v > 0x7f0000000000n || slot.v < 0x1000n) { out += "<SIGSEGV: deref 0x" + slot.v.toString(16) + ">"; crash = true; }
        else out += "\\x" + (slot.v & 0xffn).toString(16);
      }
      if (slot.canary && (spec === "p" || spec === "x")) leakedCanary = true;
    }
    let html = `<span class="dim">printf xuất ra:</span><br><span class="lk">${esc(out) || "(rỗng)"}</span><hr>`;
    if (crash) html += `<span class="bad">%s vừa deref một địa chỉ không đọc được → chương trình crash.</span><br>`;
    if (goal === "canary") {
      if (leakedCanary) html += `<span class="good">Đã leak canary = 0x${canary.toString(16)} (chú ý byte cuối 00).</span><br><span class="good">${d64(PWN_SECRETS[flagKey])}</span>`;
      else html += `<span class="dim">Canary nằm ở tham số thứ 6. Đếm số <b>%p</b> hoặc dùng trực tiếp <b>%6$p</b>.</span>`;
    } else {
      if (leakedSecret) html += `<span class="good">%s đã đi theo con trỏ ở tham số 5 và đọc chuỗi bí mật.</span><br><span class="good">${d64(PWN_SECRETS[flagKey])}</span>`;
      else html += `<span class="dim">Tham số 5 là con trỏ tới chuỗi bí mật. Dùng <b>%5$s</b> để in nội dung nó trỏ tới (khác với %5$p chỉ in địa chỉ).</span>`;
    }
    state.innerHTML = html;
  };
  inp.addEventListener("input", render);
  render();
}
WIDGETS.fmtstr = mountFmt;

/* ===========================================================================
   4) Widget "rop" — xây chuỗi ROP từ danh sách gadget để gọi system("/bin/sh")
=========================================================================== */
function mountRop(el) {
  const flagKey = el.dataset.flag || "rop1";
  const gadgets = [
    { label: 'pop rdi ; ret', addr: 0x401293n, kind: "pop_rdi" },
    { label: 'pop rsi ; ret', addr: 0x401295n, kind: "pop_rsi" },
    { label: 'ret', addr: 0x40101an, kind: "ret" },
    { label: '"/bin/sh" (bss)', addr: 0x404050n, kind: "binsh" },
    { label: 'system@plt', addr: 0x401040n, kind: "system" },
    { label: 'win()', addr: 0x401210n, kind: "win" },
  ];
  const offset = 40;
  const root = h(`
    <div class="window pwn-term">
      <div class="window-bar"><i></i><i></i><i></i><span>./rop — buffer overflow, NX bật, cần ROP</span></div>
      <div style="padding:18px">
        <p style="margin:0 0 8px;color:var(--muted);font-size:13.5px">Mục tiêu: gọi <code>system("/bin/sh")</code>. system cần tham số 1 (rdi) = địa chỉ chuỗi "/bin/sh". Bấm gadget để xếp vào chuỗi ROP sau ${offset} byte đệm.</p>
        <div class="pwn-chips c-gadgets"></div>
        <div class="pwn-rop c-chain"></div>
        <div class="pwn-state" style="margin-top:12px"></div>
      </div>
    </div>`);
  el.replaceWith(root);
  const chainEl = root.querySelector(".c-chain");
  const gEl = root.querySelector(".c-gadgets");
  const state = root.querySelector(".pwn-state");
  const chain = [];
  gadgets.forEach((g) => { const c = h(`<span class="pwn-chip">${g.label} <span class="dim">0x${g.addr.toString(16)}</span></span>`); c.addEventListener("click", () => { chain.push(g); render(); }); gEl.appendChild(c); });

  const render = () => {
    chainEl.innerHTML = `<div class="pwn-rop-slot"><span class="ra">offset</span><span><span class="dim">"A" × ${offset}  (đệm tới return address)</span></span><span></span></div>` +
      chain.map((g, i) => `<div class="pwn-rop-slot"><span class="ra">ret+${(i + 1) * 8}</span><span>0x${g.addr.toString(16)} <span class="dim">; ${g.label}</span></span><span class="rx" data-i="${i}">✕</span></div>`).join("");
    chainEl.querySelectorAll(".rx").forEach((x) => x.addEventListener("click", () => { chain.splice(+x.dataset.i, 1); render(); }));
    // mô phỏng: kiểm tra chuỗi pop rdi ; "/bin/sh" ; system  (ret gadget tuỳ chọn để căn)
    const kinds = chain.map((g) => g.kind);
    let html = "";
    // tìm mẫu đúng: [...ret?] pop_rdi, binsh, [ret?] system
    const i0 = kinds.indexOf("pop_rdi");
    let ok = false;
    if (i0 >= 0 && kinds[i0 + 1] === "binsh") {
      const after = kinds.slice(i0 + 2);
      if (after[0] === "system" || (after[0] === "ret" && after[1] === "system")) ok = true;
    }
    const winOnly = kinds.length === 1 && kinds[0] === "win";
    if (ok) html = `<span class="good">$ ./rop</span><br><span class="dim">[+] ROP chain: pop rdi → "/bin/sh" → system()</span><br><span class="good">$ whoami</span><br><span class="good">root</span><br><span class="good">${d64(PWN_SECRETS[flagKey])}</span>`;
    else if (winOnly) html = `<span class="warn">win() in flag phụ, nhưng mục tiêu bài này là mở shell bằng system("/bin/sh").</span>`;
    else if (!chain.length) html = `<span class="dim">Chuỗi ROP trống. Cần: nạp rdi = địa chỉ "/bin/sh", rồi gọi system.</span>`;
    else {
      html = `<span class="dim">Chạy thử chuỗi hiện tại…</span><br>`;
      if (kinds.includes("system") && kinds[kinds.indexOf("system") - 1] !== "binsh" && kinds.indexOf("pop_rdi") < 0)
        html += `<span class="bad">system() chạy nhưng rdi chưa trỏ tới "/bin/sh" → crash.</span>`;
      else if (kinds.includes("pop_rdi") && kinds[kinds.indexOf("pop_rdi") + 1] !== "binsh")
        html += `<span class="warn">Sau "pop rdi" phải là giá trị nạp vào rdi (địa chỉ "/bin/sh").</span>`;
      else html += `<span class="warn">Chưa đủ. Thứ tự đúng: pop rdi ; ret → "/bin/sh" → system@plt.</span>`;
    }
    state.innerHTML = html;
  };
  render();
}
WIDGETS.rop = mountRop;

/* ===========================================================================
   5) Widget "heap" — mô phỏng use-after-free đơn giản (tcache)
=========================================================================== */
function mountHeap(el) {
  const flagKey = el.dataset.flag || "heap1";
  let chunkA = null, chunkB = null, tcache = [];
  const log = [];
  const root = h(`
    <div class="window pwn-term">
      <div class="window-bar"><i></i><i></i><i></i><span>./notes — mô phỏng heap (tcache)</span></div>
      <div style="padding:18px">
        <div class="pwn-chips">
          <span class="pwn-chip" data-op="a_user">a = malloc("user")</span>
          <span class="pwn-chip" data-op="free_a">free(a)</span>
          <span class="pwn-chip" data-op="b_admin">b = malloc("is_admin=1")</span>
          <span class="pwn-chip" data-op="use_a">đọc a (dùng con trỏ cũ)</span>
          <span class="pwn-chip" data-op="reset">reset</span>
        </div>
        <div class="pwn-heap c-heap"></div>
        <div class="pwn-state"></div>
      </div>
    </div>`);
  el.replaceWith(root);
  const heapEl = root.querySelector(".c-heap");
  const state = root.querySelector(".pwn-state");
  const render = () => {
    const blocks = [];
    if (chunkA) blocks.push(`<div class="pwn-blk ${chunkA.freed ? "freed" : ""} ${chunkA.danglRead ? "target" : ""}"><b>0x${chunkA.addr.toString(16)} (a)</b>${chunkA.freed ? '<span class="warn">freed</span> — con trỏ a vẫn trỏ vào đây' : "data: " + esc(chunkA.data)}</div>`);
    if (chunkB) blocks.push(`<div class="pwn-blk target"><b>0x${chunkB.addr.toString(16)} (b)</b>data: ${esc(chunkB.data)}</div>`);
    heapEl.innerHTML = blocks.join("") || '<div class="dim" style="font-family:var(--mono);font-size:12px;color:var(--dim)">heap trống</div>';
    state.innerHTML = log.slice(-7).map((l) => l).join("<br>") || '<span class="dim">Bấm các thao tác. Mục tiêu: để con trỏ a trỏ vào vùng nhớ đã được cấp lại cho b.</span>';
  };
  const ops = {
    a_user() { if (chunkA) return; chunkA = { addr: 0x5555555592a0n, data: "user", freed: false }; log.push(`<span class="dim">a = malloc(16) → 0x${chunkA.addr.toString(16)}, ghi "user"</span>`); },
    free_a() { if (!chunkA || chunkA.freed) return; chunkA.freed = true; tcache.push(chunkA.addr); log.push(`<span class="warn">free(a) → chunk vào tcache. NHƯNG biến a chưa bị gán NULL (dangling pointer).</span>`); },
    b_admin() {
      if (!chunkA || !chunkA.freed) { log.push(`<span class="bad">malloc mới chỉ tái dùng chunk nếu nó đã được free trước đó.</span>`); render(); return; }
      const reused = tcache.pop();
      chunkB = { addr: reused, data: "is_admin=1" };
      chunkA.data = "is_admin=1"; chunkA.freed = false; chunkA.reusedByB = true;
      log.push(`<span class="warn">b = malloc(16) → tcache trả lại <b>chính chunk của a</b> (0x${reused.toString(16)}). Giờ a và b trỏ cùng chỗ.</span>`);
    },
    use_a() {
      if (!chunkA) { log.push(`<span class="dim">chưa có a.</span>`); render(); return; }
      if (chunkA.reusedByB) { chunkA.danglRead = true; log.push(`<span class="good">Đọc qua con trỏ a (đã free & tái cấp cho b): giá trị = "${esc(chunkA.data)}"</span>`); log.push(`<span class="good">Use-After-Free thành công → ${d64(PWN_SECRETS[flagKey])}</span>`); }
      else if (chunkA.freed) { chunkA.danglRead = true; log.push(`<span class="warn">Đọc chunk đã free: dữ liệu rác / con trỏ tcache. Hãy malloc lại (b) để chèn dữ liệu bạn kiểm soát rồi đọc lại.</span>`); }
      else log.push(`<span class="dim">a = "${esc(chunkA.data)}" (bình thường).</span>`);
    },
    reset() { chunkA = chunkB = null; tcache = []; log.length = 0; },
  };
  root.querySelectorAll(".pwn-chip").forEach((c) => c.addEventListener("click", () => { ops[c.dataset.op](); render(); }));
  render();
}
WIDGETS.heap = mountHeap;
