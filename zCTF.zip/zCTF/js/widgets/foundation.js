/* Widget / filesystem cho track Nền tảng */

/* ------------------------------------------------------------------
   Bài "Thiết lập môi trường": kiểm tra checksum, tìm trong ghi chép
   ------------------------------------------------------------------ */
SHELL_FS["setup-lab"] = {
  user: "kali",
  host: "kali",
  motd: 'Máy Kali mới cài. Đọc <span class="hl">cat README.txt</span> để bắt đầu.',
  fs: () => {
    const f = (c2, m) => SH.file(c2, { owner: "kali", ...m });
    const iso = (note) => `KALI-LINUX-2026.1-INSTALLER-AMD64\nbuild: official-release\nnote: ${note}\n`;
    const notes = {
      "2025-picoctf-web.md": "# picoCTF 2025 - Web\n\n## Cookies\n- Sửa cookie name=... trong DevTools → Application\n- flag nằm trong response khi name=18\n\n## Includes\n- xem file .js và .css, flag chia làm 2 nửa\n",
      "2025-picoctf-crypto.md": "# picoCTF 2025 - Crypto\n\n## Mod 26\n- ROT13: tr 'A-Za-z' 'N-ZA-Mn-za-m'\n\n## RSA nhỏ\n- n nhỏ → factordb.com\n- d = pow(e, -1, phi)\n",
      "2026-local-ctf-misc.md": "# Giải nội bộ 2026 - Misc\n\n## Bài 'notes'\n- Đề: tìm lại flag trong ghi chép cũ của chính mình\n- flag (đã base64 để khỏi lộ khi chia sẻ màn hình): " + "ekNURntnaDFfY2gzcF9sNF92dV9raDF9" + "\n",
      "cheatsheet-linux.md": "# Linux cheatsheet\n\nfind / -name '*.txt' 2>/dev/null\ngrep -rni 'password' .\nstrings file | less\n",
      "cheatsheet-python.md": "# Python cheatsheet\n\nbytes.fromhex('7a43')\nbase64.b64decode(s)\nint.from_bytes(b, 'big')\n",
    };
    const notesDir = SH.dir(Object.fromEntries(Object.entries(notes).map(([k, v]) => [k, f(v)])), { owner: "kali" });
    return SH.base({
      "README.txt": f(`Nhiệm vụ:

 1. Bạn tải Kali ISO từ 3 mirror khác nhau vào downloads/. Chỉ một bản là thật.
    Trang chủ Kali công bố checksum trong downloads/SHA256SUMS.
    Chạy sha256sum cho từng file và so với SHA256SUMS. Flag nằm trong bản thật.

 2. Trong notes/ là ghi chép từ các giải trước. Bạn nhớ có lưu một flag
    ở đâu đó nhưng quên mất ở file nào. Tìm nó (gợi ý: grep -ri).
`),
      downloads: SH.dir({
        mirror1: SH.dir({ "kali.iso": f(iso(d64("ekNURntjaDNja3N1bV9zNDFfcjAxfQ=="))) }, { owner: "kali" }),
        mirror2: SH.dir({ "kali.iso": f(iso(d64("ekNURntjaDNja3N1bV9raDBwX3IwMX0="))) }, { owner: "kali" }),
        mirror3: SH.dir({ "kali.iso": f(iso(d64("ekNURnttMXJyMHJfZzE0X200b30="))) }, { owner: "kali" }),
        SHA256SUMS: f("cd216345ef132403f82c4b1be1270853ec5781cad33ac48964270be60ff80105  kali-linux-2026.1-installer-amd64.iso\n"),
      }, { owner: "kali" }),
      notes: notesDir,
      ctf: SH.dir({ "picoctf-2026": SH.dir({ web: SH.dir({}, { owner: "kali" }), crypto: SH.dir({}, { owner: "kali" }), "notes.md": f("# picoCTF 2026\n") }, { owner: "kali" }) }, { owner: "kali" }),
    }, "kali");
  },
};

/* ------------------------------------------------------------------
   Bài "Linux căn bản"
   ------------------------------------------------------------------ */
SHELL_FS["linux-basic"] = {
  host: "zctf",
  motd: 'Kết nối tới zctf thành công. Gõ <span class="hl">help</span> để xem lệnh, thử <span class="hl">cat readme.txt</span>.',
  fs: () => {
    const ips = ["10.0.0.5", "192.168.1.20", "172.16.4.11", "10.0.0.17", "203.0.113.9", "198.51.100.23"];
    const paths = ["/", "/login", "/api/users", "/static/app.js", "/favicon.ico", "/admin", "/search?q=ctf", "/robots.txt"];
    const codes = [200, 200, 200, 304, 404, 403, 500, 302];
    let seed = 1337;
    const rnd = (n) => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) % n);
    const lines = [];
    for (let i = 0; i < 642; i++) {
      const hh = String(8 + Math.floor(i / 60)).padStart(2, "0"), mm = String(i % 60).padStart(2, "0");
      if (i === 417) { lines.push(`${ips[2]} - - [10/Nov/2026:${hh}:${mm}:07] "GET /debug?token=${d64("ekNURntncjNwX3QxbV9rMW1fZDR5fQ==")} HTTP/1.1" 200 51`); continue; }
      lines.push(`${ips[rnd(ips.length)]} - - [10/Nov/2026:${hh}:${mm}:${String(rnd(60)).padStart(2, "0")}] "GET ${paths[rnd(paths.length)]} HTTP/1.1" ${codes[rnd(codes.length)]} ${100 + rnd(9000)}`);
    }
    const names = ["an", "binh", "chi", "dung", "giang", "hai", "khoa", "lan", "minh", "nam", "oanh", "phuc", "quan", "son", "trang", "vy", "tuan", "thu", "long", "mai"];
    const teams = ["red", "blue", "green"];
    const rows = names.map((n, i) => [100 + ((i * 137) % 760), n, teams[(i * 7) % 3]]);
    rows.push([945, "huyen", "red"], [990, "kiet", "blue"], [870, "duc", "red"]);
    rows.sort((a, b) => a[1].localeCompare(b[1]));
    const csv = rows.map((r) => r.join(",")).join("\n") + "\n";
    const f = (c2, m) => SH.file(c2, { owner: "guest", ...m });
    return SH.base({
      "readme.txt": f("Chào mừng tới máy chủ luyện tập!\n\n- Flag 1 nằm trong một thư mục ẩn ngay tại đây.\n- Flag 2 nằm trong logs/access.log. File rất dài, đừng đọc tay.\n- data/scores.csv: mỗi dòng là diem,ten,team.\n- data/secret.txt: ai đó đã đảo ngược một chuỗi base64.\n\nGõ help để xem các lệnh.\n"),
      ".bashrc": f("alias ll='ls -la'\nexport PS1='\\u@\\h:\\w$ '\n"),
      notes: SH.dir({ "todo.txt": f("[x] Cài Linux\n[ ] Chơi OverTheWire Bandit\n[ ] Giải picoCTF\n"), "fake_flag.txt": f("zCTF{khong_phai_flag_nay_dau}\n") }, { owner: "guest" }),
      ".secret": SH.dir({ "flag.txt": f(d64("ekNURntmMWwzXzRuX2MwX2Q0dV9jaDRtfQ==") + "\n") }, { owner: "guest" }),
      logs: SH.dir({ "access.log": f(lines.join("\n") + "\n") }, { owner: "guest" }),
      data: SH.dir({ "scores.csv": f(csv), "secret.txt": f("ekNURntwMXAzX24waV9sM25ofQ==".split("").reverse().join("") + "\n") }, { owner: "guest" }),
    });
  },
};

/* ------------------------------------------------------------------
   Bài "Linux nâng cao": user, group, quyền file, biến môi trường, tiến trình
   ------------------------------------------------------------------ */
SHELL_FS["linux-adv"] = {
  user: "guest",
  host: "srv01",
  groups: { guest: ["dev"] },
  gids: { dev: 1002 },
  env: { ZCTF_TOKEN: d64("ekNURntiMTNuX20wMV90cnVvbmd9"), EDITOR: "nano", LANG: "vi_VN.UTF-8" },
  motd: 'Bạn đăng nhập vào srv01 với user <span class="hl">guest</span>. Đọc <span class="hl">cat README.txt</span>.',
  cmds: {
    ps: () => [
      "USER       PID %CPU %MEM COMMAND",
      "root         1  0.0  0.1 /sbin/init",
      "root       412  0.0  0.2 /usr/sbin/cron -f",
      "root       530  0.0  0.4 /usr/sbin/sshd -D",
      "www-data   601  0.1  1.2 nginx: worker process",
      "alice      877  0.0  0.6 /usr/bin/python3 /srv/project/app.py",
      "guest     1337  0.0  0.1 -bash",
      "guest     1402  0.0  0.1 ps aux",
    ].join("\n"),
    groups: (a, stdin, ctx) => "guest dev",
  },
  fs: () => {
    const g = (c2, m) => SH.file(c2, { owner: "guest", ...m });
    return SH.base({
      "README.txt": g(`srv01 — bài tập quản trị quyền

 1. ~/note.txt là file của bạn nhưng không đọc được. Vì sao? Sửa lại.
 2. /srv/project/ có tài liệu nội bộ của nhóm dev. Bạn có thuộc nhóm đó không?
    Dùng id và ls -l để hiểu vì sao bạn đọc được file nào.
 3. Ứng dụng đọc cấu hình từ biến môi trường. Xem các biến của phiên hiện tại.

Lệnh hữu ích: id, groups, ls -l, chmod, env, ps aux
`),
      "note.txt": g(d64("ekNURntjaG0wZF9jNG5fdGhpM3R9") + "\n", { mode: "----------" }),
      ".ssh": SH.dir({
        "id_ed25519": g("-----BEGIN OPENSSH PRIVATE KEY-----\n(khoá demo, không dùng được)\n-----END OPENSSH PRIVATE KEY-----\n", { mode: "-rw-------" }),
        "id_ed25519.pub": g("ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIGd1ZXN0LWtleS1kZW1v guest@srv01\n"),
        authorized_keys: g("", { mode: "-rw-------" }),
      }, { owner: "guest", mode: "drwx------" }),
    }, "guest", {
      etc: SH.dir({
        passwd: SH.file("root:x:0:0:root:/root:/bin/bash\nalice:x:1001:1001:Alice:/home/alice:/bin/bash\nguest:x:1000:1000::/home/guest:/bin/bash\nwww-data:x:33:33:www-data:/var/www:/usr/sbin/nologin"),
        group: SH.file("root:x:0:\nalice:x:1001:\ndev:x:1002:alice,guest\nguest:x:1000:"),
        shadow: SH.file("root:*:19000:0:99999:7:::", { mode: "-rw-r-----", group: "shadow" }),
        hostname: SH.file("srv01"),
      }),
      srv: SH.dir({ project: SH.dir({
        "README.md": SH.file("# Dự án nội bộ\nTài liệu chỉ dành cho nhóm dev.\n", { owner: "alice", group: "dev", mode: "-rw-r-----" }),
        "design.txt": SH.file("Ghi chú thiết kế: " + d64("ekNURntncjB1cF9kM3ZfZDBjX2R1MGN9") + "\n", { owner: "alice", group: "dev", mode: "-rw-r-----" }),
        "salary.xlsx": SH.file("(bảng lương — chỉ alice)\n", { owner: "alice", group: "alice", mode: "-rw-------" }),
        "app.py": SH.file("import os\nTOKEN = os.environ.get('ZCTF_TOKEN')\n", { owner: "alice", group: "dev", mode: "-rw-r--r--" }),
      }, { owner: "alice", group: "dev", mode: "drwxr-x---" }) }),
    });
  },
};

/* ------------------------------------------------------------------
   Bài "Mạng máy tính": nmap, dig, nc tới dịch vụ
   ------------------------------------------------------------------ */
const NET_TARGET = "10.10.10.5";
const NET_ZONE = [
  ["zctf.local.", "3600", "SOA", "ns1.zctf.local. admin.zctf.local. 2026111001 3600 600 86400 3600"],
  ["zctf.local.", "3600", "NS", "ns1.zctf.local."],
  ["zctf.local.", "3600", "A", NET_TARGET],
  ["zctf.local.", "3600", "MX", "10 mail.zctf.local."],
  ["ns1.zctf.local.", "3600", "A", NET_TARGET],
  ["mail.zctf.local.", "3600", "A", "10.10.10.25"],
  ["www.zctf.local.", "3600", "CNAME", "zctf.local."],
  ["dev-internal.zctf.local.", "3600", "A", "10.10.10.77"],
  ["s3cr3t-7f.zctf.local.", "3600", "TXT", '"' + "ekNURnt6MG4zX3RyNG5zZjNyX2wwfQ==" + '"'],
];

SHELL_FS["net-lab"] = {
  user: "student",
  host: "attacker",
  motd: `Máy tấn công trong mạng lab 10.10.10.0/24. Mục tiêu: <span class="hl">${NET_TARGET}</span> (tên miền zctf.local). Lệnh thêm: <span class="hl">ip a</span>, <span class="hl">nmap</span>, <span class="hl">dig</span>, <span class="hl">nc</span>.`,
  fs: () => SH.base({ "README.txt": SH.file(`Mạng lab:
  - máy bạn:  10.10.10.2
  - mục tiêu: ${NET_TARGET}  (DNS server của zctf.local cũng chạy ở đây)

Gợi ý quy trình: nmap → xem dịch vụ → nc vào từng cổng → đọc banner.
`, { owner: "student" }) }, "student"),
  cmds: {
    ip: (a) => (a[0] === "a" || a[0] === "addr" ? "1: lo: <LOOPBACK,UP> mtu 65536\n    inet 127.0.0.1/8 scope host lo\n2: eth0: <BROADCAST,MULTICAST,UP> mtu 1500\n    link/ether 02:42:0a:0a:0a:02\n    inet 10.10.10.2/24 brd 10.10.10.255 scope global eth0" : a[0] === "r" || a[0] === "route" ? "default via 10.10.10.1 dev eth0\n10.10.10.0/24 dev eth0 proto kernel scope link src 10.10.10.2" : "Usage: ip a | ip route"),
    ifconfig: () => "eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500\n        inet 10.10.10.2  netmask 255.255.255.0  broadcast 10.10.10.255",
    nmap: async (a) => {
      const host = a.filter((x) => !x.startsWith("-")).pop();
      if (!host) throw "Usage: nmap [-sV] [-p-] <target>";
      await new Promise((r) => setTimeout(r, 500));
      const ok = [NET_TARGET, "zctf.local"].includes(host);
      const head = `Starting Nmap 7.94 ( https://nmap.org )\nNmap scan report for ${host}${host === "zctf.local" ? " (" + NET_TARGET + ")" : ""}`;
      if (!ok) return `${head}\nNote: Host seems down. If it is really up, but blocking our ping probes, try -Pn\nNmap done: 1 IP address (0 hosts up)`;
      const sv = a.includes("-sV") || a.includes("-A");
      const all = a.includes("-p-");
      const ports = [["21/tcp", "ftp", "vsftpd 3.0.5"], ["22/tcp", "ssh", "OpenSSH 9.6p1 Ubuntu 3ubuntu13"], ["53/tcp", "domain", "ISC BIND 9.18.24"], ["80/tcp", "http", "nginx 1.24.0"]];
      if (all) ports.push(["1337/tcp", "waste?", "zCTF custom service (banner: ZCTF-SVC v2)"]);
      return `${head}\nHost is up (0.00042s latency).\nNot shown: ${all ? 65530 : 995} closed tcp ports (reset)\nPORT     STATE SERVICE${sv ? "  VERSION" : ""}\n` +
        ports.map(([p, s, v]) => `${p.padEnd(9)}open  ${s.padEnd(8)}${sv ? v : ""}`).join("\n") +
        `\n\nNmap done: 1 IP address (1 host up) scanned in ${all ? "41.17" : "0.18"} seconds` +
        (all ? "" : "\n(Mặc định nmap chỉ quét 1000 cổng phổ biến. Thêm -p- để quét đủ 65535 cổng.)");
    },
    dig: (a) => {
      const types = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA", "AXFR", "ANY"];
      const type = (a.find((x) => types.includes(x.toUpperCase())) || "A").toUpperCase();
      const server = (a.find((x) => x.startsWith("@")) || "@10.10.10.1").slice(1);
      let name = a.find((x) => !x.startsWith("@") && !x.startsWith("+") && !types.includes(x.toUpperCase()));
      if (!name) throw "Usage: dig [@server] <name> [type]";
      name = name.replace(/\.?$/, ".");
      const head = `; <<>> DiG 9.18.24 <<>> ${a.join(" ")}\n;; global options: +cmd`;
      if (type === "AXFR") {
        if (server !== NET_TARGET && server !== "ns1.zctf.local") return `${head}\n; Transfer failed. (hỏi đúng DNS server có thẩm quyền: dig @${NET_TARGET} zctf.local AXFR)`;
        if (name !== "zctf.local.") return `${head}\n; Transfer failed.`;
        return `${head}\n` + [...NET_ZONE, NET_ZONE[0]].map((r) => `${r[0].padEnd(28)}${r[1].padEnd(6)}IN\t${r[2].padEnd(6)}${r[3]}`).join("\n") + `\n;; XFR size: ${NET_ZONE.length + 1} records`;
      }
      const ans = NET_ZONE.filter((r) => r[0] === name && (type === "ANY" || r[2] === type || (type === "A" && r[2] === "CNAME")));
      const status = NET_ZONE.some((r) => r[0] === name) ? "NOERROR" : "NXDOMAIN";
      return `${head}\n;; ->>HEADER<<- opcode: QUERY, status: ${status}\n\n;; QUESTION SECTION:\n;${name}\t\tIN\t${type}\n` +
        (ans.length ? `\n;; ANSWER SECTION:\n` + ans.map((r) => `${r[0].padEnd(28)}${r[1].padEnd(6)}IN\t${r[2].padEnd(6)}${r[3]}`).join("\n") : "") +
        `\n\n;; SERVER: ${server}#53(${server}) (UDP)`;
    },
    host: (a) => { const r = NET_ZONE.find((x) => x[0] === (a[0] || "").replace(/\.?$/, ".") && x[2] === "A"); return r ? `${a[0]} has address ${r[3]}` : `Host ${a[0]} not found: 3(NXDOMAIN)`; },
    ping: (a) => { const t = a.filter((x) => !x.startsWith("-")).pop(); if (!t) throw "ping: usage error: Destination address required"; const ip = t === "zctf.local" ? NET_TARGET : t; if (!/^10\.10\.10\.(1|2|5|25|77)$/.test(ip)) return `PING ${t} 56(84) bytes of data.\n--- ${t} ping statistics ---\n3 packets transmitted, 0 received, 100% packet loss`; return `PING ${t} (${ip}) 56(84) bytes of data.\n64 bytes from ${ip}: icmp_seq=1 ttl=64 time=0.41 ms\n64 bytes from ${ip}: icmp_seq=2 ttl=64 time=0.38 ms\n--- ${t} ping statistics ---\n2 packets transmitted, 2 received, 0% packet loss`; },
  },
  nc: (() => {
    const svc1337 = () => {
      let hello = null;
      return {
        banner: "ZCTF-SVC v2 ready. Gõ HELP để xem lệnh.",
        prompt: "",
        onLine: (l) => {
          const [cmd, ...rest] = l.trim().split(/\s+/);
          switch ((cmd || "").toUpperCase()) {
            case "HELP": return "Lệnh: HELLO <tên> | FLAG | TIME | QUIT";
            case "HELLO": if (!rest.length) return "ERR cú pháp: HELLO <tên>"; hello = rest.join(" "); return `OK xin chào ${hello}`;
            case "TIME": return "OK " + new Date().toISOString();
            case "FLAG": return hello ? "OK " + d64("ekNURntiNG5uM3JfZ3I0YmIxbmd9") : "ERR phải chào (HELLO) trước đã";
            case "QUIT": return { out: "BYE", close: true };
            case "": return null;
            default: return "ERR lệnh không hợp lệ: " + cmd;
          }
        },
      };
    };
    const svcHttp = () => {
      const req = [];
      return {
        banner: "",
        prompt: "",
        onLine: (l) => {
          if (l.trim() !== "" || !req.length) { if (l.trim() !== "") req.push(l); return null; }
          const [line0, ...hdr] = req;
          const m = line0.match(/^(GET|HEAD|POST|PUT|DELETE|OPTIONS)\s+(\S+)\s+HTTP\/1\.[01]$/);
          const resp = (code, msg, body) => ({ out: `HTTP/1.1 ${code} ${msg}\nServer: nginx/1.24.0\nContent-Type: text/html; charset=utf-8\nContent-Length: ${utf8.encode(body).length}\nConnection: close\n\n${body}`, close: true, closeMsg: "Connection closed by foreign host." });
          if (!m) return resp(400, "Bad Request", "<h1>400 Bad Request</h1>Dòng đầu phải có dạng: GET /duong-dan HTTP/1.1");
          if (/^HTTP\/1\.1$/.test(line0.split(" ")[2]) && !hdr.some((x) => /^host\s*:/i.test(x))) return resp(400, "Bad Request", "<h1>400 Bad Request</h1>HTTP/1.1 bắt buộc có header Host");
          if (m[2] === "/") return resp(200, "OK", "<html><body><h1>zctf.local</h1><p>Trang đang bảo trì. Tài nguyên: /about, /flag</p></body></html>");
          if (m[2] === "/about") return resp(200, "OK", "<p>Máy chủ lab của zCTF.</p>");
          if (m[2] === "/flag") return resp(200, "OK", d64("ekNURntoNzdwX2I0bmdfdDR5fQ=="));
          return resp(404, "Not Found", "<h1>404 Not Found</h1>");
        },
      };
    };
    const svcFtp = () => {
      let user = null, logged = false;
      return {
        banner: "220 (vsFTPd 3.0.5)",
        prompt: "",
        onLine: (l) => {
          const [cmd, ...rest] = l.trim().split(/\s+/);
          const arg = rest.join(" ");
          switch ((cmd || "").toUpperCase()) {
            case "USER": user = arg; return "331 Please specify the password.";
            case "PASS": if (user && user.toLowerCase() === "anonymous") { logged = true; return "230 Login successful."; } return "530 Login incorrect.";
            case "LIST": case "LS": return logged ? "-rw-r--r--    1 0        0             164 Nov 10 08:00 ghi_chu_dns.txt\n226 Directory send OK." : "530 Please login with USER and PASS.";
            case "RETR": case "GET":
              if (!logged) return "530 Please login with USER and PASS.";
              if (arg !== "ghi_chu_dns.txt") return "550 Failed to open file.";
              return "150 Opening BINARY mode data connection.\nNhắc admin: DNS server ns1 vẫn cho phép zone transfer (AXFR) với mọi IP.\nNhớ xoá bản ghi TXT bí mật trước khi audit!\n226 Transfer complete.";
            case "HELP": return "214 USER PASS LIST RETR QUIT";
            case "QUIT": return { out: "221 Goodbye.", close: true };
            case "": return null;
            default: return "500 Unknown command.";
          }
        },
      };
    };
    const ssh = () => ({ banner: "SSH-2.0-OpenSSH_9.6p1 Ubuntu-3ubuntu13", prompt: "", onLine: () => ({ out: "Invalid SSH identification string.", close: true }) });
    const map = {};
    for (const h0 of [NET_TARGET, "zctf.local"]) { map[h0 + ":1337"] = svc1337; map[h0 + ":80"] = svcHttp; map[h0 + ":21"] = svcFtp; map[h0 + ":22"] = ssh; }
    return map;
  })(),
};

/* ------------------------------------------------------------------
   Bài "Số học & bit": cửa hàng có lỗi tràn số nguyên (int32)
   ------------------------------------------------------------------ */
WIDGETS.intshop = (el) => {
  addStyle("intshop", `
    .intshop { margin: 14px 0; border: 1px solid var(--border-2); border-radius: 12px; overflow: hidden; background: #f6f7fb; color: #1b2330; }
    .intshop .ih { padding: 12px 16px; background: #fff; border-bottom: 1px solid #e3e7ee; display: flex; justify-content: space-between; font-weight: 600; }
    .intshop .ib { padding: 16px; display: grid; gap: 12px; }
    .intshop .item { display: flex; justify-content: space-between; align-items: center; gap: 10px; padding: 10px 12px; border: 1px solid #e3e7ee; border-radius: 10px; background: #fff; flex-wrap: wrap; }
    .intshop input { width: 140px; padding: 7px 10px; border-radius: 8px; border: 1px solid #cfd6e0; font-family: var(--mono); background: #fff; color: #1b2330; }
    .intshop button { padding: 8px 16px; border-radius: 8px; border: none; background: #2e6bff; color: #fff; font-weight: 600; cursor: pointer; }
    .intshop .log { font-family: var(--mono); font-size: 13px; background: #0b0f15; color: #c9d4df; padding: 12px; border-radius: 10px; white-space: pre-wrap; min-height: 64px; }
    .intshop .log .ok { color: #3dffa2; } .intshop .log .bad { color: #ff5c7a; }
  `);
  const root = h(`
    <div class="intshop">
      <div class="ih"><span>zShop</span><span>Số dư: <span class="bal">100</span> xu</span></div>
      <div class="ib">
        <div class="item"><span>Sticker zCTF — 5 xu</span><span>SL <input type="number" value="1" data-p="5"> <button data-p="5">Mua</button></span></div>
        <div class="item"><span><b>Flag</b> — 1.000.000 xu</span><span>SL <input type="number" value="1" data-p="1000000"> <button data-p="1000000">Mua</button></span></div>
        <div class="log">// server (C):  int32_t total = price * qty;  if (total &lt;= balance) { giao hàng; balance -= total; }</div>
      </div>
    </div>`);
  el.replaceWith(root);
  let balance = 100;
  const log = root.querySelector(".log"), bal = root.querySelector(".bal");
  root.querySelectorAll("button").forEach((b) => b.addEventListener("click", () => {
    const price = +b.dataset.p;
    const inp = b.previousElementSibling;
    let qty = Math.trunc(Number(inp.value));
    if (!Number.isFinite(qty) || qty < 1) { log.innerHTML = '<span class="bad">Số lượng phải ≥ 1</span>'; return; }
    if (qty > 4294967295) qty = 4294967295;
    const total = Number(BigInt.asIntN(32, BigInt(price) * BigInt(qty)));
    const real = BigInt(price) * BigInt(qty);
    let out = `price * qty = ${price} * ${qty} = ${real}\nint32_t total = ${total}${BigInt(total) !== real ? "   ← tràn số!" : ""}\n`;
    if (total <= balance) {
      balance = Number(BigInt.asIntN(32, BigInt(balance) - BigInt(total)));
      out += `<span class="ok">✓ Mua thành công.</span> Số dư mới: ${balance}\n`;
      if (price === 1000000) out += `<span class="ok">Hàng của bạn: ${d64("ekNURnt0cjRuX3MwX25ndXkzbn0=")}</span>`;
    } else out += `<span class="bad">✗ Không đủ tiền (${total} > ${balance})</span>`;
    bal.textContent = balance;
    log.innerHTML = out;
  }));
};
