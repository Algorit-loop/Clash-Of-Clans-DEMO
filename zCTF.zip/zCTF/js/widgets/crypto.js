/* Widget cho track Crypto (dữ liệu đề nằm ở crypto_data.js, sinh bởi .dev/gen_crypto.py) */

addStyle("crypto", `
.ecb-wrap { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; margin: 18px 0; }
.ecb-wrap figure { margin: 0; text-align: center; }
.ecb-wrap canvas { width: 100%; image-rendering: pixelated; border-radius: 10px; border: 1px solid var(--border); background: #000; }
.ecb-wrap figcaption { font-family: var(--mono); font-size: 12.5px; color: var(--muted); margin-top: 6px; }
.ecb-ctrl { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; font-family: var(--mono); font-size: 13px; color: var(--muted); }
.xb { margin: 18px 0; padding: 16px; border-radius: 12px; border: 1px solid var(--border); background: #080b10; }
.xb-in { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 14px; }
.xb-in label { font-family: var(--mono); font-size: 12px; color: var(--dim); display: flex; flex-direction: column; gap: 4px; }
.xb-grid { overflow-x: auto; font-family: var(--mono); font-size: 12.5px; }
.xb-row { display: flex; gap: 10px; align-items: center; white-space: nowrap; padding: 3px 0; }
.xb-row > b { width: 64px; flex: none; color: var(--dim); font-weight: 500; }
.xb-byte { display: inline-flex; flex-direction: column; align-items: center; padding: 4px 6px; border-radius: 7px; border: 1px solid var(--border); min-width: 82px; }
.xb-byte .bits span { display: inline-block; width: 8px; text-align: center; transition: color .25s, background .25s; border-radius: 2px; }
.xb-byte .bits span.one { color: var(--accent); }
.xb-byte .bits span.zero { color: var(--dim); }
.xb-byte small { color: var(--amber); font-size: 11px; }
.xb-row.res .xb-byte { border-color: rgba(var(--accent-rgb), .35); background: rgba(var(--accent-rgb), .04); }
.vg { margin: 18px 0; padding: 16px; border-radius: 12px; border: 1px solid var(--border); background: #080b10; }
.vg textarea { width: 100%; min-height: 110px; padding: 12px; border-radius: 10px; background: #06080b; border: 1px solid var(--border-2); color: var(--text); font-family: var(--mono); font-size: 13.5px; resize: vertical; }
.vg-bars { display: flex; align-items: flex-end; gap: 6px; height: 140px; margin: 14px 0 6px; }
.vg-bar { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; height: 100%; cursor: pointer; }
.vg-bar div { width: 100%; border-radius: 5px 5px 0 0; background: var(--border-2); transition: height .4s var(--ease), background .2s; }
.vg-bar.best div { background: var(--amber); box-shadow: 0 0 12px rgba(255,200,87,.4); }
.vg-bar.sel div { outline: 2px solid var(--cyan); }
.vg-bar span { font-family: var(--mono); font-size: 11px; color: var(--muted); margin-top: 4px; }
.vg-out { font-family: var(--mono); font-size: 13px; color: var(--muted); line-height: 1.8; }
.vg-out b { color: var(--accent); }
@media (max-width: 700px) { .ecb-wrap, .xb-in { grid-template-columns: 1fr; } }
`);

/* ---------------------------------------------------------------- ECB penguin
   Mã khối đồ chơi (không an toàn, chỉ để minh hoạ): E_k(block) = PRF(k, block).
   ECB: mỗi block 16 byte (4 điểm ảnh RGBA) mã hoá độc lập → block giống nhau cho kết quả giống nhau. */
WIDGETS.ecbpenguin = (el) => {
  const W = 96, Hh = 96;
  const root = h(`
    <div>
      <div class="ecb-wrap">
        <figure><canvas width="${W}" height="${Hh}"></canvas><figcaption>Ảnh gốc</figcaption></figure>
        <figure><canvas width="${W}" height="${Hh}"></canvas><figcaption>Mã hoá ECB</figcaption></figure>
        <figure><canvas width="${W}" height="${Hh}"></canvas><figcaption>Mã hoá CBC</figcaption></figure>
      </div>
      <div class="ecb-ctrl"><button class="btn sm" data-a="key">Đổi khoá</button><span>Khoá: <code class="k"></code></span></div>
    </div>`);
  el.replaceWith(root);
  const [c0, c1, c2] = root.querySelectorAll("canvas");
  const ctx0 = c0.getContext("2d");
  // vẽ ảnh: nền trắng, ổ khoá + chữ
  ctx0.fillStyle = "#f2f2f2"; ctx0.fillRect(0, 0, W, Hh);
  ctx0.fillStyle = "#1b1f27"; ctx0.fillRect(24, 44, 48, 38);
  ctx0.lineWidth = 8; ctx0.strokeStyle = "#1b1f27"; ctx0.beginPath(); ctx0.arc(48, 44, 15, Math.PI, 0); ctx0.stroke();
  ctx0.fillStyle = "#ffc857"; ctx0.fillRect(44, 56, 8, 14);
  ctx0.fillStyle = "#ff5c7a"; ctx0.fillRect(0, 0, W, 10); ctx0.fillRect(0, Hh - 10, W, 10);
  const src = ctx0.getImageData(0, 0, W, Hh).data;
  let key = 0;
  const prf = (k, bytes, off) => {
    // FNV-1a 32-bit trên (khoá || block) → xorshift để sinh 16 byte
    let x = 0x811c9dc5 ^ k;
    for (let i = 0; i < 16; i++) { x ^= bytes[off + i]; x = Math.imul(x, 0x01000193) >>> 0; }
    const out = new Uint8Array(16);
    for (let i = 0; i < 16; i++) { x ^= x << 13; x >>>= 0; x ^= x >>> 17; x ^= x << 5; x >>>= 0; out[i] = x & 0xff; }
    return out;
  };
  const draw = () => {
    root.querySelector(".k").textContent = key.toString(16).padStart(8, "0");
    const ecb = new Uint8ClampedArray(src.length), cbc = new Uint8ClampedArray(src.length);
    let prev = prf(key ^ 0x5bd1e995, new Uint8Array(16), 0); // IV
    const tmp = new Uint8Array(16);
    for (let o = 0; o < src.length; o += 16) {
      const e = prf(key, src, o);
      for (let i = 0; i < 16; i++) ecb[o + i] = e[i];
      for (let i = 0; i < 16; i++) tmp[i] = src[o + i] ^ prev[i];
      prev = prf(key, tmp, 0);
      for (let i = 0; i < 16; i++) cbc[o + i] = prev[i];
      for (let i = 3; i < 16; i += 4) { ecb[o + i] = 255; cbc[o + i] = 255; }
    }
    c1.getContext("2d").putImageData(new ImageData(ecb, W, Hh), 0, 0);
    c2.getContext("2d").putImageData(new ImageData(cbc, W, Hh), 0, 0);
  };
  root.querySelector('[data-a="key"]').onclick = () => { key = (Math.random() * 2 ** 32) >>> 0; draw(); };
  key = 0x1337c0de;
  draw();
};

/* ---------------------------------------------------------------- XOR từng bit */
WIDGETS.xorbits = (el) => {
  const root = h(`
    <div class="xb">
      <div class="xb-in">
        <label>A (chữ, hoặc hex bắt đầu bằng 0x)<input class="field" data-k="a" value="zCTF" spellcheck="false"></label>
        <label>B (khoá)<input class="field" data-k="b" value="0x2a" spellcheck="false"></label>
      </div>
      <div class="xb-grid"></div>
    </div>`);
  el.replaceWith(root);
  const parse = (s) => (/^0x[0-9a-f]+$/i.test(s.trim()) ? (s.trim().slice(2).length % 2 ? "0" + s.trim().slice(2) : s.trim().slice(2)).match(/../g).map((x) => parseInt(x, 16)) : [...utf8.encode(s)]);
  const show = (b) => (b >= 32 && b < 127 ? esc(String.fromCharCode(b)) : "·");
  const byteHtml = (v) => `<span class="xb-byte"><span class="bits">${v.toString(2).padStart(8, "0").split("").map((x) => `<span class="${x === "1" ? "one" : "zero"}">${x}</span>`).join("")}</span><small>0x${v.toString(16).padStart(2, "0")} '${show(v)}'</small></span>`;
  const draw = () => {
    const a = parse(root.querySelector('[data-k="a"]').value).slice(0, 12);
    const b = parse(root.querySelector('[data-k="b"]').value);
    if (!a.length || !b.length) { root.querySelector(".xb-grid").innerHTML = ""; return; }
    const bb = a.map((_, i) => b[i % b.length]);
    const r = a.map((x, i) => x ^ bb[i]);
    root.querySelector(".xb-grid").innerHTML =
      `<div class="xb-row"><b>A</b>${a.map(byteHtml).join("")}</div>` +
      `<div class="xb-row"><b>B</b>${bb.map(byteHtml).join("")}</div>` +
      `<div class="xb-row res"><b>A ⊕ B</b>${r.map(byteHtml).join("")}</div>`;
  };
  root.querySelectorAll("input").forEach((i) => i.addEventListener("input", draw));
  draw();
};

/* ---------------------------------------------------------------- Phân tích Vigenère
   Index of Coincidence theo độ dài khoá + chi-squared từng cột để đoán khoá */
WIDGETS.vigtool = (el) => {
  const EN = [8.2, 1.5, 2.8, 4.3, 12.7, 2.2, 2.0, 6.1, 7.0, 0.15, 0.77, 4.0, 2.4, 6.7, 7.5, 1.9, 0.095, 6.0, 6.3, 9.1, 2.8, 0.98, 2.4, 0.15, 2.0, 0.074];
  const sample = "Vyc Kbugecgx qkgftk kcj apezgu jt vvkwdgx wpucrawhwppuzg wmg mvtvc wnbfics rsciq, qxqclqt lwogjt yfghstgqa rlpemuzq shsu emi pctb yvtwpjr xm. Sxvpn esvkcg bg uygumsf sw p wwhwcgxbv rkdnbv, ucexbfzlv hb kkq ehgkkgdg opu rwx ggtptm ygpudkr. Jfutost, flrx hjv yimoebcg escilh mvg ccczhj fd ias mvw, ias eznwxfvvvi ldnzrh bbvf qtostrj rhzwdlh, tbf vyra qqcsbg wu emiawpx kdks vyyc t Qcvqpk qkgftk. Qjrpaxg Drzqtug rls Yfkvbgbqj Byhbgmz zghyg zr xg hjv lxgsvvccmv evlinfa lqxgu tvntthgu dgtuovlil wp kft mszk.";
  const root = h(`
    <div class="vg">
      <textarea spellcheck="false"></textarea>
      <div class="vg-bars"></div>
      <div class="vg-out"></div>
    </div>`);
  el.replaceWith(root);
  const ta = root.querySelector("textarea");
  ta.value = el.dataset.text || sample;
  let sel = null;
  const ic = (s) => { const n = s.length; if (n < 2) return 0; const f = new Array(26).fill(0); for (const ch of s) f[ch]++; return f.reduce((a, x) => a + x * (x - 1), 0) / (n * (n - 1)); };
  const bestShift = (col) => {
    let best = 0, bestChi = Infinity;
    for (let k = 0; k < 26; k++) {
      const f = new Array(26).fill(0);
      for (const ch of col) f[(ch - k + 26) % 26]++;
      const chi = f.reduce((a, x, i) => { const e = (EN[i] / 100) * col.length; return a + (x - e) ** 2 / e; }, 0);
      if (chi < bestChi) { bestChi = chi; best = k; }
    }
    return best;
  };
  const draw = () => {
    const L = [...ta.value.toUpperCase()].filter((ch) => ch >= "A" && ch <= "Z").map((ch) => ch.charCodeAt(0) - 65);
    const scores = [];
    for (let k = 1; k <= 12; k++) {
      let s = 0;
      for (let j = 0; j < k; j++) s += ic(L.filter((_, i) => i % k === j));
      scores.push(s / k);
    }
    const max = Math.max(0.075, ...scores);
    const top = Math.max(...scores);
    const best = scores.findIndex((x) => x >= top * 0.9) + 1; // độ dài nhỏ nhất gần cao nhất (bội số của khoá cũng cao)
    const kl = sel || best;
    root.querySelector(".vg-bars").innerHTML = scores.map((s, i) => `<div class="vg-bar ${i + 1 === best ? "best" : ""} ${i + 1 === kl ? "sel" : ""}" data-k="${i + 1}" title="IC = ${s.toFixed(4)}"><div style="height:${Math.max(3, ((s - 0.03) / (max - 0.03)) * 100)}%"></div><span>${i + 1}</span></div>`).join("");
    root.querySelectorAll(".vg-bar").forEach((b) => (b.onclick = () => { sel = +b.dataset.k; draw(); }));
    const key = Array.from({ length: kl }, (_, j) => String.fromCharCode(65 + bestShift(L.filter((_, i) => i % kl === j)))).join("");
    let j = 0;
    const plain = [...ta.value].map((ch) => {
      const up = ch >= "A" && ch <= "Z", lo = ch >= "a" && ch <= "z";
      if (!up && !lo) return ch;
      const b = up ? 65 : 97, k = key.charCodeAt(j++ % kl) - 65;
      return String.fromCharCode(((ch.charCodeAt(0) - b - k + 26) % 26) + b);
    }).join("");
    root.querySelector(".vg-out").innerHTML = `${L.length} chữ cái · IC toàn văn bản = ${ic(L).toFixed(4)} (tiếng Anh ≈ 0.066, ngẫu nhiên ≈ 0.038)<br>Độ dài khoá đang xét: <b>${kl}</b> (bấm cột để đổi) · Khoá đoán bằng chi bình phương: <b>${key}</b><br>Bản rõ thử: ${esc(plain.slice(0, 400))}`;
  };
  ta.addEventListener("input", () => { sel = null; draw(); });
  draw();
};
