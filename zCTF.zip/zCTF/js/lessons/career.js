/* Track: career */

lesson({
  id: "career-play",
  track: "career",
  order: 1,
  level: 1,
  title: "Chơi giải thật & làm việc nhóm",
  short: "Tìm giải, chuẩn bị, chia vai và chiến thuật trong 48 giờ thi",
  time: "20 phút",
  html: `
<h2 id="tim-giai">Tìm giải để chơi</h2>
<ul>
<li><a href="https://ctftime.org/event/list/upcoming" target="_blank" rel="noopener"><strong>CTFtime</strong></a>: lịch gần như mọi giải trên thế giới. Mỗi giải có <em>weight</em> (0–100) thể hiện độ khó và uy tín. Người mới nên chọn giải weight thấp hoặc giải ghi "beginner friendly".</li>
<li><a href="https://picoctf.org/" target="_blank" rel="noopener"><strong>picoCTF</strong></a> (thường tháng 3) và kho <em>picoGym</em> mở quanh năm: tốt nhất để khởi đầu.</li>
<li>Giải dành cho sinh viên Việt Nam thường do các trường, câu lạc bộ an toàn thông tin hoặc doanh nghiệp bảo mật tổ chức, kèm vòng chung kết offline. Theo dõi fanpage câu lạc bộ trường bạn.</li>
<li>Sau mỗi giải, nhiều ban tổ chức để server chạy thêm vài ngày và đưa mã nguồn bài lên GitHub. Đó là lúc tốt nhất để giải lại.</li>
</ul>

<h2 id="the-thuc">Thể thức thường gặp</h2>
<table>
<tr><th></th><th>Jeopardy</th><th>Attack–Defense</th></tr>
<tr><td>Thời gian</td><td>24–48 giờ, online</td><td>6–10 giờ, thường offline (chung kết)</td></tr>
<tr><td>Bạn làm gì</td><td>Giải các bài độc lập</td><td>Vá dịch vụ của mình, khai thác dịch vụ đội khác theo từng vòng (tick)</td></tr>
<tr><td>Điểm</td><td>Thường là <em>dynamic scoring</em>: càng nhiều đội giải, bài càng ít điểm</td><td>Điểm tấn công + phòng thủ + SLA (dịch vụ phải luôn chạy)</td></tr>
<tr><td>Kỹ năng then chốt</td><td>Chiều sâu trong từng mảng</td><td>Tự động hoá: script nộp flag hàng loạt, giám sát lưu lượng</td></tr>
</table>

<h2 id="chuan-bi">Chuẩn bị trước giải</h2>
<ol class="steps-v">
<li><strong>Máy:</strong> VM Kali/Ubuntu đã cài sẵn công cụ, snapshot sạch để quay lại khi hỏng. Python với pwntools, pycryptodome, requests.</li>
<li><strong>Kho mẹo cá nhân:</strong> file ghi chú các lệnh hay dùng, template script exploit (pwntools, requests) để chỉ cần sửa host/port.</li>
<li><strong>Kênh liên lạc đội:</strong> một server Discord với mỗi bài một kênh (bot tự tạo như CTFNote, CTFd-bot) để ghi tiến độ, không ai làm trùng.</li>
<li><strong>Đọc luật:</strong> định dạng flag, có cho phép tấn công hạ tầng không (gần như luôn cấm), giới hạn số lần nộp sai.</li>
</ol>

<h2 id="chia-vai">Lập đội và chia vai</h2>
<p>Đội 3–6 người là hợp lý. Mỗi người nên có một mảng chính và một mảng phụ, để bài nào cũng có ít nhất hai người hiểu.</p>
<div class="grid-2">
  <div class="card"><h4>Web + OSINT</h4><p>Thường có nhiều bài nhất. Hợp với người quen lập trình web.</p></div>
  <div class="card"><h4>Crypto</h4><p>Cần nền toán (số học modulo, đại số). Viết nhiều Python/SageMath.</p></div>
  <div class="card"><h4>Reverse + Pwn</h4><p>Hai mảng bổ trợ: pwn gần như luôn cần đọc ngược binary trước.</p></div>
  <div class="card"><h4>Forensics + Misc</h4><p>Đòi hỏi kiên nhẫn và biết nhiều công cụ. Thường là "đội cứu hoả" giải các bài lạ.</p></div>
</div>

<h2 id="chien-thuat">Chiến thuật trong 48 giờ</h2>
<ul>
<li><strong>Giờ đầu:</strong> mọi người lướt qua tất cả bài, đánh dấu bài dễ (nhiều đội giải sớm). Lấy điểm dễ trước.</li>
<li><strong>Kẹt quá 1–2 giờ:</strong> viết lại những gì đã thử vào kênh bài đó, đổi sang bài khác hoặc gọi đồng đội nhìn bằng con mắt mới. Rất nhiều bài được giải bởi người thứ hai.</li>
<li><strong>Chú ý số đội giải:</strong> bài 0 đội giải sau 12 giờ có thể có lỗi; ban tổ chức thường ra gợi ý hoặc sửa đề.</li>
<li><strong>Ngủ:</strong> thức trắng 48 giờ làm hiệu suất giảm mạnh. Luân phiên nhau nghỉ.</li>
<li><strong>Không chia sẻ flag</strong> với đội khác. Đó là gian lận và hầu hết giải cấm thẳng.</li>
</ul>

<h2 id="sau-giai">Sau giải</h2>
<p>Đây là phần học được nhiều nhất. Đọc writeup của các bài chưa giải (CTFtime → trang giải → tab Writeups), tự làm lại không nhìn lời giải, và viết writeup cho bài mình đã giải. Bài tiếp theo hướng dẫn cách viết.</p>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Giải dùng dynamic scoring. Bài A lúc đầu 500 điểm, giờ đã có 300 đội giải. Điều gì đúng?",
      options: ["Bài A vẫn 500 điểm với mọi đội", "Điểm của bài A đã giảm, kể cả với các đội giải trước đó", "Chỉ đội giải đầu tiên được 500", "Bài A bị khoá"],
      answer: 1,
      explain: "Dynamic scoring giảm điểm bài theo số đội giải, áp dụng cho tất cả, nên bài khó ít người giải luôn đáng giá nhất.",
    },
    {
      q: "Bạn kẹt ở một bài 3 tiếng. Cách làm tốt nhất?",
      options: ["Tiếp tục cho tới khi xong", "Ghi lại những gì đã thử, nhờ đồng đội xem hoặc chuyển bài", "Hỏi flag đội khác", "Tấn công server để lấy flag"],
      answer: 1,
      explain: "Ghi chép giúp đồng đội không lặp lại ngõ cụt; góc nhìn mới thường tìm ra hướng đi.",
    },
  ],
});

lesson({
  id: "career-writeup",
  track: "career",
  order: 2,
  level: 1,
  title: "Ghi chép & viết writeup",
  short: "Cách ghi chép khi giải, cấu trúc một writeup tốt và nơi đăng",
  time: "20 phút",
  html: `
<h2 id="vi-sao">Vì sao phải viết?</h2>
<ul>
<li><strong>Nhớ lâu:</strong> giải thích lại cho người khác buộc bạn hiểu thật sự vì sao exploit chạy.</li>
<li><strong>Tái sử dụng:</strong> 6 tháng sau gặp dạng bài cũ, bạn tìm lại writeup của chính mình nhanh hơn Google.</li>
<li><strong>Portfolio:</strong> nhà tuyển dụng bảo mật thường đọc blog, GitHub writeup của ứng viên. Đây là bằng chứng kỹ năng rõ nhất khi bạn chưa có kinh nghiệm làm việc.</li>
</ul>

<h2 id="ghi-chep">Ghi chép trong lúc giải</h2>
<p>Đừng đợi giải xong mới viết. Mở một file Markdown cho mỗi bài và ghi liên tục:</p>
${txt`
## web/login-portal (300 pts)
- 21:05 nhìn source: form POST /login, có cookie session dạng base64
- 21:12 base64 -d cookie → {"user":"guest","admin":false}  ← thử sửa admin:true?
- 21:20 sửa cookie → 500 Internal Error. Có chữ ký HMAC ở cuối cookie, không sửa được
- 21:40 thử SQLi ở username: ' → lỗi SQLite!  → hướng này
- 22:05 ' UNION SELECT 1,sql,3 FROM sqlite_master-- → có bảng secrets
- 22:10 FLAG: zCTF{...}
`}
<p>Ghi cả <strong>ngõ cụt</strong>: đó là phần đồng đội cần biết nhất, và cũng là phần làm writeup có giá trị.</p>
<div class="callout tip"><b>Công cụ</b>
<p>Obsidian, Notion, hoặc thư mục Markdown trong Git. Dán cả lệnh lẫn output quan trọng. Chụp màn hình Burp, Ghidra khi cần.</p></div>

<h2 id="cau-truc">Cấu trúc một writeup tốt</h2>
<ol class="steps-v">
<li><strong>Thông tin bài:</strong> tên giải, tên bài, mảng, điểm, file/đường dẫn đề.</li>
<li><strong>TL;DR:</strong> một hai câu tóm tắt lỗ hổng và cách khai thác.</li>
<li><strong>Phân tích:</strong> bạn quan sát được gì, vì sao nghĩ tới hướng đó. Đây là phần người đọc học được nhiều nhất.</li>
<li><strong>Khai thác:</strong> từng bước, có lệnh và script đầy đủ chạy được.</li>
<li><strong>Flag</strong> (thường chỉ đăng sau khi giải kết thúc).</li>
<li><strong>Bài học:</strong> kỹ thuật mới, cách phòng chống, tài liệu tham khảo.</li>
</ol>
${txt`
# [zCTF 2026] web/login-portal

**Mảng:** Web · **Điểm:** 300 · **Số đội giải:** 41

## TL;DR
Trường username bị SQL injection (SQLite). Dùng UNION để đọc bảng secrets.

## Phân tích
Cookie có chữ ký HMAC nên không giả mạo được. Nhập ' vào username thì server
báo "unrecognized token", nghĩa là input được ghép thẳng vào câu SQL...

## Khai thác
    curl -d "username=' UNION SELECT 1,value,3 FROM secrets--&password=x" http://target/login

## Bài học
Luôn dùng parameterized query. Thông báo lỗi SQL chi tiết giúp kẻ tấn công rất nhiều.
`}

<h2 id="dang-o-dau">Đăng ở đâu?</h2>
<ul>
<li><strong>GitHub:</strong> một repo <code>ctf-writeups</code> chia thư mục theo giải. Đơn giản, dễ tìm.</li>
<li><strong>Blog cá nhân:</strong> GitHub Pages với Hugo/Jekyll, miễn phí, trông chuyên nghiệp.</li>
<li><strong>CTFtime:</strong> gửi link writeup vào trang bài để cộng đồng tìm thấy.</li>
</ul>
<div class="callout warn"><b>Đạo đức</b>
<p>Chỉ đăng writeup khi giải đã <strong>kết thúc</strong>. Với bài từ nền tảng luyện tập (picoGym, Hack The Box…), đọc kỹ quy định: nhiều nơi cấm đăng lời giải cho bài đang hoạt động.</p></div>
<div data-quiz="0"></div>
`,
  quiz: [
    {
      q: "Phần nào trong writeup giúp người đọc học được nhiều nhất?",
      options: ["Flag", "Lý do bạn nghĩ tới hướng khai thác đó (phân tích)", "Số điểm của bài", "Tên đội"],
      answer: 1,
      explain: "Biết cách suy luận từ dấu hiệu tới lỗ hổng mới giúp người đọc giải được bài tương tự sau này.",
    },
  ],
});

lesson({
  id: "career-path",
  track: "career",
  order: 3,
  level: 1,
  title: "Lộ trình dài hạn & nghề nghiệp",
  short: "Kế hoạch 3–6 tháng, các hướng nghề bảo mật, chứng chỉ và bug bounty",
  time: "25 phút",
  html: `
<h2 id="ke-hoach">Kế hoạch 6 tháng sau khi học xong trang này</h2>
<table>
<tr><th>Giai đoạn</th><th>Mục tiêu</th><th>Làm gì</th></tr>
<tr><td>Tháng 1</td><td>Vững nền tảng</td><td>OverTheWire Bandit (hết), Natas 0–15. picoGym mức dễ tất cả các mảng. Học Python đủ để viết script không cần tra.</td></tr>
<tr><td>Tháng 2</td><td>Chọn mảng chính</td><td>Làm thử 10 bài mỗi mảng, chọn 1–2 mảng thấy hứng thú nhất. Web: PortSwigger Academy. Crypto: CryptoHack. Pwn/Reverse: pwn.college.</td></tr>
<tr><td>Tháng 3</td><td>Giải thật đầu tiên</td><td>Tham gia ít nhất 2 giải trên CTFtime. Viết writeup cho mọi bài giải được.</td></tr>
<tr><td>Tháng 4–5</td><td>Đào sâu</td><td>Học bài bản mảng chính (sách, khoá học). Giải lại bài cũ của các giải lớn. Tham gia đội hoặc câu lạc bộ.</td></tr>
<tr><td>Tháng 6</td><td>Mở rộng</td><td>Lab thực tế: TryHackMe/Hack The Box máy đầy đủ (recon → khai thác → leo thang đặc quyền). Bắt đầu nghĩ tới chứng chỉ hoặc bug bounty.</td></tr>
</table>
<div class="callout tip"><b>Thói quen quan trọng hơn cường độ</b>
<p>1 giờ mỗi ngày đều đặn tốt hơn 10 giờ cuối tuần rồi bỏ cả tháng. Mỗi tuần: ít nhất 3 bài mới và 1 writeup.</p></div>

<h2 id="nghe">Các hướng nghề trong bảo mật</h2>
<table>
<tr><th>Vị trí</th><th>Công việc</th><th>Mảng CTF liên quan</th></tr>
<tr><td>Pentester / Red team</td><td>Được thuê để tấn công hệ thống của khách hàng, báo cáo lỗ hổng</td><td>Web, Linux/Windows privesc, mạng</td></tr>
<tr><td>Blue team / SOC analyst</td><td>Giám sát, phát hiện và phản ứng tấn công</td><td>Forensics, phân tích log, mạng</td></tr>
<tr><td>DFIR (điều tra sự cố)</td><td>Điều tra sau khi bị tấn công: chuyện gì xảy ra, từ đâu</td><td>Forensics (bộ nhớ, ổ đĩa, pcap)</td></tr>
<tr><td>Malware analyst</td><td>Phân tích mã độc, viết luật phát hiện</td><td>Reverse</td></tr>
<tr><td>Vulnerability researcher</td><td>Tìm lỗ hổng 0-day trong phần mềm, trình duyệt, hệ điều hành</td><td>Pwn, Reverse</td></tr>
<tr><td>AppSec / Security engineer</td><td>Review code, thiết kế bảo mật cho sản phẩm, làm việc cùng dev</td><td>Web, Crypto</td></tr>
<tr><td>Cryptographer / Crypto engineer</td><td>Thiết kế, kiểm định hệ thống mật mã</td><td>Crypto (cần nền toán vững)</td></tr>
</table>

<h2 id="chung-chi">Chứng chỉ</h2>
<p>Chứng chỉ không thay được kỹ năng, nhưng giúp hồ sơ qua vòng lọc. Ở mức giới thiệu:</p>
<table>
<tr><th>Chứng chỉ</th><th>Cấp độ</th><th>Đặc điểm</th></tr>
<tr><td><strong>eJPT</strong> (INE)</td><td>Nhập môn</td><td>Thi thực hành trên lab, phù hợp sau khi vững nền tảng</td></tr>
<tr><td><strong>CompTIA Security+</strong></td><td>Nhập môn</td><td>Trắc nghiệm, kiến thức rộng; được nhiều nơi yêu cầu cho vị trí blue team</td></tr>
<tr><td><strong>CEH</strong> (EC-Council)</td><td>Nhập môn – trung cấp</td><td>Nổi tiếng về tên tuổi, phần lớn là lý thuyết; giới kỹ thuật đánh giá không cao bằng chứng chỉ thực hành</td></tr>
<tr><td><strong>OSCP</strong> (OffSec)</td><td>Trung cấp</td><td>Thi thực hành 24 giờ, khai thác nhiều máy; rất được ngành pentest công nhận</td></tr>
<tr><td><strong>BSCP</strong> (PortSwigger)</td><td>Trung cấp</td><td>Chuyên về web, thi thực hành; học qua Web Security Academy miễn phí</td></tr>
<tr><td><strong>OSWE, OSED, OSEP</strong></td><td>Nâng cao</td><td>Web nâng cao, exploit development, red team</td></tr>
</table>
<p>Giá và nội dung thay đổi theo thời gian, hãy kiểm tra trên trang chính thức trước khi đăng ký.</p>

<h2 id="bug-bounty">Bug bounty</h2>
<p>Các công ty trả tiền cho người tìm ra lỗ hổng trong sản phẩm của họ, qua nền tảng như <strong>HackerOne</strong>, <strong>Bugcrowd</strong>, <strong>Intigriti</strong>, hoặc chương trình riêng.</p>
<ul>
<li><strong>Chỉ test trong phạm vi (scope)</strong> được ghi rõ. Tên miền, loại lỗi, kỹ thuật không được dùng (thường cấm DoS, social engineering).</li>
<li>Khác CTF: không có flag, lỗ hổng không được "cài sẵn", phải đọc hiểu ứng dụng thật. Recon và kiên nhẫn quan trọng hơn kỹ thuật cao siêu.</li>
<li>Báo cáo tốt quyết định tiền thưởng: mô tả rõ, các bước tái hiện, tác động thực tế, đề xuất sửa.</li>
<li>Người mới nên bắt đầu với chương trình <em>VDP</em> (không thưởng tiền, ít cạnh tranh) để luyện kỹ năng viết báo cáo.</li>
</ul>
<div class="callout danger"><b>Ranh giới pháp lý</b>
<p>Tấn công hệ thống không có sự cho phép bằng văn bản là vi phạm pháp luật, kể cả khi bạn "chỉ thử" hoặc định báo cáo sau. Chỉ làm trên CTF, lab, máy của mình, hoặc trong phạm vi chương trình bug bounty / hợp đồng pentest.</p></div>

<h2 id="hoc-tiep">Học tiếp từ đâu</h2>
<ul>
<li><strong>Sách:</strong> <em>The Web Application Hacker's Handbook</em> (web, kinh điển), <em>Hacking: The Art of Exploitation</em> (pwn nhập môn), <em>Practical Malware Analysis</em> (reverse), <em>Serious Cryptography</em> (crypto).</li>
<li><strong>Khoá học miễn phí:</strong> PortSwigger Web Security Academy, pwn.college, CryptoHack, OpenSecurityTraining2.</li>
<li><strong>Cộng đồng:</strong> câu lạc bộ an toàn thông tin của trường, Discord của picoCTF, CTFtime, các nhóm bảo mật trong nước.</li>
</ul>
<p>Danh sách đầy đủ ở trang <a href="#/resources">Tài nguyên</a>. Chúc bạn sớm có flag đầu tiên ở một giải thật!</p>
<div data-quiz="0"></div>
`,
  quiz: [
    {
      q: "Bạn tìm thấy lỗ hổng trên website một công ty không có chương trình bug bounty. Bạn đã khai thác thử để chứng minh. Việc này thế nào?",
      options: ["Hợp pháp vì có ý tốt", "Có thể vi phạm pháp luật vì không được phép", "Hợp pháp nếu báo cáo trong 24 giờ", "Hợp pháp nếu không lấy dữ liệu"],
      answer: 1,
      explain: "Không có sự cho phép thì việc khai thác là truy cập trái phép. Nếu vô tình phát hiện, hãy liên hệ công ty qua kênh chính thức (security.txt) mà không khai thác thêm.",
    },
  ],
});
