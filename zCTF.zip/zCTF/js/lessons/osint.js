/* Track: osint */

lesson({
  id: "osint-search",
  track: "osint",
  order: 1,
  level: 1,
  title: "Tìm kiếm và dấu vết số",
  short: "Google dork, DNS, Certificate Transparency, username, Wayback, metadata tài liệu",
  time: "45 phút",
  html: `
<h2 id="osint">OSINT là gì</h2>
<p><strong>Open Source Intelligence</strong> là thu thập và kết nối thông tin từ nguồn <em>công khai</em>: website, DNS, mạng xã hội, bản lưu cũ, metadata. Không có "hack" ở đây, chỉ có tìm kiếm có phương pháp. Trong kiểm thử xâm nhập thật, đây là giai đoạn <em>reconnaissance</em> trước mọi thứ khác.</p>
<div class="callout danger"><b>Giới hạn đạo đức và pháp luật</b>
<p>Chỉ thu thập trong phạm vi bài thi hoặc hợp đồng kiểm thử. Không đăng nhập vào tài khoản người khác, không liên hệ, không công khai thông tin cá nhân (doxxing). Mọi công ty, người và domain trong bài này là hư cấu (đuôi <code>.example</code>).</p></div>
<p>Một cuộc điều tra OSINT là chuỗi <strong>pivot</strong>: mỗi mẩu thông tin mở ra một hướng tìm mới.</p>
${txt`
domain ─► DNS / whois ─► subdomain ─► server lộ file
   │
   └─► file công khai ─► metadata (tác giả) ─► username ─► mạng xã hội ─► bản lưu cũ
`}

<h2 id="dork">Google dorking</h2>
<p>Toán tử tìm kiếm thu hẹp kết quả tới đúng thứ bạn cần, kể cả thứ chủ website không muốn bị tìm thấy.</p>
<table>
<tr><th>Toán tử</th><th>Ý nghĩa</th><th>Ví dụ</th></tr>
<tr><td><code>"..."</code></td><td>Khớp nguyên cụm</td><td><code>"mật khẩu mặc định"</code></td></tr>
<tr><td><code>site:</code></td><td>Trong một domain (gồm cả subdomain)</td><td><code>site:example.com</code></td></tr>
<tr><td><code>filetype:</code> / <code>ext:</code></td><td>Loại file</td><td><code>filetype:pdf</code>, <code>ext:env</code>, <code>ext:sql</code></td></tr>
<tr><td><code>intitle:</code></td><td>Có từ trong tiêu đề</td><td><code>intitle:"index of"</code></td></tr>
<tr><td><code>inurl:</code></td><td>Có từ trong URL</td><td><code>inurl:admin</code>, <code>inurl:backup</code></td></tr>
<tr><td><code>-</code></td><td>Loại trừ</td><td><code>site:example.com -site:www.example.com</code></td></tr>
</table>
<p>Kết hợp kinh điển: <code>site:target filetype:pdf</code> (tài liệu công khai), <code>site:target intitle:"index of"</code> (thư mục để mở), <code>site:target ext:env OR ext:log OR ext:bak</code> (file cấu hình lộ). Kho dork: <em>Google Hacking Database</em> trên Exploit-DB.</p>
<p>Máy tìm kiếm hư cấu dưới đây hiểu các toán tử trên. Kết quả "nhạy cảm" chỉ hiện khi bạn hỏi đúng: giống thực tế, chúng bị chôn sâu dưới hàng nghìn kết quả bình thường.</p>
<div data-widget="dork"></div>
<div data-chal="os-search-3"></div>

<h2 id="dns">DNS, whois, Certificate Transparency</h2>
<ul>
<li><code>whois domain</code>: nhà đăng ký, ngày tạo, name server. Thông tin chủ sở hữu thường bị ẩn (<em>privacy</em>), nhưng ngày tạo và name server vẫn hữu ích.</li>
<li><code>dig A|MX|TXT|NS domain</code>: bản ghi DNS. TXT hay chứa mã xác minh dịch vụ (lộ công ty dùng dịch vụ gì) và đôi khi cả ghi chú nội bộ.</li>
<li><strong>Certificate Transparency</strong>: mọi chứng chỉ HTTPS được cấp đều ghi vào log công khai. <a href="https://crt.sh/" target="_blank" rel="noopener">crt.sh</a> với <code>%.domain</code> liệt kê subdomain mà công ty có thể không quảng cáo: <code>dev.</code>, <code>vpn.</code>, <code>staging.</code>.</li>
</ul>
${sh`
$ dig TXT example.com +short
$ dig MX example.com
$ curl -s "https://crt.sh/?q=%25.example.com&output=json" | jq -r '.[].name_value' | sort -u
`}

<h2 id="username">Username và mạng xã hội</h2>
<p>Người dùng hay giữ một username trên nhiều nền tảng. <code>sherlock</code>, <code>maigret</code>, <a href="https://whatsmyname.app/" target="_blank" rel="noopener">WhatsMyName</a> kiểm tra hàng trăm trang cùng lúc. Username thường lộ ra từ metadata tài liệu, địa chỉ email, commit Git.</p>

<h2 id="wayback">Wayback Machine</h2>
<p><a href="https://web.archive.org/" target="_blank" rel="noopener">web.archive.org</a> lưu ảnh chụp của hàng tỷ trang theo thời gian. Thứ đã bị xoá khỏi trang hiện tại (bio cũ, trang tuyển dụng, file robots.txt) có thể còn trong bản lưu. Công cụ <code>waybackurls</code> liệt kê mọi URL từng được lưu của một domain.</p>

<h2 id="metadata">Metadata tài liệu</h2>
<p>PDF và file Office công khai trên website mang theo tên tác giả, tên máy, phần mềm, đường dẫn nội bộ. Tải về và chạy <code>exiftool</code>. Công cụ <code>metagoofil</code> tự động: tìm tài liệu của domain bằng dork, tải về, trích metadata.</p>

<h2 id="thuc-hanh">Thực hành</h2>
<p>Bạn đã tải hai file PDF công khai của Cà Phê Mây vào <code>downloads/</code>.</p>
<div data-widget="shell" data-fs="osint-recon" data-height="400"></div>
<div data-chal="os-search-1"></div>
<div data-chal="os-search-2"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    { q: "Cách nào tìm được subdomain mà công ty không công bố, chỉ bằng nguồn công khai?", options: ["Quét cổng toàn bộ Internet", "Tra log Certificate Transparency (crt.sh)", "Đoán mật khẩu admin", "Gửi email hỏi"], answer: 1, explain: "Mọi chứng chỉ TLS hợp lệ đều được ghi vào log công khai, kèm tên miền mà chứng chỉ bảo vệ." },
    { q: "Truy vấn nào tìm file PDF trên domain target.example?", options: ["<code>target.example pdf</code>", "<code>site:target.example filetype:pdf</code>", "<code>inurl:pdf</code>", "<code>intitle:target</code>"], answer: 1, explain: "<code>site:</code> giới hạn domain, <code>filetype:</code> giới hạn loại file. Cách đầu chỉ tìm trang có chữ \"pdf\"." },
  ],
  challenges: {
    "os-search-1": { title: "Bản ghi lắm lời", pts: 50, diff: "easy", hash: "6d1e4ae9975647269fdc233a7a663932a0d4a0283f0e62a6a2d62279b1838cb8", body: "<p>Quản trị viên của <code>caphemay.example</code> để lại một ghi chú trong DNS.</p>", hints: ["Bản ghi DNS nào chứa văn bản tự do?", "<code>dig TXT caphemay.example</code>"] },
    "os-search-2": { title: "Bio đã xoá", pts: 150, diff: "med", hash: "706bfb709fd053035a0a5df464b79fda4ebb301f4729bd3b7a8ba7eccfea984b", body: "<p>Ai đã viết báo cáo thường niên của Cà Phê Mây? Người đó từng ghi một thứ không nên ghi trong bio GitHub, rồi xoá đi.</p>", hints: ["<code>exiftool downloads/bao-cao-2025.pdf</code>, xem trường Author.", "<code>sherlock &lt;author&gt;</code> tìm tài khoản, rồi <code>wayback github.example/&lt;author&gt;</code> và xem bản lưu cũ nhất."] },
    "os-search-3": { title: "Cấu hình lộ thiên", pts: 125, diff: "med", hash: "7830d836d2f1490d31160f5811acea0fd1194d22846dea1f0f263075668a8a2a", body: "<p>Trang tuyển dụng nhắc tới một môi trường staging. Ở đó có file cấu hình bị máy tìm kiếm index. Mật khẩu database là flag.</p>", hints: ["Dùng <code>site:</code> với domain staging, hoặc cả domain chính (bao gồm subdomain).", "<code>site:caphemay.example ext:env</code>"] },
  },
});

lesson({
  id: "osint-geo",
  track: "osint",
  order: 2,
  level: 2,
  title: "Định vị ảnh",
  short: "EXIF GPS, đọc chi tiết trong ảnh, tìm ảnh ngược, bóng nắng",
  time: "40 phút",
  html: `
<h2 id="quy-trinh">Quy trình định vị một bức ảnh</h2>
<ol class="steps-v">
<li><strong>Metadata trước:</strong> <code>exiftool anh.jpg</code>. Ảnh chụp thẳng từ điện thoại thường có GPS. Mạng xã hội lớn xoá EXIF khi tải lên, nhưng file gửi qua email, drive, chat dạng "file" thì vẫn còn.</li>
<li><strong>Tìm ảnh ngược:</strong> Google Lens, Yandex Images (mạnh với địa danh và khuôn mặt cảnh quan), Bing Visual Search, TinEye (tìm bản gốc, ngày xuất hiện sớm nhất). Cắt riêng một chi tiết đặc trưng (toà nhà, biển hiệu) rồi tìm thường hiệu quả hơn cả ảnh.</li>
<li><strong>Đọc chi tiết:</strong> chữ viết, ngôn ngữ, tên miền và số điện thoại trên biển hiệu, biển số xe, phía lái xe, kiểu cột điện, vạch kẻ đường, thực vật, kiến trúc.</li>
<li><strong>Thu hẹp và xác minh:</strong> Google Maps / Street View, ảnh vệ tinh, OpenStreetMap (truy vấn Overpass Turbo: "tìm mọi nhà thờ cạnh sông trong vùng X").</li>
</ol>

<h2 id="exif">EXIF GPS</h2>
<p>Toạ độ trong EXIF thường ở dạng độ–phút–giây. Đổi sang thập phân: <code>độ + phút/60 + giây/3600</code>. Vĩ độ Nam và kinh độ Tây mang dấu âm.</p>
${txt`
GPS Latitude  : 21 deg 1' 43.30" N   →  21 + 1/60 + 43.30/3600  = 21.0287
GPS Longitude : 105 deg 51' 8.60" E  → 105 + 51/60 + 8.60/3600 = 105.8524
`}
<div data-chal="os1"></div>

<h2 id="manh-moi">Manh mối nhìn thấy được</h2>
<table>
<tr><th>Manh mối</th><th>Cho biết gì</th></tr>
<tr><td>Chữ viết</td><td>Chữ Thái, Khmer, Lào, Hàn, Cyrillic… thu hẹp ngay tới vài quốc gia</td></tr>
<tr><td>Phía lái xe</td><td>Bên trái: Anh, Nhật, Thái Lan, Úc, Ấn Độ, Indonesia, Malaysia… Bên phải: phần lớn thế giới còn lại, gồm Việt Nam</td></tr>
<tr><td>Mã điện thoại, tên miền</td><td><code>+84</code>/<code>.vn</code> Việt Nam, <code>+66</code>/<code>.th</code> Thái Lan, <code>+81</code>/<code>.jp</code> Nhật…</td></tr>
<tr><td>Biển số xe</td><td>Màu, tỉ lệ, kiểu chữ khác nhau theo quốc gia</td></tr>
<tr><td>Hạ tầng</td><td>Cột điện, vạch kẻ đường, biển báo, kiểu trạm xăng</td></tr>
<tr><td>Mặt trời và bóng</td><td>Hướng ống kính, giờ chụp, bán cầu</td></tr>
</table>
<div class="callout idea"><b>Luyện thêm</b><p>GeoGuessr và các bài "GeoOSINT" trong CTF luyện chính kỹ năng này. Cộng đồng có sẵn tài liệu nhận diện cột điện, biển số theo quốc gia.</p></div>

<h2 id="mat-troi">Mặt trời và bóng đổ</h2>
<p>Mặt trời mọc ở phía Đông, lặn ở phía Tây; buổi trưa ở bán cầu Bắc (phía bắc chí tuyến Bắc) mặt trời nằm hơi về phía Nam. Bóng luôn đổ <strong>ngược</strong> hướng mặt trời. Biết giờ chụp và hướng bóng là suy ra được hướng ống kính, và ngược lại. Công cụ <a href="https://www.suncalc.org/" target="_blank" rel="noopener">SunCalc</a> cho vị trí mặt trời tại bất kỳ điểm và thời điểm nào.</p>
${txt`
           Bắc
            ↑
  Tây ←   (bạn)   → Đông
            ↓
           Nam
Nếu bạn quay mặt về hướng Nam: bên phải là Tây, bên trái là Đông.
`}
<div data-chal="os-geo-2"></div>
<div data-chal="os-geo-3"></div>
<div data-quiz="0"></div>
`,
  quiz: [
    { q: "Ảnh tải lên từ một mạng xã hội lớn thường không có GPS trong EXIF. Vì sao?", options: ["Vì điện thoại không ghi GPS", "Vì nền tảng xoá metadata khi xử lý ảnh", "Vì GPS bị mã hoá", "Vì EXIF chỉ có ở file PNG"], answer: 1, explain: "Đa số nền tảng lớn xoá EXIF để bảo vệ quyền riêng tư. File gửi nguyên bản (email, drive, chat dạng file) thì thường vẫn giữ." },
  ],
  challenges: {
    os1: { title: "Ảnh kỷ niệm", pts: 75, diff: "easy", hash: "c781c667bfeeceb2f0cacf81e8a08da8f4523fd8ef77b452f32cd54f68c06cfe", body: '<p>Một người bạn gửi ảnh với lời nhắn "đoán xem mình đang ở hồ nào?". Đây là kết quả <code>exiftool</code>. Flag: <code>zCTF{tên_hồ}</code>, không dấu, viết thường, nối bằng <code>_</code>. Ví dụ: <code>zCTF{ho_tay}</code>.</p><div class="chal-data">Make                    : Apple\nCamera Model Name       : iPhone 13\nDate/Time Original      : 2024:02:10 07:42:15\nGPS Latitude            : 21 deg 1\' 43.30" N\nGPS Longitude           : 105 deg 51\' 8.60" E\nGPS Position            : 21.0287 N, 105.8524 E</div>', hints: ["Dán toạ độ <code>21.0287, 105.8524</code> vào Google Maps hoặc OpenStreetMap.", "Hồ nằm giữa trung tâm Hà Nội, có Tháp Rùa."] },
    "os-geo-2": {
      title: "Bóng buổi sáng", pts: 75, diff: "easy", hash: "06417d45d8144022aae72b236ebd93ab40eee1550a629ed93f3d27c1722fa64e",
      body: `<p>Ảnh chụp ở Hà Nội lúc <strong>6:45 sáng ngày 21/3</strong> (xuân phân: mặt trời mọc gần đúng hướng Đông). Bóng của cột đèn đổ thẳng sang <strong>bên phải</strong> khung hình. Người chụp đang quay ống kính về hướng nào? Flag: <code>zCTF{bac}</code>, <code>zCTF{nam}</code>, <code>zCTF{dong}</code> hoặc <code>zCTF{tay}</code>.</p>
<div class="diagram"><svg viewBox="0 0 520 220" width="520" role="img" aria-label="Cột đèn và bóng đổ sang phải">
<rect width="520" height="150" fill="#f6d6a8"/><rect y="150" width="520" height="70" fill="#9aa37a"/>
<circle cx="40" cy="70" r="18" fill="#fff3c4" opacity=".7"/>
<polygon points="250,150 262,150 470,182 470,192" fill="#3c4430" opacity=".55"/>
<rect x="250" y="40" width="12" height="112" fill="#3a3f47"/><rect x="236" y="34" width="40" height="10" rx="3" fill="#3a3f47"/>
<text x="260" y="212" text-anchor="middle" font-size="12" fill="#2b2f22" font-family="sans-serif">bóng đổ → bên phải khung hình</text>
</svg></div>`,
      hints: ["Bóng đổ ngược hướng mặt trời. 6:45 sáng xuân phân, mặt trời ở hướng Đông, vậy bóng đổ về hướng nào?", "Bóng đổ về Tây và Tây nằm bên phải khung hình. Quay mặt về hướng nào thì Tây ở bên phải?"],
    },
    "os-geo-3": {
      title: "Quốc gia nào?", pts: 100, diff: "med", hash: "f856b63d7c469bf030d03b1be1fd781f01df2df3b19f1d918c035fc363389524",
      body: `<p>Một bức ảnh đường phố được đăng kèm dòng chữ "đoán xem mình đi du lịch ở đâu". Xác định quốc gia. Flag: tên quốc gia bằng tiếng Việt không dấu, viết thường, nối bằng <code>_</code>, ví dụ <code>zCTF{viet_nam}</code>.</p>
<div class="diagram"><svg viewBox="0 0 560 300" width="560" role="img" aria-label="Phố có biển hiệu chữ Thái, số điện thoại +66, xe chạy bên trái">
<rect width="560" height="300" fill="#cfe7f5"/>
<rect x="20" y="40" width="250" height="160" fill="#efe3cf" stroke="#a89c86"/>
<rect x="34" y="54" width="222" height="44" rx="6" fill="#7a2d1e"/>
<text x="145" y="84" text-anchor="middle" font-size="24" fill="#fff6e0" font-family="sans-serif">ร้านกาแฟ บ้านเมฆ</text>
<text x="145" y="122" text-anchor="middle" font-size="14" fill="#3a2a1a" font-family="monospace">โทร +66 2 123 4567</text>
<rect x="60" y="136" width="60" height="64" fill="#5b4632"/><rect x="160" y="136" width="80" height="44" fill="#9ccbe0" stroke="#5b4632"/>
<rect x="300" y="60" width="230" height="140" fill="#e2dccd" stroke="#a89c86"/>
<rect x="320" y="80" width="190" height="34" fill="#1f5fa8"/><text x="415" y="103" text-anchor="middle" font-size="18" fill="#fff" font-family="sans-serif">ถนนสุขสวัสดิ์</text>
<rect y="200" width="560" height="100" fill="#55585d"/>
<line x1="0" y1="250" x2="560" y2="250" stroke="#f2f2f2" stroke-width="4" stroke-dasharray="26 18"/>
<g transform="translate(110 260) scale(0.8)"><rect width="150" height="34" rx="8" fill="#d23c3c"/><rect x="20" y="-16" width="96" height="22" rx="6" fill="#d23c3c"/><rect x="28" y="-12" width="38" height="16" fill="#bfe3f2"/><rect x="72" y="-12" width="38" height="16" fill="#bfe3f2"/><circle cx="30" cy="36" r="10" fill="#222"/><circle cx="120" cy="36" r="10" fill="#222"/><rect x="58" y="14" width="40" height="14" fill="#fff" stroke="#222"/><text x="78" y="25" text-anchor="middle" font-size="8" fill="#222" font-family="sans-serif">กข 1234</text></g>
<polygon points="70,276 92,266 92,286" fill="#ffd23f"/>
<text x="250" y="282" font-size="13" fill="#fff" font-family="sans-serif">← xe chạy sang trái, ở làn gần người chụp</text>
<text x="280" y="228" text-anchor="middle" font-size="12" fill="#e6e6e6" font-family="sans-serif">làn xa: xe chạy sang phải</text>
</svg></div>`,
      hints: ["Có ba manh mối độc lập: chữ viết trên biển, mã điện thoại, phía lái xe. Chúng phải cùng chỉ về một nước.", "<code>+66</code> là mã của quốc gia nào? Bảng manh mối ở trên có đáp án."],
    },
  },
});
