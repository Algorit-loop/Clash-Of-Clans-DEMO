/* Track foundation — bài 6 */

lesson({
  id: "python-ctf",
  track: "foundation",
  order: 6,
  level: 2,
  title: "Python cho CTF",
  short: "bytes vs str, chuyển đổi số, struct, hashlib, brute force, requests",
  time: "45 phút",
  html: `
<h2 id="vi-sao">Vì sao là Python</h2>
<p>Gần như mọi lời giải CTF đều có một đoạn script Python: giải mã nhiều lớp, brute force khoá, gửi hàng nghìn request, nói chuyện với server qua socket. Bài này tập trung vào những gì dùng nhiều nhất. Các ô code bên dưới chạy <strong>Python thật</strong> trong trình duyệt (bấm <em>Chạy</em> hoặc <kbd>Ctrl</kbd>+<kbd>Enter</kbd>).</p>

<h2 id="bytes-str">bytes và str</h2>
<p>Đây là chỗ người mới hay vấp nhất. <code>str</code> là chuỗi ký tự (Unicode); <code>bytes</code> là dãy số 0–255. Mạng, file nhị phân, hàm mã hoá và hash đều làm việc với <code>bytes</code>.</p>
${py`
s = "zCTF"            # str
b = b"zCTF"           # bytes
b == s.encode()       # True   str  -> bytes: .encode()
b.decode()            # 'zCTF' bytes -> str:  .decode()
b[0]                  # 122    phần tử của bytes là số nguyên
list(b)               # [122, 67, 84, 70]
bytes([122, 67])      # b'zC'
`}
<div class="callout warn"><b>Lỗi kinh điển</b>
<p><code>TypeError: can't concat str to bytes</code>: bạn đang cộng <code>"abc" + b"def"</code>. Đưa cả hai về cùng một kiểu trước.</p></div>

<h2 id="chuyen-doi">Chuyển đổi qua lại</h2>
<table>
<tr><th>Muốn</th><th>Code</th><th>Kết quả</th></tr>
<tr><td>ký tự → số</td><td><code>ord("z")</code></td><td><code>122</code></td></tr>
<tr><td>số → ký tự</td><td><code>chr(122)</code></td><td><code>'z'</code></td></tr>
<tr><td>bytes → hex</td><td><code>b"zC".hex()</code></td><td><code>'7a43'</code></td></tr>
<tr><td>hex → bytes</td><td><code>bytes.fromhex("7a43")</code></td><td><code>b'zC'</code></td></tr>
<tr><td>số → hex / bin</td><td><code>hex(255)</code>, <code>bin(5)</code></td><td><code>'0xff'</code>, <code>'0b101'</code></td></tr>
<tr><td>chuỗi số → int</td><td><code>int("ff", 16)</code>, <code>int("101", 2)</code></td><td><code>255</code>, <code>5</code></td></tr>
<tr><td>bytes → số lớn</td><td><code>int.from_bytes(b, "big")</code></td><td>dùng nhiều trong RSA</td></tr>
<tr><td>số lớn → bytes</td><td><code>n.to_bytes(length, "big")</code></td><td>ngược lại</td></tr>
<tr><td>Base64</td><td><code>base64.b64decode(s)</code></td><td><code>bytes</code></td></tr>
</table>
<div data-widget="python"><template>
import base64

b = bytes.fromhex("7a4354467b")
print(b, list(b))
print(base64.b64encode(b"zCTF"))

n = int.from_bytes(b"zCTF", "big")
print(n, hex(n))
print(n.to_bytes(4, "big"))

# XOR từng byte với một khoá
key = 0x2a
print(bytes(x ^ key for x in b"secret").hex())
</template></div>

<h2 id="vong-lap">Vòng lặp, list comprehension, brute force</h2>
<p>Brute force là thử mọi khả năng. Với không gian nhỏ (mã PIN 4 số = 10.000 khả năng, khoá XOR 1 byte = 256 khả năng), máy tính làm xong trong chớp mắt.</p>
${py`
import hashlib, itertools, string

# Thử mọi khoá XOR 1 byte, giữ kết quả bắt đầu bằng zCTF
ct = bytes.fromhex("50697e6c51")
for k in range(256):
    pt = bytes(c ^ k for c in ct)
    if pt.startswith(b"zCTF"):
        print(k, pt)

# Thử mọi chuỗi 3 chữ thường
for tup in itertools.product(string.ascii_lowercase, repeat=3):
    word = "".join(tup)
    if hashlib.md5(word.encode()).hexdigest() == "900150983cd24fb0d6963f7d28e17f72":
        print("tìm thấy:", word)   # abc
        break
`}

<h2 id="hashlib">hashlib</h2>
${py`
import hashlib
hashlib.md5(b"password").hexdigest()      # '5f4dcc3b...'
hashlib.sha256(b"password").hexdigest()   # '5e884898...'
`}
<p>Lưu ý: hàm băm nhận <code>bytes</code>, nên phải <code>.encode()</code> chuỗi trước.</p>

<h2 id="struct">struct: đóng gói số thành bytes</h2>
<p>Chương trình C lưu số nguyên trong bộ nhớ dưới dạng bytes cố định (4 byte cho <code>int</code>, 8 byte cho con trỏ 64-bit). <code>struct</code> chuyển qua lại, với ký hiệu thứ tự byte: <code>&lt;</code> little-endian (x86), <code>&gt;</code> big-endian (mạng).</p>
${py`
import struct
struct.pack("<I", 0x41424344)     # b'DCBA'  (4 byte, little-endian)
struct.pack(">I", 0x41424344)     # b'ABCD'
struct.unpack("<I", b"DCBA")[0]   # 1094861636 == 0x41424344
struct.unpack("<4I", data16)      # 4 số 32-bit liên tiếp
`}
<p>Bài <em>Số học &amp; bit</em> giải thích kỹ little-endian. Trong pwn, thư viện pwntools có <code>p32()</code>, <code>p64()</code> làm đúng việc này (trên trang này cũng có sẵn trong ô Python).</p>

<h2 id="requests">requests và socket</h2>
<p>Ngoài trình duyệt, bạn sẽ dùng hai thư viện để nói chuyện với server bài CTF (chúng cần mạng nên không chạy trong ô Python ở đây):</p>
${py`
import requests
r = requests.get("http://chal.example.com/", cookies={"role": "admin"})
print(r.status_code, r.text)
r = requests.post("http://chal.example.com/login", data={"user": "admin", "pass": "x"})

# pwntools: nói chuyện với dịch vụ TCP (thay cho nc)
from pwn import remote
io = remote("chal.example.com", 1337)
print(io.recvline())
io.sendline(b"HELLO")
io.interactive()
`}
<p>Mẫu thường gặp: server đưa 100 phép tính, mỗi câu 1 giây. Gõ tay không kịp, nên viết vòng lặp <code>recvline()</code> → tính → <code>sendline()</code>.</p>

<h2 id="thuc-hanh">Thực hành</h2>
<p>Ô code bên dưới để bạn viết lời giải. Mỗi thử thách cho sẵn dữ liệu; hãy viết script và in ra flag.</p>
<div data-widget="python"><template>
# Viết lời giải ở đây rồi bấm Chạy
data = [122, 68, 86, 73, 127]
print(data)
</template></div>
<div data-chal="py1"></div>
<div data-chal="py2"></div>
<div data-chal="py3"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    { q: "<code>hashlib.sha256(\"abc\")</code> báo lỗi. Vì sao?", options: ["sha256 không tồn tại", "Hàm băm cần bytes, phải dùng <code>\"abc\".encode()</code>", "Phải viết hoa SHA256", "Chuỗi quá ngắn"], answer: 1, explain: "hashlib nhận bytes. <code>hashlib.sha256(b\"abc\")</code> hoặc <code>hashlib.sha256(\"abc\".encode())</code>." },
    { q: "<code>struct.pack(\"&lt;I\", 1)</code> trả về gì?", options: ["<code>b'\\x00\\x00\\x00\\x01'</code>", "<code>b'\\x01\\x00\\x00\\x00'</code>", "<code>b'1'</code>", "<code>1</code>"], answer: 1, explain: "<code>&lt;</code> là little-endian: byte thấp nhất đứng trước." },
  ],
  challenges: {
    py1: { title: "Dịch chuyển theo vị trí", pts: 75, diff: "easy", hash: "c9e08ef08b5c6b122f3d350dcb607b29152e432481ebbcf9139b592948af32f5", body: '<p>Mỗi ký tự của flag đã được đổi thành <code>ord(ký_tự) + vị_trí</code> (vị trí bắt đầu từ 0).</p><div class="chal-data">[122, 68, 86, 73, 127, 113, 54, 55, 120, 104, 128, 63, 107, 112, 118, 64, 111, 132, 66, 144]</div>', hints: ["Vị trí 0: 122 - 0 = 122 = <code>z</code>. Vị trí 1: 68 - 1 = 67 = <code>C</code>.", "<code>\"\".join(chr(v - i) for i, v in enumerate(data))</code>"] },
    py2: { title: "Mã PIN", pts: 100, diff: "med", hash: "1961913ae7b2dc198efe84a8e833c17a548bd7e07768659c8fdb11f34c70b028", body: '<p>Một mã PIN 4 chữ số (0000–9999) có SHA-256 như dưới. Flag là <code>zCTF{pin_XXXX}</code>.</p><div class="chal-data">2c16a0622069b5e83fa149e604e24040856495fcd41b254301538a85f36b1f01</div>', hints: ["Chỉ có 10.000 khả năng. Lặp <code>for pin in range(10000)</code>.", "Nhớ đệm số 0 ở đầu: <code>f\"{pin:04d}\"</code>, rồi <code>hashlib.sha256(s.encode()).hexdigest()</code>."] },
    py3: { title: "Bộ nhớ đảo lộn", pts: 125, diff: "med", hash: "48ab91f2542fb6df582d7fc8eda11360ea82fb21f36d0559283a5431bb31c593", body: '<p>Flag được chia thành các khúc 4 byte, mỗi khúc đọc như một số nguyên <em>big-endian</em>, rồi số đó được ghi vào bộ nhớ dạng <em>little-endian</em> 32-bit. Đây là dump bộ nhớ:</p><div class="chal-data">4654437a74316c7b5f336c745f646e337d323375</div>', hints: ["<code>bytes.fromhex(...)</code>, rồi xét từng khúc 4 byte.", "Mỗi khúc chỉ cần đảo ngược thứ tự byte: <code>chunk[::-1]</code>. Hoặc <code>struct.unpack(\"&lt;I\", chunk)[0].to_bytes(4, \"big\")</code>."] },
  },
});
