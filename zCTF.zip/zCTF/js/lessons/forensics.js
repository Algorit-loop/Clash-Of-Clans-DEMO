/* Track: forensics */

lesson({
  id: "fo-file",
  track: "forensics",
  order: 1,
  level: 1,
  title: "Phân tích file",
  short: "Magic bytes, cấu trúc file, metadata, file lồng nhau",
  time: "45 phút",
  html: `
<h2 id="quy-trinh">Quy trình 5 bước với một file lạ</h2>
<p>Bài forensics nhập môn thường chỉ đưa một file. Trước khi nghĩ tới công cụ phức tạp, luôn chạy đủ 5 bước sau theo thứ tự, vì phần lớn bài dễ được giải ở bước 1–3.</p>
<ol class="steps-v">
<li><strong>Nó thật sự là gì?</strong> <code>file x</code> và <code>xxd x | head</code>: xem magic bytes, đừng tin đuôi file.</li>
<li><strong>Có chữ đọc được không?</strong> <code>strings x | grep -i ctf</code>, thử thêm <code>strings -e l</code> cho chuỗi UTF-16.</li>
<li><strong>Metadata nói gì?</strong> <code>exiftool x</code>: tác giả, phần mềm, ghi chú, GPS, ngày giờ.</li>
<li><strong>Có file khác bị nhét bên trong?</strong> <code>binwalk x</code>, rồi <code>binwalk -e</code> hoặc <code>dd</code> để cắt ra.</li>
<li><strong>Cấu trúc có bị sửa hỏng?</strong> Mở bằng hex editor, so với đặc tả định dạng.</li>
</ol>

<h2 id="magic">Magic bytes</h2>
<p>Hệ điều hành dùng đuôi file để chọn chương trình mở, nhưng nội dung thật được nhận diện bằng vài byte đầu tiên, gọi là <strong>magic bytes</strong> hay <em>file signature</em>. Lệnh <code>file</code> đọc chúng và so với một cơ sở dữ liệu chữ ký.</p>
<table>
<tr><th>Loại</th><th>Magic bytes (hex)</th><th>ASCII</th><th>Ghi chú</th></tr>
<tr><td>PNG</td><td><code>89 50 4E 47 0D 0A 1A 0A</code></td><td><code>.PNG....</code></td><td>Kết thúc bằng chunk <code>IEND</code> + <code>AE 42 60 82</code></td></tr>
<tr><td>JPEG</td><td><code>FF D8 FF</code></td><td><code>ÿØÿ</code></td><td>Kết thúc bằng <code>FF D9</code></td></tr>
<tr><td>GIF</td><td><code>47 49 46 38 39 61</code></td><td><code>GIF89a</code></td><td></td></tr>
<tr><td>PDF</td><td><code>25 50 44 46 2D</code></td><td><code>%PDF-</code></td><td>Kết thúc bằng <code>%%EOF</code></td></tr>
<tr><td>ZIP / DOCX / XLSX / APK / JAR</td><td><code>50 4B 03 04</code></td><td><code>PK..</code></td><td>Office hiện đại thực chất là file zip</td></tr>
<tr><td>GZIP</td><td><code>1F 8B 08</code></td><td></td><td></td></tr>
<tr><td>ELF (Linux)</td><td><code>7F 45 4C 46</code></td><td><code>.ELF</code></td><td></td></tr>
<tr><td>PE (Windows .exe)</td><td><code>4D 5A</code></td><td><code>MZ</code></td><td></td></tr>
</table>
<div class="callout tip"><b>Mẹo</b><p>Danh sách đầy đủ: tìm "List of file signatures" trên Wikipedia. Khi gặp file lạ, tra 4–8 byte đầu là ra.</p></div>

<h2 id="cau-truc">Cấu trúc bên trong: PNG làm ví dụ</h2>
<p>Hầu hết định dạng có cấu trúc rõ ràng. PNG gồm chữ ký 8 byte, sau đó là chuỗi <strong>chunk</strong>, mỗi chunk có 4 phần:</p>
${txt`
┌──────────────┬──────────────┬──────────────────┬──────────────┐
│ Length (4B)  │ Type (4B)    │ Data (Length B)  │ CRC32 (4B)   │
│ big-endian   │ IHDR/IDAT/.. │                  │ của Type+Data│
└──────────────┴──────────────┴──────────────────┴──────────────┘
IHDR (bắt buộc, đầu tiên): rộng, cao, độ sâu màu
IDAT: dữ liệu ảnh đã nén zlib       tEXt/zTXt: chuỗi chú thích
IEND: kết thúc file. Mọi thứ phía sau IEND đều bị trình xem ảnh bỏ qua.
`}
<p>Chữ hoa/thường trong tên chunk có ý nghĩa: chữ đầu viết hoa = chunk bắt buộc (<em>critical</em>). Đổi <code>IHDR</code> thành <code>ihdr</code> là đủ để mọi trình xem ảnh từ chối file. Vì CRC tính trên cả Type, sửa sai một ký tự là CRC không khớp; công cụ <code>pngcheck</code> sẽ chỉ ra chunk lỗi.</p>
${sh`
$ pngcheck -v broken.png
File: broken.png (5821 bytes)
  this is neither a PNG or JNG image nor a MNG stream
$ xxd broken.png | head -2
00000000: 2e2e 2e2e 0d0a 1a0a 0000 000d 6968 6472  ............ihdr
00000010: 0000 0230 0000 0096 0806 0000 00a1 33e4  ...0..........3.
`}

<div data-chal="fo1"></div>

<h2 id="hex-editor">Sửa file bằng hex editor</h2>
<p>Trên máy thật: <code>hexedit</code>, <code>ghex</code>, <code>bless</code>, hoặc online <a href="https://hexed.it/" target="_blank" rel="noopener">hexed.it</a>. Quy trình: xác định byte sai bằng cách so với đặc tả, sửa đúng giá trị, lưu, mở lại. Trong Python: đọc <code>bytearray</code>, sửa chỉ số, ghi lại.</p>
${py`
data = bytearray(open("broken.png", "rb").read())
data[0:8] = b"\x89PNG\r\n\x1a\n"
open("fixed.png", "wb").write(data)
`}
<div data-chal="fo-file-3"></div>

<h2 id="strings">strings: không chỉ ASCII</h2>
<p><code>strings</code> in mọi chuỗi ký tự in được dài từ 4 trở lên (đổi bằng <code>-n</code>). Mặc định nó chỉ tìm ASCII 1 byte/ký tự. Chương trình Windows thường lưu chuỗi dạng <strong>UTF-16LE</strong>: mỗi ký tự 2 byte, byte thứ hai là <code>00</code> (<code>A</code> = <code>41 00</code>). Với kiểu đó phải dùng <code>strings -e l</code> (little-endian 16-bit).</p>
${sh`
$ strings -n 8 firmware.bin | head
$ strings -e l malware.exe | grep -i http
`}

<h2 id="exif">Metadata</h2>
<p>Ảnh, PDF, file Office đều mang metadata: tác giả, phần mềm tạo, thời gian, toạ độ GPS, ghi chú. <code>exiftool</code> đọc được gần như mọi định dạng. Trong CTF, flag hoặc mật khẩu hay nằm ở các trường <code>Comment</code>, <code>Author</code>, <code>XP Comment</code>, <code>Description</code>.</p>

<h2 id="carving">File lồng nhau và file carving</h2>
<p>Trình xem JPEG dừng đọc ở <code>FF D9</code>, nên ai cũng có thể nối thêm một file zip phía sau mà ảnh vẫn mở bình thường. <code>binwalk</code> quét toàn bộ file tìm chữ ký đã biết và báo vị trí (offset).</p>
${sh`
$ binwalk vacation.jpg
DECIMAL       HEXADECIMAL     DESCRIPTION
--------------------------------------------------------------------------------
0             0x0             JPEG image data, JFIF standard 1.01
5120          0x1400          Zip archive data, ... name: flag.txt
# Cách 1: để binwalk tự cắt
$ binwalk -e vacation.jpg
# Cách 2: tự cắt bằng dd (bs=1: đơn vị 1 byte, skip: bỏ qua N byte đầu)
$ dd if=vacation.jpg of=out.zip bs=1 skip=5120
$ unzip out.zip
`}
<p>Kỹ thuật này gọi là <strong>file carving</strong>: cắt file ra khỏi một khối dữ liệu dựa trên chữ ký đầu/cuối. Công cụ chuyên dụng: <code>foremost</code>, <code>scalpel</code>, <code>photorec</code> (khôi phục cả từ ổ đĩa đã format).</p>

<h2 id="thuc-hanh">Thực hành</h2>
<p>Thư mục <code>evidence/</code> có ba file. Dùng terminal dưới đây cho hai thử thách cuối.</p>
<div data-widget="shell" data-fs="fo-files" data-height="380"></div>
<div data-chal="fo-file-2"></div>
<div data-chal="fo-file-4"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    { q: "File tên <code>holiday.jpg</code> nhưng 4 byte đầu là <code>50 4B 03 04</code>. Bạn nên làm gì?", options: ["Mở bằng trình xem ảnh", "Giải nén như file zip", "Xoá file", "Chạy file như chương trình"], answer: 1, explain: "<code>50 4B 03 04</code> (\"PK\") là chữ ký ZIP. Đuôi .jpg chỉ là ngụy trang." },
    { q: "Vì sao dữ liệu nối sau <code>FF D9</code> của JPEG không làm ảnh hỏng?", options: ["Vì JPEG được nén", "Vì trình xem ảnh dừng đọc ở marker kết thúc", "Vì exiftool xoá nó", "Vì hệ điều hành ẩn nó"], answer: 1, explain: "<code>FF D9</code> (EOI) báo hết ảnh, mọi byte phía sau bị bỏ qua. Đó là lý do binwalk luôn là bước bắt buộc." },
  ],
  challenges: {
    fo1: { title: "Đuôi giả", pts: 50, diff: "easy", hash: "b38baef84bfe84db0ba3374d0fa3f26fa02642609bbd7fbd029f111185cbf826", body: '<p>File <code>meme.png</code> không mở được. Đây là kết quả <code>xxd meme.png | head -2</code>. Nó thật ra là loại file gì? Flag: <code>zCTF{đuôi_file_viết_thường}</code>, ví dụ <code>zCTF{gif}</code>.</p><div class="chal-data">00000000: 2550 4446 2d31 2e37 0a25 e2e3 cfd3 0a31  %PDF-1.7.%.....1\n00000010: 2030 206f 626a 0a3c 3c2f 5479 7065 2f43   0 obj.&lt;&lt;/Type/C</div>', hints: ["So 4 byte đầu với bảng magic bytes.", "Cột ASCII bên phải đã nói hết."] },
    "fo-file-3": { title: "Ảnh hỏng header", pts: 125, diff: "med", widget: "png-fix", hash: "ccbcbf2a097579637f6663ba30d9ef8dc41bc2cf6f9e01f0bac7c817c43cdc3c", body: "<p>Ảnh <code>broken.png</code> bị sửa hỏng ở hai chỗ trong 16 byte đầu. Sửa lại cho đúng đặc tả PNG rồi bấm <em>Mở ảnh</em>. Flag nằm trong ảnh.</p>", hints: ["Chữ ký PNG đủ 8 byte là <code>89 50 4E 47 0D 0A 1A 0A</code>.", "Chunk đầu tiên phải tên <code>IHDR</code> viết hoa: <code>49 48 44 52</code>. Chữ thường khác chữ hoa đúng 0x20."] },
    "fo-file-2": { title: "Chuỗi hai byte", pts: 100, diff: "med", hash: "df922e096b18ae182fd31814f17bd69e3f65b25577309d2cb54980b5e2373aed", body: "<p><code>evidence/firmware.bin</code> chứa một khoá sao lưu. <code>strings</code> thường không tìm thấy nó.</p>", hints: ["Thử <code>strings evidence/firmware.bin</code>, có admin_password nhưng không có flag. Flag được lưu kiểu khác.", "Chuỗi UTF-16LE: <code>strings -e l evidence/firmware.bin</code>"] },
    "fo-file-4": { title: "Kỳ nghỉ bí mật", pts: 125, diff: "med", hash: "6f83ce671e8d8d18f16c1ce80ee66d605a96c8ced4cd8b2548c7560e17ec0529", body: "<p><code>evidence/vacation.jpg</code> mở ra chỉ là một bức ảnh. exiftool có cảnh báo gì đó.</p>", hints: ["<code>exiftool evidence/vacation.jpg</code> báo có dữ liệu sau marker EOI. <code>binwalk</code> xem đó là gì.", "<code>binwalk -e evidence/vacation.jpg</code> rồi <code>cat</code> file trong thư mục <code>_vacation.jpg.extracted</code>. Hoặc <code>dd ... skip=5120</code> rồi <code>unzip</code>."] },
  },
});

lesson({
  id: "fo-stego",
  track: "forensics",
  order: 2,
  level: 2,
  title: "Steganography",
  short: "Giấu tin trong ảnh và âm thanh: bit plane, LSB, dữ liệu nối đuôi",
  time: "45 phút",
  html: `
<h2 id="khai-niem">Giấu tin khác mã hoá</h2>
<p><strong>Mã hoá</strong> làm nội dung không đọc được, nhưng ai cũng biết có bí mật. <strong>Steganography</strong> giấu chính sự tồn tại của bí mật: một bức ảnh mèo bình thường nhưng mang theo thông điệp. Trong CTF, stego thường kết hợp với các bước phân tích file ở bài trước.</p>
<table>
<tr><th>Kỹ thuật</th><th>Dấu hiệu</th><th>Công cụ</th></tr>
<tr><td>Chữ gần trùng màu nền</td><td>Ảnh tối/đơn sắc khả nghi</td><td>Chỉnh độ sáng, StegSolve</td></tr>
<tr><td>Bit plane</td><td>Ảnh bình thường</td><td>StegSolve, Aperi'Solve</td></tr>
<tr><td>LSB (bit thấp nhất)</td><td>Ảnh PNG/BMP không nén mất dữ liệu</td><td><code>zsteg</code>, <code>stegsolve</code>, script Python</td></tr>
<tr><td>Nối dữ liệu sau EOF</td><td><code>exiftool</code> báo "trailer data"</td><td><code>binwalk</code>, <code>strings</code>, <code>tail -c</code></td></tr>
<tr><td>Steghide (JPEG, có mật khẩu)</td><td>Ảnh JPEG, đề có gợi ý mật khẩu</td><td><code>steghide</code>, <code>stegseek</code> (bẻ bằng rockyou)</td></tr>
<tr><td>Âm thanh: spectrogram</td><td>File .wav/.mp3 nghe như nhiễu</td><td>Audacity, Sonic Visualiser</td></tr>
</table>

<h2 id="mau">Màu gần trùng nhau</h2>
<p>Mắt người không phân biệt được <code>rgb(5,5,5)</code> và <code>rgb(12,12,12)</code>, nhưng máy thì có. Khuếch đại độ sáng (nhân mỗi giá trị lên nhiều lần) là thấy ngay.</p>
<div data-chal="fo2"></div>

<h2 id="bit-plane">Bit plane</h2>
<p>Mỗi kênh màu (Red, Green, Blue) của một điểm ảnh là một số 0–255, tức 8 bit. Lấy riêng <strong>một bit</strong> của mọi điểm ảnh sẽ được một ảnh đen trắng gọi là <em>bit plane</em>.</p>
${txt`
Red = 201 = 1 1 0 0 1 0 0 1
            ↑               ↑
          bit 7           bit 0
          (MSB)           (LSB)
Đổi bit 7: giá trị thay đổi 128 → thấy rõ.   Đổi bit 0: thay đổi 1 → mắt không thấy.
`}
<p>Bit cao (6, 7) trông giống ảnh gốc. Bit thấp (0, 1, 2) thường trông như nhiễu ngẫu nhiên. Nếu một bit plane thấp lại hiện ra hình chữ rõ ràng, chắc chắn có người đã chỉnh nó. StegSolve và <a href="https://www.aperisolve.com/" target="_blank" rel="noopener">Aperi'Solve</a> hiển thị cả 24 bit plane để bạn duyệt nhanh.</p>

<h2 id="lsb">LSB: giấu dữ liệu vào bit cuối</h2>
<p>Thay vì vẽ hình, kỹ thuật LSB nhét <strong>từng bit của thông điệp</strong> vào bit 0 của các kênh màu, lần lượt từng điểm ảnh. Ảnh 1000×1000 chứa được 1000×1000×3 bit ≈ 375 KB mà không thay đổi gì nhìn thấy được.</p>
${py`
from PIL import Image          # pip install pillow
img = Image.open("sunset.png").convert("RGB")
bits = ""
for (r, g, b) in img.getdata():
    bits += f"{r & 1}{g & 1}{b & 1}"     # thứ tự R, G, B — kiểu "b1,rgb,lsb,xy" của zsteg
data = bytes(int(bits[i:i+8], 2) for i in range(0, len(bits), 8))
print(data[:80])
`}
<p>Có nhiều biến thể: thứ tự kênh (RGB, BGR), bit nào (0, 1…), duyệt theo hàng hay cột, bit đầu là MSB hay LSB. <code>zsteg -a anh.png</code> thử hàng loạt tổ hợp tự động. Lưu ý LSB chỉ sống sót trong định dạng <strong>nén không mất dữ liệu</strong> (PNG, BMP); lưu lại thành JPEG sẽ xoá sạch.</p>
<div data-widget="lsb"></div>
<div data-chal="fo-stego-2"></div>
<div data-chal="fo-stego-3"></div>

<h2 id="eof">Dữ liệu sau IEND / EOF và steghide</h2>
<p>Giống JPEG, mọi byte sau chunk <code>IEND</code> của PNG đều bị bỏ qua. Dữ liệu nối đuôi có thể là chữ, base64, hoặc cả một file zip.</p>
${sh`
$ exiftool cat.png | grep -i warning
Warning                         : [minor] Trailer data after PNG IEND chunk
$ strings cat.png | tail -3
$ tail -c 64 cat.png | xxd
`}
<p><strong>steghide</strong> giấu dữ liệu trong hệ số nén của JPEG và cần mật khẩu. Nếu đề không cho, thử <code>stegseek anh.jpg rockyou.txt</code> để dò mật khẩu, hoặc tìm trong metadata.</p>
<div data-widget="shell" data-fs="fo-stego" data-height="300"></div>
<div data-chal="fo-stego-4"></div>

<h2 id="audio">Âm thanh</h2>
<ul>
<li><strong>Spectrogram</strong>: biểu đồ tần số theo thời gian. Người ra đề có thể "vẽ" chữ bằng tần số. Audacity: chọn track → <em>Spectrogram</em>.</li>
<li><strong>Morse / DTMF</strong>: tiếng bíp dài ngắn hoặc âm bấm phím điện thoại, giải bằng dCode.</li>
<li><strong>SSTV</strong>: âm thanh rè rè kiểu vệ tinh, giải mã thành ảnh bằng ứng dụng như QSSTV, Robot36.</li>
<li><strong>LSB âm thanh</strong>: giống ảnh, nhưng trên mẫu âm thanh WAV.</li>
</ul>
<div data-quiz="0"></div>
`,
  quiz: [
    { q: "Bạn tải về một ảnh PNG có giấu dữ liệu bằng LSB, rồi lưu lại thành JPEG. Dữ liệu giấu sẽ thế nào?", options: ["Vẫn còn nguyên", "Gần như chắc chắn bị phá huỷ", "Được mã hoá thêm", "Chuyển sang metadata"], answer: 1, explain: "JPEG nén mất dữ liệu, thay đổi giá trị điểm ảnh nên các bit thấp bị xáo trộn hoàn toàn." },
  ],
  challenges: {
    fo2: { title: "Bóng tối", pts: 75, diff: "easy", widget: "stego", hash: "6706409ace50c294f4c37503b97ae63e9d31e24c2653261ebc36be4ce2c76a14", body: "<p>Một bức ảnh trông đen hoàn toàn. Thật sao?</p>", hints: ["Ảnh không đen tuyệt đối. Thử khuếch đại độ sáng.", "Kéo thanh khuếch đại lên khoảng 20x."] },
    "fo-stego-2": { title: "Lớp thứ hai", pts: 100, diff: "med", hash: "b546d00dcaf97a2ea13752d6c815ac7bb6c4e3bcf4065a90d44db837a8eb0115", body: "<p>Ảnh hoàng hôn ở trên có một dòng chữ vẽ trong một bit plane thấp. Duyệt các kênh và bit để tìm nó.</p>", hints: ["Bit 0 của mọi kênh đều trông như nhiễu ở vài hàng đầu (đó là dữ liệu của thử thách sau). Thử bit 1.", "Kênh Green, bit 1."] },
    "fo-stego-3": { title: "Bit cuối cùng", pts: 150, diff: "med", hash: "de1c6d5966d4326c60bd00c36df4a7dbdd918bdcd487d7213ac91d832cffc1fe", body: "<p>Một thông điệp văn bản được giấu theo kiểu LSB kinh điển trong cùng bức ảnh. Trích xuất nó.</p>", hints: ["Xem bit plane 0 của cả ba kênh: chỉ vài hàng đầu là nhiễu bất thường. Dữ liệu nằm đó.", "Phần Trích xuất: chọn R, G, B, bit 0 (cấu hình b1,rgb,msb,xy) rồi bấm Trích xuất."] },
    "fo-stego-4": { title: "Sau dấu chấm hết", pts: 100, diff: "easy", hash: "81c7c242ba65590c73ee766a7a3a89d0f112f9155ed1ce4e5a1fe3a559c9f022", body: "<p><code>cat.png</code> trong terminal ở trên có gì đó sau chunk IEND.</p>", hints: ["<code>strings cat.png | tail</code>. Chuỗi cuối trông giống encoding nào?", "<code>strings cat.png | tail -1 | base64 -d</code>"] },
  },
});

lesson({
  id: "fo-network",
  track: "forensics",
  order: 3,
  level: 2,
  title: "Phân tích gói tin mạng",
  short: "pcap, Wireshark, Follow TCP Stream, mật khẩu rõ, DNS exfiltration",
  time: "50 phút",
  html: `
<h2 id="pcap">File pcap là gì</h2>
<p><code>.pcap</code> / <code>.pcapng</code> là bản ghi mọi gói tin đi qua một card mạng, tạo bởi <code>tcpdump</code> hoặc Wireshark. Bài network forensics đưa file này và hỏi: ai nói chuyện với ai, dữ liệu gì bị lộ, kẻ tấn công lấy được gì.</p>
${sh`
# Bắt gói tin trên máy thật (cần quyền root)
$ sudo tcpdump -i eth0 -w capture.pcap
# Đọc nhanh trên terminal
$ tcpdump -r capture.pcap -nn 'port 80' | head
$ tshark -r capture.pcap -Y http.request -T fields -e http.host -e http.request.uri
`}

<h2 id="tang">Nhắc lại các tầng</h2>
<p>Mỗi gói tin là các lớp bọc nhau. Wireshark hiển thị đúng thứ tự này ở khung chi tiết:</p>
${txt`
Ethernet  (MAC nguồn/đích)
 └─ IP     (địa chỉ IP nguồn/đích)
     └─ TCP / UDP  (cổng nguồn/đích; TCP có seq/ack, cờ SYN/ACK/FIN)
         └─ Ứng dụng: HTTP (80), DNS (53/UDP), FTP (21 + cổng dữ liệu), SSH (22), TLS (443)…
`}
<p>Một kết nối TCP bắt đầu bằng bắt tay 3 bước <code>SYN → SYN,ACK → ACK</code> và kết thúc bằng <code>FIN</code>. Wireshark gán mỗi kết nối một <strong>stream index</strong>; gom các gói cùng stream lại là đọc được cả cuộc hội thoại.</p>

<h2 id="filter">Display filter</h2>
<table>
<tr><th>Filter</th><th>Ý nghĩa</th></tr>
<tr><td><code>http</code>, <code>dns</code>, <code>ftp</code>, <code>tcp</code>, <code>udp</code></td><td>Theo giao thức</td></tr>
<tr><td><code>ip.addr == 10.0.0.5</code></td><td>Nguồn hoặc đích là IP này (<code>ip.src</code>, <code>ip.dst</code> cho một chiều)</td></tr>
<tr><td><code>tcp.port == 21</code></td><td>Theo cổng</td></tr>
<tr><td><code>http.request.method == "POST"</code></td><td>Chỉ request POST (form đăng nhập!)</td></tr>
<tr><td><code>frame contains "pass"</code></td><td>Gói có chứa chuỗi</td></tr>
<tr><td><code>dns.qry.name contains "evil"</code></td><td>Truy vấn DNS theo tên</td></tr>
<tr><td><code>tcp.stream eq 3</code></td><td>Một kết nối TCP</td></tr>
<tr><td><code>a &amp;&amp; b</code>, <code>a || b</code>, <code>!a</code></td><td>Kết hợp điều kiện</td></tr>
</table>
<div class="callout tip"><b>Ba thao tác hay dùng nhất</b>
<p><strong>Statistics → Conversations</strong> để xem ai nói nhiều nhất. <strong>Chuột phải → Follow → TCP Stream</strong> để đọc nguyên cuộc hội thoại. <strong>File → Export Objects → HTTP</strong> để trích xuất file đã tải qua HTTP.</p></div>

<h2 id="cleartext">Giao thức không mã hoá</h2>
<p>HTTP, FTP, Telnet, SMTP, POP3, IMAP (không có TLS) gửi mọi thứ ở dạng rõ, kể cả mật khẩu. FTP tách làm hai kết nối: <strong>kênh điều khiển</strong> (cổng 21: lệnh <code>USER</code>, <code>PASS</code>, <code>RETR</code>) và <strong>kênh dữ liệu</strong> (cổng khác, chứa nội dung file). Nội dung file nằm ở kênh dữ liệu.</p>
<p>Với HTTPS/TLS, nội dung bị mã hoá. Đề sẽ phải cho thêm file key (<code>SSLKEYLOGFILE</code>) để Wireshark giải mã: <em>Edit → Preferences → Protocols → TLS</em>.</p>

<h2 id="dns-exfil">DNS exfiltration</h2>
<p>Mã độc trong mạng bị chặn ra Internet vẫn thường được phép hỏi DNS. Nó tận dụng điều đó: chia dữ liệu thành mẩu nhỏ, mã hoá hex/base32, rồi gửi dưới dạng tên miền con tới máy chủ DNS do kẻ tấn công kiểm soát.</p>
${txt`
0-6d6b2c3a1f.x.attacker.example     ← mẩu 0
1-9e0a77b2c4.x.attacker.example     ← mẩu 1
...
`}
<p>Dấu hiệu: nhiều truy vấn tới cùng một domain lạ, tên miền con dài và ngẫu nhiên, kiểu TXT. Ghép các mẩu theo thứ tự rồi giải mã.</p>

<h2 id="thuc-hanh">Thực hành: Wireshark mô phỏng</h2>
<p>Bản ghi dưới đây từ máy <code>192.168.1.23</code> trong một buổi sáng. Bấm vào một dòng để xem chi tiết; chọn gói TCP rồi bấm <em>Follow TCP Stream</em>.</p>
<div data-widget="wireshark"></div>
<div data-chal="fo-net-1"></div>
<div data-chal="fo-net-2"></div>
<div data-chal="fo-net-3"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    { q: "Trong phiên FTP, nội dung file được tải về nằm ở đâu?", options: ["Trong lệnh RETR ở cổng 21", "Trong kết nối dữ liệu riêng (FTP-DATA)", "Trong truy vấn DNS", "FTP không truyền file"], answer: 1, explain: "Cổng 21 chỉ mang lệnh và phản hồi. Nội dung đi qua một kết nối TCP thứ hai, cổng do lệnh PASV/PORT thoả thuận." },
    { q: "Filter nào hiện các request đăng nhập gửi bằng form?", options: ["<code>http.response.code == 200</code>", "<code>http.request.method == \"POST\"</code>", "<code>dns</code>", "<code>tcp.flags.syn == 1</code>"], answer: 1, explain: "Form đăng nhập gần như luôn gửi bằng POST, dữ liệu nằm trong body của request." },
  ],
  challenges: {
    "fo-net-1": { title: "Đăng nhập trần trụi", pts: 75, diff: "easy", hash: "ee147a7a4076aa0221b1fae5850edd0282e0ae8b2a5a451435627b8a4dbd34a1", body: "<p>Nhân viên <code>an.nguyen</code> đăng nhập vào intranet qua HTTP. Mật khẩu của họ là flag.</p>", hints: ["Filter <code>http.request.method == \"POST\"</code>.", "Xem body của request POST /login. Ký tự <code>%7B</code>, <code>%7D</code> là <code>{</code>, <code>}</code> đã được URL-encode."] },
    "fo-net-2": { title: "Tài liệu bị đánh cắp", pts: 100, diff: "med", hash: "0d5179294467e9e65f5140101ea769e15dcc2a7760f9077016e18760275d93e0", body: "<p>Ai đó tải file <code>secret_plan.txt</code> qua FTP. Đọc nội dung file.</p>", hints: ["Filter <code>ftp</code> để thấy lệnh RETR, sau đó tìm kết nối dữ liệu: <code>ftp-data</code>.", "Chọn một gói FTP-DATA, bấm Follow TCP Stream."] },
    "fo-net-3": { title: "Rò rỉ qua DNS", pts: 175, diff: "hard", hash: "4c34d5d7583b8a24471caf45581ba93cb0c0a895568bf54a70856553b5e651df", body: "<p>Máy <code>192.168.1.23</code> đã bị nhiễm mã độc và gửi dữ liệu ra ngoài mà không cần kết nối TCP nào.</p>", hints: ["Filter <code>dns.qry.name contains \"cdn-update\"</code>. Tên miền con có dạng <code>số-hex</code>.", "Ghép phần hex theo số thứ tự 0, 1, 2… rồi dùng From Hex ở trang Công cụ."] },
  },
});

lesson({
  id: "fo-dfir",
  track: "forensics",
  order: 4,
  level: 3,
  title: "Bộ nhớ, ổ đĩa và log",
  short: "Volatility, Sleuth Kit, phân tích log, dựng timeline sự cố",
  time: "55 phút",
  html: `
<h2 id="dfir">Điều tra sự cố (DFIR)</h2>
<p>Bài forensics nâng cao mô phỏng công việc thật của đội ứng cứu sự cố: có bản sao RAM, ổ đĩa, log của máy bị tấn công, phải trả lời <em>kẻ tấn công vào bằng cách nào, làm gì, lấy gì</em>. Nguyên tắc vàng: <strong>làm việc trên bản sao</strong>, ghi lại hash của chứng cứ (<code>sha256sum</code>) để chứng minh không bị sửa.</p>

<h2 id="memory">Phân tích bộ nhớ với Volatility 3</h2>
<p>RAM chứa thứ không có trên ổ đĩa: tiến trình đang chạy, kết nối mạng, lệnh đã gõ, khoá giải mã, mã độc chỉ chạy trong bộ nhớ. Volatility đọc bản dump RAM và trích xuất các cấu trúc đó qua <strong>plugin</strong>.</p>
<table>
<tr><th>Plugin</th><th>Cho biết</th></tr>
<tr><td><code>windows.info</code></td><td>Phiên bản hệ điều hành, thời điểm chụp</td></tr>
<tr><td><code>windows.pslist</code> / <code>pstree</code></td><td>Tiến trình và quan hệ cha–con</td></tr>
<tr><td><code>windows.cmdline</code></td><td>Tham số dòng lệnh của từng tiến trình</td></tr>
<tr><td><code>windows.netscan</code></td><td>Kết nối mạng, cổng đang mở</td></tr>
<tr><td><code>windows.filescan</code></td><td>File đang được mở trong bộ nhớ, kèm offset</td></tr>
<tr><td><code>windows.dumpfiles --virtaddr X</code></td><td>Trích xuất file ở offset X ra đĩa</td></tr>
<tr><td><code>windows.hashdump</code>, <code>windows.malfind</code></td><td>Hash mật khẩu, vùng nhớ có code bị chèn</td></tr>
</table>
<p>Linux dùng plugin <code>linux.pslist</code>, <code>linux.bash</code> (lịch sử lệnh bash)…</p>
<div class="callout warn"><b>Dấu hiệu bất thường</b>
<p>Tên giả mạo tiến trình hệ thống (<code>svch0st.exe</code>, <code>lsas.exe</code>); tiến trình chạy từ <code>Temp</code> hay <code>Downloads</code>; quan hệ cha–con vô lý như <code>WINWORD.EXE</code> sinh ra <code>powershell.exe</code>; PowerShell với <code>-enc</code> (lệnh mã hoá base64) và <code>-w hidden</code>.</p></div>
<p>PowerShell <code>-EncodedCommand</code> là base64 của chuỗi <strong>UTF-16LE</strong>. Giải mã chỉ bằng <code>base64 -d</code> sẽ ra chữ xen kẽ byte 0:</p>
${sh`
$ echo "SQBFAFgA..." | base64 -d | iconv -f UTF-16LE -t UTF-8
IEX (New-Object Net.WebClient)...
`}
${py`
import base64
print(base64.b64decode("SQBFAFgA...").decode("utf-16-le"))
`}

<h2 id="disk">Ổ đĩa và file đã xoá</h2>
<p>Xoá file thường chỉ đánh dấu vùng dữ liệu là "trống" trong bảng quản lý của hệ thống file (MFT ở NTFS, inode ở ext4). Dữ liệu vẫn còn cho tới khi bị ghi đè. <strong>The Sleuth Kit</strong> đọc thẳng cấu trúc đó:</p>
${sh`
$ mmls disk.img            # bảng phân vùng
$ fls -r disk.img          # liệt kê file, dấu * = đã xoá
r/r * 23:    passwords.txt
$ icat disk.img 23         # in nội dung inode 23
`}
<p>Giao diện đồ hoạ: <strong>Autopsy</strong>. Khôi phục theo chữ ký: <code>photorec</code>, <code>foremost</code>. Thêm: thùng rác (<code>$Recycle.Bin</code>), shadow copy, file swap/pagefile.</p>

<h2 id="logs">Phân tích log</h2>
<p>Log là nhật ký của hệ thống. Với Linux, hay gặp nhất là <code>/var/log/auth.log</code> (đăng nhập, sudo, ssh) và log web server (<code>access.log</code>). Kỹ năng chính là lọc và đếm bằng pipeline:</p>
${sh`
# IP nào thử sai mật khẩu nhiều nhất?
$ grep "Failed password" auth.log | grep -oE "from [0-9.]+" | sort | uniq -c | sort -rn | head
# Sau đó IP đó có đăng nhập thành công không, với user nào?
$ grep "Accepted" auth.log | grep 203.0.113.77
# User-Agent lạ trong log web (sqlmap, nikto, curl…)
$ cut -d'"' -f6 access.log | sort | uniq -c
`}
<p>Trên Windows: Event Viewer, các mã sự kiện 4624 (đăng nhập thành công), 4625 (thất bại), 4688 (tạo tiến trình). Công cụ: <code>chainsaw</code>, <code>hayabusa</code>.</p>

<h2 id="timeline">Dựng timeline</h2>
<p>Kết luận cuối của mọi cuộc điều tra là một dòng thời gian. Ghép dấu vết từ RAM, đĩa, log và mạng theo thứ tự thời gian, ví dụ:</p>
${txt`
02:27:31  WINWORD.EXE mở HoaDon_T11.docm (file tải về)       ← vào bằng email lừa đảo
02:28:02  WINWORD.EXE → powershell.exe -enc ...              ← macro chạy lệnh
02:28:09  powershell.exe → svch0st.exe (trong Temp)          ← cài mã độc
02:28:10  svch0st.exe kết nối 203.0.113.66:4444               ← liên lạc máy chủ điều khiển
02:40:12  notepad.exe mở ke_hoach_mat.txt                     ← mục tiêu
`}

<h2 id="thuc-hanh">Thực hành</h2>
<p>Máy phân tích có ba nguồn chứng cứ trong <code>case/</code>. Bắt đầu bằng <code>cat case/NOTES.txt</code>, sau đó <code>vol -f case/memdump.raw windows.pslist</code>.</p>
<div data-widget="shell" data-fs="fo-dfir" data-height="420"></div>
<div data-chal="fo-mem-1"></div>
<div data-chal="fo-mem-2"></div>
<div data-chal="fo-mem-3"></div>
<div data-chal="fo-mem-4"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    { q: "Trong <code>pstree</code>, tiến trình nào là cha đáng ngờ nhất của <code>powershell.exe</code>?", options: ["<code>explorer.exe</code>", "<code>WINWORD.EXE</code>", "<code>services.exe</code>", "<code>System</code>"], answer: 1, explain: "Word không có lý do gì để chạy PowerShell. Đây là dấu hiệu điển hình của macro độc hại trong tài liệu." },
    { q: "Vì sao file đã xoá thường vẫn khôi phục được?", options: ["Vì hệ điều hành sao lưu tự động", "Vì xoá chỉ đánh dấu vùng là trống, dữ liệu còn tới khi bị ghi đè", "Vì file được mã hoá", "Không khôi phục được"], answer: 1, explain: "Hệ thống file chỉ sửa bảng quản lý. Đó cũng là lý do muốn xoá thật sự phải ghi đè (shred, secure erase)." },
  ],
  challenges: {
    "fo-mem-1": { title: "Lệnh bị mã hoá", pts: 125, diff: "med", hash: "7fd43548981fee7bccdc5c4d833837e7c878e096a21da3e236e02743dd9a9f48", body: "<p>Một tiến trình PowerShell đáng ngờ chạy với lệnh bị mã hoá. Giải mã nó.</p>", hints: ["<code>vol -f case/memdump.raw windows.cmdline</code>, tìm <code>-enc</code>.", "Chuỗi sau <code>-enc</code> là base64 của UTF-16LE: <code>echo &lt;chuỗi&gt; | base64 -d | iconv -f UTF-16LE -t UTF-8</code>"] },
    "fo-mem-2": { title: "File đang mở", pts: 150, diff: "med", hash: "a6feb2abe893bebac49e68c41cfabdf10a6426d9b97d3e3ed0349be2042d6461", body: "<p>Lúc chụp RAM, nạn nhân đang mở một tài liệu bằng Notepad. Lấy nội dung tài liệu đó từ bộ nhớ.</p>", hints: ["<code>windows.cmdline</code> cho biết tên file Notepad mở; <code>windows.filescan</code> cho offset của nó.", "<code>vol -f case/memdump.raw windows.dumpfiles --virtaddr 0xe0001a2b3c40</code> rồi <code>cat</code> file .dat vừa tạo."] },
    "fo-mem-3": { title: "Kẻ đột nhập", pts: 125, diff: "med", hash: "e249834d596f1bd809a277704530cee8e4c5caa445b5866145cc30048784633e", body: "<p>Từ <code>case/logs/auth.log</code> của máy chủ web01: IP nào brute force SSH, và nó đăng nhập thành công bằng tài khoản nào? Flag: <code>zCTF{IP_user}</code>, ví dụ <code>zCTF{10.0.0.1_root}</code>.</p>", hints: ["Đếm: <code>grep Failed case/logs/auth.log | grep -oE \"from [0-9.]+\" | sort | uniq -c | sort -rn</code>", "<code>grep Accepted case/logs/auth.log | grep &lt;IP&gt;</code>"] },
    "fo-mem-4": { title: "Đã xoá nhưng chưa mất", pts: 150, diff: "hard", hash: "6e01a8e395de3ee6b35c1211151d9fec811ca7f463d171761b1970ecb9459eb9", body: "<p>USB của nghi phạm (<code>case/disk.img</code>) từng chứa một file mật khẩu, nhưng đã bị xoá. Mật khẩu VPN là flag.</p>", hints: ["<code>fls -r case/disk.img</code>, file đã xoá có dấu <code>*</code>.", "<code>icat case/disk.img 23</code>"] },
  },
});
