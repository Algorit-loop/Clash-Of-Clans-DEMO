/* Track foundation — bài 5 */

lesson({
  id: "network",
  track: "foundation",
  order: 5,
  level: 2,
  title: "Mạng máy tính",
  short: "IP, port, TCP/UDP, DNS, HTTP, nc, nmap và Wireshark",
  time: "45 phút",
  html: `
<h2 id="mo-hinh">Dữ liệu đi qua mạng thế nào</h2>
<p>Khi bạn mở một trang web, dữ liệu được đóng gói qua nhiều lớp, mỗi lớp thêm "phong bì" riêng. Mô hình <strong>TCP/IP</strong> có 4 lớp:</p>
<table>
<tr><th>Lớp</th><th>Nhiệm vụ</th><th>Giao thức / ví dụ</th></tr>
<tr><td>Ứng dụng</td><td>Nội dung có nghĩa với chương trình</td><td>HTTP, DNS, SSH, FTP, SMTP</td></tr>
<tr><td>Giao vận</td><td>Chuyển dữ liệu giữa hai <strong>cổng</strong> (port)</td><td>TCP, UDP</td></tr>
<tr><td>Mạng</td><td>Định tuyến giữa các <strong>địa chỉ IP</strong></td><td>IP, ICMP (ping)</td></tr>
<tr><td>Liên kết</td><td>Truyền trong cùng mạng vật lý</td><td>Ethernet, Wi-Fi, địa chỉ MAC</td></tr>
</table>
<p>Mô hình OSI 7 lớp chia nhỏ hơn nữa; trong CTF bạn thường chỉ cần mô hình 4 lớp này.</p>

<h2 id="ip">Địa chỉ IP và mạng con</h2>
<p>IPv4 gồm 4 số 0–255, ví dụ <code>10.10.10.5</code>. Ký hiệu <code>/24</code> (CIDR) nghĩa là 24 bit đầu là phần mạng: <code>10.10.10.0/24</code> gồm các địa chỉ <code>10.10.10.0</code> đến <code>10.10.10.255</code>.</p>
<table>
<tr><th>Dải</th><th>Ý nghĩa</th></tr>
<tr><td><code>127.0.0.1</code></td><td>localhost, chính máy mình</td></tr>
<tr><td><code>10.0.0.0/8</code>, <code>172.16.0.0/12</code>, <code>192.168.0.0/16</code></td><td>Mạng nội bộ (private), không đi ra Internet trực tiếp</td></tr>
<tr><td><code>0.0.0.0</code></td><td>Khi server "lắng nghe 0.0.0.0": nhận kết nối trên mọi card mạng</td></tr>
</table>

<h2 id="port">Port, TCP và UDP</h2>
<p>Một máy chạy nhiều dịch vụ; mỗi dịch vụ lắng nghe trên một <strong>port</strong> (0–65535). Kết nối được xác định bởi cặp <code>IP:port</code>.</p>
<div class="grid-2">
  <div class="card"><h4>TCP</h4><p>Có kết nối (bắt tay 3 bước SYN → SYN-ACK → ACK), đảm bảo dữ liệu đến đủ và đúng thứ tự. Dùng cho HTTP, SSH, FTP.</p></div>
  <div class="card"><h4>UDP</h4><p>Gửi rồi thôi, không đảm bảo, nhưng nhanh. Dùng cho DNS, video, game.</p></div>
</div>
<table>
<tr><th>Port</th><th>Dịch vụ</th><th>Port</th><th>Dịch vụ</th></tr>
<tr><td>21</td><td>FTP</td><td>80 / 443</td><td>HTTP / HTTPS</td></tr>
<tr><td>22</td><td>SSH</td><td>3306</td><td>MySQL</td></tr>
<tr><td>25</td><td>SMTP (mail)</td><td>5432</td><td>PostgreSQL</td></tr>
<tr><td>53</td><td>DNS</td><td>6379</td><td>Redis</td></tr>
</table>

<h2 id="dns">DNS</h2>
<p>DNS dịch tên miền thành địa chỉ IP. Mỗi tên miền có nhiều loại <strong>bản ghi</strong>:</p>
<table>
<tr><th>Loại</th><th>Chứa gì</th></tr>
<tr><td><code>A</code> / <code>AAAA</code></td><td>Địa chỉ IPv4 / IPv6</td></tr>
<tr><td><code>CNAME</code></td><td>Bí danh, trỏ sang tên khác</td></tr>
<tr><td><code>MX</code></td><td>Máy chủ nhận mail</td></tr>
<tr><td><code>NS</code></td><td>Máy chủ DNS quản lý tên miền</td></tr>
<tr><td><code>TXT</code></td><td>Chuỗi văn bản tuỳ ý (xác minh tên miền, SPF…) — hay giấu flag</td></tr>
</table>
${sh`
$ dig zctf.local            # mặc định hỏi bản ghi A
$ dig zctf.local MX
$ dig @10.10.10.5 zctf.local TXT     # hỏi một DNS server cụ thể
`}
<div class="callout warn"><b>Zone transfer (AXFR)</b>
<p>AXFR là cơ chế để DNS server phụ sao chép <em>toàn bộ</em> danh sách bản ghi từ server chính. Nếu cấu hình sai cho phép bất kỳ ai hỏi AXFR, mọi tên miền con nội bộ (dev, admin, staging…) bị lộ. Cấu hình đúng: chỉ cho phép AXFR từ IP của server phụ.</p></div>

<h2 id="http">HTTP</h2>
<p>HTTP là văn bản thuần chạy trên TCP. Bạn có thể tự gõ một request bằng <code>nc</code>:</p>
${http`
GET /index.html HTTP/1.1
Host: zctf.local
User-Agent: curl/8.5.0

HTTP/1.1 200 OK
Content-Type: text/html
Content-Length: 120

<html>...</html>
`}
<p>Dòng đầu: <em>phương thức</em> (GET, POST…), <em>đường dẫn</em>, <em>phiên bản</em>. Tiếp theo là các header, rồi một <strong>dòng trống</strong> báo hết phần header. HTTP/1.1 bắt buộc có header <code>Host</code>. Mã trạng thái: 2xx thành công, 3xx chuyển hướng, 4xx lỗi phía client (404 không tìm thấy, 403 cấm), 5xx lỗi server. Track Web sẽ đi sâu hơn.</p>

<h2 id="nc">netcat: dao đa năng</h2>
${sh`
$ nc 10.10.10.5 1337              # kết nối TCP, gõ gì gửi nấy
$ nc -lvnp 4444                   # lắng nghe trên cổng 4444 (làm server)
$ echo "HELLO" | nc host 1337     # gửi một dòng rồi đọc phản hồi
`}
<p>Khi kết nối vào một dịch vụ lạ, việc đầu tiên là đọc <strong>banner</strong>: dòng chào thường tiết lộ tên phần mềm và phiên bản. Kỹ thuật này gọi là <em>banner grabbing</em>.</p>

<h2 id="nmap">nmap: quét cổng</h2>
${sh`
$ nmap 10.10.10.5            # 1000 cổng phổ biến
$ nmap -sV 10.10.10.5        # đoán phiên bản dịch vụ
$ nmap -p- 10.10.10.5        # quét đủ 65535 cổng
PORT     STATE SERVICE  VERSION
22/tcp   open  ssh      OpenSSH 9.6p1
80/tcp   open  http     nginx 1.24.0
`}
<p><code>open</code>: có dịch vụ đang lắng nghe. <code>closed</code>: máy trả lời nhưng không có dịch vụ. <code>filtered</code>: tường lửa chặn, không biết. Dịch vụ CTF hay chạy ở cổng cao không phổ biến, nên nhớ <code>-p-</code>.</p>
<div class="callout danger"><b>Chỉ quét khi được phép</b>
<p>Quét cổng hệ thống của người khác khi không được phép có thể vi phạm pháp luật và điều khoản của nhà mạng. Chỉ quét máy trong phạm vi bài CTF hoặc lab của bạn.</p></div>

<h2 id="wireshark">Wireshark nhập môn</h2>
<p>Wireshark bắt và hiển thị từng gói tin. Trong CTF bạn thường được cho sẵn file <code>.pcap</code>.</p>
<ul>
<li>Lọc theo giao thức: <code>http</code>, <code>dns</code>, <code>ftp</code>, <code>tcp.port == 1337</code>, <code>ip.addr == 10.0.0.5</code>.</li>
<li>Chuột phải một gói → <em>Follow → TCP Stream</em> để đọc cả cuộc hội thoại.</li>
<li><em>File → Export Objects → HTTP</em> để lấy lại file đã truyền.</li>
<li>Giao thức không mã hoá (HTTP, FTP, Telnet) để lộ mật khẩu ở dạng rõ.</li>
</ul>

<h2 id="thuc-hanh">Thực hành: mạng lab</h2>
<p>Bạn đang ở máy <code>10.10.10.2</code> trong mạng lab. Mục tiêu là <code>10.10.10.5</code>. Lệnh thêm: <code>ip a</code>, <code>nmap</code>, <code>dig</code>, <code>host</code>, <code>ping</code>, <code>nc</code>. Thoát khỏi <code>nc</code> bằng <kbd>Ctrl</kbd>+<kbd>C</kbd>.</p>
<div data-widget="shell" data-fs="net-lab" data-height="400"></div>
<div data-chal="nw1"></div>
<div data-chal="nw2"></div>
<div data-chal="nw3"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
<div data-quiz="2"></div>
`,
  quiz: [
    { q: "DNS thường chạy trên giao thức và cổng nào?", options: ["TCP 80", "UDP 53", "TCP 22", "UDP 443"], answer: 1, explain: "DNS dùng UDP 53 cho truy vấn thường; zone transfer (AXFR) dùng TCP 53." },
    { q: "nmap báo một cổng là <code>filtered</code>. Nghĩa là gì?", options: ["Có dịch vụ đang chạy", "Máy trả lời là không có dịch vụ", "Có tường lửa chặn nên nmap không biết trạng thái", "Máy đã tắt"], answer: 2, explain: "filtered: gói tin bị chặn hoặc không có phản hồi, nmap không xác định được cổng mở hay đóng." },
    { q: "Trong một request HTTP gõ tay, điều gì báo cho server biết đã hết phần header?", options: ["Dấu chấm phẩy", "Một dòng trống", "Từ khoá END", "Đóng kết nối"], answer: 1, explain: "Header kết thúc bằng một dòng trống (CRLF CRLF). Sau đó là phần body (nếu có)." },
  ],
  challenges: {
    nw1: { title: "Cổng lạ", pts: 75, diff: "easy", hash: "13f6ef8b99e55b63d42d60cc442d162c23ce736c0589837c3ffd9adbe8745725", body: "<p>Mục tiêu chạy một dịch vụ tự viết ở cổng không phổ biến. Tìm nó, kết nối và làm theo giao thức của nó.</p>", hints: ["<code>nmap 10.10.10.5</code> chỉ quét 1000 cổng phổ biến. Thử <code>nmap -p- 10.10.10.5</code>.", "<code>nc 10.10.10.5 1337</code>, gõ <code>HELP</code>. Dịch vụ muốn bạn chào trước khi xin FLAG."] },
    nw2: { title: "Danh bạ bị lộ", pts: 125, diff: "med", hash: "76af9814faf73428e791e1b41e46f75e2a4a0816dba18df74a0bc0b7d4b05853", body: "<p>Admin để lại một ghi chú trên dịch vụ FTP của mục tiêu. Đọc nó, rồi tìm bản ghi DNS bí mật của <code>zctf.local</code>.</p>", hints: ["<code>nc 10.10.10.5 21</code>, đăng nhập <code>USER anonymous</code>, <code>PASS</code> bất kỳ, rồi <code>LIST</code> và <code>RETR</code>.", "<code>dig @10.10.10.5 zctf.local AXFR</code> liệt kê mọi bản ghi. Bản ghi TXT chứa chuỗi Base64."] },
    nw3: { title: "HTTP bằng tay", pts: 100, diff: "med", hash: "026ee9c4c6799cc2c02bb63c6df179ab3769a1ba7baae9204e779cc07a2e4dd9", body: "<p>Không có curl hay trình duyệt, chỉ có <code>nc</code>. Lấy trang <code>/flag</code> từ web server cổng 80 của mục tiêu.</p>", hints: ["Sau khi <code>nc 10.10.10.5 80</code>, gõ từng dòng: <code>GET /flag HTTP/1.1</code>, rồi header Host.", "Dòng thứ hai: <code>Host: zctf.local</code>. Sau đó nhấn Enter thêm một lần (dòng trống) để gửi."] },
  },
});
