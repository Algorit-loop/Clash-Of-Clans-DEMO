/* Track foundation — bài 3 */

lesson({
  id: "linux",
  track: "foundation",
  order: 3,
  level: 1,
  title: "Linux căn bản",
  short: "Đường dẫn, xem file, tìm kiếm, pipe, xử lý văn bản",
  time: "40 phút",
  html: `
<h2 id="vi-sao">Vì sao phải học terminal?</h2>
<p>Gần như mọi công cụ CTF chạy trên dòng lệnh Linux, và nhiều bài yêu cầu kết nối vào một máy Linux từ xa chỉ có terminal. Bạn chỉ cần nắm chắc khoảng 25 lệnh trong bài này. Cuối bài có terminal giả lập để tập ngay.</p>

<h2 id="cau-truc">Cây thư mục và đường dẫn</h2>
<p>Linux có một cây thư mục duy nhất bắt đầu từ gốc <code>/</code>, không có ổ C:, D: như Windows.</p>
${txt`
/
├── bin, usr/bin   chương trình (ls, cat, python3…)
├── etc            cấu hình hệ thống (passwd, hosts…)
├── home/guest     thư mục nhà của user guest  (~)
├── root           thư mục nhà của root
├── tmp            file tạm, ai cũng ghi được
└── var/log        log hệ thống
`}
<table>
<tr><th>Ký hiệu</th><th>Ý nghĩa</th><th>Ví dụ</th></tr>
<tr><td><code>/</code> ở đầu</td><td>Đường dẫn tuyệt đối (tính từ gốc)</td><td><code>/etc/passwd</code></td></tr>
<tr><td>không có <code>/</code> ở đầu</td><td>Đường dẫn tương đối (tính từ thư mục hiện tại)</td><td><code>notes/todo.txt</code></td></tr>
<tr><td><code>.</code></td><td>Thư mục hiện tại</td><td><code>./run.sh</code></td></tr>
<tr><td><code>..</code></td><td>Thư mục cha</td><td><code>cd ../..</code></td></tr>
<tr><td><code>~</code></td><td>Thư mục nhà</td><td><code>cd ~</code></td></tr>
</table>

<h2 id="di-chuyen">Di chuyển và xem file</h2>
<table>
<tr><th>Lệnh</th><th>Ý nghĩa</th></tr>
<tr><td><code>pwd</code></td><td>Đang đứng ở thư mục nào</td></tr>
<tr><td><code>ls</code> / <code>ls -la</code></td><td>Liệt kê file; <code>-a</code> hiện cả file ẩn (tên bắt đầu bằng <code>.</code>), <code>-l</code> hiện quyền, chủ, kích thước</td></tr>
<tr><td><code>cd thư_mục</code></td><td>Vào thư mục</td></tr>
<tr><td><code>cat file</code></td><td>In toàn bộ nội dung file</td></tr>
<tr><td><code>head -n 5 file</code> / <code>tail -n 5 file</code></td><td>5 dòng đầu / cuối</td></tr>
<tr><td><code>less file</code></td><td>Xem file dài, cuộn được (thoát bằng <kbd>q</kbd>)</td></tr>
<tr><td><code>file x</code></td><td>Đoán loại file dựa vào nội dung, không dựa vào đuôi</td></tr>
<tr><td><code>strings x</code></td><td>In các chuỗi đọc được trong file nhị phân</td></tr>
<tr><td><code>wc -l file</code></td><td>Đếm số dòng</td></tr>
</table>
${sh`
$ pwd
/home/guest
$ ls -la
drwxr-xr-x 1 guest guest   4096 Nov 10 09:00 .
-rw-r--r-- 1 guest guest     32 Nov 10 09:00 .bashrc
drwxr-xr-x 1 guest guest   4096 Nov 10 09:00 notes
-rw-r--r-- 1 guest guest    256 Nov 10 09:00 readme.txt
`}
<div class="callout tip"><b>Đọc hướng dẫn</b>
<p>Quên cú pháp thì gõ <code>man ls</code> (hướng dẫn đầy đủ) hoặc <code>ls --help</code>. Trong terminal giả lập bên dưới, <code>man &lt;lệnh&gt;</code> in bản tóm tắt tiếng Việt.</p></div>

<h2 id="tim-kiem">Tìm kiếm: find và grep</h2>
<p><code>find</code> tìm <em>file</em> theo tên/thuộc tính; <code>grep</code> tìm <em>dòng chữ</em> bên trong file.</p>
${sh`
# Mọi file tên bắt đầu bằng "flag" trong thư mục hiện tại (cả thư mục con)
$ find . -name "flag*"
# Chỉ lấy thư mục
$ find / -type d -name "backup" 2>/dev/null
# Dòng chứa "zCTF" trong một file
$ grep "zCTF" log.txt
# -r: cả thư mục, -i: không phân biệt hoa thường, -n: kèm số dòng
$ grep -rin "password" .
# -v: dòng KHÔNG khớp, -c: chỉ đếm
$ grep -vc "200" access.log
`}
<p><code>2&gt;/dev/null</code> nghĩa là bỏ các thông báo lỗi (như "Permission denied") cho output gọn.</p>

<h2 id="pipe">Pipe và chuyển hướng</h2>
<p>Ý tưởng mạnh nhất của Unix: mỗi lệnh làm một việc nhỏ, rồi <strong>nối</strong> chúng lại.</p>
<table>
<tr><th>Ký hiệu</th><th>Ý nghĩa</th><th>Ví dụ</th></tr>
<tr><td><code>a | b</code></td><td>Output của a thành input của b</td><td><code>cat log | grep error</code></td></tr>
<tr><td><code>&gt; file</code></td><td>Ghi output vào file (ghi đè)</td><td><code>strings bin &gt; out.txt</code></td></tr>
<tr><td><code>&gt;&gt; file</code></td><td>Ghi nối vào cuối file</td><td><code>echo "ok" &gt;&gt; notes.txt</code></td></tr>
<tr><td><code>&lt; file</code></td><td>Lấy input từ file</td><td><code>tr a-z A-Z &lt; in.txt</code></td></tr>
<tr><td><code>a ; b</code></td><td>Chạy a rồi chạy b</td><td><code>cd /tmp ; ls</code></td></tr>
<tr><td><code>a &amp;&amp; b</code></td><td>Chạy b chỉ khi a thành công</td><td><code>mkdir x &amp;&amp; cd x</code></td></tr>
</table>
${sh`
$ cat big.log | grep "error" | wc -l
42
$ echo "ekNURnt0ZXN0fQ==" | base64 -d
zCTF{test}
`}

<h2 id="xu-ly-text">Xử lý văn bản</h2>
<p>Rất nhiều bài nhập môn là lọc dữ liệu: tìm một dòng trong hàng nghìn dòng, đếm, sắp xếp, đảo ngược.</p>
<table>
<tr><th>Lệnh</th><th>Việc</th><th>Ví dụ</th></tr>
<tr><td><code>cut</code></td><td>Lấy cột</td><td><code>cut -d, -f2 data.csv</code> (cột 2, phân tách bằng dấu phẩy)</td></tr>
<tr><td><code>sort</code></td><td>Sắp xếp (<code>-n</code> theo số, <code>-r</code> ngược)</td><td><code>sort -n scores.txt</code></td></tr>
<tr><td><code>uniq -c</code></td><td>Gộp và đếm dòng trùng liên tiếp (nên <code>sort</code> trước)</td><td><code>sort ips | uniq -c</code></td></tr>
<tr><td><code>tr</code></td><td>Thay / xoá ký tự</td><td><code>tr 'a-z' 'A-Z'</code>, <code>tr -d ' '</code></td></tr>
<tr><td><code>rev</code></td><td>Đảo ngược từng dòng</td><td><code>echo abc | rev</code> → <code>cba</code></td></tr>
<tr><td><code>base64 -d</code></td><td>Giải Base64</td><td><code>cat x | base64 -d</code></td></tr>
</table>
${sh`
# Ba IP truy cập nhiều nhất
$ cut -d' ' -f1 access.log | sort | uniq -c | sort -n | tail -3
     97 10.0.0.17
    101 192.168.1.20
    118 10.0.0.5
`}

<h2 id="ket-noi">Kết nối tới máy chủ</h2>
${sh`
# nc (netcat): nói chuyện thô với một cổng TCP
$ nc challenge.example.com 1337
# ssh: đăng nhập vào máy Linux từ xa
$ ssh bandit0@bandit.labs.overthewire.org -p 2220
`}
<div class="callout idea"><b>Luyện thêm</b>
<p><a href="https://overthewire.org/wargames/bandit/" target="_blank" rel="noopener">OverTheWire: Bandit</a> là chuỗi bài dạy Linux kinh điển qua SSH, mỗi màn mở khoá màn tiếp theo. Màn 0–15 dùng đúng các lệnh ở đây.</p></div>

<h2 id="thuc-hanh">Thực hành: terminal giả lập</h2>
<p>Gõ <code>help</code> để xem lệnh, <kbd>Tab</kbd> để tự hoàn thành tên file, <kbd>↑</kbd> để gọi lại lệnh cũ. Bốn flag đang nằm trong thư mục nhà của bạn.</p>
<div data-widget="shell" data-fs="linux-basic" data-height="380"></div>
<div data-chal="lx1"></div>
<div data-chal="lx2"></div>
<div data-chal="lx3"></div>
<div data-chal="lx4"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
<div data-quiz="2"></div>
`,
  quiz: [
    { q: "Bạn chạy <code>ls</code> nhưng không thấy file nào, dù đề nói có flag trong thư mục. Bước tiếp theo hợp lý nhất?", options: ["Bỏ cuộc", "Chạy <code>ls -a</code> để xem file ẩn", "Xoá thư mục", "Chạy <code>cd /</code>"], answer: 1, explain: "File và thư mục có tên bắt đầu bằng dấu chấm bị ẩn khỏi ls thường. ls -a hiển thị tất cả." },
    { q: "Đang ở <code>/home/guest/notes</code>, lệnh <code>cat ../readme.txt</code> đọc file nào?", options: ["/home/guest/notes/readme.txt", "/home/guest/readme.txt", "/home/readme.txt", "/readme.txt"], answer: 1, explain: "<code>..</code> là thư mục cha của thư mục hiện tại, tức /home/guest." },
    { q: "Lệnh nào đếm số dòng chứa chữ <code>Failed</code> trong auth.log?", options: ["<code>cat auth.log | wc -l</code>", "<code>grep Failed auth.log | wc -l</code>", "<code>find Failed auth.log</code>", "<code>sort auth.log | uniq</code>"], answer: 1, explain: "grep lọc ra các dòng khớp, wc -l đếm số dòng. Cũng có thể dùng <code>grep -c Failed auth.log</code>." },
  ],
  challenges: {
    lx1: { title: "Thư mục ẩn", pts: 50, diff: "easy", hash: "0b37ff090e6310335efd06dd07945add6fc797a4aeba1a951fa67bf33fa22c4f", body: "<p>Đọc <code>readme.txt</code> trong terminal ở trên, rồi tìm flag thứ nhất.</p>", hints: ["Thư mục ẩn không hiện với <code>ls</code> thường.", "<code>ls -a</code>, sau đó <code>cd</code> vào thư mục có dấu chấm và <code>cat</code> file bên trong."] },
    lx2: { title: "Mò kim đáy bể", pts: 75, diff: "easy", hash: "642a63dbf2f47437a6335fac6e71db0b095c10bb8b3708c99efcf84dc7fbd74c", body: "<p>File <code>logs/access.log</code> có hơn 600 dòng. Flag thứ hai nằm đâu đó trong đó.</p>", hints: ["Không cần đọc từng dòng. Lệnh nào tìm chữ trong file?", "<code>grep zCTF logs/access.log</code>"] },
    lx3: { title: "Bảng xếp hạng", pts: 100, diff: "med", hash: "7be98bfc965348ed861974d1331c62c2759f41e6bbacb6a207b04c7e5451188a", body: "<p><code>data/scores.csv</code> có dạng <code>diem,ten,team</code>. Ai có điểm <strong>cao nhất trong team red</strong>? Flag là <code>zCTF{tên}</code>, ví dụ <code>zCTF{an}</code>.</p>", hints: ["Lọc các dòng của team red trước: <code>grep red data/scores.csv</code>", "Nối thêm <code>| sort -n | tail -1</code> để lấy dòng có điểm lớn nhất (cột đầu là điểm)."] },
    lx4: { title: "Ngược dòng", pts: 100, diff: "med", hash: "14878b70ccccd8178c2832dcb9ec3c830601ff8f22a6777491935bd7ee891818", body: "<p><code>data/secret.txt</code> là một chuỗi Base64 đã bị viết ngược. Giải nó bằng một dòng lệnh.</p>", hints: ["Chuỗi kết thúc bằng <code>...nRUNke</code>; đọc ngược là <code>ekNURn</code>, phần đầu của <code>zCTF{</code> khi Base64.", "<code>cat data/secret.txt | rev | base64 -d</code>"] },
  },
});
