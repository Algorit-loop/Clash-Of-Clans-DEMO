/* Track foundation — bài 1–2 */

lesson({
  id: "intro",
  track: "foundation",
  order: 1,
  level: 1,
  title: "CTF là gì?",
  short: "Luật chơi, thể loại, các mảng, cách tính điểm và tư duy",
  time: "15 phút",
  html: `
<h2 id="dinh-nghia">Capture The Flag</h2>
<p><strong>CTF (Capture The Flag)</strong> là cuộc thi an toàn thông tin: bạn giải các bài toán bảo mật để tìm ra một chuỗi bí mật gọi là <strong>flag</strong>. Nộp đúng flag thì được điểm, đội nhiều điểm nhất thắng.</p>
<p>Mỗi bài là một lỗ hổng thu nhỏ do ban tổ chức cố tình tạo ra: một trang web lọc dữ liệu sai, một file ảnh giấu dữ liệu, một chương trình tràn bộ đệm, một hệ mã hoá dùng khoá yếu. Vì môi trường được dựng sẵn để bị tấn công, đây là cách hợp pháp và an toàn để học kỹ năng bảo mật.</p>
<div class="callout tip"><b>Flag trông như thế nào?</b>
<p>Thường có dạng <code>TênGiải{nội_dung}</code>, ví dụ <code>picoCTF{...}</code>, <code>HTB{...}</code>, <code>flag{...}</code>. Trên trang này mọi flag có dạng <code>zCTF{...}</code>. Đề luôn ghi rõ định dạng; thiếu ngoặc hay thừa dấu cách cũng tính là sai.</p></div>

<h2 id="the-loai">Ba thể loại CTF</h2>
<div class="grid-3">
  <div class="card"><span class="big">01 · Jeopardy</span><h4>Phổ biến nhất</h4><p>Bảng gồm nhiều bài độc lập, chia theo mảng và theo điểm. Bài càng khó càng nhiều điểm. Người mới nên bắt đầu ở đây.</p></div>
  <div class="card"><span class="big">02 · Attack–Defense</span><h4>Công và thủ</h4><p>Mỗi đội có một máy chủ chạy dịch vụ có lỗi. Vá lỗi máy mình, đồng thời khai thác máy đội khác để lấy flag theo từng vòng.</p></div>
  <div class="card"><span class="big">03 · King of the Hill</span><h4>Giữ ngôi vua</h4><p>Các đội tranh quyền kiểm soát một máy chủ chung. Giữ được càng lâu, điểm càng cao.</p></div>
</div>

<h2 id="cac-mang">Các mảng trong Jeopardy</h2>
<table>
<tr><th>Mảng</th><th>Bạn làm gì</th><th>Ví dụ</th><th>Cần biết</th></tr>
<tr><td><strong>Web</strong></td><td>Tìm lỗi trong ứng dụng web</td><td>SQL injection, XSS, cookie giả mạo</td><td>HTTP, HTML/JS, SQL</td></tr>
<tr><td><strong>Crypto</strong></td><td>Phá hệ mã hoá dùng sai</td><td>Caesar, XOR, RSA khoá yếu</td><td>Python, toán modulo</td></tr>
<tr><td><strong>Forensics</strong></td><td>Điều tra file, gói tin, bộ nhớ</td><td>Ảnh giấu tin, file .pcap</td><td>Định dạng file, mạng</td></tr>
<tr><td><strong>Reverse</strong></td><td>Đọc hiểu chương trình đã biên dịch</td><td>Tìm mật khẩu được kiểm tra trong file .exe</td><td>C, assembly</td></tr>
<tr><td><strong>Pwn</strong></td><td>Khai thác lỗi bộ nhớ</td><td>Buffer overflow, format string</td><td>C, assembly, bộ nhớ</td></tr>
<tr><td><strong>OSINT</strong></td><td>Tìm thông tin từ nguồn công khai</td><td>Xác định nơi chụp một bức ảnh</td><td>Tìm kiếm, bản đồ</td></tr>
<tr><td><strong>Misc</strong></td><td>Mọi thứ còn lại</td><td>Lập trình, mã QR hỏng, Python jail</td><td>Tuỳ bài</td></tr>
</table>
<p>Lộ trình trên trang này đi đúng thứ tự đó: học <strong>Nền tảng</strong> trước (Linux, mạng, Python, encoding, số học), sau đó chọn mảng bạn thích.</p>

<h2 id="diem">Cách tính điểm</h2>
<ul>
<li><strong>Điểm tĩnh</strong>: mỗi bài có số điểm cố định, ví dụ 100, 200, 500.</li>
<li><strong>Điểm động</strong> (dynamic scoring): càng nhiều đội giải được, điểm của bài càng giảm, áp dụng cho cả đội đã giải trước đó.</li>
<li><strong>First blood</strong>: một số giải thưởng thêm cho đội giải đầu tiên.</li>
<li>Bằng điểm thì đội đạt mức điểm đó <strong>sớm hơn</strong> xếp trên.</li>
<li>Gợi ý (hint) đôi khi phải "mua" bằng điểm.</li>
</ul>

<h2 id="mot-bai">Một bài CTF trông như thế nào</h2>
${txt`
Tên bài:   Cookie Monster                         [Web · 150 điểm · 87 lượt giải]
Mô tả:     Trang quản trị chỉ dành cho admin. Bạn có phải admin không?
Kết nối:   http://chal.example.com:31337
File:      (không có)
Flag:      flag{...}
`}
<p>Mọi thông tin đều có giá trị: <em>tên bài</em> gợi ý hướng đi ("cookie"), <em>số lượt giải</em> cho biết độ khó thực tế, <em>file đính kèm</em> thường là mã nguồn hoặc dữ liệu cần phân tích.</p>

<h2 id="tu-duy">Tư duy của người chơi CTF</h2>
<ol class="steps-v">
<li><strong>Đọc kỹ đề.</strong> Tên bài và mô tả thường chứa gợi ý, đôi khi là chơi chữ.</li>
<li><strong>Thử thứ đơn giản trước.</strong> Xem mã nguồn trang, chạy <code>file</code>, <code>strings</code>, đọc metadata. Rất nhiều bài dễ giải được ngay ở bước này.</li>
<li><strong>Tìm kiếm.</strong> Gặp định dạng lạ, thông báo lỗi lạ, tên thuật toán lạ: tìm Google ngay.</li>
<li><strong>Ghi chép.</strong> Lưu lệnh đã chạy, kết quả, hướng đã thử. Hai tiếng sau bạn sẽ quên.</li>
<li><strong>Bí thì đổi bài.</strong> Đừng kẹt 5 tiếng ở một bài. Quay lại sau thường thấy hướng mới.</li>
<li><strong>Đọc writeup.</strong> Sau giải, đọc lời giải của đội khác cho những bài bạn chưa giải được, rồi tự làm lại.</li>
</ol>

<div class="callout danger"><b>Đạo đức và pháp luật</b>
<p>Kỹ năng trong CTF chỉ được dùng trên hệ thống <strong>bạn được phép kiểm thử</strong>: bài CTF, phòng lab, máy của chính bạn, chương trình bug bounty trong phạm vi cho phép. Truy cập trái phép hệ thống của người khác là vi phạm pháp luật. Trong giải cũng không tấn công hạ tầng của ban tổ chức (trang nộp flag, scoreboard) và không chia sẻ flag cho đội khác.</p></div>

<h2 id="thu-thach">Thử thách đầu tiên</h2>
<p>Nộp flag sau để làm quen với ô nhập: <code>zCTF{xin_chao_hacker}</code></p>
<div data-chal="intro"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
<div data-quiz="2"></div>
`,
  quiz: [
    { q: "Trong CTF dạng Jeopardy, bạn nhận điểm khi nào?", options: ["Khi tấn công được máy của đội khác", "Khi nộp đúng flag của một bài", "Khi giữ máy chủ lâu nhất", "Khi viết writeup"], answer: 1, explain: "Jeopardy là bảng các bài độc lập; mỗi bài có một flag, nộp đúng thì nhận điểm của bài đó." },
    { q: "Giải dùng <em>dynamic scoring</em>. Bài A có 200 lượt giải, bài B có 5 lượt giải. Điều nào đúng?", options: ["A đáng nhiều điểm hơn B", "B đáng nhiều điểm hơn A", "Hai bài bằng điểm", "Không xác định được"], answer: 1, explain: "Với điểm động, bài càng ít người giải càng giữ được điểm cao." },
    { q: "Bạn phát hiện một lỗi trên trang nộp flag của ban tổ chức. Nên làm gì?", options: ["Khai thác để cộng điểm", "Báo cho ban tổ chức", "Chia sẻ cho đội bạn", "Giữ bí mật"], answer: 1, explain: "Hạ tầng của giải không nằm trong phạm vi thi. Báo cho ban tổ chức là cách đúng; nhiều giải còn thưởng cho việc này." },
  ],
  challenges: {
    intro: { title: "Chào mừng", pts: 10, diff: "easy", hash: "fb4ff450b5be408c95535a1f19712e6fdab097315e254233572e8aad21f7144b", body: "<p>Nhập flag đã cho ở trên.</p>", hints: [] },
  },
});

lesson({
  id: "setup",
  track: "foundation",
  order: 2,
  level: 1,
  title: "Thiết lập môi trường",
  short: "Máy ảo, WSL, công cụ theo từng mảng và cách ghi chép",
  time: "25 phút",
  html: `
<h2 id="chon">Chọn môi trường</h2>
<p>Hầu hết công cụ CTF chạy trên Linux. Có ba lựa chọn, có thể kết hợp:</p>
<table>
<tr><th>Cách</th><th>Ưu điểm</th><th>Nhược điểm</th><th>Hợp với</th></tr>
<tr><td><strong>WSL2</strong> (Windows)</td><td>Cài 1 lệnh, chạy song song Windows, nhẹ</td><td>Giao diện đồ hoạ hạn chế, mạng hơi khác máy thật</td><td>Bắt đầu nhanh, crypto, web, script</td></tr>
<tr><td><strong>Máy ảo Kali Linux</strong></td><td>Có sẵn hàng trăm công cụ, cô lập khỏi máy thật, có snapshot</td><td>Tốn RAM (nên có ≥ 8GB)</td><td>Mọi mảng, nhất là pwn và forensics</td></tr>
<tr><td><strong>Docker</strong></td><td>Dựng môi trường giống hệt đề (cùng phiên bản thư viện)</td><td>Cần hiểu Docker</td><td>Pwn nâng cao</td></tr>
</table>
${sh`
# Windows: mở PowerShell bằng quyền Administrator
$ wsl --install -d Ubuntu
# Sau khi khởi động lại, trong Ubuntu:
$ sudo apt update && sudo apt upgrade -y
`}
<div class="callout warn"><b>Máy ảo</b>
<p>Dùng VirtualBox hoặc VMware, tải bản <em>Kali Linux Virtual Machine</em> dựng sẵn từ kali.org. Đặt RAM 4GB, 2 CPU. Chụp <strong>snapshot</strong> ngay sau khi cài xong để quay lại khi hỏng. File đề CTF (nhất là reverse, forensics) có thể là mã độc thật, nên mở trong máy ảo.</p></div>

<h2 id="cong-cu">Công cụ theo từng mảng</h2>
${sh`
# Nền tảng
$ sudo apt install -y git curl wget python3 python3-pip python3-venv netcat-openbsd nmap file xxd
# Forensics
$ sudo apt install -y binwalk exiftool foremost steghide wireshark tshark
# Mật khẩu / hash
$ sudo apt install -y john hashcat
# Reverse / Pwn
$ sudo apt install -y gdb ltrace strace gcc
`}
<table>
<tr><th>Mảng</th><th>Công cụ chính</th></tr>
<tr><td>Web</td><td>Trình duyệt + DevTools, <strong>Burp Suite Community</strong>, curl, sqlmap, ffuf</td></tr>
<tr><td>Crypto</td><td>Python + pycryptodome, SageMath, CyberChef, dCode</td></tr>
<tr><td>Forensics</td><td>file, strings, binwalk, exiftool, Wireshark, Volatility, Autopsy</td></tr>
<tr><td>Reverse</td><td><strong>Ghidra</strong>, IDA Free, gdb + pwndbg, jadx, dnSpy</td></tr>
<tr><td>Pwn</td><td>gdb + pwndbg/GEF, pwntools, checksec, ROPgadget</td></tr>
</table>
<p>Trang <a href="#/tools">Công cụ</a> có sẵn terminal, Python, SQL và bộ giải mã chạy trong trình duyệt, đủ để làm toàn bộ bài tập ở đây trước khi cài gì.</p>

<h2 id="python-env">Môi trường Python riêng</h2>
<p>Đừng <code>pip install</code> vào Python hệ thống. Tạo một môi trường ảo (venv) cho CTF:</p>
${sh`
$ python3 -m venv ~/ctf-venv
$ source ~/ctf-venv/bin/activate
(ctf-venv) $ pip install pwntools pycryptodome requests
`}

<h2 id="checksum">Xác minh file tải về</h2>
<p>Khi tải ISO, công cụ hay file đề, hãy kiểm tra <strong>checksum</strong>: một hash (thường là SHA-256) do nơi phát hành công bố. Chỉ cần đổi 1 byte trong file là hash khác hoàn toàn. Hash khớp nghĩa là file đúng bản gốc.</p>
${sh`
$ sha256sum kali.iso
cd216345ef13...0105  kali.iso
$ cat SHA256SUMS
cd216345ef13...0105  kali-linux-2026.1-installer-amd64.iso
# Hai chuỗi giống nhau → file chuẩn
`}

<h2 id="ghi-chep">Tổ chức thư mục và ghi chép</h2>
${txt`
~/ctf/
└── picoctf-2026/
    ├── notes.md            # ghi chú chung của giải
    ├── web/
    │   └── cookie-monster/
    │       ├── solve.py    # script giải
    │       └── notes.md    # đã thử gì, kết quả ra sao
    └── crypto/
`}
<p>Ghi chép bằng Markdown (Obsidian, VS Code, Notion…). Mỗi bài nên có: đề, file, các hướng đã thử (cả hướng sai), lệnh và script cuối cùng, flag. Đây chính là bản nháp writeup. Sau vài giải, thư mục ghi chép trở thành từ điển riêng: gặp bài giống, chỉ cần <code>grep -ri</code>.</p>

<h2 id="thuc-hanh">Thực hành</h2>
<p>Máy Kali giả lập bên dưới vừa tải ISO từ ba mirror khác nhau.</p>
<div data-widget="shell" data-fs="setup-lab" data-height="360"></div>
<div data-chal="setup1"></div>
<div data-chal="setup2"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    { q: "Vì sao nên mở file đề CTF trong máy ảo?", options: ["Vì máy ảo chạy nhanh hơn", "Vì file có thể độc hại; máy ảo cô lập và quay lại được bằng snapshot", "Vì Windows không chạy được Python", "Không có lý do"], answer: 1, explain: "File đề có thể là mã độc thật. Máy ảo cô lập rủi ro và khôi phục trạng thái sạch bằng snapshot." },
    { q: "Hai file có SHA-256 chỉ khác nhau 1 ký tự hex. Kết luận gì?", options: ["Hai file gần như giống nhau", "Hai file khác nhau, không suy ra được khác bao nhiêu", "Một file hỏng đúng 1 byte", "Hash bị tính sai"], answer: 1, explain: "Hàm băm tốt có hiệu ứng thác (avalanche): đổi rất nhỏ ở đầu vào làm hash đổi hoàn toàn, nên độ giống của hai hash không nói gì về độ giống của hai file." },
  ],
  challenges: {
    setup1: { title: "Mirror nào là thật?", pts: 50, diff: "easy", hash: "9aa593c4079dcf9ce8106267e4e8e55f04f71ea102c7930f82e997f8bc04ec91", body: "<p>Cả ba file đều chứa một chuỗi trông giống flag. Chỉ bản có checksum khớp với <code>downloads/SHA256SUMS</code> là thật.</p>", hints: ["<code>cat downloads/SHA256SUMS</code>, rồi <code>sha256sum downloads/mirror1/kali.iso</code>; làm tương tự với mirror2, mirror3.", "So từng hash với dòng trong SHA256SUMS, rồi <code>cat</code> file khớp."] },
    setup2: { title: "Ghi chép cũ", pts: 75, diff: "easy", hash: "79ff791682a699301b9fa12a937ad0de441122241f95bdd5e4176e9c71989779", body: "<p>Bạn từng lưu một flag trong <code>notes/</code> nhưng quên ở file nào, và nhớ là đã mã hoá nó lại.</p>", hints: ["<code>grep -ri flag notes</code> tìm chữ \"flag\" trong mọi file, không phân biệt hoa thường.", "Chuỗi tìm được là Base64: <code>echo &lt;chuỗi&gt; | base64 -d</code>"] },
  },
});
