/* Track foundation — bài 7–8 */

lesson({
  id: "encoding",
  track: "foundation",
  order: 7,
  level: 1,
  title: "Encoding",
  short: "ASCII, hex, Base64, Base32, URL, HTML entity, nhiều lớp",
  time: "35 phút",
  html: `
<h2 id="la-gi">Encoding không phải mã hoá</h2>
<p>Máy tính chỉ lưu số. <strong>Encoding</strong> là quy ước biểu diễn dữ liệu dưới dạng khác để truyền hoặc hiển thị, <strong>không có khoá</strong>, ai cũng giải ngược được. Rất nhiều bài CTF bọc flag qua một hoặc nhiều lớp encoding.</p>
<table>
<tr><th></th><th>Encoding</th><th>Encryption (mã hoá)</th><th>Hashing (băm)</th></tr>
<tr><td>Mục đích</td><td>Biểu diễn dữ liệu</td><td>Giữ bí mật</td><td>Tạo "vân tay" của dữ liệu</td></tr>
<tr><td>Cần khoá?</td><td>Không</td><td>Có</td><td>Không</td></tr>
<tr><td>Đảo ngược?</td><td>Luôn được</td><td>Được, nếu có khoá</td><td>Không (chỉ đoán thử)</td></tr>
<tr><td>Ví dụ</td><td>Base64, hex, URL</td><td>AES, RSA</td><td>MD5, SHA-256</td></tr>
</table>

<h2 id="ascii">ASCII và UTF-8</h2>
<p>Mỗi ký tự ứng với một số. <code>A</code> = 65, <code>a</code> = 97, <code>0</code> = 48, <code>{</code> = 123. Chuỗi <code>zCTF</code> thực chất là <code>122 67 84 70</code>. ASCII chỉ có 128 ký tự; chữ có dấu như <code>ế</code> dùng <strong>UTF-8</strong>, chiếm 2–4 byte (<code>ế</code> = <code>e1 ba bf</code>). Xem bảng ở <a href="#/tools/ascii">Công cụ → Bảng ASCII</a>.</p>

<h2 id="binary-hex">Binary và hex</h2>
${txt`
Ký tự   Thập phân   Hex    Binary
  z        122      7a    01111010
  C         67      43    01000011
  T         84      54    01010100
  F         70      46    01000110
`}
<p><strong>Hex</strong> (cơ số 16) dùng 0–9 và a–f, mỗi byte đúng 2 ký tự. <strong>Binary</strong> chỉ có 0 và 1, mỗi byte 8 ký tự. Bài <em>Số học &amp; bit</em> giải thích cách đổi.</p>

<h2 id="base64">Base64</h2>
<p>Base64 biểu diễn dữ liệu bất kỳ bằng 64 ký tự an toàn: <code>A–Z a–z 0–9 + /</code>. Cứ 3 byte (24 bit) được cắt thành 4 nhóm 6 bit, mỗi nhóm thành 1 ký tự. Thiếu byte thì thêm <code>=</code> ở cuối. Vì vậy dữ liệu Base64 dài hơn bản gốc khoảng 33%, và độ dài luôn chia hết cho 4.</p>
${txt`
 z        C        T
 01111010 01000011 01010100
 011110 100100 001101 010100
   e      k      N      U        →  "zCT" = "ekNU"
`}
${sh`
$ echo -n "zCTF" | base64
ekNURg==
$ echo "ekNURg==" | base64 -d
zCTF
`}
<div class="callout tip"><b>Mẹo nhận diện</b>
<p>Mọi flag <code>zCTF{</code> khi Base64 đều bắt đầu bằng <code>ekNURn</code>. Tương tự <code>picoCTF{</code> luôn thành <code>cGljb0NURn</code>, <code>flag{</code> thành <code>ZmxhZ3</code>. Biến thể <em>Base64 URL-safe</em> dùng <code>-</code> và <code>_</code> thay cho <code>+</code> và <code>/</code>.</p></div>

<h2 id="base32">Base32</h2>
<p>Giống Base64 nhưng chỉ dùng 32 ký tự <code>A–Z</code> và <code>2–7</code>, toàn chữ hoa, thường kết thúc bằng nhiều dấu <code>=</code>. Mỗi 5 byte thành 8 ký tự. Hay gặp trong mã bí mật 2FA (TOTP).</p>
${sh`
$ echo -n "zCTF" | base32
PJBVIRQ=
$ echo "PJBVIRQ=" | base32 -d
zCTF
`}

<h2 id="url-html">URL encoding và HTML entity</h2>
<p><strong>URL encoding</strong> (percent-encoding) thay ký tự đặc biệt bằng <code>%</code> + 2 chữ số hex: dấu cách → <code>%20</code>, <code>{</code> → <code>%7B</code>, <code>'</code> → <code>%27</code>. Bạn sẽ gặp liên tục trong bài web.</p>
<p><strong>HTML entity</strong> biểu diễn ký tự trong HTML: <code>&amp;lt;</code> là <code>&lt;</code>, <code>&amp;#122;</code> là <code>z</code> (thập phân), <code>&amp;#x7a;</code> cũng là <code>z</code> (hex).</p>

<h2 id="nhan-dien">Bảng nhận diện nhanh</h2>
<table>
<tr><th>Bạn thấy</th><th>Có thể là</th></tr>
<tr><td><code>01111010 01000011</code></td><td>Binary</td></tr>
<tr><td><code>7a 43 54 46</code>, <code>7a435446</code>, <code>\\x7a\\x43</code></td><td>Hex</td></tr>
<tr><td><code>ekNURnt0ZXN0fQ==</code> (chữ hoa + thường + số, có thể có <code>=</code>)</td><td>Base64</td></tr>
<tr><td><code>PJBVIRT3...===</code> (chỉ chữ hoa và 2–7)</td><td>Base32</td></tr>
<tr><td><code>%7B%20%7D</code></td><td>URL encoding</td></tr>
<tr><td><code>&amp;#122;&amp;#67;</code></td><td>HTML entity</td></tr>
<tr><td><code>122 67 84 70</code></td><td>Mã ASCII thập phân</td></tr>
<tr><td><code>mPGS{grfg}</code> (giữ nguyên ngoặc, chữ bị xáo)</td><td>ROT13 / Caesar</td></tr>
<tr><td><code>.-- . .-..</code></td><td>Morse</td></tr>
</table>

<h2 id="nhieu-lop">Nhiều lớp</h2>
<p>Đề thường lồng nhiều lớp: hex của Base64 của ROT13… Cách làm: nhận diện lớp ngoài cùng, giải nó, nhìn kết quả, lặp lại. Kết quả mỗi bước luôn "trông có nghĩa hơn" bước trước. <a href="#/tools/decode">Công cụ → Giải mã</a> cho phép nối nhiều bước thành một công thức và gợi ý lớp tiếp theo; <a href="https://gchq.github.io/CyberChef/" target="_blank" rel="noopener">CyberChef</a> có chức năng <em>Magic</em> tương tự.</p>
${py`
import base64, codecs, urllib.parse
s = "%4E%6D%51..."
s = urllib.parse.unquote(s)          # lớp URL
s = base64.b64decode(s).decode()     # lớp Base64
s = bytes.fromhex(s).decode()        # lớp hex
print(codecs.decode(s, "rot13"))     # lớp ROT13
`}

<div data-chal="en1"></div>
<div data-chal="en2"></div>
<div data-chal="en3"></div>
<div data-chal="en4"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    { q: "Một website lưu mật khẩu người dùng bằng Base64. Điều này có an toàn không?", options: ["An toàn, vì Base64 là mã hoá", "Không, vì ai cũng giải Base64 được mà không cần khoá", "An toàn nếu mật khẩu dài", "Chỉ an toàn trên HTTPS"], answer: 1, explain: "Base64 là encoding, không có khoá. Mật khẩu phải được băm bằng thuật toán chuyên dụng như bcrypt hoặc Argon2." },
    { q: "Chuỗi <code>KZXW6YTV</code> nhiều khả năng là gì?", options: ["Base64", "Base32", "Hex", "Binary"], answer: 1, explain: "Chỉ có chữ hoa và các số 2–7: đặc trưng của Base32 (giải ra là \"Voobu\")." },
  ],
  challenges: {
    en1: { title: "Ngụy trang", pts: 50, diff: "easy", hash: "02254eb6fef5c4bd55b4ed7a327a5cddd1d429f3c1b7f52a61ebd7b952beec52", body: '<p>Giải mã chuỗi sau:</p><div class="chal-data">ekNURntiYXNlNjRfa2hvbmdfcGhhaV9tYV9ob2F9</div>', hints: ["Chuỗi bắt đầu bằng <code>ekNURn</code>…", "Dùng <code>base64 -d</code> hoặc Công cụ → From Base64."] },
    en2: { title: "Số và chữ", pts: 50, diff: "easy", hash: "f0359044419bb8e792df3a7a5ea783bc6efc65933d03b488944118d4a85f3027", body: '<p>Mỗi cặp ký tự là một byte:</p><div class="chal-data">7a 43 54 46 7b 68 33 78 5f 76 34 5f 62 31 6e 34 72 79 7d</div>', hints: ["Chỉ có 0–9 và a–f, mỗi nhóm 2 ký tự: đây là hex.", "<code>7a</code> = 122 = <code>z</code>. Dùng From Hex."] },
    en3: { title: "Toàn chữ hoa", pts: 75, diff: "easy", hash: "1e0345a2023a5bcc090ca0b5e3fe898a0c63d17039054bd43522e184a6beb6d6", body: '<div class="chal-data">PJBVIRT3MI2HGMZTGJPWG2BRL5RTAX3IGA2H2===</div>', hints: ["Chỉ chữ hoa, số 2–7 và nhiều dấu <code>=</code>.", "Base32: <code>echo ... | base32 -d</code> hoặc From Base32."] },
    en4: { title: "Củ hành", pts: 150, diff: "med", hash: "f560fb9cf0a4c9f2a15090840aa551866a88013d378af8a2f9f7306efe57ae71", body: '<p>Bốn lớp. Bóc từng lớp một.</p><div class="chal-data">%4E%6D%51%31%4D%44%51%33%4E%54%4D%33%59%6A%59%78%4E%7A%55%7A%4D%54%63%79%4E%6A%67%31%5A%6A%63%35%4D%7A%41%32%4D%7A%56%6D%4E%6A%51%32%4F%44%4D%30%4E%32%51%3D</div>', hints: ["Lớp ngoài: toàn <code>%XX</code> → URL Decode.", "Tiếp theo là Base64, rồi hex. Kết quả cuối trông như <code>mPGS{...}</code>: còn một lớp ROT13."] },
  },
});

lesson({
  id: "bits",
  track: "foundation",
  order: 8,
  level: 2,
  title: "Số học & bit",
  short: "Hệ cơ số, phép bit, endianness, bù hai, tràn số, modulo",
  time: "45 phút",
  html: `
<h2 id="co-so">Hệ cơ số</h2>
<p>Cùng một số, viết theo nhiều cơ số. Mỗi chữ số có "trọng số" là lũy thừa của cơ số:</p>
${txt`
Thập phân  182 = 1·100 + 8·10 + 2
Nhị phân   10110110 = 128 + 32 + 16 + 4 + 2 = 182
Hex        b6 = 11·16 + 6 = 182
`}
<p>Mẹo: 1 chữ số hex = đúng 4 bit, nên đổi giữa hex và nhị phân rất nhanh: <code>b</code> = <code>1011</code>, <code>6</code> = <code>0110</code> → <code>0xb6</code> = <code>1011 0110</code>.</p>
<table>
<tr><th>Hex</th><th>0</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6</th><th>7</th><th>8</th><th>9</th><th>a</th><th>b</th><th>c</th><th>d</th><th>e</th><th>f</th></tr>
<tr><td>Bit</td><td>0000</td><td>0001</td><td>0010</td><td>0011</td><td>0100</td><td>0101</td><td>0110</td><td>0111</td><td>1000</td><td>1001</td><td>1010</td><td>1011</td><td>1100</td><td>1101</td><td>1110</td><td>1111</td></tr>
</table>
<p>Đơn vị: 1 byte = 8 bit (0–255, <code>0x00</code>–<code>0xff</code>). Số 32-bit có giá trị tới 2<sup>32</sup> − 1 = 4.294.967.295.</p>

<h2 id="phep-bit">Phép toán bit</h2>
<table>
<tr><th>Phép</th><th>Python / C</th><th>Ví dụ</th><th>Dùng để</th></tr>
<tr><td>AND</td><td><code>a &amp; b</code></td><td><code>0b1100 &amp; 0b1010 = 0b1000</code></td><td>Lấy một số bit (mặt nạ): <code>x &amp; 0xff</code> lấy byte thấp</td></tr>
<tr><td>OR</td><td><code>a | b</code></td><td><code>0b1100 | 0b1010 = 0b1110</code></td><td>Bật bit</td></tr>
<tr><td>XOR</td><td><code>a ^ b</code></td><td><code>0b1100 ^ 0b1010 = 0b0110</code></td><td>Mã hoá đơn giản, đảo bit; <code>a ^ b ^ b = a</code></td></tr>
<tr><td>NOT</td><td><code>~a</code></td><td><code>~0b1100</code> (đảo mọi bit)</td><td>Đảo mặt nạ</td></tr>
<tr><td>Dịch trái</td><td><code>a &lt;&lt; n</code></td><td><code>1 &lt;&lt; 4 = 16</code></td><td>Nhân với 2<sup>n</sup></td></tr>
<tr><td>Dịch phải</td><td><code>a &gt;&gt; n</code></td><td><code>0xf0 &gt;&gt; 4 = 0x0f</code></td><td>Chia cho 2<sup>n</sup>, lấy nửa trên</td></tr>
</table>
${py`
x = 0x12345678
(x >> 8) & 0xff      # 0x56  — byte thứ 2 tính từ phải
x & 0xffff           # 0x5678 — 16 bit thấp
0x41 | 0x20          # 0x61 = 'a'  — bật bit 5 biến chữ hoa thành chữ thường
`}

<h2 id="endian">Endianness: thứ tự byte</h2>
<p>Số nhiều byte được lưu trong bộ nhớ theo một thứ tự:</p>
${txt`
Số 0x12345678 (4 byte)        địa chỉ:  +0   +1   +2   +3
Big-endian    (mạng, Java)              12   34   56   78
Little-endian (x86, ARM)                78   56   34   12
`}
<p>Khi đọc hexdump của chương trình x86, số nằm "ngược". Đây là kiến thức bắt buộc cho reverse và pwn: muốn ghi địa chỉ <code>0x401136</code> vào bộ nhớ, bạn phải gửi các byte <code>36 11 40 00 ...</code>.</p>

<h2 id="bu-hai">Số âm: bù hai</h2>
<p>Máy tính biểu diễn số nguyên có dấu bằng <strong>bù hai</strong> (two's complement): bit cao nhất mang trọng số âm. Với 8 bit, bit 7 có giá trị −128.</p>
${txt`
0111 1111 =  127
1000 0000 = -128
1111 1111 = -1
1110 1100 = -128 + 64 + 32 + 8 + 4 = -20
`}
<p>Cách nhanh để đổi dấu: đảo mọi bit rồi cộng 1. Cùng một byte <code>0xff</code> là 255 nếu hiểu là <code>unsigned</code>, là −1 nếu hiểu là <code>signed</code>. Chương trình hiểu theo kiểu biến khai báo trong code.</p>
<table>
<tr><th>Kiểu C</th><th>Khoảng giá trị</th></tr>
<tr><td><code>uint8_t</code> / <code>int8_t</code></td><td>0…255 / −128…127</td></tr>
<tr><td><code>uint32_t</code> / <code>int32_t</code></td><td>0…4.294.967.295 / −2.147.483.648…2.147.483.647</td></tr>
<tr><td><code>uint64_t</code> / <code>int64_t</code></td><td>0…2<sup>64</sup>−1 / −2<sup>63</sup>…2<sup>63</sup>−1</td></tr>
</table>

<h2 id="tran-so">Tràn số nguyên</h2>
<p>Khi kết quả vượt quá khoảng của kiểu, các bit thừa bị cắt bỏ: phép tính thực chất là <strong>modulo 2<sup>n</sup></strong>. <code>int32_t</code> lớn nhất cộng 1 thành số âm nhỏ nhất.</p>
${c`
int32_t a = 2147483647;
a = a + 1;            // -2147483648
uint8_t b = 250;
b = b + 10;           // 4   (260 mod 256)
`}
<p>Lỗi kinh điển: kiểm tra số tiền bằng <code>price * qty &lt;= balance</code> với biến 32-bit. Chọn <code>qty</code> sao cho tích vượt 2<sup>31</sup> và quay vòng thành số âm, điều kiện thành đúng. Python không bị tràn (số nguyên không giới hạn), nên khi mô phỏng phải tự cắt: <code>x &amp; 0xffffffff</code>.</p>

<h2 id="modulo">Modulo</h2>
<p><code>a % n</code> là số dư khi chia a cho n, luôn nằm trong 0…n−1 (trong Python). Đây là nền của gần như mọi thuật toán mật mã:</p>
<ul>
<li>Caesar: <code>(vị_trí + k) % 26</code>.</li>
<li>Tràn số: số học máy tính là số học modulo 2<sup>32</sup> hoặc 2<sup>64</sup>.</li>
<li>RSA: <code>pow(m, e, n)</code> tính m<sup>e</sup> mod n rất nhanh dù số có hàng trăm chữ số.</li>
</ul>
${py`
(25 + 3) % 26         # 2  — Caesar quay vòng từ z về c
-1 % 26               # 25 trong Python (trong C là -1)
pow(3, 200, 1000)     # 3^200 mod 1000, tính tức thì
`}
<p>Thử các phép tính này trong <a href="#/tools/python">Công cụ → Python</a> hoặc <a href="#/tools/convert">Chuyển đổi số</a>.</p>

<h2 id="thuc-hanh">Thực hành</h2>
<div data-chal="bt1"></div>
<div data-chal="bt2"></div>
<div data-chal="bt3"></div>
<div data-chal="bt4"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
<div data-quiz="2"></div>
`,
  quiz: [
    { q: "<code>0x3c</code> viết ở dạng nhị phân là gì?", options: ["0011 1100", "0011 1010", "1100 0011", "0010 1100"], answer: 0, explain: "3 = 0011, c = 1100." },
    { q: "Trên x86, bộ nhớ chứa các byte <code>01 00 00 00</code>. Đọc như số 32-bit, giá trị là?", options: ["1", "16777216", "256", "0x01000000"], answer: 0, explain: "Little-endian: byte đầu tiên là byte thấp nhất, nên giá trị là 0x00000001 = 1." },
    { q: "<code>uint8_t x = 0; x = x - 1;</code> Giá trị của x?", options: ["-1", "0", "255", "Lỗi"], answer: 2, explain: "Kiểu không dấu 8 bit quay vòng: −1 mod 256 = 255." },
  ],
  challenges: {
    bt1: { title: "Dịch và ghép", pts: 50, diff: "easy", hash: "1eaec19c1d718197b9d6128d9ea9e3ec326f7903ee0722bbed28473385038ee0", body: '<p>Tính giá trị thập phân của biểu thức sau. Flag: <code>zCTF{số_thập_phân}</code>.</p><div class="chal-data">(0xF0 &gt;&gt; 4) | (0x0F &lt;&lt; 4)</div>', hints: ["<code>0xF0 &gt;&gt; 4 = 0x0F</code>; <code>0x0F &lt;&lt; 4 = 0xF0</code>.", "<code>0x0F | 0xF0 = 0xFF</code>. Đổi sang thập phân."] },
    bt2: { title: "Byte có dấu", pts: 75, diff: "easy", hash: "a04d23f8524ac61ccf0abea59036d9775f0940910218608fbeaf3c7ed5e9696e", body: '<p>Biến <code>int8_t</code> đang chứa byte <code>0xEC</code>. Giá trị có dấu của nó là bao nhiêu? Flag: <code>zCTF{giá_trị}</code>, ví dụ <code>zCTF{-5}</code>.</p>', hints: ["0xEC = 236. Bit cao nhất bằng 1 nên đây là số âm.", "Số âm = 236 − 256."] },
    bt3: { title: "Cửa hàng 32-bit", pts: 150, diff: "med", hash: "9ed8c5a8cbb38ec7d61df2ffb08e301e209c00e2deb4dfc724c9dda1c92ccbc4", widget: "intshop", body: "<p>Bạn có 100 xu. Flag giá 1.000.000 xu. Server tính tổng tiền bằng biến <code>int32_t</code>.</p>", hints: ["<code>int32_t</code> lớn nhất là 2.147.483.647. Điều gì xảy ra nếu <code>1000000 * qty</code> vượt quá số đó?", "Cần <code>qty</code> sao cho tích nằm trong khoảng 2<sup>31</sup> đến 2<sup>32</sup>: khi đó nó quay vòng thành số âm. Thử <code>qty = 2148</code>."] },
    bt4: { title: "Đọc bộ nhớ", pts: 100, diff: "med", hash: "eeff2be8c7e3e21baff036c006d95bf7af5370d2759c5dda61ae545e1a024bd0", body: '<p>Đây là 8 byte trong bộ nhớ của một chương trình x86-64, đọc như một số <code>uint64_t</code>. Flag: <code>zCTF{giá_trị_thập_phân}</code>.</p><div class="chal-data">ef be ad de 00 00 00 00</div>', hints: ["Little-endian: đảo thứ tự byte → <code>00 00 00 00 de ad be ef</code>.", "<code>0xdeadbeef</code> đổi sang thập phân (dùng Python hoặc Công cụ → Chuyển đổi số)."] },
  },
});
