/* Track: crypto — dữ liệu đề: js/widgets/crypto_data.js (CR, CR_HASH), sinh bởi .dev/gen_crypto.py */

/* ===================================================================== 1. Mật mã cổ điển */
lesson({
  id: "crypto-classical",
  track: "crypto",
  order: 1,
  level: 1,
  title: "Mật mã cổ điển",
  short: "Caesar, Atbash, thay thế, Vigenère và cách phá từng loại",
  time: "45 phút",
  html: `
<h2 id="thuat-ngu">Thuật ngữ cơ bản</h2>
<table>
<tr><th>Thuật ngữ</th><th>Ý nghĩa</th></tr>
<tr><td><strong>Plaintext</strong> (bản rõ)</td><td>Thông điệp gốc, ký hiệu <code>P</code> hoặc <code>m</code></td></tr>
<tr><td><strong>Ciphertext</strong> (bản mã)</td><td>Kết quả sau khi mã hoá, ký hiệu <code>C</code> hoặc <code>c</code></td></tr>
<tr><td><strong>Key</strong> (khoá)</td><td>Bí mật dùng để mã hoá / giải mã, ký hiệu <code>k</code></td></tr>
<tr><td><strong>Keyspace</strong></td><td>Số khoá có thể có. Keyspace nhỏ thì thử hết được (brute force)</td></tr>
<tr><td><strong>Cryptanalysis</strong></td><td>Phân tích mật mã: tìm bản rõ hoặc khoá mà không được cho trước khoá</td></tr>
</table>
<div class="callout idea"><b>Nguyên lý Kerckhoffs</b>
<p>Một hệ mật phải an toàn ngay cả khi kẻ tấn công biết toàn bộ thuật toán, chỉ trừ khoá. Trong CTF bạn gần như luôn được biết thuật toán; điểm yếu nằm ở khoá hoặc cách dùng.</p></div>
<p>Các loại tấn công theo lượng thông tin bạn có:</p>
<ul>
<li><strong>Ciphertext-only</strong>: chỉ có bản mã. Dựa vào thống kê ngôn ngữ.</li>
<li><strong>Known-plaintext</strong>: biết một phần bản rõ. Trong CTF bạn luôn biết flag bắt đầu bằng <code>zCTF{</code>.</li>
<li><strong>Chosen-plaintext</strong>: tự chọn bản rõ và xem bản mã (gặp lại ở bài mã khối).</li>
</ul>

<h2 id="caesar">Caesar và ROT13</h2>
<p>Đánh số chữ cái <code>A=0, B=1, …, Z=25</code>. Caesar với khoá <code>k</code>:</p>
${txt`
Mã hoá:  C = (P + k) mod 26
Giải mã: P = (C - k) mod 26
`}
<p>Keyspace chỉ có 25 khoá có nghĩa, nên thử hết là xong. ROT13 là Caesar với <code>k = 13</code>; vì 13 + 13 = 26 nên mã hoá hai lần ra lại bản gốc. Biến thể <strong>ROT47</strong> xoay 94 ký tự in được (từ <code>!</code> đến <code>~</code>), nên cả số và dấu câu cũng bị đổi.</p>
${py`
def caesar(s, k):
    out = ""
    for ch in s:
        if ch.isalpha():
            base = ord("A") if ch.isupper() else ord("a")
            out += chr((ord(ch) - base + k) % 26 + base)
        else:
            out += ch
    return out

for k in range(1, 26):
    print(k, caesar("gJAM{...}", -k))
`}
<p>Trang <a href="#/tools/decode">Công cụ → Giải mã</a> có sẵn mục <em>Caesar brute force</em>.</p>

<h2 id="atbash">Atbash</h2>
<p>Đảo ngược bảng chữ cái: <code>A↔Z, B↔Y, C↔X…</code>. Công thức <code>C = 25 − P</code>. Không có khoá, nên chỉ cần nhận ra nó. Dấu hiệu: mã hoá hai lần ra bản gốc, và <code>zCTF</code> biến thành <code>aXGU</code>.</p>

<h2 id="thay-the">Mã thay thế đơn bảng</h2>
<p>Mỗi chữ cái được thay bằng một chữ khác theo một bảng hoán vị cố định, ví dụ <code>a→q, b→w, c→e…</code>. Keyspace là <code>26! ≈ 4 × 10<sup>26</sup></code>, quá lớn để thử hết. Nhưng mã này <strong>giữ nguyên thống kê</strong> của ngôn ngữ: chữ xuất hiện nhiều nhất trong bản mã nhiều khả năng là <code>e</code>.</p>
<table>
<tr><th>Đặc trưng tiếng Anh</th><th>Giá trị</th></tr>
<tr><td>Chữ phổ biến nhất</td><td><code>e t a o i n s h r</code></td></tr>
<tr><td>Cặp chữ (bigram)</td><td><code>th he in er an re</code></td></tr>
<tr><td>Từ 1 chữ cái</td><td><code>a</code>, <code>I</code></td></tr>
<tr><td>Từ 3 chữ phổ biến</td><td><code>the and for are</code></td></tr>
<tr><td>Chữ đôi</td><td><code>ll ee ss oo tt</code></td></tr>
</table>
<p>Cách làm: đếm tần suất (tab <a href="#/tools/cipher">Mật mã cổ điển</a>), đoán vài chữ phổ biến, tìm từ <code>the</code>, rồi điền dần như giải ô chữ. Văn bản càng dài càng dễ. Công cụ tự động: <a href="https://quipqiup.com/" target="_blank" rel="noopener">quipqiup</a>.</p>

<h2 id="vigenere">Vigenère</h2>
<p>Mã đa bảng: mỗi chữ dịch theo một chữ của khoá, khoá lặp lại. Với khoá <code>KEY</code> (10, 4, 24):</p>
${txt`
Bản rõ : A T T A C K A T D A W N
Khoá   : K E Y K E Y K E Y K E Y
Bản mã : K X R K G I K X B K A L

C[i] = (P[i] + K[i mod L]) mod 26        L = độ dài khoá
`}
<p>Cùng một chữ <code>A</code> có thể thành <code>K</code> hay <code>Y</code>, nên phân tích tần suất trực tiếp thất bại. Cách phá gồm hai bước:</p>
<ol class="steps-v">
<li><strong>Tìm độ dài khoá L.</strong> <em>Phương pháp Kasiski</em>: các đoạn lặp lại trong bản mã thường cách nhau một bội số của L. <em>Index of Coincidence</em> (IC): xác suất hai chữ chọn ngẫu nhiên giống nhau,
<code>IC = Σ n<sub>i</sub>(n<sub>i</sub> − 1) / (N(N − 1))</code>. Tiếng Anh có IC ≈ 0.066, chữ ngẫu nhiên ≈ 0.038. Chia bản mã thành L cột (chữ thứ 0, L, 2L… vào cột 0); với L đúng, mỗi cột có IC gần 0.066.</li>
<li><strong>Mỗi cột là một Caesar.</strong> Với mỗi cột, thử 26 độ dịch và chọn độ dịch làm tần suất khớp tiếng Anh nhất (chi bình phương nhỏ nhất). Ghép các độ dịch lại là ra khoá.</li>
</ol>
<p>Công cụ dưới đây làm đúng hai bước trên. Cột vàng là độ dài khoá có IC cao; để ý các bội số của độ dài khoá thật cũng cao.</p>
<div data-widget="vigtool"></div>
<div class="callout tip"><b>Lối tắt trong CTF: known-plaintext</b>
<p>Bản mã ngắn thì thống kê không đủ tin cậy. Nhưng bạn biết bản rõ bắt đầu bằng <code>zCTF</code>, nên 4 chữ khoá đầu tiên là <code>K[i] = (C[i] − P[i]) mod 26</code>. Nếu khoá dài ≤ 4 thì có ngay toàn bộ khoá.</p></div>

<h2 id="hoan-vi">Mã hoán vị</h2>
<p>Không đổi chữ mà đổi <strong>vị trí</strong>. Tần suất chữ cái giữ nguyên như tiếng Anh thường (dấu hiệu nhận biết). Ví dụ <em>Rail fence</em> 3 hàng với <code>WEAREDISCOVERED</code>:</p>
${txt`
W . . . E . . . C . . . R . .
. E . R . D . S . O . E . E .
. . A . . . I . . . V . . . D
Bản mã: WECR ERDSOEE AIVD  →  WECRERDSOEEAIVD
`}

<h2 id="nhan-dien">Nhận diện nhanh</h2>
<table>
<tr><th>Dấu hiệu</th><th>Khả năng</th></tr>
<tr><td>Giữ dấu câu, độ dài từ; <code>zCTF</code> thành 4 chữ khác giữ hoa/thường</td><td>Caesar, Atbash, thay thế, Vigenère</td></tr>
<tr><td>Tần suất chữ giống hệt tiếng Anh nhưng chữ bị xáo trộn vị trí</td><td>Hoán vị</td></tr>
<tr><td>Tần suất bị "dịch ngang" so với tiếng Anh</td><td>Caesar</td></tr>
<tr><td>Tần suất phẳng, IC ≈ 0.04</td><td>Vigenère / đa bảng</td></tr>
<tr><td>Chỉ có số 1–26, hoặc cặp số</td><td>A1Z26, Polybius</td></tr>
</table>
<p>Kho tra cứu lớn nhất: <a href="https://www.dcode.fr/cipher-identifier" target="_blank" rel="noopener">dCode Cipher Identifier</a>.</p>

<h2 id="thu-thach">Thử thách</h2>
<div data-chal="cr1"></div>
<div data-chal="cr-atbash"></div>
<div data-chal="cr-vig"></div>
<div data-chal="cr-sub"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Vì sao phân tích tần suất trực tiếp không phá được Vigenère?",
      options: ["Vì Vigenère dùng máy tính", "Vì cùng một chữ rõ có thể thành nhiều chữ mã khác nhau tuỳ vị trí", "Vì Vigenère xoá dấu cách", "Vì keyspace chỉ có 25"],
      answer: 1,
      explain: "Mỗi vị trí dùng một độ dịch khác nhau nên tần suất bị trải phẳng. Tách thành L cột theo độ dài khoá thì mỗi cột lại là Caesar.",
    },
    {
      q: "Bản mã có tần suất chữ cái gần như y hệt tiếng Anh thông thường nhưng không đọc được. Nhiều khả năng là gì?",
      options: ["Caesar", "Vigenère", "Mã hoán vị", "Base64"],
      answer: 2,
      explain: "Hoán vị chỉ đổi vị trí, không đổi chữ, nên thống kê chữ cái giữ nguyên. Caesar sẽ làm biểu đồ tần suất bị dịch ngang.",
    },
  ],
  challenges: {
    cr1: { title: "Hoàng đế La Mã", pts: 50, diff: "easy", hash: CR_HASH.cr1, body: '<div class="chal-data">gJAM{jhlzhy_xbh_kl_woh}</div>', hints: ["Dấu ngoặc và gạch dưới giữ nguyên, chỉ chữ cái bị dịch.", "<code>z → g</code>: dịch bao nhiêu? Hoặc dùng Caesar brute force ở trang Công cụ."] },
    "cr-atbash": { title: "Soi gương", pts: 50, diff: "easy", hash: CR_HASH["cr-atbash"], body: `<div class="chal-data">${CR.atbash}</div>`, hints: ["Thử Caesar 25 khoá đều không ra. Phép biến đổi nào biến <code>z</code> thành <code>a</code> và <code>C</code> thành <code>X</code>?", "Atbash: <code>A↔Z</code>. Có sẵn trong Công cụ → Giải mã."] },
    "cr-vig": { title: "Khoá bốn chữ", pts: 125, diff: "med", hash: CR_HASH["cr-vig"], body: `<p>Bản mã Vigenère, khoá dài 4 chữ cái. Văn bản quá ngắn để dùng IC.</p><div class="chal-data">${CR.vig}</div>`, hints: ["Bạn biết 4 chữ đầu của bản rõ là <code>zCTF</code>.", "<code>K = (C − P) mod 26</code> cho từng chữ: j−z, J−C, H−T, F−F. Rồi giải ở Công cụ → Mật mã cổ điển."] },
    "cr-sub": { title: "Tần suất chiến thắng", pts: 200, diff: "hard", hash: CR_HASH["cr-sub"], body: `<p>Mã thay thế đơn bảng (mỗi chữ cái thay bằng một chữ khác, giữ hoa/thường). Flag ở cuối văn bản.</p><div class="chal-data">${CR.sub}</div>`, hints: ["Đếm tần suất (Công cụ → Mật mã cổ điển). Chữ nhiều nhất ≈ <code>e</code>; từ 3 chữ hay gặp nhất ≈ <code>the</code>.", "Câu đầu tiên bàn về chính kỹ thuật bạn đang dùng: <em>frequency analysis</em>.", "Dán toàn bộ bản mã vào <a href=\"https://quipqiup.com/\" target=\"_blank\" rel=\"noopener\">quipqiup</a>. Nhớ bỏ dấu và viết đúng hoa/thường khi nộp."] },
  },
});

/* ===================================================================== 2. XOR & OTP */
lesson({
  id: "crypto-xor",
  track: "crypto",
  order: 2,
  level: 1,
  title: "XOR và One-Time Pad",
  short: "Phép toán nền tảng của mật mã hiện đại và cách khai thác khi dùng sai",
  time: "40 phút",
  html: `
<h2 id="xor">XOR là gì</h2>
<p>XOR (<code>⊕</code>, trong code là <code>^</code>) so sánh từng bit: giống nhau ra 0, khác nhau ra 1. Trên byte, XOR áp dụng cho từng cặp bit tương ứng.</p>
${txt`
 a b | a⊕b          0x7a = 0111 1010   ('z')
 0 0 |  0           0x2a = 0010 1010
 0 1 |  1          ─────────────────
 1 0 |  1           0x50 = 0101 0000   ('P')
 1 1 |  0
`}
<div data-widget="xorbits"></div>
<p>Bốn tính chất làm nên mọi thứ:</p>
<table>
<tr><th>Tính chất</th><th>Công thức</th></tr>
<tr><td>Giao hoán</td><td><code>a ⊕ b = b ⊕ a</code></td></tr>
<tr><td>Kết hợp</td><td><code>(a ⊕ b) ⊕ c = a ⊕ (b ⊕ c)</code></td></tr>
<tr><td>Phần tử trung hoà</td><td><code>a ⊕ 0 = a</code></td></tr>
<tr><td>Tự nghịch đảo</td><td><code>a ⊕ a = 0</code></td></tr>
</table>
<p>Hệ quả: với <code>c = m ⊕ k</code> thì <code>c ⊕ k = m</code> (giải mã giống hệt mã hoá) và <code>c ⊕ m = k</code> (biết bản rõ là ra khoá).</p>

<h2 id="mot-byte">XOR với khoá 1 byte</h2>
<p>Chỉ có 256 khoá. Thử hết, rồi chấm điểm kết quả: chuỗi nào toàn ký tự in được, nhiều chữ cái và dấu cách nhất là ứng viên tốt.</p>
${py`
ct = bytes.fromhex("50697e6c51521a58755c1a437541421a4b754e454457")

def score(b):
    return sum(ch in b"etaoin shrdluETAOINSHRDLU_{}" for ch in b)

best = max(range(256), key=lambda k: score(bytes(x ^ k for x in ct)))
print(hex(best), bytes(x ^ best for x in ct))
`}
<p>Nhanh hơn nữa: biết byte đầu bản rõ là <code>z</code> thì <code>k = ct[0] ⊕ ord('z')</code>. Trang <a href="#/tools/decode">Công cụ</a> có mục <em>XOR brute force 1 byte</em>.</p>

<h2 id="lap-khoa">XOR với khoá lặp (repeating-key)</h2>
<p>Khoá <code>k</code> dài L byte được lặp lại: <code>c[i] = m[i] ⊕ k[i mod L]</code>. Đây chính là Vigenère trên byte.</p>
<ol class="steps-v">
<li><strong>Known-plaintext:</strong> XOR 5 byte đầu bản mã với <code>zCTF{</code> cho 5 byte đầu của dòng khoá. Nếu L ≤ 5 thì thấy khoá bắt đầu lặp lại.</li>
<li><strong>Không có bản rõ:</strong> đoán L bằng <em>khoảng cách Hamming</em> (số bit khác nhau). Với L đúng, các khối dài L của bản mã có khoảng cách Hamming trung bình nhỏ nhất. Sau đó tách thành L cột, mỗi cột là XOR 1 byte.</li>
</ol>
${py`
ct = bytes.fromhex("...")
ks = bytes(c ^ p for c, p in zip(ct, b"zCTF{"))
print(ks)                    # thấy khoá lặp lại? → đó là độ dài L
key = ks[:4]                 # giả sử L = 4
print(xor(ct, key))          # hàm xor có sẵn trong widget Python của trang này
`}

<h2 id="otp">One-Time Pad</h2>
<p>Nếu khoá <strong>ngẫu nhiên thật sự</strong>, <strong>dài bằng thông điệp</strong> và <strong>chỉ dùng một lần</strong>, XOR cho bảo mật tuyệt đối (Shannon, 1949): với mỗi bản rõ có thể có, luôn tồn tại một khoá cho ra đúng bản mã đó, nên bản mã không tiết lộ gì ngoài độ dài.</p>
<div class="callout danger"><b>Many-time pad</b>
<p>Dùng lại khoá cho hai thông điệp thì khoá triệt tiêu:</p>
<p><code>c₁ ⊕ c₂ = (m₁ ⊕ k) ⊕ (m₂ ⊕ k) = m₁ ⊕ m₂</code></p>
<p>Biết (hoặc đoán đúng) một phần <code>m₁</code> là ra phần tương ứng của <code>m₂</code>. Lỗi này từng xảy ra thật với dự án VENONA (Liên Xô dùng lại sổ khoá) và với WEP Wi-Fi (IV lặp lại).</p></div>
<h3>Crib dragging</h3>
<p>Khi không biết <code>m₁</code>, đoán một từ hay gặp (<em>crib</em>, ví dụ <code>" the "</code>), XOR nó vào <code>c₁ ⊕ c₂</code> tại từng vị trí. Vị trí nào cho ra chữ đọc được thì có thể đúng; mở rộng dần từ đó.</p>
${py`
x = xor(c1, c2)                       # = m1 ^ m2
crib = b" the "
for i in range(len(x) - len(crib) + 1):
    piece = xor(x[i:i + len(crib)], crib)
    if all(32 <= b < 127 for b in piece):
        print(i, piece)
`}
<p>Cùng lỗi này xuất hiện ở mọi <strong>stream cipher</strong> (RC4, AES-CTR, ChaCha20) nếu dùng lại cặp khoá/nonce: chúng đều sinh một dòng khoá rồi XOR với bản rõ.</p>

<h2 id="python">Luyện tay</h2>
<div data-widget="python"><template>
# Thử nghiệm: XOR hai lần ra bản gốc, và known-plaintext lộ khoá
m = b"zCTF{thu_nghiem}"
k = b"\x13\x37"
c = xor(m, k)
print("ciphertext:", c.hex())
print("giải mã   :", xor(c, k))
print("lộ khoá   :", xor(c[:2], m[:2]))
</template></div>

<h2 id="thu-thach">Thử thách</h2>
<div data-chal="cr2"></div>
<div data-chal="cr-xor-rep"></div>
<div data-chal="cr-mtp"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Bạn có <code>c = m ⊕ k</code> và biết chắc 5 byte đầu của m là <code>zCTF{</code>. Bạn biết được gì?",
      options: ["Không gì cả", "5 byte đầu của dòng khoá", "Toàn bộ m", "Độ dài khoá"],
      answer: 1,
      explain: "<code>k[i] = c[i] ⊕ m[i]</code> tại mọi vị trí biết m. Nếu khoá lặp với chu kỳ ≤ 5 thì có luôn toàn bộ khoá.",
    },
    {
      q: "Điều kiện nào <strong>không</strong> bắt buộc để One-Time Pad an toàn tuyệt đối?",
      options: ["Khoá ngẫu nhiên thật sự", "Khoá dài ít nhất bằng thông điệp", "Khoá chỉ dùng một lần", "Thông điệp phải là chữ in hoa"],
      answer: 3,
      explain: "Ba điều kiện về khoá là đủ. Vi phạm bất kỳ điều kiện nào (đặc biệt là dùng lại khoá) đều phá vỡ bảo mật.",
    },
  ],
  challenges: {
    cr2: { title: "XOR một byte", pts: 75, diff: "easy", hash: CR_HASH.cr2, body: '<p>Flag đã được XOR với một khoá dài 1 byte:</p><div class="chal-data">50697e6c51521a58755c1a437541421a4b754e454457</div>', hints: ["Byte đầu <code>0x50</code> là <code>'z'</code> (0x7a) XOR khoá.", "Khoá = 0x50 ⊕ 0x7a. Công cụ → Giải mã: From Hex rồi XOR."] },
    "cr-xor-rep": { title: "Khoá ngắn là chết", pts: 125, diff: "med", hash: CR_HASH["cr-xor-rep"], body: `<p>Flag XOR với một khoá lặp lại, độ dài chưa biết:</p><div class="chal-data">${CR.xor_rep}</div>`, hints: ["XOR 5 byte đầu bản mã với <code>zCTF{</code>.", "Dòng khoá thu được bắt đầu lặp lại sau 4 byte. Dùng 4 byte đó làm khoá XOR (Công cụ → Giải mã, key dạng hex)."] },
    "cr-mtp": { title: "Một lần thôi nhé", pts: 175, diff: "med", hash: CR_HASH["cr-mtp"], body: `<p>Câu lạc bộ dùng One-Time Pad để gửi tin, nhưng lười tạo khoá mới. Bạn chặn được hai bản mã. Bản mã thứ nhất là thông báo công khai trên bảng tin, nên bạn biết nội dung của nó.</p><div class="chal-data">m1 = "${CR.mtp_m1}"\nc1 = ${CR.mtp_c1}\nc2 = ${CR.mtp_c2}</div>`, hints: ["<code>c1 ⊕ c2 = m1 ⊕ m2</code>.", "<code>m2 = c1 ⊕ c2 ⊕ m1</code>. Trong widget Python: <code>xor(xor(bytes.fromhex(c1), bytes.fromhex(c2)), m1.encode())</code> (cắt theo độ dài c2)."] },
  },
});

/* ===================================================================== 3. Toán cho crypto */
lesson({
  id: "crypto-math",
  track: "crypto",
  order: 3,
  level: 2,
  title: "Toán cho mật mã",
  short: "Modulo, gcd, nghịch đảo, luỹ thừa nhanh, Fermat, Euler, CRT",
  time: "50 phút",
  html: `
<p>Mật mã khoá công khai (RSA, Diffie–Hellman, ECC) dựa hoàn toàn trên số học modulo. Bài này đủ để bạn hiểu và tự viết lại các tấn công RSA ở bài sau. Mọi đoạn code đều chạy được trong widget Python.</p>

<h2 id="modulo">Số học modulo</h2>
<p><code>a mod n</code> là số dư khi chia <code>a</code> cho <code>n</code>, luôn nằm trong <code>[0, n−1]</code>. Viết <code>a ≡ b (mod n)</code> nghĩa là <code>n</code> chia hết <code>a − b</code>. Cộng, trừ, nhân đều "đi qua" được modulo:</p>
${txt`
(a + b) mod n = ((a mod n) + (b mod n)) mod n
(a · b) mod n = ((a mod n) · (b mod n)) mod n
Ví dụ (mod 7):  5 + 4 = 9 ≡ 2     5 · 4 = 20 ≡ 6     3 − 5 = −2 ≡ 5
`}
<div class="callout warn"><b>Chia không đi qua được</b>
<p>Không có phép "chia" trực tiếp trong modulo. Thay vào đó ta nhân với <strong>nghịch đảo modulo</strong> (phần dưới). Python: <code>-2 % 7</code> cho <code>5</code> (luôn không âm), khác với C.</p></div>

<h2 id="gcd">Ước chung lớn nhất và thuật toán Euclid</h2>
<p><code>gcd(a, b) = gcd(b, a mod b)</code>, lặp đến khi số dư bằng 0:</p>
${txt`
gcd(240, 46):  240 = 5·46 + 10
                46 = 4·10 + 6
                10 = 1·6  + 4
                 6 = 1·4  + 2
                 4 = 2·2  + 0     → gcd = 2
`}
<p>Thuật toán chạy cực nhanh kể cả với số 2048 bit (số bước tỉ lệ với số chữ số). Đây là lý do tấn công "hai khoá RSA chung thừa số" chỉ cần một phép <code>gcd</code>.</p>

<h2 id="egcd">Euclid mở rộng và đẳng thức Bézout</h2>
<p>Luôn tồn tại số nguyên <code>x, y</code> sao cho <code>a·x + b·y = gcd(a, b)</code>. Thuật toán Euclid mở rộng tìm ra chúng:</p>
${py`
def egcd(a, b):
    if b == 0:
        return a, 1, 0
    g, x, y = egcd(b, a % b)
    return g, y, x - (a // b) * y

g, x, y = egcd(240, 46)
print(g, x, y, 240 * x + 46 * y)   # 2 -9 47 2
`}

<h2 id="nghich-dao">Nghịch đảo modulo</h2>
<p><code>a⁻¹ mod n</code> là số <code>x</code> sao cho <code>a·x ≡ 1 (mod n)</code>. Nó tồn tại <strong>khi và chỉ khi</strong> <code>gcd(a, n) = 1</code>. Từ Bézout: <code>a·x + n·y = 1</code> → <code>a·x ≡ 1 (mod n)</code>.</p>
${py`
print(pow(3, -1, 7))        # 5, vì 3·5 = 15 ≡ 1 (mod 7)   (Python ≥ 3.8)
print(egcd(3, 7)[1] % 7)    # cách tự làm, cùng kết quả
`}

<h2 id="luy-thua">Luỹ thừa nhanh (square-and-multiply)</h2>
<p>Tính <code>a<sup>e</sup> mod n</code> với <code>e</code> hàng trăm chữ số? Không nhân <code>e</code> lần. Viết <code>e</code> dưới dạng nhị phân, bình phương liên tục và chỉ nhân vào ở bit 1: số phép nhân ≈ 2·log₂(e).</p>
${py`
def power(a, e, n):
    r = 1
    a %= n
    while e > 0:
        if e & 1:
            r = r * a % n
        a = a * a % n
        e >>= 1
    return r

print(power(7, 560, 561), pow(7, 560, 561))   # hàm pow 3 tham số làm đúng việc này
`}

<h2 id="fermat-euler">Số nguyên tố, Fermat và Euler</h2>
<p><strong>Định lý Fermat nhỏ:</strong> nếu <code>p</code> nguyên tố và <code>p ∤ a</code> thì <code>a<sup>p−1</sup> ≡ 1 (mod p)</code>. Hệ quả: số mũ có thể rút gọn theo <code>p − 1</code>:
<code>a<sup>e</sup> ≡ a<sup>e mod (p−1)</sup> (mod p)</code>.</p>
<p><strong>Phi hàm Euler</strong> <code>φ(n)</code> = số các số trong <code>[1, n]</code> nguyên tố cùng nhau với <code>n</code>. Với <code>p, q</code> nguyên tố khác nhau: <code>φ(p) = p − 1</code>, <code>φ(p·q) = (p − 1)(q − 1)</code>.</p>
<p><strong>Định lý Euler:</strong> nếu <code>gcd(a, n) = 1</code> thì <code>a<sup>φ(n)</sup> ≡ 1 (mod n)</code>. Đây chính là lý do RSA giải mã đúng.</p>
<p><strong>Kiểm tra nguyên tố:</strong> thử chia chỉ dùng được với số nhỏ. Với số lớn, dùng <em>Miller–Rabin</em>: kiểm tra xác suất dựa trên Fermat, sai số giảm theo cấp số nhân khi lặp nhiều vòng. Mọi thư viện crypto đều dùng nó để sinh số nguyên tố.</p>

<h2 id="crt">Định lý số dư Trung Hoa (CRT)</h2>
<p>Nếu <code>m₁, m₂, …, m<sub>k</sub></code> đôi một nguyên tố cùng nhau, hệ</p>
${txt`
x ≡ r₁ (mod m₁)
x ≡ r₂ (mod m₂)
...
x ≡ rₖ (mod mₖ)
`}
<p>có <strong>đúng một</strong> nghiệm <code>x</code> trong <code>[0, M)</code> với <code>M = m₁·m₂·…·m<sub>k</sub></code>:</p>
${txt`
Mᵢ = M / mᵢ        yᵢ = Mᵢ⁻¹ mod mᵢ        x = Σ rᵢ · Mᵢ · yᵢ  (mod M)
`}
${py`
from math import prod

def crt(rs, ms):
    M = prod(ms)
    return sum(r * (M // m) * pow(M // m, -1, m) for r, m in zip(rs, ms)) % M

print(crt([2, 3, 2], [3, 5, 7]))    # 23 — bài toán gốc của Tôn Tử
`}
<p>CRT xuất hiện trong tấn công Håstad (RSA), trong việc tăng tốc giải mã RSA, và trong các bài "cho số dư theo nhiều modulo".</p>

<h2 id="thuc-hanh">Bàn thực hành</h2>
<div data-widget="python"><template>
# Dùng ô này cho các thử thách bên dưới.
from math import gcd, prod

def egcd(a, b):
    if b == 0:
        return a, 1, 0
    g, x, y = egcd(b, a % b)
    return g, y, x - (a // b) * y

print(gcd(240, 46), egcd(240, 46))
print(pow(3, -1, 7))
</template></div>

<h2 id="thu-thach">Thử thách</h2>
<div data-chal="cr-inv"></div>
<div data-chal="cr-pow"></div>
<div data-chal="cr-crt"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Khi nào <code>a</code> có nghịch đảo modulo <code>n</code>?",
      options: ["Khi a < n", "Khi n là số nguyên tố", "Khi gcd(a, n) = 1", "Luôn luôn"],
      answer: 2,
      explain: "Nghịch đảo tồn tại khi và chỉ khi gcd(a, n) = 1. Nếu n nguyên tố thì mọi a không chia hết cho n đều thoả, nhưng đó chỉ là trường hợp riêng.",
    },
    {
      q: "Với <code>p = 101</code> nguyên tố, <code>5<sup>1000</sup> mod 101</code> bằng với số nào?",
      options: ["5<sup>1000 mod 100</sup> mod 101 = 5<sup>0</sup> = 1", "5<sup>1000 mod 101</sup> mod 101", "0", "Không rút gọn được"],
      answer: 0,
      explain: "Theo Fermat, số mũ rút gọn theo p − 1 = 100. 1000 mod 100 = 0 nên kết quả là 1.",
    },
  ],
  challenges: {
    "cr-inv": { title: "Phép chia bí ẩn", pts: 50, diff: "easy", hash: CR_HASH["cr-inv"], body: `<p>Tìm <code>x</code> sao cho <code>${CR.inv[0]} · x ≡ 1 (mod ${CR.inv[1]})</code>, với <code>0 ≤ x &lt; ${CR.inv[1]}</code>. Flag: <code>zCTF{x}</code>.</p>`, hints: ["Đây là nghịch đảo modulo.", "<code>pow(1337, -1, 1000000007)</code>"] },
    "cr-pow": { title: "Số mũ khổng lồ", pts: 75, diff: "easy", hash: CR_HASH["cr-pow"], body: `<p>Tính <code>${CR.pow[0]}<sup>${CR.pow[1]}</sup> mod ${CR.pow[2]}</code> (số mũ là 10 mũ 100, cộng 2026; modulo là số nguyên tố). Flag: <code>zCTF{kết_quả}</code>.</p>`, hints: ["Python <code>pow(7, 10**100 + 2026, 1000000007)</code> làm được ngay nhờ luỹ thừa nhanh.", "Tự kiểm tra bằng Fermat: rút gọn số mũ theo p − 1 rồi tính lại, hai kết quả phải giống nhau."] },
    "cr-crt": { title: "Ghép mảnh", pts: 150, diff: "med", hash: CR_HASH["cr-crt"], body: `<p>Một số nguyên <code>x</code> (chính là flag, đổi bằng <code>bytes_to_long</code>) được chia thành các số dư:</p><div class="chal-data">${CR.crt.map(([r, m]) => `x ≡ ${r} (mod ${m})`).join("\n")}</div>`, hints: ["Các modulo là số nguyên tố khác nhau, nên đôi một nguyên tố cùng nhau. Áp dụng CRT.", "Dùng hàm <code>crt(rs, ms)</code> trong bài, rồi <code>long_to_bytes(x)</code>."] },
  },
});

/* ===================================================================== 4. Mã khối & AES */
lesson({
  id: "crypto-block",
  track: "crypto",
  order: 4,
  level: 2,
  title: "Mã khối và AES",
  short: "ECB, CBC, CTR, padding và các tấn công oracle kinh điển",
  time: "60 phút",
  html: `
<h2 id="ma-khoi">Mã khối là gì</h2>
<p>Mã khối (block cipher) là một hàm <code>E<sub>k</sub></code> biến một khối có kích thước cố định thành một khối khác cùng kích thước, đảo ngược được nếu có khoá. <strong>AES</strong> (chuẩn từ 2001) dùng khối 16 byte, khoá 128/192/256 bit. Bản thân AES chưa từng bị phá trong thực tế; bài CTF luôn tấn công <strong>cách dùng</strong> nó.</p>
<p>Mỗi vòng AES-128 (10 vòng) gồm: <code>SubBytes</code> (thay từng byte qua S-box, tạo tính phi tuyến), <code>ShiftRows</code> và <code>MixColumns</code> (trộn byte, tạo tính khuếch tán), <code>AddRoundKey</code> (XOR với khoá vòng).</p>

<h2 id="padding">Padding PKCS#7</h2>
<p>Dữ liệu phải dài bằng bội số của 16. PKCS#7 thêm <code>N</code> byte, mỗi byte có giá trị <code>N</code> (từ 1 đến 16). Nếu dữ liệu đã đủ bội số 16, vẫn thêm nguyên một khối <code>10 10 … 10</code> để việc gỡ padding không nhập nhằng.</p>
${txt`
"YELLOW SUBMARINE"       (16 byte)  → + 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10
"HELLO"                  (5 byte)   → + 0b 0b 0b 0b 0b 0b 0b 0b 0b 0b 0b
`}

<h2 id="che-do">Chế độ hoạt động</h2>
<table>
<tr><th>Chế độ</th><th>Công thức</th><th>Ghi chú</th></tr>
<tr><td><strong>ECB</strong></td><td><code>Cᵢ = E(Pᵢ)</code></td><td>Khối giống nhau → bản mã giống nhau. Lộ cấu trúc dữ liệu.</td></tr>
<tr><td><strong>CBC</strong></td><td><code>Cᵢ = E(Pᵢ ⊕ Cᵢ₋₁)</code>, <code>C₀ = IV</code></td><td>Cần IV ngẫu nhiên. Giải mã: <code>Pᵢ = D(Cᵢ) ⊕ Cᵢ₋₁</code></td></tr>
<tr><td><strong>CTR</strong></td><td><code>Cᵢ = Pᵢ ⊕ E(nonce ‖ i)</code></td><td>Biến AES thành stream cipher. Dùng lại nonce = many-time pad.</td></tr>
<tr><td><strong>GCM</strong></td><td>CTR + mã xác thực</td><td>Chế độ nên dùng ngày nay: vừa bí mật vừa chống sửa đổi.</td></tr>
</table>
<p>Hình dưới mã hoá từng 16 byte điểm ảnh bằng một mã khối đồ chơi. Ở ECB, vùng cùng màu cho ra cùng bản mã nên hình dạng vẫn hiện rõ (hiện tượng "chim cánh cụt ECB" nổi tiếng):</p>
<div data-widget="ecbpenguin"></div>

<h2 id="ecb-cut">Tấn công ECB 1: cắt và dán khối</h2>
<p>Vì mỗi khối mã hoá độc lập, bạn có thể ghép các khối từ nhiều bản mã khác nhau, server vẫn giải mã được. Ví dụ server tạo token cho email bạn nhập:</p>
${txt`
email=AAAAAAAAAAadmin\x0b\x0b\x0b...   &uid=10&role=user
|-- khối 0 -----|-- khối 1 -----|-- khối 2 ...
 "email=" + 10 chữ A    "admin" + padding hợp lệ 11 byte 0x0b
`}
<ol class="steps-v">
<li>Chọn email sao cho khối 1 chứa đúng <code>admin</code> + padding PKCS#7. Lấy khối mã hoá tương ứng.</li>
<li>Chọn email có độ dài sao cho chuỗi <code>role=</code> kết thúc đúng ở cuối một khối, để <code>user</code> rơi vào khối cuối cùng.</li>
<li>Thay khối cuối bằng khối <code>admin…</code> từ bước 1. Server giải mã ra <code>…&amp;role=admin</code>.</li>
</ol>

<h2 id="ecb-byte">Tấn công ECB 2: oracle giải từng byte</h2>
<p>Server mã hoá <code>input ‖ SECRET</code> và trả bản mã cho bạn (<em>chosen-plaintext oracle</em>). Bạn có thể đọc <code>SECRET</code> từng byte:</p>
<ol class="steps-v">
<li>Gửi 15 chữ <code>A</code>. Khối đầu tiên là <code>AAAAAAAAAAAAAAA?</code>, với <code>?</code> là byte đầu của SECRET. Ghi lại khối mã.</li>
<li>Gửi lần lượt <code>AAAAAAAAAAAAAAA</code> + mọi byte có thể (256 lần), so khối đầu với khối đã ghi. Khớp là biết byte đầu.</li>
<li>Gửi 14 chữ <code>A</code> + byte đã biết + đoán byte thứ hai… Tiếp tục, sang khối sau khi đã biết 16 byte.</li>
</ol>
<p>Mỗi byte tốn tối đa 256 lần thử, nên phải viết script. Widget Python trên trang này gọi được lab qua <code>pyodide.http.open_url</code>.</p>

<h2 id="cbc-flip">Tấn công CBC: lật bit</h2>
<p>Khi giải mã CBC: <code>P₁ = D(C₁) ⊕ IV</code>. Kẻ tấn công không biết khoá vẫn sửa được <code>IV</code>. Lật bit ở <code>IV</code> lật đúng bit đó ở <code>P₁</code>:</p>
${txt`
IV' = IV ⊕ Δ    →    P₁' = D(C₁) ⊕ IV ⊕ Δ = P₁ ⊕ Δ
Muốn đổi ký tự '0' thành '1' ở vị trí j:  Δ[j] = ord('0') ⊕ ord('1') = 0x01
`}
<p>Sửa <code>Cᵢ₋₁</code> thì <code>Pᵢ</code> đổi theo ý muốn, còn <code>Pᵢ₋₁</code> thành rác. Bài học: <strong>mã hoá không đồng nghĩa với toàn vẹn</strong>. Cần MAC hoặc chế độ có xác thực như GCM.</p>

<h2 id="padding-oracle">Padding oracle</h2>
<p>Nếu server báo khác nhau giữa "padding sai" và "padding đúng nhưng dữ liệu sai", kẻ tấn công giải mã được toàn bộ bản mã CBC mà không cần khoá. Ý tưởng: sửa byte cuối của <code>Cᵢ₋₁</code> qua 256 giá trị; giá trị làm padding hợp lệ (byte cuối = <code>01</code>) cho biết <code>D(Cᵢ)[15] = guess ⊕ 0x01</code>, từ đó ra byte rõ. Lặp cho từng byte. Tấn công này (Vaudenay, 2002) từng phá ASP.NET, SSL/TLS (POODLE, Lucky13).</p>

<h2 id="lab">Lab: oracle AES thật</h2>
<p>Lab chạy trên server FastAPI của trang (AES-128 thật, khoá ngẫu nhiên mỗi lần khởi động). Mở <a href="/lab/crypto/" target="_blank">/lab/crypto/</a> để xem danh sách endpoint. Có thể gọi bằng <code>curl</code> trong <a href="#/tools/shell">Terminal</a> hoặc bằng Python:</p>
${py`
from pyodide.http import open_url
import json

def get(path):
    return json.loads(open_url(path).read())

print(get("/lab/crypto/ecb/profile?email=a@b.c"))
print(get("/lab/crypto/ecb/oracle?p=" + "41" * 15))
`}
<div data-widget="python"><template>
from pyodide.http import open_url
from urllib.parse import quote
import json

def get(path):
    return json.loads(open_url(path).read())

r = get("/lab/crypto/ecb/profile?email=" + quote("hacker@zctf.local"))
print(r["profile"])
tok = bytes.fromhex(r["token"])
for i in range(0, len(tok), 16):
    print(i // 16, tok[i:i + 16].hex())
</template></div>

<h2 id="thu-thach">Thử thách</h2>
<div data-chal="cr-pad"></div>
<div data-chal="cr-cbc"></div>
<div data-chal="cr-ecb-cut"></div>
<div data-chal="cr-ecb-byte"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Hai thông điệp có khối thứ 3 giống hệt nhau được mã hoá AES với cùng khoá. Ở chế độ nào bản mã khối thứ 3 chắc chắn giống nhau?",
      options: ["ECB", "CBC với IV ngẫu nhiên", "CTR với nonce khác nhau", "GCM"],
      answer: 0,
      explain: "ECB mã hoá từng khối độc lập, không phụ thuộc vị trí hay khối trước. Đó là lý do ECB lộ mẫu.",
    },
    {
      q: "Trong CBC, bạn XOR byte thứ 5 của IV với <code>0x01</code>. Điều gì xảy ra với bản rõ sau giải mã?",
      options: ["Toàn bộ bản rõ thành rác", "Byte thứ 5 của khối rõ đầu tiên bị lật bit thấp nhất, phần còn lại giữ nguyên", "Padding sai", "Không gì thay đổi"],
      answer: 1,
      explain: "<code>P₁ = D(C₁) ⊕ IV</code>, nên thay đổi IV truyền thẳng sang P₁, đúng vị trí, đúng bit.",
    },
  ],
  challenges: {
    "cr-pad": { title: "Lấp đầy khối", pts: 50, diff: "easy", hash: CR_HASH["cr-pad"], body: "<p>Thông điệp dài 13 byte, mã khối 16 byte, padding PKCS#7. Các byte padding được thêm vào (hex, viết liền) là gì? Flag: <code>zCTF{hex}</code>, ví dụ <code>zCTF{0202}</code>.</p>", hints: ["Thiếu bao nhiêu byte để đủ 16?", "Thiếu 3 byte, mỗi byte có giá trị 3."] },
    "cr-cbc": { title: "Lật một bit", pts: 150, diff: "med", hash: CR_HASH["cr-cbc"], body: '<p>Lấy token tại <a href="/lab/crypto/cbc/token" target="_blank">/lab/crypto/cbc/token</a> (bản rõ <code>admin=0;user=guest;note=hello</code>, token = <code>iv ‖ ct</code>). Sửa token để server nghĩ bạn là admin, rồi gửi tới <code>/lab/crypto/cbc/check?token=...</code>.</p>', hints: ["Ký tự <code>0</code> trong <code>admin=0</code> nằm ở vị trí 6 của khối rõ đầu tiên, tức là chịu ảnh hưởng của byte thứ 6 trong IV.", "Byte IV[6] (cặp hex thứ 7 của token) XOR với <code>0x30 ⊕ 0x31 = 0x01</code>. Ví dụ <code>4f</code> thành <code>4e</code>."] },
    "cr-ecb-cut": { title: "Cắt dán khối", pts: 250, diff: "hard", hash: CR_HASH["cr-ecb-cut"], body: '<p>Server tạo token tại <code>/lab/crypto/ecb/profile?email=...</code> từ chuỗi <code>email=&lt;email&gt;&amp;uid=10&amp;role=user</code> (đã lọc ký tự <code>&amp;</code> và <code>=</code>), mã hoá AES-ECB. Đăng nhập tại <code>/lab/crypto/ecb/login?token=...</code>. Hãy trở thành <code>role=admin</code>.</p>', hints: ["<code>email=</code> dài 6 byte. Email gồm 10 ký tự bất kỳ + <code>admin</code> + 11 byte <code>0x0b</code> (trong URL: <code>%0b</code>) cho bạn khối thứ 2 là <code>admin</code> kèm padding hợp lệ.", "<code>email=&amp;uid=10&amp;role=</code> dài 19 byte. Email dài 13 ký tự làm chuỗi này kết thúc ở byte 32, nên <code>user</code> nằm riêng ở khối thứ 3.", "Token mới = 2 khối đầu của token email-13-ký-tự + khối thứ 2 của token chứa admin."] },
    "cr-ecb-byte": { title: "Từng byte một", pts: 300, diff: "hard", hash: CR_HASH["cr-ecb-byte"], body: '<p>Oracle <code>/lab/crypto/ecb/oracle?p=&lt;hex&gt;</code> trả về <code>AES-ECB(k, p ‖ FLAG)</code>. Có thể gửi nhiều input cùng lúc: <code>p=hex1,hex2,…</code> (tối đa 300). Đọc FLAG.</p>', hints: ["Gửi 15 byte <code>A</code>; khối đầu chứa 15 chữ A + byte đầu của flag. So với 256 khối <code>AAAAAAAAAAAAAAA + x</code> (gửi 1 lần dạng danh sách).", "Tổng quát: với <code>known</code> là phần đã biết, đệm <code>15 − len(known) % 16</code> chữ A, xét khối số <code>len(known) // 16</code>; ứng viên là 16 byte cuối của <code>A…A + known + x</code>.", "Viết vòng lặp trong widget Python với <code>open_url</code>; dừng khi gặp <code>}</code>."] },
  },
});

/* ===================================================================== 5. Hash */
lesson({
  id: "crypto-hash",
  track: "crypto",
  order: 5,
  level: 2,
  title: "Hàm băm",
  short: "Tính chất, lưu mật khẩu, bẻ hash, salt, HMAC và length extension",
  time: "40 phút",
  html: `
<h2 id="tinh-chat">Hàm băm mật mã</h2>
<p>Hàm băm <code>H</code> biến dữ liệu độ dài bất kỳ thành chuỗi độ dài cố định (<em>digest</em>). Hàm băm mật mã cần ba tính chất:</p>
<table>
<tr><th>Tính chất</th><th>Nghĩa là</th><th>Chi phí tấn công lý tưởng (n bit)</th></tr>
<tr><td>Kháng tiền ảnh</td><td>Cho <code>h</code>, khó tìm <code>m</code> với <code>H(m) = h</code></td><td><code>2ⁿ</code></td></tr>
<tr><td>Kháng tiền ảnh thứ hai</td><td>Cho <code>m₁</code>, khó tìm <code>m₂ ≠ m₁</code> cùng hash</td><td><code>2ⁿ</code></td></tr>
<tr><td>Kháng va chạm</td><td>Khó tìm bất kỳ cặp <code>m₁ ≠ m₂</code> cùng hash</td><td><code>2<sup>n/2</sup></code> (nghịch lý ngày sinh)</td></tr>
</table>
<div class="callout idea"><b>Nghịch lý ngày sinh</b>
<p>Chỉ cần 23 người là xác suất có hai người trùng ngày sinh vượt 50%. Tổng quát, sau khoảng <code>√N</code> lần thử đã có va chạm trong không gian N giá trị. Vì vậy hash 128 bit chỉ cho khoảng 64 bit an toàn trước va chạm.</p></div>
<table>
<tr><th>Thuật toán</th><th>Độ dài</th><th>Tình trạng</th></tr>
<tr><td>MD5</td><td>128 bit (32 hex)</td><td>Va chạm tạo được trong vài giây (Wang, 2004). Không dùng cho bảo mật.</td></tr>
<tr><td>SHA-1</td><td>160 bit (40 hex)</td><td>Va chạm thực tế: SHAttered (Google, 2017). Đã bị loại bỏ.</td></tr>
<tr><td>SHA-256 / SHA-512</td><td>256 / 512 bit</td><td>An toàn. Họ SHA-2.</td></tr>
<tr><td>SHA-3, BLAKE2/3</td><td>tuỳ chọn</td><td>An toàn, cấu trúc khác SHA-2.</td></tr>
</table>

<h2 id="mat-khau">Lưu mật khẩu</h2>
<p>Server không nên lưu mật khẩu gốc mà lưu hash. Nhưng người dùng chọn mật khẩu dễ đoán, nên kẻ tấn công lấy được database chỉ cần <strong>đoán và băm thử</strong>:</p>
<ul>
<li><strong>Tấn công từ điển</strong>: thử danh sách mật khẩu bị lộ, nổi tiếng nhất là <code>rockyou.txt</code> (14 triệu mật khẩu).</li>
<li><strong>Bảng tra / rainbow table</strong>: tính sẵn hash của hàng tỷ chuỗi, tra là ra (CrackStation).</li>
<li><strong>Brute force</strong>: thử mọi tổ hợp. GPU hiện đại tính hàng chục tỷ MD5 mỗi giây.</li>
</ul>
<p>Phòng thủ:</p>
<ol class="steps-v">
<li><strong>Salt</strong>: chuỗi ngẫu nhiên riêng cho mỗi người, lưu cùng hash: <code>H(salt ‖ password)</code>. Bảng tra sẵn trở nên vô dụng, và hai người cùng mật khẩu có hash khác nhau. Salt không bí mật; nó chỉ buộc kẻ tấn công phải bẻ riêng từng tài khoản.</li>
<li><strong>Hàm chậm</strong>: bcrypt, scrypt, Argon2 cố tình tốn nhiều thời gian và bộ nhớ. Một lần thử mất 100 ms thì brute force chậm đi hàng triệu lần.</li>
</ol>
${sh`
# hashcat: -m chọn loại hash, -a 0 là tấn công từ điển
$ hashcat -m 0    -a 0 hashes.txt rockyou.txt      # MD5
$ hashcat -m 1400 -a 0 hashes.txt rockyou.txt      # SHA-256
$ hashcat -m 1410 -a 0 hash_salt.txt rockyou.txt   # sha256($pass.$salt)
$ john --wordlist=rockyou.txt --format=raw-md5 hashes.txt
`}
<p>Trang <a href="#/tools/hash">Công cụ → Hash</a> tính MD5/SHA, nhận diện loại hash và thử một từ điển nhỏ.</p>

<h2 id="mac">MAC và HMAC</h2>
<p><strong>MAC</strong> (Message Authentication Code) chứng minh thông điệp đến từ người có khoá và không bị sửa. Cách làm ngây thơ <code>MAC = H(key ‖ message)</code> có hai vấn đề:</p>
<ul>
<li><strong>Khoá ngắn</strong>: biết một cặp (thông điệp, MAC) là brute force được khoá offline.</li>
<li><strong>Length extension</strong>: MD5, SHA-1, SHA-256 dùng cấu trúc Merkle–Damgård, trong đó hash chính là trạng thái nội bộ sau khối cuối. Biết <code>H(key ‖ m)</code> và độ dài key, kẻ tấn công tính được <code>H(key ‖ m ‖ padding ‖ m')</code> mà <strong>không cần biết key</strong>. Công cụ: <code>hash_extender</code>, <code>hashpump</code>.</li>
</ul>
<p>Cách đúng là <strong>HMAC</strong>: <code>HMAC(k, m) = H((k ⊕ opad) ‖ H((k ⊕ ipad) ‖ m))</code>. Hai lớp băm chặn length extension. Python: <code>hmac.new(key, msg, hashlib.sha256)</code>.</p>

<h2 id="python">Thực hành</h2>
<div data-widget="python"><template>
import hashlib, hmac

pw = b"password"
print("md5   ", hashlib.md5(pw).hexdigest())
print("sha1  ", hashlib.sha1(pw).hexdigest())
print("sha256", hashlib.sha256(pw).hexdigest())

# Cùng mật khẩu, salt khác → hash khác
for salt in (b"a1", b"b2"):
    print(salt, hashlib.sha256(salt + pw).hexdigest()[:16])

print("hmac  ", hmac.new(b"key", b"msg", hashlib.sha256).hexdigest())
</template></div>

<h2 id="thu-thach">Thử thách</h2>
<div data-chal="cr3"></div>
<div data-chal="cr-salt"></div>
<div data-chal="cr-mac"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Salt giúp chống lại điều gì?",
      options: ["Kẻ tấn công đoán đúng mật khẩu yếu", "Bảng tra tính sẵn (rainbow table) và việc bẻ nhiều tài khoản cùng lúc", "Va chạm MD5", "Nghe lén mạng"],
      answer: 1,
      explain: "Salt khác nhau làm bảng tra sẵn vô dụng và buộc phải bẻ riêng từng hash. Nó không cứu được mật khẩu quá yếu; cần thêm hàm băm chậm.",
    },
    {
      q: "Vì sao <code>SHA256(key ‖ message)</code> không phải MAC an toàn?",
      options: ["SHA-256 đã bị phá", "Kẻ tấn công có thể nối thêm dữ liệu và tính MAC hợp lệ mới (length extension)", "Nó quá chậm", "Nó không có salt"],
      answer: 1,
      explain: "Cấu trúc Merkle–Damgård để lộ trạng thái nội bộ. Dùng HMAC, hoặc hash không bị length extension như SHA-3.",
    },
  ],
  challenges: {
    cr3: { title: "Mật khẩu yếu", pts: 50, diff: "easy", hash: CR_HASH.cr3, body: '<p>Hash MD5 của mật khẩu admin. Flag: <code>zCTF{mật_khẩu}</code>.</p><div class="chal-data">5f4dcc3b5aa765d61d8327deb882cf99</div>', hints: ["32 ký tự hex: MD5. Tra CrackStation hoặc Công cụ → Hash.", "Mật khẩu phổ biến nhất thế giới."] },
    "cr-salt": { title: "Có muối vẫn mặn", pts: 125, diff: "med", hash: CR_HASH["cr-salt"], body: `<p>Database bị lộ một dòng: <code>sha256(salt + password)</code>. Mật khẩu nằm trong danh sách bên dưới (trích từ rockyou). Flag: <code>zCTF{mật_khẩu}</code>.</p><div class="chal-data">salt = "${CR.salt[0]}"\nhash = ${CR.salt[1]}</div><div data-widget="python"><template>
import hashlib
salt = "${CR.salt[0]}"
target = "${CR.salt[1]}"
words = """${CR.words.join(" ")}""".split()

# TODO: thử từng word, so sánh sha256(salt + word) với target
</template></div>`, hints: ["<code>hashlib.sha256((salt + w).encode()).hexdigest() == target</code>", "Một vòng <code>for</code> qua <code>words</code> là đủ, ít hơn 100 lần thử."] },
    "cr-mac": { title: "PIN bốn số", pts: 150, diff: "med", hash: CR_HASH["cr-mac"], body: `<p>Một API ký cookie bằng <code>sha256(PIN + message)</code>, với PIN là 4 chữ số bí mật. Bạn có một cookie hợp lệ. Tìm PIN. Flag: <code>zCTF{pin_XXXX}</code>.</p><div class="chal-data">message = ${CR.mac[0]}\nmac     = ${CR.mac[1]}</div>`, hints: ["Chỉ có 10 000 PIN từ 0000 đến 9999.", "<code>for i in range(10000): p = f\"{i:04d}\"</code> rồi so sánh hash. Khi có PIN, bạn ký được mọi message, ví dụ <code>role=admin</code>."] },
  },
});

/* ===================================================================== 6. RSA */
lesson({
  id: "crypto-rsa",
  track: "crypto",
  order: 6,
  level: 3,
  title: "RSA và các tấn công",
  short: "Sinh khoá, chứng minh, và 6 cách phá RSA dùng sai",
  time: "70 phút",
  html: `
<h2 id="sinh-khoa">Sinh khoá RSA</h2>
<ol class="steps-v">
<li>Chọn hai số nguyên tố lớn, khác nhau, ngẫu nhiên <code>p</code> và <code>q</code> (mỗi số 1024 bit trở lên).</li>
<li><code>n = p · q</code> (modulus), <code>φ(n) = (p − 1)(q − 1)</code>.</li>
<li>Chọn <code>e</code> với <code>gcd(e, φ(n)) = 1</code>, thường là <code>65537</code>.</li>
<li><code>d = e⁻¹ mod φ(n)</code>.</li>
<li>Khoá công khai <code>(n, e)</code>, khoá bí mật <code>d</code> (hoặc <code>p, q</code>).</li>
</ol>
${txt`
Mã hoá:  c = mᵉ mod n            (m là số nguyên, m < n)
Giải mã: m = cᵈ mod n
Ký:      s = mᵈ mod n            Kiểm tra: sᵉ mod n == m
`}
<p><strong>Vì sao đúng:</strong> <code>e·d = 1 + k·φ(n)</code>, nên <code>c<sup>d</sup> = m<sup>ed</sup> = m · (m<sup>φ(n)</sup>)<sup>k</sup> ≡ m · 1<sup>k</sup> = m (mod n)</code> theo định lý Euler.</p>
<p><strong>Vì sao an toàn:</strong> tính <code>d</code> cần <code>φ(n)</code>, mà tính <code>φ(n)</code> tương đương phân tích <code>n</code> thành <code>p · q</code>. Với n 2048 bit, chưa ai làm được.</p>
${py`
p, q, e = 61, 53, 17
n, phi = p * q, (p - 1) * (q - 1)       # n = 3233, phi = 3120
d = pow(e, -1, phi)                     # 2753
m = 65
c = pow(m, e, n)                        # 2790
print(c, pow(c, d, n))                  # 2790 65
`}
<p>Flag được đổi thành số bằng <code>bytes_to_long</code> (đọc bytes như một số big-endian), và đổi ngược bằng <code>long_to_bytes</code>.</p>

<h2 id="quy-trinh">Quy trình khi gặp bài RSA</h2>
<table>
<tr><th>Dấu hiệu</th><th>Tấn công</th></tr>
<tr><td>Cho sẵn <code>p, q</code> hoặc <code>φ</code></td><td>Tính <code>d</code>, giải mã thẳng</td></tr>
<tr><td><code>n</code> nhỏ (dưới ~256 bit), hoặc n có trên FactorDB</td><td>Phân tích n (FactorDB, yafu, sympy)</td></tr>
<tr><td><code>p</code> và <code>q</code> rất gần nhau</td><td>Phân tích Fermat</td></tr>
<tr><td><code>e = 3</code> (hoặc nhỏ) và thông điệp ngắn</td><td>Căn bậc e nguyên</td></tr>
<tr><td>Nhiều <code>n</code> khác nhau</td><td><code>gcd</code> từng cặp: chung thừa số?</td></tr>
<tr><td>Cùng <code>n</code>, cùng <code>m</code>, hai <code>e</code> khác nhau</td><td>Common modulus (Bézout)</td></tr>
<tr><td>Cùng <code>m</code>, <code>e = 3</code>, ba <code>n</code> khác nhau</td><td>Håstad broadcast (CRT + căn bậc 3)</td></tr>
<tr><td><code>e</code> rất lớn (gần bằng n)</td><td>Có thể d nhỏ → Wiener</td></tr>
</table>
<p>Công cụ thử tự động: <a href="https://github.com/RsaCtfTool/RsaCtfTool" target="_blank" rel="noopener">RsaCtfTool</a>. Tra phân tích: <a href="http://factordb.com/" target="_blank" rel="noopener">FactorDB</a>.</p>

<h2 id="fermat">Phân tích Fermat khi p ≈ q</h2>
<p>Viết <code>n = a² − b² = (a − b)(a + b)</code> với <code>a = (p + q)/2</code>, <code>b = (q − p)/2</code>. Nếu p, q gần nhau thì <code>a</code> chỉ lớn hơn <code>√n</code> một chút: bắt đầu từ <code>a = ⌈√n⌉</code>, tăng dần đến khi <code>a² − n</code> là số chính phương.</p>
${py`
from math import isqrt

def fermat(n):
    a = isqrt(n)
    if a * a < n:
        a += 1
    while True:
        b2 = a * a - n
        b = isqrt(b2)
        if b * b == b2:
            return a - b, a + b
        a += 1

print(fermat(5959))      # (59, 101)
`}

<h2 id="e-nho">Số mũ nhỏ: căn bậc e</h2>
<p>Với <code>e = 3</code> và <code>m³ &lt; n</code>, phép modulo không hề "quấn vòng": <code>c = m³</code> đúng theo nghĩa số nguyên. Lấy căn bậc ba nguyên của <code>c</code> là xong. Đây là lý do phải dùng padding (OAEP) để m luôn lớn.</p>
${py`
def iroot(x, k):
    lo, hi = 0, 1 << (x.bit_length() // k + 1)
    while lo < hi:                       # tìm kiếm nhị phân số lớn nhất r với r**k <= x
        mid = (lo + hi + 1) // 2
        if mid ** k <= x:
            lo = mid
        else:
            hi = mid - 1
    return lo
`}
<p><strong>Håstad broadcast:</strong> cùng <code>m</code> gửi cho 3 người với <code>e = 3</code> và <code>n₁, n₂, n₃</code> khác nhau. CRT ghép <code>c₁, c₂, c₃</code> thành <code>m³ mod n₁n₂n₃</code>; vì <code>m³ &lt; n₁n₂n₃</code> nên đó chính là <code>m³</code>, lấy căn bậc ba.</p>

<h2 id="gcd">Chung thừa số</h2>
<p>Hai khoá được sinh bằng bộ sinh số ngẫu nhiên yếu có thể dùng chung một số nguyên tố: <code>n₁ = p·q₁</code>, <code>n₂ = p·q₂</code>. Khi đó <code>gcd(n₁, n₂) = p</code>, tính trong tích tắc. Năm 2012, nhóm nghiên cứu của Lenstra quét hàng triệu khoá công khai trên Internet và phá được khoảng 0.2% bằng đúng cách này.</p>

<h2 id="common-modulus">Common modulus</h2>
<p>Cùng <code>m</code>, cùng <code>n</code>, mã hoá với hai số mũ <code>e₁, e₂</code> nguyên tố cùng nhau. Bézout cho <code>s·e₁ + t·e₂ = 1</code>, nên:</p>
${txt`
c₁ˢ · c₂ᵗ = m^(s·e₁) · m^(t·e₂) = m^(s·e₁ + t·e₂) = m   (mod n)
`}
<p>Một trong hai hệ số <code>s, t</code> âm; Python 3.8+ xử lý <code>pow(c, -k, n)</code> bằng nghịch đảo modulo.</p>

<h2 id="wiener">Wiener: d quá nhỏ</h2>
<p>Nếu <code>d &lt; n<sup>1/4</sup>/3</code>, phân số <code>k/d</code> xuất hiện trong khai triển <em>liên phân số</em> của <code>e/n</code>. Thử từng phân số hội tụ, kiểm tra xem có cho <code>φ(n)</code> hợp lệ không. Dấu hiệu nhận biết: <code>e</code> lớn bất thường, gần bằng <code>n</code>.</p>

<h2 id="ban-lam-viec">Bàn làm việc RSA</h2>
<div data-widget="python"><template>
from math import gcd, isqrt

def egcd(a, b):
    if b == 0:
        return a, 1, 0
    g, x, y = egcd(b, a % b)
    return g, y, x - (a // b) * y

def iroot(x, k):
    lo, hi = 0, 1 << (x.bit_length() // k + 1)
    while lo &lt; hi:
        mid = (lo + hi + 1) // 2
        if mid ** k &lt;= x:
            lo = mid
        else:
            hi = mid - 1
    return lo

def decrypt(c, p, q, e=65537):
    d = pow(e, -1, (p - 1) * (q - 1))
    return long_to_bytes(pow(c, d, p * q))

# Dán số liệu của thử thách vào đây
</template></div>

<h2 id="thu-thach">Thử thách</h2>
<div data-chal="cr-rsa1"></div>
<div data-chal="cr-rsa-fermat"></div>
<div data-chal="cr-rsa-e3"></div>
<div data-chal="cr-rsa-gcd"></div>
<div data-chal="cr-rsa-cm"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
<div data-quiz="2"></div>
`,
  quiz: [
    {
      q: "Biết <code>n</code>, <code>e</code> và <code>φ(n)</code>. Bạn làm được gì?",
      options: ["Không gì cả", "Tính d = e⁻¹ mod φ(n) và giải mã mọi bản mã", "Chỉ ký được, không giải mã được", "Chỉ biết độ dài khoá"],
      answer: 1,
      explain: "φ(n) là thứ duy nhất ngăn bạn tính d. Biết φ(n) còn cho phép tìm lại p, q bằng cách giải phương trình bậc hai.",
    },
    {
      q: "<code>e = 3</code>, flag 30 byte, <code>n</code> 2048 bit, không padding. Tấn công nhanh nhất?",
      options: ["Phân tích n", "Lấy căn bậc ba nguyên của c", "Wiener", "Common modulus"],
      answer: 1,
      explain: "m khoảng 240 bit, m³ khoảng 720 bit, nhỏ hơn n nhiều, nên c = m³ không bị modulo. Căn bậc ba nguyên cho m.",
    },
    {
      q: "Bạn có 50 khoá công khai RSA từ cùng một thiết bị IoT. Việc nên thử đầu tiên?",
      options: ["Brute force d", "Tính gcd từng cặp n", "Đoán p = q", "Gửi email xin khoá"],
      answer: 1,
      explain: "Thiết bị có nguồn ngẫu nhiên yếu thường sinh trùng số nguyên tố. gcd của hai n chung thừa số lộ ngay p.",
    },
  ],
  challenges: {
    "cr-rsa1": { title: "RSA nhập môn", pts: 75, diff: "easy", hash: CR_HASH["cr-rsa1"], body: `<p>Bạn được cho cả <code>p</code> và <code>q</code>.</p><div class="chal-data">p = ${CR.rsa1.p}\nq = ${CR.rsa1.q}\ne = ${CR.rsa1.e}\nc = ${CR.rsa1.c}</div>`, hints: ["<code>d = pow(e, -1, (p-1)*(q-1))</code>", "<code>long_to_bytes(pow(c, d, p*q))</code>, hoặc gọi <code>decrypt(c, p, q)</code> trong bàn làm việc."] },
    "cr-rsa-fermat": { title: "Hai người hàng xóm", pts: 175, diff: "med", hash: CR_HASH["cr-rsa-fermat"], body: `<p>n 1024 bit, không có trên FactorDB. Lập trình viên sinh <code>q</code> bằng cách tìm số nguyên tố tiếp theo sau <code>p + một_số_nhỏ</code>.</p><div class="chal-data">n = ${CR.rsa_fermat.n}\ne = ${CR.rsa_fermat.e}\nc = ${CR.rsa_fermat.c}</div>`, hints: ["p và q rất gần nhau → phân tích Fermat.", "Dùng hàm <code>fermat(n)</code> trong bài; vòng lặp chỉ chạy vài lần."] },
    "cr-rsa-e3": { title: "Số mũ ba", pts: 150, diff: "med", hash: CR_HASH["cr-rsa-e3"], body: `<p>Khoá 2048 bit, <code>e = 3</code>, không padding.</p><div class="chal-data">n = ${CR.rsa_e3.n}\ne = 3\nc = ${CR.rsa_e3.c}</div>`, hints: ["So sánh độ dài: <code>c.bit_length()</code> và <code>n.bit_length()</code>. c nhỏ hơn nhiều so với n.", "<code>long_to_bytes(iroot(c, 3))</code>"] },
    "cr-rsa-gcd": { title: "Bộ sinh số lười", pts: 175, diff: "med", hash: CR_HASH["cr-rsa-gcd"], body: `<p>Hai khoá công khai từ cùng một thiết bị. Flag được mã hoá bằng khoá thứ nhất.</p><div class="chal-data">n1 = ${CR.rsa_gcd.n1}\nn2 = ${CR.rsa_gcd.n2}\ne  = ${CR.rsa_gcd.e}\nc1 = ${CR.rsa_gcd.c1}</div>`, hints: ["<code>p = gcd(n1, n2)</code>", "<code>q = n1 // p</code>, rồi giải mã như bình thường."] },
    "cr-rsa-cm": { title: "Cùng n khác e", pts: 250, diff: "hard", hash: CR_HASH["cr-rsa-cm"], body: `<p>Cùng một flag được gửi cho hai người dùng chung <code>n</code> nhưng khác số mũ.</p><div class="chal-data">n  = ${CR.rsa_cm.n}\ne1 = ${CR.rsa_cm.e1}\ne2 = ${CR.rsa_cm.e2}\nc1 = ${CR.rsa_cm.c1}\nc2 = ${CR.rsa_cm.c2}</div>`, hints: ["<code>gcd(e1, e2) = 1</code>, nên có <code>s·e1 + t·e2 = 1</code> từ <code>egcd</code>.", "<code>m = pow(c1, s, n) * pow(c2, t, n) % n</code> (Python tự xử lý số mũ âm)."] },
  },
});
