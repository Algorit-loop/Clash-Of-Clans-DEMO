/* Track: Reverse Engineering */

/* ------------------------------------------------------------------ 1 */
lesson({
  id: "rev-intro",
  track: "reverse",
  order: 1,
  level: 1,
  title: "Nhập môn dịch ngược",
  short: "Chương trình được tạo ra thế nào, và những công cụ đầu tiên để mổ xẻ nó",
  time: "40 phút",
  html: `
<h2 id="la-gi">Dịch ngược là gì</h2>
<p>Bài reverse đưa cho bạn một chương trình <strong>không kèm mã nguồn</strong>. Thường nó hỏi mật khẩu và chỉ in flag khi bạn nhập đúng. Nhiệm vụ của bạn: hiểu chương trình kiểm tra input thế nào, rồi suy ngược ra input đúng. Có khi flag nằm ngay trong chương trình, chỉ bị giấu đi.</p>

<h2 id="bien-dich">Từ mã nguồn đến file thực thi</h2>
<p>Muốn dịch ngược thì phải biết chương trình được "dịch xuôi" thế nào. Với C, trình biên dịch <code>gcc</code> đi qua 4 bước:</p>
<ol class="steps-v">
<li><strong>Tiền xử lý</strong>: chèn nội dung <code>#include</code>, thay <code>#define</code>. Ra file <code>.i</code>.</li>
<li><strong>Biên dịch</strong>: C → hợp ngữ (assembly), file <code>.s</code>. Tên biến cục bộ, kiểu dữ liệu, comment biến mất ở bước này.</li>
<li><strong>Hợp dịch</strong>: assembly → mã máy (các byte CPU chạy được), file object <code>.o</code>.</li>
<li><strong>Liên kết</strong>: ghép các file <code>.o</code> với thư viện (libc) thành file thực thi: <strong>ELF</strong> trên Linux, <strong>PE</strong> (.exe) trên Windows, <strong>Mach-O</strong> trên macOS.</li>
</ol>
${c`
// hello.c
int main() {
    int x = 10;
    return x * 7 + 3;
}
`}
${sh`
$ gcc -O0 -o hello hello.c
$ objdump -d -M intel hello | grep -A8 "<main>:"
0000000000001129 <main>:
    1129:	55                   	push   rbp
    112a:	48 89 e5             	mov    rbp,rsp
    112d:	c7 45 fc 0a 00 00 00 	mov    DWORD PTR [rbp-0x4],0xa
`}
<p>Cột giữa là <strong>mã máy</strong> (byte thật trong file), cột phải là <strong>assembly</strong> tương ứng. Dịch ngược là đi theo chiều ngược lại: byte → assembly (<em>disassemble</em>) → mã giống C (<em>decompile</em>). Bước cuối không bao giờ khôi phục đúng 100% mã gốc, vì thông tin đã mất ở bước 2.</p>
<div class="callout tip"><b>Stripped hay không</b>
<p>File "<code>not stripped</code>" còn giữ bảng tên hàm (<code>main</code>, <code>check_password</code>…), dễ đọc hơn hẳn. File "<code>stripped</code>" đã xoá bảng này, bạn chỉ thấy <code>FUN_00101189</code>.</p></div>

<h2 id="tinh-dong">Phân tích tĩnh và động</h2>
<div class="grid-2">
<div class="card"><h4>Tĩnh (static)</h4><p>Đọc chương trình <strong>không chạy</strong> nó: <code>file</code>, <code>strings</code>, <code>objdump</code>, Ghidra, IDA. An toàn, thấy được toàn bộ code, nhưng phải tự suy luận giá trị lúc chạy.</p></div>
<div class="card"><h4>Động (dynamic)</h4><p><strong>Chạy</strong> chương trình và quan sát: <code>ltrace</code>, <code>strace</code>, <code>gdb</code>. Thấy giá trị thật trong bộ nhớ, nhưng chỉ thấy nhánh code được chạy tới. Với mã độc thì chỉ chạy trong máy ảo.</p></div>
</div>
<p>Người chơi giỏi kết hợp cả hai: đọc tĩnh để biết <em>chỗ nào</em> quan trọng, rồi chạy động để xem <em>giá trị gì</em> ở chỗ đó.</p>

<h2 id="cong-cu">Bộ công cụ 5 phút đầu</h2>
<table>
<tr><th>Lệnh</th><th>Cho bạn biết</th></tr>
<tr><td><code>file prog</code></td><td>Định dạng, kiến trúc (x86-64, ARM), 32/64 bit, stripped hay không</td></tr>
<tr><td><code>strings prog</code></td><td>Mọi chuỗi ký tự in được: thông báo, đường dẫn, đôi khi cả mật khẩu</td></tr>
<tr><td><code>readelf -h</code> / <code>-S</code> / <code>-s</code></td><td>Header, các section (.text là code, .rodata là hằng chuỗi), bảng symbol</td></tr>
<tr><td><code>objdump -d -M intel</code></td><td>Disassembly theo cú pháp Intel (dễ đọc hơn AT&amp;T)</td></tr>
<tr><td><code>ltrace ./prog</code></td><td>Mọi lời gọi <strong>hàm thư viện</strong> kèm tham số: <code>strcmp</code>, <code>strlen</code>, <code>printf</code>…</td></tr>
<tr><td><code>strace ./prog</code></td><td>Mọi lời gọi <strong>hệ thống</strong> (syscall): <code>open</code>, <code>read</code>, <code>write</code>, <code>ptrace</code>…</td></tr>
</table>
${sh`
$ strings -n 6 prog | less        # chỉ chuỗi dài từ 6 ký tự
$ strings prog | grep -i -E "flag|pass|key|ctf"
$ ltrace ./prog AAAA 2>&1 | grep cmp
strcmp("AAAA", "mat_khau_that")                = -12
`}
<div class="callout warn"><b>Tại sao ltrace lộ mật khẩu</b>
<p><code>strcmp(a, b)</code> nhận <em>cả hai</em> chuỗi làm tham số. ltrace in tham số của mọi hàm thư viện, nên chuỗi bí mật hiện ra ngay. Người ra đề biết điều này nên bài khó hơn sẽ tự viết hàm so sánh (ltrace không thấy được), hoặc biến đổi input trước khi so.</p></div>

<h2 id="thuc-hanh">Thực hành</h2>
<p>Terminal dưới đây có ba chương trình và các lệnh <code>ltrace</code>, <code>strace</code>, <code>objdump -d</code>, <code>readelf -h</code>. Bắt đầu với <code>file crackme</code> và <code>strings crackme</code>.</p>
<div data-widget="shell" data-fs="rev-intro" data-height="400"></div>
<div data-chal="rev-intro-1"></div>
<div data-chal="rev-intro-2"></div>
<div data-chal="rev-intro-3"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Chương trình so sánh input bằng một hàm tự viết <code>my_cmp</code> (không phải hàm libc). Công cụ nào <strong>không</strong> giúp bạn thấy chuỗi đang được so sánh?",
      options: ["gdb, đặt breakpoint ở my_cmp", "ltrace", "Ghidra, đọc code của my_cmp", "Đọc disassembly bằng objdump"],
      answer: 1,
      explain: "ltrace chỉ chặn lời gọi tới thư viện dùng chung (libc…). Hàm nằm sẵn trong chương trình thì ltrace không thấy.",
    },
    {
      q: "Bước nào của quá trình biên dịch làm mất tên biến cục bộ và comment?",
      options: ["Tiền xử lý", "Biên dịch C → assembly", "Liên kết", "Chạy chương trình"],
      answer: 1,
      explain: "Assembly chỉ còn thanh ghi và ô nhớ như <code>[rbp-0x4]</code>. Vì vậy decompiler phải tự đặt tên như <code>local_c</code>, <code>iVar1</code>.",
    },
  ],
  challenges: {
    "rev-intro-1": {
      title: "CrackMe đầu tiên", pts: 50, diff: "easy",
      hash: "a277ab00f0255669d321a78e0710028eb15b6aa8b2610947bd23d60e751b5425",
      body: "<p>Chạy <code>./crackme</code>. Nó hỏi mật khẩu. Đừng đoán: chuỗi nào trong file trông giống mật khẩu?</p>",
      hints: ["<code>strings crackme</code>. Chú ý các chuỗi nằm gần <code>Password:</code>.", "Mật khẩu là <code>s1mpl3_p4ss</code>. Flag thì bị mã hoá trong file nên strings không thấy, phải chạy chương trình."],
    },
    "rev-intro-2": {
      title: "Két sắt", pts: 75, diff: "easy",
      hash: "18a612056c25a2f419863117ff9155a6631bae93c3397f88321444fe1d28e4e4",
      body: "<p><code>./vault &lt;mật_khẩu&gt;</code>. Lần này mật khẩu được ghép lúc chạy nên <code>strings</code> chỉ thấy từng mảnh. Hãy xem chương trình gọi hàm thư viện nào.</p>",
      hints: ["<code>ltrace ./vault test</code>", "Dòng <code>strcmp(...)</code> in cả input của bạn lẫn chuỗi đúng."],
    },
    "rev-intro-3": {
      title: "Đọc assembly", pts: 75, diff: "easy",
      hash: "68d3a295bb765c617dad919c25ebc79697348150c8611cda550773bb83174636",
      body: "<p><code>./answer</code> không in gì, nhưng <code>main</code> trả về một số. Theo quy ước, giá trị trả về nằm trong thanh ghi <code>eax</code>. Đọc <code>objdump -d answer</code> và tính số đó. Flag: <code>zCTF{số_thập_phân}</code>.</p>",
      hints: ["<code>0xa</code> = 10. Lệnh <code>imul eax,eax,0x7</code> nghĩa là eax = eax × 7.", "10 × 7 + 3."],
    },
  },
});

/* ------------------------------------------------------------------ 2 */
lesson({
  id: "rev-asm",
  track: "reverse",
  order: 2,
  level: 2,
  title: "Assembly x86-64",
  short: "Thanh ghi, lệnh, cờ, stack và quy ước gọi hàm, có trình mô phỏng để chạy từng lệnh",
  time: "60 phút",
  html: `
<h2 id="vi-sao">Vì sao phải đọc assembly</h2>
<p>Decompiler đôi khi sai, hoặc code bị làm rối khiến decompile vô dụng. Khi đó bạn phải đọc thẳng assembly. Tin tốt: trong CTF chỉ khoảng 20 lệnh xuất hiện thường xuyên. Bài này dùng <strong>cú pháp Intel</strong> (<code>lệnh đích, nguồn</code>), giống Ghidra, IDA và <code>objdump -M intel</code>.</p>
<div class="callout idea"><b>Intel và AT&amp;T</b>
<p>Mặc định <code>objdump</code> và <code>gdb</code> dùng AT&amp;T: <code>movl $0xa,-0x4(%rbp)</code> (nguồn trước, đích sau, có <code>%</code> và <code>$</code>). Cùng lệnh đó ở Intel: <code>mov DWORD PTR [rbp-0x4], 0xa</code>. Trong gdb gõ <code>set disassembly-flavor intel</code>.</p></div>

<h2 id="thanh-ghi">Thanh ghi</h2>
<p>Thanh ghi là các ô nhớ siêu nhanh trong CPU. x86-64 có 16 thanh ghi đa dụng 64 bit, và có thể truy cập phần thấp của chúng:</p>
${txt`
 63                              31              15       7      0
 ┌───────────────────────────────┬───────────────┬────────┬──────┐
 │                              rax (64 bit)                     │
 │                               │       eax (32 bit)            │
 │                               │               │  ax (16 bit)  │
 │                               │               │   ah   │  al  │
 └───────────────────────────────┴───────────────┴────────┴──────┘
`}
<table>
<tr><th>Thanh ghi</th><th>Vai trò thường gặp</th></tr>
<tr><td><code>rax</code></td><td>Giá trị trả về của hàm</td></tr>
<tr><td><code>rdi, rsi, rdx, rcx, r8, r9</code></td><td>Tham số thứ 1 → 6 của hàm (Linux, System V ABI)</td></tr>
<tr><td><code>rsp</code></td><td>Đỉnh stack (stack pointer)</td></tr>
<tr><td><code>rbp</code></td><td>Đáy stack frame hiện tại, biến cục bộ hay nằm ở <code>[rbp-0x..]</code></td></tr>
<tr><td><code>rip</code></td><td>Địa chỉ lệnh sắp chạy (không ghi trực tiếp được)</td></tr>
<tr><td><code>rbx, r12–r15</code></td><td>"Callee-saved": hàm được gọi phải giữ nguyên giá trị</td></tr>
</table>
<div class="callout warn"><b>Bẫy hay gặp</b>
<p>Ghi vào thanh ghi 32 bit (<code>mov eax, 1</code>) sẽ <strong>xoá 32 bit cao</strong> của rax. Ghi vào 8 hoặc 16 bit (<code>mov al, 1</code>) thì giữ nguyên phần còn lại. Vì vậy <code>xor eax, eax</code> là cách đặt cả rax về 0 ngắn nhất.</p></div>

<h2 id="lenh">Các lệnh chính</h2>
<table>
<tr><th>Lệnh</th><th>Ý nghĩa</th><th>Ghi chú</th></tr>
<tr><td><code>mov a, b</code></td><td>a = b</td><td><code>[...]</code> là đọc/ghi bộ nhớ tại địa chỉ đó</td></tr>
<tr><td><code>lea a, [x+y*4+8]</code></td><td>a = x+y*4+8</td><td>Chỉ tính địa chỉ, <strong>không</strong> đọc bộ nhớ. Hay bị dùng để làm toán nhanh</td></tr>
<tr><td><code>add / sub a, b</code></td><td>a += b / a -= b</td><td>Cập nhật cờ</td></tr>
<tr><td><code>imul a, b[, c]</code></td><td>a = a*b hoặc a = b*c</td><td>Nhân có dấu</td></tr>
<tr><td><code>and / or / xor a, b</code></td><td>Phép bit</td><td><code>xor a, a</code> = đặt về 0</td></tr>
<tr><td><code>shl / shr / sar a, n</code></td><td>Dịch bit</td><td><code>shl</code> 1 bit = nhân 2; <code>sar</code> giữ dấu</td></tr>
<tr><td><code>inc / dec / neg / not</code></td><td>+1, -1, đổi dấu, đảo bit</td><td></td></tr>
<tr><td><code>cmp a, b</code></td><td>Tính a - b, chỉ đặt cờ</td><td>Không lưu kết quả</td></tr>
<tr><td><code>test a, b</code></td><td>Tính a &amp; b, chỉ đặt cờ</td><td><code>test eax, eax</code> = kiểm tra eax == 0</td></tr>
<tr><td><code>jmp nhãn</code></td><td>Nhảy vô điều kiện</td><td></td></tr>
<tr><td><code>je/jz, jne/jnz, jg, jl, ja, jb…</code></td><td>Nhảy có điều kiện theo cờ</td><td>Xem bảng dưới</td></tr>
<tr><td><code>push x / pop x</code></td><td>rsp -= 8, [rsp] = x / x = [rsp], rsp += 8</td><td></td></tr>
<tr><td><code>call f / ret</code></td><td>push địa chỉ lệnh kế + nhảy tới f / pop rip</td><td></td></tr>
</table>

<h2 id="co">Cờ và nhảy có điều kiện</h2>
<p>Sau <code>cmp a, b</code> (tính a − b), CPU đặt các cờ trong thanh ghi RFLAGS:</p>
<ul>
<li><strong>ZF</strong> (zero): kết quả bằng 0, tức a == b.</li>
<li><strong>SF</strong> (sign): bit cao nhất của kết quả là 1 (âm nếu hiểu là số có dấu).</li>
<li><strong>CF</strong> (carry): phép trừ "mượn", tức a &lt; b nếu coi là số <em>không dấu</em>.</li>
<li><strong>OF</strong> (overflow): tràn số có dấu.</li>
</ul>
<table>
<tr><th>Lệnh</th><th>Nhảy khi (sau cmp a, b)</th><th>Điều kiện cờ</th></tr>
<tr><td><code>je / jz</code></td><td>a == b</td><td>ZF = 1</td></tr>
<tr><td><code>jne / jnz</code></td><td>a != b</td><td>ZF = 0</td></tr>
<tr><td><code>jg / jl</code></td><td>a &gt; b / a &lt; b (có dấu)</td><td>ZF=0 và SF=OF / SF≠OF</td></tr>
<tr><td><code>jge / jle</code></td><td>a ≥ b / a ≤ b (có dấu)</td><td>SF=OF / ZF=1 hoặc SF≠OF</td></tr>
<tr><td><code>ja / jb</code></td><td>a &gt; b / a &lt; b (không dấu)</td><td>CF=0 và ZF=0 / CF=1</td></tr>
</table>
<div class="callout tip"><b>Mẹo nhớ</b>
<p><strong>g</strong>reater/<strong>l</strong>ess dùng cho số có dấu (<code>int</code>), <strong>a</strong>bove/<strong>b</strong>elow cho số không dấu (<code>unsigned</code>, con trỏ). Nhìn lệnh nhảy là đoán được kiểu biến trong mã gốc.</p></div>

<h2 id="stack">Stack và stack frame</h2>
<p>Stack mọc từ địa chỉ cao xuống thấp. Mở đầu một hàm (<em>prologue</em>) và kết thúc (<em>epilogue</em>) gần như luôn có dạng:</p>
${asm`
push rbp            ; lưu rbp của hàm gọi
mov  rbp, rsp       ; rbp = đáy frame mới
sub  rsp, 0x20      ; dành 0x20 byte cho biến cục bộ
...                 ; biến cục bộ: [rbp-0x4], [rbp-0x8]...
leave               ; = mov rsp, rbp ; pop rbp
ret                 ; pop rip -> quay về hàm gọi
`}
${txt`
địa chỉ cao   ┌──────────────────────┐
              │ địa chỉ trả về       │  ← do call đẩy vào
              │ rbp cũ               │  ← push rbp
     rbp  →   ├──────────────────────┤
              │ int x   [rbp-0x4]    │
              │ char buf[16] ...     │
     rsp  →   └──────────────────────┘
địa chỉ thấp
`}

<h2 id="abi">Quy ước gọi hàm System V (Linux x86-64)</h2>
<p>Gọi <code>check(a, b, c)</code> thì trước <code>call</code>, chương trình đặt <code>rdi = a</code>, <code>rsi = b</code>, <code>rdx = c</code>. Tham số thứ 7 trở đi đẩy lên stack. Kết quả trả về trong <code>rax</code>. Windows x64 thì khác: <code>rcx, rdx, r8, r9</code>.</p>
${asm`
mov  esi, 0x10              ; tham số 2 = 16
lea  rdi, [rbp-0x30]        ; tham số 1 = địa chỉ buffer
call fgets@plt              ; fgets(buf, 16, ...)
...
lea  rsi, [rip+0xe3d]       ; tham số 2 = địa chỉ chuỗi hằng "secret"
lea  rdi, [rbp-0x30]        ; tham số 1 = buf
call strcmp@plt
test eax, eax               ; strcmp trả về 0 nếu giống nhau
jne  wrong                  ; khác 0 -> sai mật khẩu
`}
<p>Đoạn cuối (<code>call strcmp</code> → <code>test eax, eax</code> → <code>jne</code>) xuất hiện trong gần như mọi crackme. Thấy nó là biết ngay chỗ kiểm tra mật khẩu.</p>

<h2 id="mo-phong">Trình mô phỏng</h2>
<p>Bấm <strong>Step</strong> để chạy từng lệnh, theo dõi thanh ghi đổi màu, cờ và stack. Tự đoán kết quả trước rồi mới chạy để kiểm tra. <strong>Sửa code</strong> để thử nghiệm.</p>
<div data-widget="asmsim" data-prog="asm-basic"></div>
<div data-chal="rev-asm-1"></div>
<div data-widget="asmsim" data-prog="asm-loop"></div>
<div data-chal="rev-asm-2"></div>
<div data-widget="asmsim" data-prog="asm-check"></div>
<div data-chal="rev-asm-3"></div>

<h2 id="san-choi">Sân chơi</h2>
<p>Thử tự viết: tính giai thừa bằng vòng lặp, hoặc viết hàm nhận tham số trong <code>rdi</code> rồi <code>call</code> nó.</p>
<div data-widget="asmsim" data-prog="asm-free"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
<div data-quiz="2"></div>
`,
  quiz: [
    {
      q: "Sau <code>mov rax, 0xffffffffffffffff</code> rồi <code>mov eax, 1</code>, rax bằng bao nhiêu?",
      options: ["0xffffffff00000001", "0x0000000000000001", "0xffffffffffffff01", "0xffffffffffffffff"],
      answer: 1,
      explain: "Ghi vào thanh ghi 32 bit luôn xoá 32 bit cao. Nếu là <code>mov al, 1</code> thì kết quả mới là 0xffffffffffffff01.",
    },
    {
      q: "Trong <code>cmp eax, 5</code> rồi <code>ja label</code>, biến eax trong mã C nhiều khả năng có kiểu gì?",
      options: ["int (có dấu)", "unsigned int (không dấu)", "char*", "float"],
      answer: 1,
      explain: "<code>ja</code>/<code>jb</code> so sánh không dấu (dựa trên CF). Số có dấu sẽ dùng <code>jg</code>/<code>jl</code>.",
    },
    {
      q: "Trên Linux x86-64, ngay trước <code>call strcmp</code>, chuỗi thứ hai được truyền qua thanh ghi nào?",
      options: ["rdi", "rsi", "rax", "rsp"],
      answer: 1,
      explain: "Thứ tự tham số: rdi, rsi, rdx, rcx, r8, r9. Trong gdb, <code>x/s $rsi</code> tại breakpoint strcmp sẽ in chuỗi thứ hai.",
    },
  ],
  challenges: {
    "rev-asm-1": {
      title: "Số học thanh ghi", pts: 50, diff: "easy",
      hash: "5395bad3cf5300206be77878b3984ebd8328dae63f21b105f5e820e40e30b366",
      body: "<p>Chương trình 1 (ở trên): giá trị cuối của <code>rax</code> là bao nhiêu? Flag: <code>zCTF{0x..}</code>, hex viết thường, không có số 0 thừa ở đầu (ví dụ <code>zCTF{0x2a}</code>).</p>",
      hints: ["0x10 + 0x22 = 0x32. Dịch trái 2 bit = nhân 4.", "0xc8 XOR 0xff = 0x37."],
    },
    "rev-asm-2": {
      title: "Vòng lặp", pts: 75, diff: "easy",
      hash: "b42a2a2a999cace76cd7ec29445443ee2f82b44830dac2c867caba403e3bc35b",
      body: "<p>Chương trình 2: giá trị cuối của <code>eax</code> (thập phân)? Flag: <code>zCTF{số}</code>.</p>",
      hints: ["Vòng lặp cộng ecx = 1, 2, …, 10 vào eax.", "<code>lea eax, [rax+rax*2]</code> = eax × 3. Tổng 1..10 là 55."],
    },
    "rev-asm-3": {
      title: "Tìm tham số", pts: 150, diff: "med",
      hash: "d2f9c4d9bf1a3ffcb351281ff24642bb2a9be1234f3da3ce11cd4a7e6460b9b7",
      body: "<p>Chương trình 3: nhập giá trị ban đầu của <code>rdi</code> sao cho chương trình tới nhãn <code>win</code>. Bấm Reset sau khi nhập, rồi Run. Trình mô phỏng sẽ in flag.</p>",
      hints: ["Đi ngược từ <code>cmp rax, 0x5442</code>: trước đó rax đã được cộng 0x100 và XOR 0x1337.", "rdi = (0x5442 − 0x100) XOR 0x1337. Phép ngược của XOR là chính nó. Nhập dạng <code>0x...</code>."],
    },
  },
});

/* ------------------------------------------------------------------ 3 */
lesson({
  id: "rev-decompile",
  track: "reverse",
  order: 3,
  level: 2,
  title: "Đọc mã decompile",
  short: "Ghidra/IDA, nhận diện cấu trúc điều khiển và viết script đảo ngược thuật toán kiểm tra",
  time: "55 phút",
  html: `
<h2 id="ghidra">Ghidra trong 5 phút</h2>
<p><strong>Ghidra</strong> (miễn phí, của NSA) và <strong>IDA</strong> biến mã máy thành mã giống C. Quy trình cơ bản với Ghidra:</p>
<ol class="steps-v">
<li>File → New Project → Import File, chọn chương trình. Đồng ý chạy <em>Auto Analyze</em>.</li>
<li>Cửa sổ <strong>Symbol Tree</strong> → Functions → tìm <code>main</code>. File stripped thì tìm <code>entry</code>, tham số đầu của <code>__libc_start_main</code> chính là main.</li>
<li><strong>Window → Defined Strings</strong>: tìm chuỗi như "Wrong" hoặc "Correct", double-click rồi xem <em>XREF</em> để nhảy tới hàm dùng chuỗi đó. Đây là cách nhanh nhất tìm hàm kiểm tra.</li>
<li>Trong cửa sổ Decompile: bấm <kbd>L</kbd> để đổi tên biến, <kbd>Ctrl</kbd>+<kbd>L</kbd> để đổi kiểu (ví dụ thành <code>char[32]</code>), <kbd>;</kbd> để ghi chú. Đặt tên dần dần là cách hiểu code.</li>
</ol>
<p>Không muốn cài: <a href="https://dogbolt.org/" target="_blank" rel="noopener">dogbolt.org</a> chạy cùng lúc Ghidra, Hex-Rays, Binary Ninja… trên file bạn tải lên.</p>

<h2 id="nhan-dien">Nhận diện cấu trúc</h2>
<p>Decompiler đặt tên kiểu <code>local_28</code> (biến ở <code>[rbp-0x28]</code>), <code>iVar1</code>, <code>param_1</code>. Việc của bạn là nhận ra khuôn mẫu:</p>
<div class="grid-2">
<div class="card"><h4>Vòng lặp for</h4><p>Biến đếm khởi tạo 0, so với giới hạn rồi nhảy ngược lên. Trong Ghidra thường hiện thành <code>for (local_c = 0; local_c &lt; 0x20; local_c = local_c + 1)</code>.</p></div>
<div class="card"><h4>Truy cập mảng</h4><p><code>*(byte *)(param_1 + local_c)</code> chính là <code>input[i]</code>. Mảng int: <code>*(int *)(arr + i * 4)</code>.</p></div>
<div class="card"><h4>switch</h4><p>Bảng nhảy (<em>jump table</em>): <code>jmp qword ptr [rax*8 + table]</code>. Ghidra thường tự dựng lại thành switch.</p></div>
<div class="card"><h4>Chuỗi trên stack</h4><p>Nhiều lệnh <code>mov</code> hằng số liên tiếp, kiểu <code>local_38 = 0x67616c66</code>. Đọc little-endian: 66 6c 61 67 = "flag".</p></div>
</div>
${asm`
; hằng số 8 byte bị chèn thẳng vào code
mov  rax, 0x7b4654437a        ; ghép ngược từng byte: 7a 43 54 46 7b = "zCTF{"
mov  QWORD PTR [rbp-0x30], rax
`}
<div class="callout tip"><b>Hằng số "ma thuật"</b>
<p>Google các hằng số lạ. <code>0x67452301</code> là MD5/SHA-1, <code>0x9e3779b9</code> là TEA, bảng 256 byte bắt đầu bằng <code>63 7c 77 7b</code> là S-box của AES. Plugin <strong>FindCrypt</strong> của Ghidra tự làm việc này.</p></div>

<h2 id="dao-nguoc">Đảo ngược thuật toán kiểm tra</h2>
<p>Hầu hết hàm check có dạng: biến đổi từng ký tự input rồi so với một mảng hằng <code>enc[]</code>. Đừng đoán input. Hãy viết phép biến đổi <strong>ngược</strong> và áp lên <code>enc</code>:</p>
<table>
<tr><th>Trong chương trình</th><th>Phép ngược</th></tr>
<tr><td><code>x ^ k</code></td><td><code>e ^ k</code> (XOR tự đảo ngược)</td></tr>
<tr><td><code>(x + k) &amp; 0xff</code></td><td><code>(e - k) &amp; 0xff</code></td></tr>
<tr><td><code>x * k mod 256</code> (k lẻ)</td><td><code>e * pow(k, -1, 256) % 256</code></td></tr>
<tr><td>Xoay trái <code>(x &lt;&lt; n | x &gt;&gt; (8-n)) &amp; 0xff</code></td><td>Xoay phải n bit</td></tr>
<tr><td><code>out[perm[i]] = in[i]</code></td><td><code>in[i] = out[perm[i]]</code></td></tr>
<tr><td>Phụ thuộc vào ký tự trước (<code>x[i] ^ x[i-1]</code>)</td><td>Giải lần lượt từ đầu, dùng kết quả vừa tìm</td></tr>
</table>
<div class="callout warn"><b>Thứ tự phép toán</b>
<p>Phép ngược phải làm theo thứ tự <strong>đảo lại</strong>: nếu chương trình làm XOR rồi cộng, thì bạn trừ trước rồi mới XOR. Cũng nhớ <code>&amp; 0xff</code> vì ký tự chỉ có 1 byte.</p></div>
<p>Khi phép biến đổi quá rối để đảo bằng tay, có thể brute-force từng ký tự (mỗi vị trí chỉ 95 khả năng in được) hoặc dùng công cụ giải ràng buộc <strong>z3</strong> / <strong>angr</strong>.</p>

<h2 id="thuc-hanh">Thực hành</h2>
<p>Mỗi bài là đoạn code Ghidra xuất ra (đã dọn gọn). Viết script giải trong ô Python, bấm Chạy.</p>
<div data-chal="rev-dc-1"></div>
<div data-chal="rev-dc-2"></div>
<div data-chal="rev-dc-3"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Ghidra hiện <code>local_38 = 0x7265746e65</code>. Chuỗi trong bộ nhớ là gì?",
      options: ["\"rtene\"", "\"enter\"", "\"retne\"", "Không phải chuỗi"],
      answer: 1,
      explain: "x86 là little-endian: byte thấp nằm trước. Các byte trong bộ nhớ là 65 6e 74 65 72 = \"enter\".",
    },
    {
      q: "Hàm check làm <code>enc[i] = ((in[i] ^ 0x11) + 3) &amp; 0xff</code>. Để tìm in[i] từ enc[i], cách nào đúng?",
      options: ["((enc[i] ^ 0x11) - 3) &amp; 0xff", "((enc[i] - 3) &amp; 0xff) ^ 0x11", "(enc[i] + 3) ^ 0x11", "enc[i] ^ 0x14"],
      answer: 1,
      explain: "Làm ngược thứ tự: bỏ phép cộng trước (trừ 3), rồi mới bỏ XOR.",
    },
  ],
  challenges: {
    "rev-dc-1": {
      title: "XOR và cộng chỉ số", pts: 100, diff: "easy",
      hash: "f7a3f2fee2edf5d565a4fd02916523291d7de0e03819399389772b3cd211776a",
      body: `${c`
undefined8 check(char *param_1)
{
  size_t sVar1;
  int local_c;

  sVar1 = strlen(param_1);
  if (sVar1 != 0x1d) return 0;
  for (local_c = 0; local_c < 0x1d; local_c = local_c + 1) {
    if ((byte)(((byte)param_1[local_c] ^ 0x5a) + (char)local_c) != enc[local_c])
      return 0;
  }
  return 1;
}
// enc = {32, 26, 16, 31, 37, 67, 111, 64, 114, 64, 52, 118, 66, 118, 19,
//        55, 122, 68, 23, 81, 130, 127, 27, 75, 85, 72, 132, 84, 67}
`}<div data-widget="python"><template>enc = [32, 26, 16, 31, 37, 67, 111, 64, 114, 64, 52, 118, 66, 118, 19,
       55, 122, 68, 23, 81, 130, 127, 27, 75, 85, 72, 132, 84, 67]

flag = ""
for i, e in enumerate(enc):
    # TODO: chương trình làm (c ^ 0x5a) + i. Hãy làm ngược lại.
    c = e
    flag += chr(c)
print(flag)
</template></div>`,
      hints: ["Ngược thứ tự: trừ i trước, rồi XOR 0x5a.", "<code>c = ((e - i) &amp; 0xff) ^ 0x5a</code>"],
    },
    "rev-dc-2": {
      title: "Hoán vị", pts: 125, diff: "med",
      hash: "a884b7af7e50df36f45c20f37968c91fb9a062ee02a33d11d015b083b73d5f63",
      body: `${c`
int check(char *input)
{
  char out[21];
  int i;

  if (strlen(input) != 20) return 0;
  for (i = 0; i < 20; i = i + 1) {
    out[perm[i]] = input[i];
  }
  out[20] = '\0';
  return strcmp(out, "__1401h{cv}TshnC_zF0") == 0;
}
// perm = {17, 15, 11, 18, 7, 6, 19, 3, 14, 0, 9, 5, 16, 8, 13, 2, 1, 12, 4, 10}
`}<div data-widget="python"><template>perm = [17, 15, 11, 18, 7, 6, 19, 3, 14, 0, 9, 5, 16, 8, 13, 2, 1, 12, 4, 10]
target = "__1401h{cv}TshnC_zF0"

# Ký tự input[i] được đặt vào vị trí perm[i] của out.
inp = ["?"] * 20
# TODO
print("".join(inp))
</template></div>`,
      hints: ["out[perm[i]] = input[i], và out phải bằng target. Vậy input[i] = target[?]", "<code>inp[i] = target[perm[i]]</code>"],
    },
    "rev-dc-3": {
      title: "Xoay bit", pts: 175, diff: "hard",
      hash: "a7b54181770b9246b0aa70b52e5471aaba1368b828732fca44b34ca9fe91661e",
      body: `${c`
bool check(byte *param_1)
{
  byte bVar1;
  int i;
  char key[4] = "R3V!";

  for (i = 0; i < 0x15; i = i + 1) {
    bVar1 = param_1[i];
    if ((byte)((bVar1 << 3 | bVar1 >> 5) ^ key[i & 3]) != enc[i]) return false;
  }
  return true;
}
// enc = {129, 41, 244, 19, 137, 32, 223, 130, 168, 240, 215, 128, 153, 201,
//        229, 128, 168, 240, 215, 178, 185}
`}<div data-widget="python"><template>enc = [129, 41, 244, 19, 137, 32, 223, 130, 168, 240, 215, 128, 153, 201,
       229, 128, 168, 240, 215, 178, 185]
key = b"R3V!"

def ror(x, n):
    # TODO: xoay phải n bit trong 8 bit
    return x

print("".join(chr(ror(e ^ key[i % 4], 3)) for i, e in enumerate(enc)))
</template></div>`,
      hints: ["<code>(b &lt;&lt; 3 | b &gt;&gt; 5)</code> trên 1 byte là xoay trái 3 bit. Phép ngược: xoay phải 3 bit, làm <em>sau</em> khi bỏ XOR.", "<code>return ((x &gt;&gt; n) | (x &lt;&lt; (8 - n))) &amp; 0xff</code>"],
    },
  },
});

/* ------------------------------------------------------------------ 4 */
lesson({
  id: "rev-dynamic",
  track: "reverse",
  order: 4,
  level: 3,
  title: "Phân tích động và patch",
  short: "GDB, đọc bộ nhớ lúc chạy, sửa giá trị trả về, patch lệnh nhảy và vượt chống debug",
  time: "60 phút",
  html: `
<h2 id="gdb">GDB căn bản</h2>
<p>GDB cho bạn dừng chương trình ở bất kỳ đâu, xem và sửa thanh ghi lẫn bộ nhớ. Nên cài thêm <strong>pwndbg</strong> hoặc <strong>GEF</strong>: mỗi lần dừng chúng tự in thanh ghi, stack và đoạn code xung quanh.</p>
<table>
<tr><th>Lệnh</th><th>Tác dụng</th></tr>
<tr><td><code>break main</code> / <code>b *0x401196</code></td><td>Đặt breakpoint ở hàm / ở địa chỉ</td></tr>
<tr><td><code>run arg1 arg2</code> / <code>run &lt; input.txt</code></td><td>Chạy với tham số / với stdin từ file</td></tr>
<tr><td><code>continue</code>, <code>finish</code></td><td>Chạy tiếp / chạy tới khi hàm hiện tại return</td></tr>
<tr><td><code>ni</code> / <code>si</code></td><td>Chạy 1 lệnh (bước qua call / bước vào call)</td></tr>
<tr><td><code>info registers</code>, <code>p $rax</code></td><td>Xem thanh ghi</td></tr>
<tr><td><code>x/s $rdi</code>, <code>x/16xb $rsp</code>, <code>x/4gx $rsp</code></td><td>Xem bộ nhớ: chuỗi / 16 byte hex / 4 qword hex</td></tr>
<tr><td><code>set $rax = 0</code>, <code>set *(int*)0x404040 = 1</code></td><td>Sửa thanh ghi / bộ nhớ</td></tr>
<tr><td><code>disassemble check</code>, <code>bt</code></td><td>Xem asm của hàm / call stack</td></tr>
</table>
${sh`
$ gdb -q ./prog
(gdb) set disassembly-flavor intel
(gdb) break strcmp
(gdb) run AAAA
Breakpoint 1, 0x00007ffff7e2d5a0 in strcmp ()
(gdb) x/s $rdi
0x7fffffffe6a2:	"AAAA"
(gdb) x/s $rsi
0x402010:	"mat_khau_that"
`}

<h2 id="chien-thuat">Ba chiến thuật</h2>
<ol class="steps-v">
<li><strong>Đọc bí mật trong bộ nhớ</strong>: chương trình nào cũng phải có chuỗi đúng ở đâu đó trong RAM lúc so sánh, dù nó được giải mã lúc chạy. Dừng đúng lúc rồi <code>x/s</code>.</li>
<li><strong>Đổi kết quả</strong>: dừng sau hàm check (<code>finish</code>), <code>set $rax = 1</code>, rồi <code>continue</code>. Chương trình tưởng bạn đúng. Chỉ dùng được khi flag được in ra hoặc giải mã sau bước kiểm tra, chứ không phải khi chính input là flag.</li>
<li><strong>Patch file</strong>: sửa hẳn lệnh trong file thực thi, để lần chạy sau không cần gdb.</li>
</ol>

<h2 id="patch">Patch lệnh nhảy</h2>
<p>Lệnh nhảy ngắn chỉ có 2 byte: opcode và độ lệch. Đổi opcode là đổi logic:</p>
<table>
<tr><th>Byte</th><th>Lệnh</th><th>Patch hay dùng</th></tr>
<tr><td><code>74 xx</code></td><td><code>je</code></td><td>→ <code>75 xx</code> (jne): đảo điều kiện</td></tr>
<tr><td><code>75 xx</code></td><td><code>jne</code></td><td>→ <code>74 xx</code></td></tr>
<tr><td><code>eb xx</code></td><td><code>jmp</code></td><td>Luôn nhảy</td></tr>
<tr><td><code>90</code></td><td><code>nop</code></td><td><code>90 90</code> xoá hẳn lệnh nhảy 2 byte</td></tr>
</table>
<p>Cần biết <strong>offset trong file</strong> của lệnh. Với file PIE như trong bài này, đoạn code đầu được nạp sao cho địa chỉ objdump in ra (<code>11c4</code>) trùng với offset trong file. Tổng quát hơn: offset = địa chỉ − địa chỉ ảo của segment + offset của segment (xem bằng <code>readelf -l</code>).</p>
${sh`
$ cp prog prog.bak                         # luôn sao lưu trước
$ printf '\x75' | dd of=prog bs=1 seek=$((0x11c4)) conv=notrunc
1+0 records in
1+0 records out
1 byte copied
$ objdump -d -M intel prog | grep 11c4
`}
<p>Cách dễ hơn: Ghidra (chuột phải → <em>Patch Instruction</em> → File → Export Program), Cutter, hoặc hex editor.</p>

<h2 id="anti-debug">Chống debug</h2>
<p>Chương trình có thể phát hiện mình đang bị debug và đổi hành vi:</p>
<ul>
<li><code>ptrace(PTRACE_TRACEME, 0, 0, 0)</code>: mỗi tiến trình chỉ bị một trình debug theo dõi. Nếu gdb đang gắn vào thì lời gọi trả về <strong>−1</strong>. Đây là kiểu phổ biến nhất trên Linux.</li>
<li>Đọc <code>/proc/self/status</code> và kiểm tra <code>TracerPid</code> khác 0.</li>
<li>Đo thời gian (<code>rdtsc</code>, <code>clock_gettime</code>): chạy từng bước trong debugger chậm hơn rất nhiều.</li>
<li>Windows: <code>IsDebuggerPresent()</code>, cờ <code>BeingDebugged</code> trong PEB.</li>
</ul>
<p>Cách vượt: <code>finish</code> sau <code>ptrace</code> rồi <code>set $rax = 0</code>; hoặc patch lệnh nhảy ngay sau đó; hoặc dùng <code>catch syscall ptrace</code>. pwndbg và GEF có sẵn lệnh để bỏ qua kiểu kiểm tra này.</p>

<h2 id="thuc-hanh">Thực hành</h2>
<p>Terminal có <code>gdb</code> mô phỏng (gõ <code>help</code> trong gdb để xem lệnh), <code>objdump</code>, <code>printf</code> và <code>dd</code>.</p>
<div data-widget="shell" data-fs="rev-dyn" data-height="440"></div>
<div data-chal="rev-dyn-1"></div>
<div data-chal="rev-dyn-2"></div>
<div data-chal="rev-dyn-3"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Bạn đổi byte <code>74 07</code> thành <code>90 90</code>. Lệnh nhảy cũ là je. Chuyện gì xảy ra?",
      options: ["Chương trình luôn nhảy", "Chương trình không bao giờ nhảy, luôn chạy tiếp lệnh kế", "Chương trình crash", "Không thay đổi gì"],
      answer: 1,
      explain: "Hai lệnh nop không làm gì, nên luồng chạy luôn rơi xuống lệnh ngay sau.",
    },
    {
      q: "Chương trình gọi <code>ptrace(PTRACE_TRACEME)</code> và thoát nếu kết quả là −1. Trong gdb, bạn làm gì?",
      options: ["break ptrace, run, finish, set $rax = 0, continue", "Chạy lại nhiều lần", "Đổi tên file", "Dùng strings"],
      answer: 0,
      explain: "Sửa giá trị trả về ngay sau lời gọi để chương trình tin rằng không có debugger.",
    },
  ],
  challenges: {
    "rev-dyn-1": {
      title: "Hộp khoá", pts: 125, diff: "med",
      hash: "b3c190cae521ad7eb0ebee3c0782fcb226935cecdcf58723893c81984d2c3927",
      body: "<p><code>./lockbox &lt;mật_khẩu&gt;</code>. Khoá được giải mã lúc chạy và so bằng hàm tự viết, nên <code>strings</code> và <code>ltrace</code> đều vô dụng. Dùng gdb.</p>",
      hints: ["<code>gdb ./lockbox</code> → <code>disassemble check</code>: hàm nào nhận khoá làm tham số?", "<code>break my_cmp</code>, <code>run AAAA</code>, <code>x/s $rsi</code>. Sau đó <code>quit</code> và chạy <code>./lockbox &lt;khoá&gt;</code>. (Đổi <code>$rax</code> sau <code>finish</code> cũng được.)"],
    },
    "rev-dyn-2": {
      title: "Hết hạn dùng thử", pts: 150, diff: "med",
      hash: "1f0f43806d318991d1aacb3546b6c121a8b15c7e496012d7dbe045f81d6a0ed2",
      body: "<p><code>./trial</code> luôn báo hết hạn vì <code>license_valid</code> trả về 0. Patch đúng một lệnh trong file để nó in flag.</p>",
      hints: ["<code>objdump -d trial</code>: tìm lệnh nhảy ngay sau <code>cmp DWORD PTR [rbp-0x4],0x0</code>.", "Đổi byte <code>74</code> (je) ở offset <code>0x11c4</code> thành <code>75</code> (jne): <code>printf '\\x75' | dd of=trial bs=1 seek=$((0x11c4)) conv=notrunc</code>, rồi chạy <code>./trial</code>."],
    },
    "rev-dyn-3": {
      title: "Người gác cổng", pts: 200, diff: "hard",
      hash: "4ed31a859a62f763cba495f4ebc5bcd19fecbcaf834ee7de817b175b4e4e38fe",
      body: "<p><code>./guard</code> giải mã flag vào bộ nhớ rồi xoá ngay. Nếu phát hiện debugger thì thoát sớm. Đọc flag trong khoảng thời gian nó còn nằm trong bộ nhớ.</p>",
      hints: ["<code>disassemble main</code>: ptrace → decrypt(buf) → memset(buf, 0, 0x18).", "<code>break ptrace</code>, <code>run</code>, <code>finish</code>, <code>set $rax = 0</code>, <code>break memset</code>, <code>continue</code>, <code>x/s $rdi</code>."],
    },
  },
});

/* ------------------------------------------------------------------ 5 */
lesson({
  id: "rev-interp",
  track: "reverse",
  order: 5,
  level: 2,
  title: "Bytecode và ngôn ngữ thông dịch",
  short: "Python .pyc, JavaScript bị làm rối, Java/Android và .NET",
  time: "50 phút",
  html: `
<h2 id="tong-quan">Vì sao dễ hơn mã máy</h2>
<p>Python, Java, C#, JavaScript không biên dịch ra mã máy mà ra <strong>bytecode</strong> cho máy ảo (hoặc giữ nguyên mã nguồn). Bytecode giữ lại rất nhiều thông tin: tên hàm, tên biến, kiểu, hằng số. Decompiler thường khôi phục được code gần giống bản gốc.</p>
<table>
<tr><th>Ngôn ngữ</th><th>File</th><th>Công cụ</th></tr>
<tr><td>Python</td><td><code>.pyc</code>, exe từ PyInstaller</td><td><code>pyinstxtractor</code> → <code>pycdc</code>, <code>uncompyle6</code>/<code>decompyle3</code> (Python cũ), <code>dis</code> có sẵn</td></tr>
<tr><td>Java</td><td><code>.class</code>, <code>.jar</code></td><td>JD-GUI, CFR, Procyon, jadx</td></tr>
<tr><td>Android</td><td><code>.apk</code> (chứa <code>classes.dex</code>)</td><td><strong>jadx-gui</strong>, apktool (xem smali, resource)</td></tr>
<tr><td>.NET (C#)</td><td><code>.exe</code>/<code>.dll</code> có CLR header</td><td><strong>dnSpy</strong>/dnSpyEx, ILSpy: ra C# gần như nguyên bản</td></tr>
<tr><td>JavaScript</td><td><code>.js</code>, WebAssembly <code>.wasm</code></td><td>DevTools, beautifier, <code>wasm2wat</code>/Ghidra cho wasm</td></tr>
</table>
<div class="callout tip"><b>Nhận diện</b>
<p><code>file</code> báo "python 3.x byte-compiled", "compiled Java class data" (magic <code>CA FE BA BE</code>), "PE32 executable ... Mono/.Net assembly". File .exe chứa nhiều chuỗi <code>PyInstaller</code>, <code>_MEIPASS</code> là Python đóng gói.</p></div>

<h2 id="python">Python bytecode</h2>
<p>CPython chạy trên máy ảo dạng <strong>stack</strong>: lệnh <code>LOAD_*</code> đẩy giá trị lên stack, phép toán lấy giá trị ra rồi đẩy kết quả vào. Module <code>dis</code> in bytecode của một hàm:</p>
${py`
import dis
def f(x):
    return x * 2 + 1
dis.dis(f)
`}
${txt`
  3           0 LOAD_FAST                0 (x)      # stack: [x]
              2 LOAD_CONST               1 (2)      # stack: [x, 2]
              4 BINARY_MULTIPLY                     # stack: [x*2]
              6 LOAD_CONST               2 (1)      # stack: [x*2, 1]
              8 BINARY_ADD                          # stack: [x*2+1]
             10 RETURN_VALUE
`}
<p>Tên lệnh đổi theo phiên bản (từ 3.11, <code>BINARY_ADD</code> thành <code>BINARY_OP 0 (+)</code>), vì vậy decompiler phải đúng phiên bản. 16 byte đầu file <code>.pyc</code> chứa <em>magic number</em> cho biết phiên bản Python. Thử ngay trong REPL:</p>
<div data-widget="python" data-height="240"></div>

<h2 id="js">JavaScript bị làm rối</h2>
<p>Obfuscator (như obfuscator.io) đổi tên biến thành <code>_0x3f2a</code>, gom mọi chuỗi vào một mảng rồi truy cập qua hàm giải mã, viết chuỗi dạng <code>'\\x61'</code>, thêm code chết. Cách xử lý:</p>
<ol class="steps-v">
<li>Làm đẹp code (<em>Pretty print</em> <code>{}</code> trong DevTools, hoặc beautifier.io).</li>
<li>Đừng đọc hết. Tìm chỗ so sánh/kết quả cuối, rồi <strong>chạy</strong> từng phần nhỏ trong console để xem giá trị thật. Hàm giải mã chuỗi cứ để nó tự chạy.</li>
<li>Code dùng <code>eval</code> hoặc <code>Function(...)</code>: thay bằng <code>console.log</code> để in ra code thật thay vì chạy nó.</li>
<li>Công cụ tự động: <a href="https://deobfuscate.io/" target="_blank" rel="noopener">deobfuscate.io</a>, webcrack, synchrony.</li>
</ol>
<div data-widget="jsconsole" data-height="220"></div>

<h2 id="java">Java, Android, .NET</h2>
<p>Với ba nền tảng này, decompiler thường cho code đọc được ngay. Mở apk bằng <strong>jadx-gui</strong>, tìm trong <code>AndroidManifest.xml</code> activity chính, rồi tìm hàm có <code>equals</code>, <code>check</code>, <code>verify</code>. Chuỗi thường nằm ở <code>res/values/strings.xml</code>. Nếu logic nằm trong thư viện native (<code>lib/*.so</code>), quay về Ghidra. Muốn thay đổi hành vi lúc chạy thì dùng <strong>Frida</strong> để hook hàm.</p>

<h2 id="thuc-hanh">Thực hành</h2>
<div data-chal="re2"></div>
<div data-chal="re1"></div>
<div data-chal="rev-dis"></div>
<div data-chal="rev-js"></div>
<div data-chal="rev-apk"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "Trong bytecode Python, <code>LOAD_FAST 0 (x)</code>, <code>LOAD_CONST 1 (3)</code>, <code>BINARY_SUBTRACT</code> tính gì?",
      options: ["3 - x", "x - 3", "x * 3", "x == 3"],
      answer: 1,
      explain: "Giá trị đẩy vào trước (x) là toán hạng trái. Phép trừ lấy hai giá trị trên cùng và tính trái − phải.",
    },
    {
      q: "Một đoạn JS bị làm rối kết thúc bằng <code>eval(_0x5d())</code>. Cách an toàn để xem code thật?",
      options: ["Chạy nguyên đoạn code", "Thay eval bằng console.log rồi chạy", "Xoá dòng eval", "Đổi tên biến"],
      answer: 1,
      explain: "console.log in ra chuỗi code sẽ được eval, thay vì thực thi nó.",
    },
  ],
  challenges: {
    re2: {
      title: "Đọc ngược", pts: 50, diff: "easy",
      hash: "8b5c147422e823d0f6fe5c118b4aea6b990a1ae8803015e690352bfeb8fbf738",
      body: `${py`
def check(pw):
    return pw[::-1] == "}iouhc_cougn_04d{FTCz"`}`,
      hints: ["Trong Python, <code>s[::-1]</code> là chuỗi đảo ngược."],
    },
    re1: {
      title: "Mảng bí ẩn", pts: 100, diff: "easy",
      hash: "13118bee5c46ff9fe179960af3e37722362bbb7f9259154351d1336c259d8409",
      body: `<p>Hàm sau trả về <code>true</code> khi nhận đúng flag:</p>${js`
function check(input) {
  const secret = [125,68,83,65,124,117,52,113,52,117,116,52,88,99,52,88,111,54,52,114,122];
  if (input.length !== secret.length) return false;
  for (let i = 0; i < input.length; i++) {
    if ((input.charCodeAt(i) ^ 7) !== secret[i]) return false;
  }
  return true;
}`}`,
      hints: ["XOR là phép tự đảo ngược: nếu <code>x ^ 7 = s</code> thì <code>x = s ^ 7</code>.", "Trong JS console: <code>String.fromCharCode(...[125,68,...].map(x =&gt; x ^ 7))</code>"],
    },
    "rev-dis": {
      title: "Đọc bytecode", pts: 150, diff: "med",
      hash: "99f14b1086c3fc8669e0599e656eb50c8f4885f287fd3d95a9b86666b5a6abb5",
      body: `<p>Chỉ có output của <code>dis.dis(check)</code> (Python 3.10). Dựng lại hàm và tìm input làm nó trả về True.</p>${txt`
  2           0 LOAD_CONST               1 (7)
              2 STORE_FAST               1 (key)

  3           4 BUILD_LIST               0
              6 STORE_FAST               2 (out)

  4           8 LOAD_GLOBAL              0 (enumerate)
             10 LOAD_FAST                0 (s)
             12 CALL_FUNCTION            1
             14 GET_ITER
        >>   16 FOR_ITER                15 (to 48)
             18 UNPACK_SEQUENCE          2
             20 STORE_FAST               3 (i)
             22 STORE_FAST               4 (ch)

  5          24 LOAD_FAST                2 (out)
             26 LOAD_METHOD              1 (append)
             28 LOAD_GLOBAL              2 (ord)
             30 LOAD_FAST                4 (ch)
             32 CALL_FUNCTION            1
             34 LOAD_FAST                1 (key)
             36 BINARY_ADD
             38 LOAD_FAST                3 (i)
             40 BINARY_ADD
             42 CALL_METHOD              1
             44 POP_TOP
             46 JUMP_ABSOLUTE            8 (to 16)

  6     >>   48 LOAD_FAST                2 (out)
             50 LOAD_GLOBAL              3 (TARGET)
             52 COMPARE_OP               2 (==)
             54 RETURN_VALUE

TARGET = [129, 75, 93, 80, 134, 110, 134, 130, 66, 115, 65, 118, 70, 115, 128, 70, 118, 131, 129, 74, 152]
`}`,
      hints: ["Dòng 4–5: <code>for i, ch in enumerate(s): out.append(ord(ch) + key + i)</code>.", "<code>''.join(chr(t - 7 - i) for i, t in enumerate(TARGET))</code>"],
    },
    "rev-js": {
      title: "Gỡ rối JavaScript", pts: 125, diff: "med",
      hash: "917b8fe03faddfe1f67acd612cb65671b50628c7435a3f114347783e520f67a3",
      body: `<p>Tìm thấy trong file <code>app.min.js</code> của một trang web:</p>${js`
var _0x4e=['\x66\x72\x6f\x6d\x43\x68\x61\x72\x43\x6f\x64\x65','\x6d\x61\x70'];var _0x7b=function(_0x1){return _0x4e[_0x1];};function _0x2c(){return [0x8b,0x54,0x65,0x57,0x8c,0x75,0x44,0x41,0x73,0x77,0x86,0x84,0x74,0x45,0x85,0x44,0x70,0x7b,0x84,0x70,0x75,0x44,0x70,0x85,0x79,0x41,0x7a,0x8e][_0x7b(0x1)](function(_0x5){return _0x5-0x11;});}function check(_0x9){var _0x3=String[_0x7b(0x0)].apply(null,_0x2c());return _0x9===_0x3;}
`}`,
      hints: ["Dán cả dòng vào JS console ở trên (hoặc tab Công cụ → JavaScript). Hàm sẽ được định nghĩa.", "Gọi phần tạo chuỗi: <code>String.fromCharCode(..._0x2c())</code>"],
    },
    "rev-apk": {
      title: "Ứng dụng Android", pts: 100, diff: "easy",
      hash: "c2b2051b18accf5e62337678fbfdc9fb3cd19e84e99e713dbf85c7ef496b3d06",
      body: `<p>Mở <code>secret.apk</code> bằng jadx, lớp <code>com.zctf.app.LoginActivity</code>:</p>${codeBlock("java")`
public boolean verify(String input) {
    byte[] data = Base64.decode("aVBHVWh5J3drTHcjcExyY3hMdyBu", 0);
    for (int i = 0; i < data.length; i++) {
        data[i] = (byte) (data[i] ^ 0x13);
    }
    return input.equals(new String(data));
}`}`,
      hints: ["Giải Base64 rồi XOR từng byte với 0x13.", "Python: <code>xor(base64.b64decode('aVBH...'), 0x13)</code> (hàm xor có sẵn trong REPL)."],
    },
  },
});
