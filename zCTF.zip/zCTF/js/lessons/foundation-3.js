/* Track foundation — bài 4 */

lesson({
  id: "linux-adv",
  track: "foundation",
  order: 4,
  level: 2,
  title: "Linux: user, quyền và tiến trình",
  short: "User/group, quyền rwx, chmod, biến môi trường, process, SSH key",
  time: "35 phút",
  html: `
<h2 id="user">User và group</h2>
<p>Mỗi tiến trình chạy dưới danh nghĩa một <strong>user</strong>. User <code>root</code> (UID 0) có toàn quyền. Mỗi user thuộc một hoặc nhiều <strong>group</strong>; group giúp chia quyền cho cả nhóm người mà không phải cấp từng người.</p>
${sh`
$ id
uid=1000(guest) gid=1000(guest) groups=1000(guest),1002(dev)
$ cat /etc/passwd
root:x:0:0:root:/root:/bin/bash
guest:x:1000:1000::/home/guest:/bin/bash
#    tên : x : UID : GID : mô tả : thư mục nhà : shell
$ cat /etc/group
dev:x:1002:alice,guest
`}
<p><code>/etc/passwd</code> ai cũng đọc được; mật khẩu đã băm nằm riêng trong <code>/etc/shadow</code> và chỉ root đọc được.</p>

<h2 id="quyen">Đọc quyền rwx</h2>
${txt`
-rwxr-x--- 1 alice dev 1024 Nov 10 09:00 deploy.sh
│└┬┘└┬┘└┬┘   │     │
│ │  │  │    chủ   group
│ │  │  └── người khác (other): ---  không có quyền
│ │  └───── group dev:           r-x  đọc + chạy
│ └──────── chủ alice:           rwx  đọc + ghi + chạy
└────────── loại: - file, d thư mục, l link
`}
<table>
<tr><th>Quyền</th><th>Với file</th><th>Với thư mục</th><th>Số</th></tr>
<tr><td><code>r</code></td><td>Đọc nội dung</td><td>Liệt kê file bên trong (ls)</td><td>4</td></tr>
<tr><td><code>w</code></td><td>Sửa nội dung</td><td>Tạo/xoá/đổi tên file bên trong</td><td>2</td></tr>
<tr><td><code>x</code></td><td>Chạy như chương trình</td><td>Đi vào (cd), truy cập file bên trong</td><td>1</td></tr>
</table>
<p>Hệ thống kiểm tra theo thứ tự: bạn là <strong>chủ</strong> thì dùng bộ quyền đầu; nếu không mà thuộc <strong>group</strong> của file thì dùng bộ giữa; còn lại dùng bộ cuối. Dạng số: cộng giá trị từng nhóm. <code>rwxr-x---</code> = 7 5 0 → <code>750</code>; <code>rw-r--r--</code> = <code>644</code>.</p>
${sh`
$ chmod 600 id_ed25519     # chỉ chủ được đọc/ghi (SSH bắt buộc với khoá riêng)
$ chmod +x script.sh       # thêm quyền chạy
$ chmod u+r note.txt       # thêm quyền đọc cho chủ
$ chmod 640 report.txt     # chủ đọc/ghi, group đọc, người khác không
`}
<div class="callout warn"><b>Chủ luôn đổi được quyền</b>
<p>File của bạn có quyền <code>----------</code> thì bạn không đọc được, nhưng vì là chủ nên vẫn <code>chmod</code> được. Root bỏ qua mọi kiểm tra quyền.</p></div>

<h2 id="nguyen-tac">Nguyên tắc quyền tối thiểu</h2>
<p>Trong quản trị hệ thống, mỗi user và dịch vụ chỉ nên có đúng quyền cần thiết:</p>
<ul>
<li>Dịch vụ web chạy bằng user riêng (<code>www-data</code>), không chạy bằng root.</li>
<li>Tài liệu nội bộ của nhóm: chủ <code>rw</code>, group <code>r</code>, người khác không có gì (<code>640</code>).</li>
<li>Khoá SSH riêng, file chứa mật khẩu: <code>600</code>.</li>
<li>Không đặt <code>777</code> cho bất cứ thứ gì "cho nhanh". Cấu hình quyền sai là một trong những nguyên nhân phổ biến nhất khiến dữ liệu bị lộ, và cũng là chủ đề hay gặp trong CTF.</li>
</ul>

<h2 id="env">Biến môi trường</h2>
<p>Mỗi tiến trình mang theo một bộ biến môi trường: <code>PATH</code> (nơi tìm chương trình), <code>HOME</code>, <code>USER</code>… Ứng dụng hay đọc cấu hình (đường dẫn, token, mật khẩu DB) từ đây.</p>
${sh`
$ echo $HOME
/home/guest
$ env | grep PATH
PATH=/usr/local/bin:/usr/bin:/bin
$ export APP_MODE=debug
`}
<div class="callout tip"><b>Để ý khi điều tra</b>
<p>Biến môi trường, file <code>.env</code>, lịch sử lệnh (<code>.bash_history</code>) là chỗ hay để lộ thông tin nhạy cảm. Khi làm quản trị, đừng để token trong lịch sử lệnh hay trong file đọc được bởi mọi người.</p></div>

<h2 id="process">Tiến trình</h2>
${sh`
$ ps aux                 # mọi tiến trình đang chạy, kèm user và lệnh
$ ps aux | grep nginx
$ kill 1234              # gửi tín hiệu dừng cho PID 1234
$ top                    # theo dõi trực tiếp (thoát bằng q)
`}
<p>Cột <code>USER</code> cho biết tiến trình chạy bằng quyền của ai. Một tiến trình của root bị lỗi nguy hiểm hơn nhiều so với tiến trình của <code>www-data</code>, đó là lý do của nguyên tắc quyền tối thiểu.</p>

<h2 id="ssh">SSH key</h2>
<p>Thay vì mật khẩu, SSH dùng cặp khoá: <strong>khoá riêng</strong> (giữ bí mật, trên máy bạn) và <strong>khoá công khai</strong> (đặt vào <code>~/.ssh/authorized_keys</code> trên máy chủ).</p>
${sh`
$ ssh-keygen -t ed25519            # tạo ~/.ssh/id_ed25519 và id_ed25519.pub
$ ssh -i ~/.ssh/id_ed25519 user@host
$ chmod 700 ~/.ssh ; chmod 600 ~/.ssh/id_ed25519
`}
<p>Nếu khoá riêng có quyền quá rộng (ví dụ <code>644</code>), ssh từ chối dùng nó và báo <em>UNPROTECTED PRIVATE KEY FILE</em>.</p>

<h2 id="thuc-hanh">Thực hành</h2>
<p>Máy <code>srv01</code> bên dưới có ba bài tập về quyền. Đọc <code>README.txt</code> trước.</p>
<div data-widget="shell" data-fs="linux-adv" data-height="380"></div>
<div data-chal="la1"></div>
<div data-chal="la2"></div>
<div data-chal="la3"></div>
<div data-quiz="0"></div>
<div data-quiz="1"></div>
<div data-quiz="2"></div>

<div class="callout idea"><b>Học tiếp</b>
<p>Sau khi nắm quyền file, bước tiếp theo trong các nền tảng như OverTheWire Bandit và TryHackMe (phòng <em>Linux Fundamentals</em>) là các chủ đề như sudo, SUID và cron. Hãy học chúng trong phòng lab của các nền tảng đó.</p></div>
`,
  quiz: [
    { q: "File <code>-rw-r----- alice dev report.txt</code>. User <code>bob</code> thuộc group <code>dev</code>. Bob làm được gì?", options: ["Đọc và sửa", "Chỉ đọc", "Không làm được gì", "Chỉ chạy"], answer: 1, explain: "Bob không phải chủ nhưng thuộc group dev, nên dùng bộ quyền giữa: <code>r--</code>." },
    { q: "Quyền dạng số <code>640</code> tương ứng với chuỗi nào?", options: ["<code>rw-r-----</code>", "<code>rwxr--r--</code>", "<code>rw-rw----</code>", "<code>r--r-----</code>"], answer: 0, explain: "6 = 4+2 = rw-, 4 = r--, 0 = ---." },
    { q: "Vì sao không nên chạy dịch vụ web bằng root?", options: ["Vì root chạy chậm hơn", "Vì nếu dịch vụ bị khai thác, kẻ tấn công có ngay toàn quyền hệ thống", "Vì root không mở được cổng 80", "Không có lý do"], answer: 1, explain: "Nguyên tắc quyền tối thiểu: dịch vụ bị lỗi chỉ gây hại trong phạm vi quyền của user chạy nó." },
  ],
  challenges: {
    la1: { title: "File của chính mình", pts: 50, diff: "easy", hash: "808c25c14494ff215dd27a85ad85ea86442156b69798490e277f44fcdde917cf", body: "<p><code>~/note.txt</code> thuộc về bạn nhưng <code>cat</code> báo <em>Permission denied</em>.</p>", hints: ["<code>ls -l note.txt</code>: chủ file có những quyền gì?", "<code>chmod u+r note.txt</code> (hoặc <code>chmod 600 note.txt</code>) rồi <code>cat</code> lại."] },
    la2: { title: "Tài liệu của nhóm", pts: 75, diff: "easy", hash: "8bccb5eb2467375ba327544befa97e46129c21a72825174a629e622311067d99", body: "<p>Thư mục <code>/srv/project</code> thuộc <code>alice</code>. Bạn không phải alice, vậy bạn đọc được file nào trong đó, và vì sao?</p>", hints: ["<code>id</code> cho biết bạn thuộc những group nào.", "<code>ls -l /srv/project</code>: file nào có group <code>dev</code> và quyền group là <code>r</code>? Đọc file ghi chú thiết kế."] },
    la3: { title: "Cấu hình trong môi trường", pts: 75, diff: "easy", hash: "4254cf3c555ddc33d4affa0e8fc11e4764b096589b522212263ba29a9b8d701d", body: "<p><code>/srv/project/app.py</code> đọc token từ một biến môi trường. Giá trị của biến đó trong phiên hiện tại là flag.</p>", hints: ["Xem <code>app.py</code> để biết tên biến.", "<code>env</code> hoặc <code>echo $ZCTF_TOKEN</code>"] },
  },
});
