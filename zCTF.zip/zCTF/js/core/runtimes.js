/* =====================================================================
   Runtime thật chạy trong trình duyệt:
     WIDGETS.python   — CPython (Pyodide, tải từ /vendor, ~10MB lần đầu)
        <div data-widget="python"></div>                          REPL
        <div data-widget="python" data-code="print(1)"></div>     Editor + Run (code nhiều dòng: dùng &#10; cho xuống dòng,
                                                                   hoặc đặt code trong <template> con)
     WIDGETS.sql      — SQLite (sql.js)
        <div data-widget="sql" data-db="shop"></div>   SQL_DBS[name] = "SQL khởi tạo" | { init, examples: [] }
     WIDGETS.jsconsole — JavaScript chạy trong iframe sandbox
   ===================================================================== */

/* ---------- Console UI dùng chung ---------- */
function createConsole(el, { title, prompt = "> ", height, banner, onLine, onKey }) {
  const root = h(`
    <div class="shell"><div class="window">
      <div class="window-bar"><i></i><i></i><i></i><span>${esc(title)}</span></div>
      <div class="shell-out" tabindex="-1" style="${height ? "height:" + height + "px" : ""}"></div>
    </div></div>`);
  el.replaceWith(root);
  const out = root.querySelector(".shell-out");
  const line = h(`<div class="shell-line"><span class="p"></span><input spellcheck="false" autocomplete="off" autocapitalize="off"></div>`);
  out.appendChild(line);
  const input = line.querySelector("input");
  const pEl = line.querySelector(".p");
  let curPrompt = prompt;
  const setPrompt = (p) => { curPrompt = p; pEl.textContent = p; };
  setPrompt(prompt);
  const hist = []; let hi = 0; let busy = false;
  const api = {
    root, out, input,
    print(text, cls) {
      const d = document.createElement("div");
      if (cls) d.className = cls;
      d.textContent = text;
      out.insertBefore(d, line);
      out.scrollTop = out.scrollHeight;
      return d;
    },
    printHtml(html) { const d = document.createElement("div"); d.innerHTML = html; out.insertBefore(d, line); out.scrollTop = out.scrollHeight; return d; },
    /** in tiếp không xuống dòng (stdout dạng stream) */
    write(text, cls) {
      let last = line.previousElementSibling;
      if (!last || !last.dataset.stream || last.dataset.cls !== (cls || "")) { last = api.print("", cls); last.dataset.stream = "1"; last.dataset.cls = cls || ""; }
      last.textContent += text;
      if (last.textContent.endsWith("\n")) { last.textContent = last.textContent.slice(0, -1); delete last.dataset.stream; }
      out.scrollTop = out.scrollHeight;
    },
    setPrompt,
    clear() { [...out.children].forEach((x) => x !== line && x.remove()); },
  };
  if (banner) api.print(banner, "m");
  input.addEventListener("keydown", async (e) => {
    if (onKey && onKey(e, api) === false) return;
    if (e.key === "Enter" && !busy) {
      const v = input.value; input.value = "";
      api.print(curPrompt + v, "echo");
      if (v.trim()) { hist.push(v); hi = hist.length; }
      busy = true; input.disabled = true;
      try { await onLine(v, api); } catch (err) { api.print(String(err.message || err), "e"); }
      busy = false; input.disabled = false; input.focus({ preventScroll: true });
    } else if (e.key === "ArrowUp") { if (hi > 0) input.value = hist[--hi]; e.preventDefault(); }
    else if (e.key === "ArrowDown") { input.value = hi < hist.length - 1 ? hist[++hi] : ((hi = hist.length), ""); e.preventDefault(); }
    else if (e.key === "l" && e.ctrlKey) { e.preventDefault(); api.clear(); }
  });
  out.addEventListener("click", () => { if (!getSelection().toString()) input.focus({ preventScroll: true }); });
  return api;
}

/* ---------- Python (Pyodide) ---------- */
let _pyodide = null;
function getPyodide(onStatus) {
  if (!_pyodide) {
    _pyodide = (async () => {
      onStatus && onStatus("Đang tải Python (khoảng 10MB, chỉ lần đầu)…");
      await loadScript("/vendor/pyodide/pyodide.js");
      const py = await loadPyodide({ indexURL: "/vendor/pyodide/" });
      return py;
    })();
    _pyodide.catch(() => (_pyodide = null));
  }
  return _pyodide;
}

const PY_PRELUDE = `
import base64, binascii, hashlib, struct, string, itertools, math, re, json, random, codecs, collections, functools, os, sys, zlib
from math import gcd
def long_to_bytes(n):
    n = int(n)
    return n.to_bytes((n.bit_length() + 7) // 8 or 1, "big")
def bytes_to_long(b):
    return int.from_bytes(b, "big")
def xor(a, b):
    if isinstance(b, int): b = bytes([b])
    if isinstance(a, str): a = a.encode()
    if isinstance(b, str): b = b.encode()
    return bytes(x ^ b[i % len(b)] for i, x in enumerate(a))
def p32(x): return struct.pack("<I", x & 0xffffffff)
def p64(x): return struct.pack("<Q", x & 0xffffffffffffffff)
def u32(b): return struct.unpack("<I", b.ljust(4, b"\\0")[:4])[0]
def u64(b): return struct.unpack("<Q", b.ljust(8, b"\\0")[:8])[0]
`;

WIDGETS.python = (el) => {
  const raw = el.querySelector('script[type="text/x-python"]');
  const tpl = el.querySelector("template");
  const code = raw ? raw.textContent.replace(/^\n/, "") : tpl ? tpl.innerHTML.replace(/^\n/, "").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&") : el.dataset.code;
  if (code != null) return mountPyEditor(el, code);
  const con = createConsole(el, {
    title: "python3",
    prompt: ">>> ",
    height: el.dataset.height ? +el.dataset.height : 320,
    banner: "Python 3 (Pyodide) — chạy thật trong trình duyệt. Có sẵn: base64, hashlib, struct, long_to_bytes, bytes_to_long, xor, p32/p64…",
    onLine: async (line, api) => {
      const st = await ensure(api);
      if (!st) return;
      const { pyconsole, awaitFut, reprShorten, pyodide } = st;
      const fut = pyconsole.push(line);
      api.setPrompt(fut.syntax_check === "incomplete" ? "... " : ">>> ");
      if (fut.syntax_check === "syntax-error") { api.print(fut.formatted_error.trimEnd(), "e"); fut.destroy(); return; }
      if (fut.syntax_check === "incomplete") { fut.destroy(); return; }
      const wrapped = awaitFut(fut);
      try {
        const [value] = await wrapped;
        if (value !== undefined) api.print(reprShorten.callKwargs(value, { separator: "\n<…>\n" }));
        if (value instanceof pyodide.ffi.PyProxy) value.destroy();
      } catch (e) {
        if (e.constructor.name === "PythonError") api.print((fut.formatted_error || e.message).trimEnd(), "e");
        else throw e;
      } finally { fut.destroy(); wrapped.destroy(); }
    },
    onKey: (e, api) => {
      if (e.key === "Tab") {
        e.preventDefault();
        const st = api._st;
        if (!st) { api.input.value += "    "; return false; }
        const v = api.input.value;
        if (!v.trim()) { api.input.value += "    "; return false; }
        const [cands, start] = st.pyconsole.complete(v).toJs();
        if (cands.length === 1) api.input.value = v.slice(0, start) + cands[0];
        else if (cands.length > 1) api.print(cands.join("  "), "m");
        return false;
      }
      if (e.key === "c" && e.ctrlKey && !getSelection().toString() && api._st) {
        e.preventDefault(); api._st.pyconsole.buffer.clear(); api.print("KeyboardInterrupt", "e"); api.setPrompt(">>> "); api.input.value = ""; return false;
      }
    },
  });
  async function ensure(api) {
    if (api._st) return api._st;
    const msg = api.print("Đang tải Python…", "m");
    try {
      const pyodide = await getPyodide((s) => (msg.textContent = s));
      const ns = pyodide.globals.get("dict")();
      pyodide.runPython(PY_PRELUDE, { globals: ns });
      const { repr_shorten, PyodideConsole } = pyodide.pyimport("pyodide.console");
      const pyconsole = PyodideConsole(ns);
      pyconsole.stdout_callback = (s) => api.write(s);
      pyconsole.stderr_callback = (s) => api.write(s, "e");
      const tmp = pyodide.globals.get("dict")();
      const awaitFut = pyodide.runPython(`
import builtins
from pyodide.ffi import to_js
async def await_fut(fut):
    res = await fut
    if res is not None:
        builtins._ = res
    return to_js([res], depth=1)
await_fut`, { globals: tmp });
      msg.textContent = "Python đã sẵn sàng.";
      api._st = { pyodide, pyconsole, awaitFut, reprShorten: repr_shorten };
      return api._st;
    } catch (e) {
      msg.textContent = "Không tải được Python: " + (e.message || e);
      msg.className = "e";
      return null;
    }
  }
  // tải sẵn khi người dùng focus lần đầu
  con.input.addEventListener("focus", () => ensure(con), { once: true });
};

function mountPyEditor(el, code) {
  const root = h(`
    <div class="py-editor window">
      <div class="window-bar"><i></i><i></i><i></i><span>solve.py</span></div>
      <textarea spellcheck="false"></textarea>
      <div class="py-bar">
        <button class="btn primary sm" data-a="run">▶ Chạy <kbd>Ctrl+Enter</kbd></button>
        <button class="btn sm" data-a="reset">Khôi phục code</button>
        <span class="py-status"></span>
      </div>
      <pre class="py-out"></pre>
    </div>`);
  el.replaceWith(root);
  const ta = root.querySelector("textarea");
  const outEl = root.querySelector(".py-out");
  const status = root.querySelector(".py-status");
  ta.value = code;
  const fit = () => { ta.style.height = "auto"; ta.style.height = Math.min(520, ta.scrollHeight + 4) + "px"; };
  ta.addEventListener("input", fit);
  requestAnimationFrame(fit);
  ta.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); run(); }
    else if (e.key === "Tab") { e.preventDefault(); const s = ta.selectionStart; ta.setRangeText("    ", s, ta.selectionEnd, "end"); }
  });
  root.querySelector('[data-a="reset"]').onclick = () => { ta.value = code; fit(); };
  root.querySelector('[data-a="run"]').onclick = run;
  async function run() {
    outEl.textContent = "";
    outEl.classList.remove("err");
    status.textContent = "Đang chạy…";
    try {
      const pyodide = await getPyodide((s) => (status.textContent = s));
      const ns = pyodide.globals.get("dict")();
      pyodide.runPython(PY_PRELUDE, { globals: ns });
      const buf = [];
      pyodide.setStdout({ batched: (s) => buf.push(s) });
      pyodide.setStderr({ batched: (s) => buf.push(s) });
      const t0 = performance.now();
      try {
        const r = await pyodide.runPythonAsync(ta.value, { globals: ns });
        if (r !== undefined && r !== null && !buf.length) buf.push(String(r));
        status.textContent = `Xong trong ${Math.round(performance.now() - t0)} ms`;
      } catch (e) {
        buf.push(String(e.message || e).split("\n").filter((l) => !/File "\/lib\/python|_pyodide|pyodide\/_base/.test(l)).join("\n"));
        outEl.classList.add("err");
        status.textContent = "Lỗi";
      } finally {
        pyodide.setStdout(); pyodide.setStderr();
        ns.destroy();
      }
      outEl.textContent = buf.join("\n") || "(không có output)";
    } catch (e) {
      status.textContent = "Không tải được Python: " + (e.message || e);
    }
  }
}

/* ---------- SQL (sql.js) ---------- */
let _sqljs = null;
function getSqlJs() {
  if (!_sqljs) {
    _sqljs = (async () => {
      await loadScript("/vendor/sqljs/sql-wasm.js");
      return initSqlJs({ locateFile: (f) => "/vendor/sqljs/" + f });
    })();
    _sqljs.catch(() => (_sqljs = null));
  }
  return _sqljs;
}

SQL_DBS.shop = {
  init: `
CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, password TEXT, role TEXT, email TEXT);
INSERT INTO users VALUES (1,'admin','S!eu_Bi_Mat_9f3k2','admin','admin@shop.local'),(2,'alice','alice123','user','alice@mail.com'),(3,'bob','hunter2','user','bob@mail.com'),(4,'guest','guest','guest',NULL);
CREATE TABLE products (id INTEGER PRIMARY KEY, name TEXT, price INTEGER, category TEXT, stock INTEGER);
INSERT INTO products VALUES (1,'Bàn phím cơ',1200000,'phu-kien',15),(2,'Chuột không dây',350000,'phu-kien',40),(3,'Màn hình 27"',4500000,'man-hinh',7),(4,'Tai nghe',800000,'am-thanh',0),(5,'Loa bluetooth',650000,'am-thanh',22);
CREATE TABLE orders (id INTEGER PRIMARY KEY, user_id INTEGER, product_id INTEGER, qty INTEGER, created TEXT);
INSERT INTO orders VALUES (1,2,1,1,'2026-10-01'),(2,2,5,2,'2026-10-03'),(3,3,3,1,'2026-10-05'),(4,3,2,3,'2026-10-07');
CREATE TABLE secrets (id INTEGER PRIMARY KEY, name TEXT, value TEXT);
INSERT INTO secrets VALUES (1,'api_key','sk_live_khong_dua_ai'),(2,'note','Bảng này chỉ để luyện tập SQL.');`,
  examples: [
    "SELECT * FROM products;",
    "SELECT name, price FROM products WHERE price > 500000 ORDER BY price DESC;",
    "SELECT category, COUNT(*), AVG(price) FROM products GROUP BY category;",
    "SELECT u.username, p.name, o.qty FROM orders o JOIN users u ON u.id = o.user_id JOIN products p ON p.id = o.product_id;",
    "SELECT name FROM sqlite_master WHERE type = 'table';",
    "SELECT name, price FROM products WHERE id = 1 UNION SELECT username, password FROM users;",
  ],
};

WIDGETS.sql = (el) => {
  const name = el.dataset.db || "shop";
  const spec = typeof SQL_DBS[name] === "string" ? { init: SQL_DBS[name], examples: [] } : SQL_DBS[name] || SQL_DBS.shop;
  const root = h(`
    <div class="sql-box window">
      <div class="window-bar"><i></i><i></i><i></i><span>sqlite3 ${esc(name)}.db</span></div>
      <div class="sql-ex"></div>
      <textarea spellcheck="false" placeholder="Gõ câu SQL… (Ctrl+Enter để chạy)"></textarea>
      <div class="py-bar">
        <button class="btn primary sm" data-a="run">▶ Chạy <kbd>Ctrl+Enter</kbd></button>
        <button class="btn sm" data-a="schema">Xem cấu trúc bảng</button>
        <button class="btn sm" data-a="reset">Khôi phục dữ liệu</button>
        <span class="py-status"></span>
      </div>
      <div class="sql-res"></div>
    </div>`);
  el.replaceWith(root);
  const ta = root.querySelector("textarea");
  const res = root.querySelector(".sql-res");
  const status = root.querySelector(".py-status");
  const ex = root.querySelector(".sql-ex");
  (spec.examples || []).forEach((q) => { const b = document.createElement("button"); b.className = "op"; b.textContent = q.length > 60 ? q.slice(0, 57) + "…" : q; b.title = q; b.onclick = () => { ta.value = q; run(); }; ex.appendChild(b); });
  if (!spec.examples || !spec.examples.length) ex.remove();
  ta.value = el.dataset.query || (spec.examples && spec.examples[0]) || "";
  let db = null;
  async function getDb(reset) {
    if (db && !reset) return db;
    const SQL = await getSqlJs();
    if (db) db.close();
    db = new SQL.Database();
    db.run(spec.init);
    return db;
  }
  const table = (r) => `<div class="tbl-wrap"><table><tr>${r.columns.map((c2) => `<th>${esc(c2)}</th>`).join("")}</tr>${r.values.map((row) => `<tr>${row.map((v) => `<td>${v === null ? '<span class="null">NULL</span>' : esc(v)}</td>`).join("")}</tr>`).join("")}</table></div>`;
  async function run(q = ta.value) {
    status.textContent = "Đang chạy…";
    try {
      const d = await getDb();
      const t0 = performance.now();
      const r = d.exec(q);
      const changes = d.getRowsModified();
      res.innerHTML = r.length ? r.map(table).join("") : `<div class="m">OK. ${changes} dòng bị thay đổi.</div>`;
      status.textContent = `${r.reduce((s, x) => s + x.values.length, 0)} dòng · ${Math.round(performance.now() - t0)} ms`;
    } catch (e) {
      res.innerHTML = `<div class="e">Error: ${esc(e.message || e)}</div>`;
      status.textContent = "Lỗi";
    }
  }
  ta.addEventListener("keydown", (e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); run(); } });
  root.querySelector('[data-a="run"]').onclick = () => run();
  root.querySelector('[data-a="schema"]').onclick = () => run("SELECT name AS bang, sql AS cau_truc FROM sqlite_master WHERE type='table';");
  root.querySelector('[data-a="reset"]').onclick = async () => { await getDb(true); res.innerHTML = '<div class="m">Đã khôi phục dữ liệu gốc.</div>'; };
};

/* ---------- JavaScript console (iframe sandbox) ---------- */
WIDGETS.jsconsole = (el) => {
  const frame = document.createElement("iframe");
  frame.setAttribute("sandbox", "allow-scripts");
  frame.style.display = "none";
  frame.srcdoc = `<script>
    const fmt = (v, d = 0) => {
      if (typeof v === "string") return d ? JSON.stringify(v) : v;
      if (typeof v === "function") return "ƒ " + (v.name || "anonymous") + "()";
      if (typeof v === "bigint") return v + "n";
      if (v instanceof Uint8Array) return "Uint8Array(" + v.length + ") [" + Array.from(v).join(", ") + "]";
      if (Array.isArray(v)) return d > 2 ? "[…]" : "[" + v.map((x) => fmt(x, d + 1)).join(", ") + "]";
      if (v && typeof v === "object") { if (d > 2) return "{…}"; try { return "{" + Object.entries(v).map(([k, x]) => k + ": " + fmt(x, d + 1)).join(", ") + "}"; } catch { return String(v); } }
      return String(v);
    };
    const send = (type, text) => parent.postMessage({ __zjs: 1, type, text }, "*");
    console.log = (...a) => send("log", a.map((x) => fmt(x)).join(" "));
    console.error = (...a) => send("err", a.map((x) => fmt(x)).join(" "));
    console.warn = console.info = console.log;
    addEventListener("message", async (e) => {
      if (!e.data || !e.data.__run) return;
      try { let r = (0, eval)(e.data.code); if (r instanceof Promise) r = await r; send("ret", r === undefined ? "undefined" : fmt(r, 1)); }
      catch (err) { send("err", String(err)); }
      send("done");
    });
  <\/script>`;
  document.body.appendChild(frame);
  let pending = null;
  const con = createConsole(el, {
    title: "JavaScript console",
    prompt: "> ",
    height: el.dataset.height ? +el.dataset.height : 300,
    banner: "JavaScript chạy trong sandbox riêng. Thử: atob('ekNURg=='), [...'abc'].map(c => c.charCodeAt(0)), 0x41.toString(2)",
    onLine: (line) => new Promise((resolve) => { if (!line.trim()) return resolve(); pending = resolve; frame.contentWindow.postMessage({ __run: 1, code: line }, "*"); setTimeout(() => { if (pending === resolve) { con.print("(quá thời gian)", "e"); pending = null; resolve(); } }, 4000); }),
  });
  const onMsg = (e) => {
    if (e.source !== frame.contentWindow || !e.data || !e.data.__zjs) return;
    const { type, text } = e.data;
    if (type === "log") con.print(text);
    else if (type === "err") con.print(text, "e");
    else if (type === "ret") con.print("← " + text, "ret");
    else if (type === "done" && pending) { const p = pending; pending = null; p(); }
  };
  addEventListener("message", onMsg);
  const mo = new MutationObserver(() => { if (!document.body.contains(con.root)) { frame.remove(); removeEventListener("message", onMsg); mo.disconnect(); } });
  mo.observe(document.body, { childList: true, subtree: true });
};
