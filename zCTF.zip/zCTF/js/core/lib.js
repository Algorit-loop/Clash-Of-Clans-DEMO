/* =====================================================================
   zCTF core library — helper dùng chung + registry.
   Thứ tự nạp (server.py tự chèn): core/* → data/* → widgets/* → lessons/* → tools.js → app.js
   ===================================================================== */

/* ---------- Registry ---------- */
const LESSONS = [];        // mọi bài học (lesson()) — app sắp xếp theo TRACKS rồi order
const WIDGETS = {};        // WIDGETS[name] = (placeholderEl) => void   (đọc el.dataset để lấy tham số)
const SHELL_FS = {};       // SHELL_FS[name] = () => cây thư mục cho createShell
const NC_SERVICES = {};    // NC_SERVICES["host:port"] = (ctx) => ({ banner, prompt, onLine(line) })
const SQL_DBS = {};        // SQL_DBS[name] = "CREATE TABLE ...; INSERT ..." (dùng cho widget sql)
const GLOSSARY = [];       // { term, cat, def }

const TRACKS = [
  { id: "foundation", title: "Nền tảng", color: "#3dffa2", icon: ">_", desc: "Tư duy CTF, Linux, mạng, Python và encoding" },
  { id: "web", title: "Web Exploitation", color: "#ff6bb5", icon: "&lt;/&gt;", desc: "HTTP, injection, xác thực, lỗ hổng phía server" },
  { id: "crypto", title: "Cryptography", color: "#ffc857", icon: "k⊕", desc: "Mật mã cổ điển, XOR, AES, hash, RSA" },
  { id: "forensics", title: "Forensics", color: "#ff9a5c", icon: "0x", desc: "Phân tích file, giấu tin, gói tin, bộ nhớ" },
  { id: "reverse", title: "Reverse Engineering", color: "#5cc8ff", icon: "asm", desc: "Assembly, decompiler, dịch ngược chương trình" },
  { id: "pwn", title: "Binary Exploitation", color: "#ff5c7a", icon: "bof", desc: "Stack, buffer overflow, format string, ROP" },
  { id: "osint", title: "OSINT", color: "#7ee787", icon: "@", desc: "Tìm kiếm, định vị ảnh, dấu vết số" },
  { id: "misc", title: "Misc", color: "#a58bff", icon: "?!", desc: "Lập trình, esolang, jail, mã QR" },
  { id: "career", title: "Bước tiếp theo", color: "#8b98a9", icon: "→", desc: "Chơi giải thật, viết writeup, lộ trình dài hạn" },
];

/** Đăng ký bài học.
 * { id, track, order, title, short, time, level: 1|2|3, html, quiz: [{q, options, answer, explain}],
 *   challenges: { id: { title, pts, diff: "easy"|"med"|"hard", hash, body, hints: [], widget? } } } */
function lesson(def) {
  LESSONS.push({ quiz: [], challenges: {}, level: 1, order: 0, ...def });
}

/* ---------- HTML helpers ---------- */
const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const d64 = (s) => atob(s);
function h(html) {
  const t = document.createElement("template");
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}

/* Khối terminal: dòng "$ " = lệnh, "# " = comment, "!" = tô vàng, còn lại = output.
   Dùng dạng tagged template: sh`...` (String.raw nên backslash giữ nguyên). */
function sh(strings, ...vals) {
  const src = String.raw(strings, ...vals).replace(/^\n|\n\s*$/g, "");
  const out = src.split("\n").map((l) => {
    if (l.startsWith("$ ")) return '<span class="pr">$ </span>' + esc(l.slice(2));
    if (l.startsWith("# ") || /^\s+# /.test(l)) return '<span class="cm">' + esc(l) + "</span>";
    if (l.startsWith("!")) return '<span class="hl">' + esc(l.slice(1)) + "</span>";
    return '<span class="ou">' + esc(l) + "</span>";
  });
  return `<pre class="code" data-lang="terminal"><code>${out.join("\n")}</code></pre>`;
}
function codeBlock(lang) {
  return (strings, ...vals) => {
    const src = String.raw(strings, ...vals).replace(/^\n|\n\s*$/g, "");
    const out = src.split("\n").map((l) => (/^\s*(#|\/\/|;|--)/.test(l) ? '<span class="cm">' + esc(l) + "</span>" : esc(l)));
    return `<pre class="code" data-lang="${lang}"><code>${out.join("\n")}</code></pre>`;
  };
}
const py = codeBlock("python");
const js = codeBlock("javascript");
const c = codeBlock("c");
const txt = codeBlock("text");
const http = codeBlock("http");
const asm = codeBlock("asm");
const sql = codeBlock("sql");

/* ---------- Bytes helpers ---------- */
const utf8 = new TextEncoder();
const bytesOf = (s) => (s instanceof Uint8Array ? s : utf8.encode(String(s)));
/** chuỗi "latin1" (mỗi ký tự = 1 byte) ↔ bytes, dùng cho file nhị phân trong shell */
const latin1ToBytes = (s) => Uint8Array.from(s, (ch) => ch.charCodeAt(0) & 0xff);
const bytesToLatin1 = (b) => Array.from(b, (x) => String.fromCharCode(x)).join("");
const hexOf = (b) => Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");

/* ---------- Hash (thuần JS, chạy mọi nơi) ---------- */
function sha256Bytes(input) {
  const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const bytes = [...bytesOf(input)];
  const bitLen = bytes.length * 8;
  bytes.push(0x80);
  while (bytes.length % 64 !== 56) bytes.push(0);
  for (let i = 7; i >= 0; i--) bytes.push(i >= 4 ? Math.floor(bitLen / 2 ** (i * 8)) & 0xff : (bitLen >>> (i * 8)) & 0xff);
  let H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const rotr = (x, n) => (x >>> n) | (x << (32 - n));
  for (let o = 0; o < bytes.length; o += 64) {
    const w = new Array(64);
    for (let i = 0; i < 16; i++) w[i] = (bytes[o+i*4] << 24) | (bytes[o+i*4+1] << 16) | (bytes[o+i*4+2] << 8) | bytes[o+i*4+3];
    for (let i = 16; i < 64; i++) {
      const s0 = rotr(w[i-15], 7) ^ rotr(w[i-15], 18) ^ (w[i-15] >>> 3);
      const s1 = rotr(w[i-2], 17) ^ rotr(w[i-2], 19) ^ (w[i-2] >>> 10);
      w[i] = (w[i-16] + s0 + w[i-7] + s1) | 0;
    }
    let [a, b, cc, d, e, f, g, hh] = H;
    for (let i = 0; i < 64; i++) {
      const t1 = (hh + (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
      const t2 = ((rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) + ((a & b) ^ (a & cc) ^ (b & cc))) | 0;
      hh = g; g = f; f = e; e = (d + t1) | 0; d = cc; cc = b; b = a; a = (t1 + t2) | 0;
    }
    H = H.map((v, i) => (v + [a, b, cc, d, e, f, g, hh][i]) | 0);
  }
  return H.map((v) => (v >>> 0).toString(16).padStart(8, "0")).join("");
}
const sha256Hex = (s) => sha256Bytes(s);

function sha1Hex(input) {
  const bytes = [...bytesOf(input)];
  const bitLen = bytes.length * 8;
  bytes.push(0x80);
  while (bytes.length % 64 !== 56) bytes.push(0);
  for (let i = 7; i >= 0; i--) bytes.push(i >= 4 ? Math.floor(bitLen / 2 ** (i * 8)) & 0xff : (bitLen >>> (i * 8)) & 0xff);
  let [h0, h1, h2, h3, h4] = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0];
  const rotl = (x, n) => (x << n) | (x >>> (32 - n));
  for (let o = 0; o < bytes.length; o += 64) {
    const w = new Array(80);
    for (let i = 0; i < 16; i++) w[i] = (bytes[o+i*4] << 24) | (bytes[o+i*4+1] << 16) | (bytes[o+i*4+2] << 8) | bytes[o+i*4+3];
    for (let i = 16; i < 80; i++) w[i] = rotl(w[i-3] ^ w[i-8] ^ w[i-14] ^ w[i-16], 1);
    let [a, b, cc, d, e] = [h0, h1, h2, h3, h4];
    for (let i = 0; i < 80; i++) {
      const [f, k] = i < 20 ? [(b & cc) | (~b & d), 0x5a827999] : i < 40 ? [b ^ cc ^ d, 0x6ed9eba1] : i < 60 ? [(b & cc) | (b & d) | (cc & d), 0x8f1bbcdc] : [b ^ cc ^ d, 0xca62c1d6];
      const t = (rotl(a, 5) + f + e + k + w[i]) | 0;
      e = d; d = cc; cc = rotl(b, 30); b = a; a = t;
    }
    h0 = (h0 + a) | 0; h1 = (h1 + b) | 0; h2 = (h2 + cc) | 0; h3 = (h3 + d) | 0; h4 = (h4 + e) | 0;
  }
  return [h0, h1, h2, h3, h4].map((v) => (v >>> 0).toString(16).padStart(8, "0")).join("");
}

function md5Hex(input) {
  const bytes = [...bytesOf(input)];
  const bitLen = bytes.length * 8;
  bytes.push(0x80);
  while (bytes.length % 64 !== 56) bytes.push(0);
  for (let i = 0; i < 8; i++) bytes.push(i < 4 ? (bitLen >>> (i * 8)) & 0xff : Math.floor(bitLen / 2 ** (i * 8)) & 0xff);
  const S = [7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21];
  const K = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 2 ** 32) | 0);
  let [a0, b0, c0, d0] = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476];
  const rotl = (x, n) => (x << n) | (x >>> (32 - n));
  for (let o = 0; o < bytes.length; o += 64) {
    const M = Array.from({ length: 16 }, (_, i) => bytes[o+i*4] | (bytes[o+i*4+1] << 8) | (bytes[o+i*4+2] << 16) | (bytes[o+i*4+3] << 24));
    let [A, B, C, D] = [a0, b0, c0, d0];
    for (let i = 0; i < 64; i++) {
      let F, g;
      if (i < 16) { F = (B & C) | (~B & D); g = i; }
      else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; }
      else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      F = (F + A + K[i] + M[g]) | 0;
      A = D; D = C; C = B; B = (B + rotl(F, S[i])) | 0;
    }
    a0 = (a0 + A) | 0; b0 = (b0 + B) | 0; c0 = (c0 + C) | 0; d0 = (d0 + D) | 0;
  }
  return [a0, b0, c0, d0].map((v) => [0, 8, 16, 24].map((s) => ((v >>> s) & 0xff).toString(16).padStart(2, "0")).join("")).join("");
}

/* ---------- Tải script ngoài (vendor) một lần ---------- */
const _loaded = {};
function loadScript(src) {
  if (!_loaded[src]) {
    _loaded[src] = new Promise((res, rej) => {
      const s = document.createElement("script");
      s.src = src;
      s.onload = res;
      s.onerror = () => rej(new Error("Không tải được " + src));
      document.head.appendChild(s);
    });
  }
  return _loaded[src];
}

/* ---------- CSS riêng cho widget (không sửa css/style.css) ---------- */
function addStyle(id, css) {
  if (document.getElementById("style-" + id)) return;
  const s = document.createElement("style");
  s.id = "style-" + id;
  s.textContent = css;
  document.head.appendChild(s);
}
