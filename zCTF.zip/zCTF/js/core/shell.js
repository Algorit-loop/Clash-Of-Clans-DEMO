/* =====================================================================
   Shell engine — terminal Linux giả lập dùng chung cho bài học và trang Công cụ.

   createShell(el, opts) thay el bằng một terminal. opts:
     fs       : cây thư mục (SH.dir) hoặc tên trong SHELL_FS
     user     : "guest" (mặc định)      host: "zctf"
     home     : "/home/guest"          cwd: mặc định = home
     motd     : HTML in ra khi mở
     cmds     : { tên: async (args, stdin, ctx) => string | {html, text?} | {text, bin?} | {interactive} | null }  (throw "lỗi" để in đỏ)
     sudo     : { nopasswd: true, allow: ["/usr/bin/find", ...] }   (sudo -l / sudo <cmd>)
     height   : chiều cao vùng output (px)
     title    : tiêu đề cửa sổ
   File node: SH.file(content, {mode, owner, group, bin})  — bin: nội dung là chuỗi latin1 (mỗi ký tự 1 byte)
   Thư mục  : SH.dir({tên: node}, {mode, owner})
   Chương trình chạy được: SH.exe(async (args, ctx, stdin) => ..., {owner, mode: "-rwsr-xr-x"})  — gọi bằng ./tên hoặc đặt trong /usr/bin
      ctx.euser = owner nếu có bit SUID; ctx.readFile(path) kiểm tra quyền theo euser.
   Interactive (nc, chương trình hỏi input): trả về { interactive: { banner, prompt, onLine: async (line) => string | {out, close, prompt} } }
   ===================================================================== */

const SH = {
  dir: (children = {}, meta = {}) => ({ t: "d", c: children, mode: "drwxr-xr-x", owner: "root", ...meta }),
  file: (content = "", meta = {}) => ({ t: "f", c: content, mode: "-rw-r--r--", owner: "root", ...meta }),
  exe: (run, meta = {}) => ({ t: "f", c: "\x7fELF\x02\x01\x01\x00" + "\x00".repeat(8) + "\x02\x00\x3e\x00", bin: true, run, mode: "-rwxr-xr-x", owner: "root", ...meta }),
  /** Cây thư mục Linux tối thiểu, gộp thêm phần riêng */
  base(home = {}, user = "guest", extra = {}) {
    const d = SH.dir, f = SH.file;
    return d({
      bin: d({}),
      usr: d({ bin: d({}), share: d({}) }),
      etc: d({
        passwd: f(`root:x:0:0:root:/root:/bin/bash\n${user}:x:1000:1000::/home/${user}:/bin/bash`),
        hostname: f("zctf"),
        "os-release": f('NAME="zCTF Linux"\nVERSION="1.0"'),
        shadow: f("root:$6$Zc7f$hash_bi_mat:19000:0:99999:7:::", { mode: "-rw-r-----", group: "shadow" }),
      }),
      tmp: d({}, { mode: "drwxrwxrwt" }),
      root: d({}, { mode: "drwx------" }),
      home: d({ [user]: d(home, { owner: user }) }),
      ...extra,
    });
  },
};

const MAN = {
  ls: "ls [-a] [-l] [dir] — liệt kê file. -a: hiện file ẩn (bắt đầu bằng .), -l: chi tiết quyền/chủ/kích thước",
  cd: "cd <dir> — đổi thư mục. cd .. lên một cấp, cd ~ về thư mục nhà, cd / về gốc",
  pwd: "pwd — in đường dẫn thư mục hiện tại",
  cat: "cat <file...> — in nội dung file",
  head: "head [-n N] <file> — N dòng đầu (mặc định 10)",
  tail: "tail [-n N] <file> — N dòng cuối",
  wc: "wc [-l|-w|-c] <file> — đếm dòng / từ / byte",
  file: "file <file> — đoán loại file dựa trên magic bytes",
  strings: "strings [-n N] [-e l] <file> — in các chuỗi in được dài ≥ N (mặc định 4); -e l: chuỗi UTF-16LE",
  xxd: "xxd [-p] [-l N] <file> — hexdump. -p: chỉ hex liền",
  grep: "grep [-i -v -n -c -o -r -E] <mẫu> [file|dir] — tìm dòng khớp mẫu",
  find: "find [dir] [-name M] [-iname M] [-type f|d] [-user U] [-perm -4000] — tìm file",
  sort: "sort [-r -n -u] — sắp xếp dòng",
  uniq: "uniq [-c] — gộp dòng trùng liên tiếp (-c: đếm)",
  tr: "tr <set1> <set2> | tr -d <set> — thay/xoá ký tự. VD: tr 'A-Za-z' 'N-ZA-Mn-za-m' (ROT13)",
  rev: "rev — đảo ngược từng dòng",
  cut: "cut -d <ký tự> -f <số> | cut -c <a-b> — cắt cột",
  base64: "base64 [-d] [file] — mã hoá / giải mã Base64",
  base32: "base32 [-d] [file] — mã hoá / giải mã Base32",
  md5sum: "md5sum <file> — tính hash MD5", sha1sum: "sha1sum <file> — tính SHA-1", sha256sum: "sha256sum <file> — tính SHA-256",
  echo: "echo [-n] [-e] <text> — in chữ. -e: hiểu \\n, \\x41",
  touch: "touch <file> — tạo file rỗng", mkdir: "mkdir <dir> — tạo thư mục", rm: "rm [-r] <file> — xoá",
  cp: "cp <nguồn> <đích> — sao chép", mv: "mv <nguồn> <đích> — đổi tên / di chuyển",
  chmod: "chmod <mode> <file> — đổi quyền. VD: chmod +x a.sh, chmod 600 key",
  id: "id — UID, GID và các nhóm của bạn", whoami: "whoami — tên người dùng hiện tại",
  sudo: "sudo -l | sudo <lệnh> — chạy lệnh với quyền root (nếu được phép)",
  curl: "curl [-i -I -v -L -s] [-X M] [-H 'K: V'] [-b 'a=b'] [-d data] [-A ua] [-u user:pass] [-o file] <url> — gửi HTTP request tới lab",
  nc: "nc <host> <port> — kết nối TCP tới dịch vụ. Ctrl+C để thoát",
  history: "history — lệnh đã gõ", clear: "clear — xoá màn hình (Ctrl+L)",
  uname: "uname [-a] — thông tin hệ điều hành", env: "env — biến môi trường", date: "date — ngày giờ",
  man: "man <lệnh> — hướng dẫn ngắn của lệnh",
};

function createShell(el, opts = {}) {
  if (typeof opts.fs === "string") {
    const reg = SHELL_FS[opts.fs];
    if (!reg) throw new Error("SHELL_FS chưa có: " + opts.fs);
    if (typeof reg === "function") opts = { ...opts, fs: reg() };
    else { const { fs: mk, ...rest } = reg; opts = { ...rest, ...Object.fromEntries(Object.entries(opts).filter(([, v]) => v !== undefined)), fs: mk() }; }
  }
  const user0 = opts.user || "guest";
  const home = opts.home || (user0 === "root" ? "/root" : "/home/" + user0);
  let fs = opts.fs || SH.base();
  const split = (p) => p.split("/").filter(Boolean);
  let cwd = split(opts.cwd || home);
  const history = [];
  let hIdx = 0;
  let interactive = null;
  let busy = false;
  let lastStatus = 0;
  const env = { USER: user0, HOME: home, SHELL: "/bin/bash", PATH: "/usr/local/bin:/usr/bin:/bin", TERM: "xterm-256color", ...(opts.env || {}) };

  const root = h(`
    <div class="shell"><div class="window">
      <div class="window-bar"><i></i><i></i><i></i><span></span></div>
      <div class="shell-out" tabindex="-1" style="${opts.height ? "height:" + opts.height + "px" : ""}"></div>
    </div></div>`);
  el.replaceWith(root);
  const out = root.querySelector(".shell-out");
  const bar = root.querySelector(".window-bar span");

  const pathStr = () => {
    const p = "/" + cwd.join("/");
    return p === home || p.startsWith(home + "/") ? "~" + p.slice(home.length) : p;
  };
  const resolve = (p) => {
    if (p == null || p === "") return [...cwd];
    let parts = p.startsWith("/") ? [] : p.startsWith("~") ? split(home) : [...cwd];
    for (const s of split(p.replace(/^~/, ""))) {
      if (s === ".") continue;
      if (s === "..") parts.pop();
      else parts.push(s);
    }
    return parts;
  };
  const node = (parts) => {
    let n = fs;
    for (const s of parts) {
      if (!n || n.t !== "d" || !(s in n.c)) return null;
      n = n.c[s];
    }
    return n;
  };
  const parentOf = (parts) => node(parts.slice(0, -1));

  const groupsOf = (u) => (u === "root" ? ["root"] : [u, ...((opts.groups && opts.groups[u]) || [])]);
  const can = (n, u, what) => {
    if (u === "root") return true;
    const m = n.mode || "";
    const idx = { r: 0, w: 1, x: 2 }[what];
    if (n.owner === u) return m[1 + idx] === what || (what === "x" && /[sx]/.test(m[3]));
    if (groupsOf(u).includes(n.group || n.owner)) return m[4 + idx] === what || (what === "x" && /[sx]/.test(m[6]));
    return m[7 + idx] === what || (what === "x" && /[tx]/.test(m[9]));
  };
  const toBytes = (s, bin) => (bin ? latin1ToBytes(s) : utf8.encode(s));

  const ctx = {
    get cwd() { return "/" + cwd.join("/"); },
    get user() { return ctx._user || user0; },
    euser: null,
    env, home, opts, resolve, node, SH,
    get fs() { return fs; },
    print: (html) => print(html),
    esc,
    readNode(p, asUser) {
      const parts = resolve(p);
      const n = node(parts);
      if (!n) throw `${p}: No such file or directory`;
      const u = asUser || ctx.euser || ctx.user;
      if (n.t === "d") throw `${p}: Is a directory`;
      if (!can(n, u, "r")) throw `${p}: Permission denied`;
      return n;
    },
    readFile(p, asUser) { return ctx.readNode(p, asUser).c; },
    readBytes(p, asUser) { const n = ctx.readNode(p, asUser); return toBytes(n.c, n.bin); },
    writeFile(p, content, { append = false, bin = false } = {}) {
      const parts = resolve(p);
      const dir = parentOf(parts);
      if (!dir || dir.t !== "d") throw `${p}: No such file or directory`;
      const name = parts[parts.length - 1];
      const ex = dir.c[name];
      const u = ctx.euser || ctx.user;
      if (ex && ex.t === "d") throw `${p}: Is a directory`;
      if (ex ? !can(ex, u, "w") : !can(dir, u, "w")) throw `${p}: Permission denied`;
      if (ex && append) ex.c += content;
      else dir.c[name] = SH.file(content, { owner: u, mode: ex ? ex.mode : "-rw-r--r--", bin });
    },
    stdinBytes: null,
  };

  const print = (html, cls) => {
    const line = document.createElement("div");
    if (cls) line.className = cls;
    line.innerHTML = html;
    out.insertBefore(line, inputLine);
    out.scrollTop = out.scrollHeight;
  };

  /* ---------- tiện ích ---------- */
  const flagsOf = (a) => a.filter((x) => /^-[A-Za-z]+$/.test(x)).join("").replace(/-/g, "");
  const nonFlags = (a) => a.filter((x) => !/^-[A-Za-z]+$/.test(x));
  const takeOpt = (a, name) => {
    const i = a.indexOf(name);
    if (i >= 0) { const v = a[i + 1]; a.splice(i, 2); return v; }
    const j = a.findIndex((x) => x.startsWith(name) && x.length > name.length);
    if (j >= 0) { const v = a[j].slice(name.length); a.splice(j, 1); return v; }
    return null;
  };
  const inputText = (files, stdin) => (files.length ? files.map((f) => ctx.readFile(f)).join("\n") : stdin ?? "");
  const inputBytes = (files, stdin) => {
    if (files.length) return ctx.readBytes(files[0]);
    if (ctx.stdinBytes) return ctx.stdinBytes;
    return utf8.encode(stdin ?? "");
  };
  const lines = (t) => { const L = t.split("\n"); if (L.length && L[L.length - 1] === "") L.pop(); return L; };
  const expandSet = (s) => {
    s = s.replace(/\[:upper:\]/g, "A-Z").replace(/\[:lower:\]/g, "a-z").replace(/\[:digit:\]/g, "0-9").replace(/\[:alpha:\]/g, "A-Za-z").replace(/\[:space:\]/g, " \t\n");
    s = s.replace(/\\n/g, "\n").replace(/\\t/g, "\t").replace(/\\x([0-9a-fA-F]{2})/g, (_, x) => String.fromCharCode(parseInt(x, 16))).replace(/\\([0-7]{1,3})/g, (_, o) => String.fromCharCode(parseInt(o, 8)));
    let r = "";
    for (let i = 0; i < s.length; i++) {
      if (s[i + 1] === "-" && i + 2 < s.length) { for (let k = s.charCodeAt(i); k <= s.charCodeAt(i + 2); k++) r += String.fromCharCode(k); i += 2; }
      else r += s[i];
    }
    return r;
  };
  const detect = (b) => {
    const hx = hexOf(b.slice(0, 16));
    const t = bytesToLatin1(b.slice(0, 64));
    if (!b.length) return "empty";
    if (hx.startsWith("89504e470d0a1a0a")) return "PNG image data";
    if (hx.startsWith("ffd8ff")) return "JPEG image data";
    if (t.startsWith("GIF8")) return "GIF image data";
    if (t.startsWith("%PDF")) return "PDF document, version " + t.slice(5, 8);
    if (hx.startsWith("504b0304")) return "Zip archive data";
    if (hx.startsWith("1f8b")) return "gzip compressed data";
    if (hx.startsWith("7f454c46")) return "ELF 64-bit LSB executable, x86-64, dynamically linked, not stripped";
    if (t.startsWith("MZ")) return "PE32 executable (console) Intel 80386, for MS Windows";
    if (hx.startsWith("d4c3b2a1") || hx.startsWith("0a0d0d0a")) return "pcap capture file";
    if (t.startsWith("RIFF") && t.slice(8, 12) === "WAVE") return "RIFF (little-endian) data, WAVE audio";
    if (t.startsWith("ID3") || hx.startsWith("fffb")) return "Audio file with ID3, MPEG layer III";
    if (t.startsWith("#!")) return "script, ASCII text executable";
    if (t.startsWith("-----BEGIN")) return "PEM " + (t.includes("PRIVATE") ? "private key" : "certificate");
    if (hx.startsWith("cafebabe")) return "compiled Java class data";
    if (hx.startsWith("420d0d0a") || hx.startsWith("550d0d0a") || hx.startsWith("610d0d0a") || hx.startsWith("a70d0d0a") || hx.startsWith("cb0d0d0a")) return "python 3 byte-compiled";
    const bad = [...b.slice(0, 512)].filter((x) => x < 9 || (x > 13 && x < 32)).length;
    if (bad) return "data";
    return [...b].some((x) => x > 127) ? "UTF-8 Unicode text" : "ASCII text";
  };
  const b32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const sumOf = (fn, a, stdin) => {
    const files = nonFlags(a);
    if (!files.length) return fn(inputBytes([], stdin)) + "  -";
    return files.map((f) => { try { return fn(ctx.readBytes(f)) + "  " + f; } catch (e) { return `sum: ${e}`; } }).join("\n");
  };

  /* ---------- lệnh có sẵn ---------- */
  const cmds = {
    help: () =>
      `<span class="hl">Lệnh có sẵn</span> (gõ <span class="hl">man &lt;lệnh&gt;</span> để xem chi tiết):\n` +
      Object.keys({ ...MAN, ...(opts.cmds || {}) }).filter((k) => !k.startsWith("_")).sort().join("  ") +
      `\n\nHỗ trợ: pipe <span class="hl">|</span>, ghi file <span class="hl">&gt;</span> <span class="hl">&gt;&gt;</span>, nối lệnh <span class="hl">;</span> <span class="hl">&amp;&amp;</span>, Tab để gợi ý, ↑↓ lịch sử, Ctrl+C dừng, Ctrl+L xoá màn hình.`,
    man: (a) => { if (!a[0]) throw "What manual page do you want?"; const m = MAN[a[0]]; if (!m) throw `No manual entry for ${a[0]}`; return m; },
    pwd: () => ctx.cwd,
    whoami: () => ctx.euser || ctx.user,
    id: () => { const u = ctx.euser || ctx.user; const uid = u === "root" ? 0 : 1000; const g = groupsOf(u); return `uid=${uid}(${u}) gid=${uid}(${g[0]}) groups=${g.map((x, i) => `${i ? (opts.gids && opts.gids[x]) ?? 1000 + i : uid}(${x})`).join(",")}`; },
    hostname: () => opts.host || "zctf",
    uname: (a) => (a.includes("-a") ? `Linux ${opts.host || "zctf"} 6.8.0-zctf #1 SMP x86_64 GNU/Linux` : "Linux"),
    date: () => new Date().toString(),
    env: () => Object.entries(env).map(([k, v]) => `${k}=${v}`).join("\n"),
    export: (a) => { a.forEach((kv) => { const [k, ...v] = kv.split("="); env[k] = v.join("="); }); return null; },
    clear: () => { [...out.children].forEach((d) => d !== inputLine && d.remove()); return null; },
    history: () => history.map((x, i) => `  ${String(i + 1).padStart(3)}  ${esc(x)}`).join("\n"),
    exit: () => "logout (terminal này không đóng được, cứ tiếp tục nhé)",
    echo: (a) => {
      let n = false, e = false;
      while (a[0] && /^-[ne]+$/.test(a[0])) { n ||= a[0].includes("n"); e ||= a[0].includes("e"); a.shift(); }
      let s = a.join(" ");
      if (e) s = s.replace(/\\x([0-9a-fA-F]{2})/g, (_, x) => String.fromCharCode(parseInt(x, 16))).replace(/\\n/g, "\n").replace(/\\t/g, "\t").replace(/\\\\/g, "\\");
      return { text: s, raw: true, noNewline: n };
    },
    printf: (a) => {
      if (!a.length) throw "printf: usage: printf format [arguments]";
      let fmt = a[0], args = a.slice(1), out = "";
      const unesc = (x) => x.replace(/\\x([0-9a-fA-F]{2})/g, (_, hx) => String.fromCharCode(parseInt(hx, 16))).replace(/\\([0-7]{1,3})/g, (_, o) => String.fromCharCode(parseInt(o, 8))).replace(/\\n/g, "\n").replace(/\\t/g, "\t").replace(/\\\\/g, "\\");
      do {
        out += unesc(fmt).replace(/%(-?\d*)([sdxXoc%])/g, (_, w, t) => {
          if (t === "%") return "%";
          const v = args.shift() ?? "";
          let r = t === "s" ? v : t === "c" ? v[0] || "" : (() => { const n = parseInt(v) || 0; return t === "d" ? String(n) : t === "x" ? n.toString(16) : t === "X" ? n.toString(16).toUpperCase() : n.toString(8); })();
          const wd = Math.abs(parseInt(w) || 0);
          return w.startsWith("-") ? r.padEnd(wd) : r.padStart(wd, w.startsWith("0") && t !== "s" ? "0" : " ");
        });
      } while (args.length && /%[sdxXoc]/.test(fmt));
      return { text: out, raw: true, noNewline: true, bin: /[\x80-\xff]/.test(out) && !/[^\x00-\xff]/.test(out) };
    },
    cd: (a) => {
      const target = resolve(a[0] || "~");
      const n = node(target);
      if (!n) throw `cd: ${a[0]}: No such file or directory`;
      if (n.t !== "d") throw `cd: ${a[0]}: Not a directory`;
      if (!can(n, ctx.euser || ctx.user, "x")) throw `cd: ${a[0]}: Permission denied`;
      cwd = target;
      return null;
    },
    ls: (a) => {
      const fl = flagsOf(a);
      const all = fl.includes("a"), long = fl.includes("l");
      const targets = nonFlags(a);
      const one = (p) => {
        const n = node(resolve(p));
        if (!n) throw `ls: cannot access '${p}': No such file or directory`;
        if (n.t === "f") return long ? fmt(p.split("/").pop(), n) : colorName(p, n);
        if (!can(n, ctx.euser || ctx.user, "r")) throw `ls: cannot open directory '${p || "."}': Permission denied`;
        let names = Object.keys(n.c).sort((x, y) => x.replace(/^\./, "").localeCompare(y.replace(/^\./, "")));
        if (!all) names = names.filter((x) => !x.startsWith("."));
        const entries = (all ? [[".", n], ["..", n]] : []).concat(names.map((k) => [k, n.c[k]]));
        if (long) return `total ${entries.length * 4}\n` + entries.map(([k, v]) => fmt(k, v)).join("\n");
        return entries.map(([k, v]) => colorName(k, v)).join("  ");
      };
      const colorName = (k, v) => (v.t === "d" ? `<span class="d">${esc(k)}</span>` : /x|s/.test((v.mode || "").slice(1)) && v.run ? `<span class="x">${esc(k)}</span>` : esc(k));
      const fmt = (k, v) => {
        const size = v.t === "f" ? (v.bin ? v.c.length : utf8.encode(v.c).length) : 4096;
        const suid = /s/.test(v.mode || "") ? ` <span class="e">${esc(k)}</span>` : " " + colorName(k, v);
        return `${(v.mode || "-rw-r--r--").padEnd(10)} 1 ${(v.owner || "root").padEnd(6)} ${(v.group || v.owner || "root").padEnd(6)} ${String(size).padStart(6)} Nov 10 09:00${suid}`;
      };
      if (targets.length <= 1) return { html: one(targets[0]) };
      const files = targets.filter((t) => { const n = node(resolve(t)); return n && n.t === "f"; });
      const others = targets.filter((t) => !files.includes(t));
      const partsOut = [];
      if (files.length) partsOut.push(files.map((f) => one(f)).join(long ? "\n" : "  "));
      others.forEach((t) => partsOut.push(`${esc(t)}:\n${one(t)}`));
      return { html: partsOut.join("\n\n") };
    },
    cat: (a, stdin) => {
      const files = nonFlags(a);
      if (!files.length) return { text: stdin ?? "", raw: true, bin: !!ctx.stdinBytes };
      const nodes = files.map((f) => ctx.readNode(f));
      return { text: nodes.map((n) => n.c).join(""), raw: true, bin: nodes.some((n) => n.bin) };
    },
    head: (a, stdin) => { const n = parseInt(takeOpt(a, "-n") || (a.find((x) => /^-\d+$/.test(x)) || "-10").slice(1)); return lines(inputText(nonFlags(a).filter((x) => !/^-\d+$/.test(x)), stdin)).slice(0, n).join("\n"); },
    tail: (a, stdin) => { const n = parseInt(takeOpt(a, "-n") || (a.find((x) => /^-\d+$/.test(x)) || "-10").slice(1)); return lines(inputText(nonFlags(a).filter((x) => !/^-\d+$/.test(x)), stdin)).slice(-n).join("\n"); },
    wc: (a, stdin) => {
      const fl = flagsOf(a); const files = nonFlags(a);
      const t = inputText(files, stdin);
      const L = t ? t.split("\n").length - (t.endsWith("\n") ? 1 : 0) : 0, W = t.split(/\s+/).filter(Boolean).length, C = files.length ? inputBytes(files).length : utf8.encode(t).length;
      const r = fl.includes("l") ? [L] : fl.includes("w") ? [W] : fl.includes("c") ? [C] : [L, W, C];
      return r.join(" ") + (files[0] ? " " + files[0] : "");
    },
    file: (a) => {
      if (!a.length) throw "Usage: file <file>";
      return a.map((p) => { const n = node(resolve(p)); if (!n) return `${p}: cannot open \`${p}' (No such file or directory)`; if (n.t === "d") return `${p}: directory`; if (!can(n, ctx.euser || ctx.user, "r")) return `${p}: regular file, no read permission`; return `${p}: ${detect(toBytes(n.c, n.bin))}`; }).join("\n");
    },
    strings: (a, stdin) => {
      const n = parseInt(takeOpt(a, "-n") || "4");
      const encOpt = takeOpt(a, "-e");
      const b = inputBytes(nonFlags(a), stdin);
      const res = []; let cur = "";
      if (encOpt === "l" || encOpt === "b") {
        for (let i = 0; i + 1 < b.length; i += 2) {
          const [lo, hi] = encOpt === "l" ? [b[i], b[i + 1]] : [b[i + 1], b[i]];
          if (hi === 0 && lo >= 32 && lo < 127) cur += String.fromCharCode(lo); else { if (cur.length >= n) res.push(cur); cur = ""; }
        }
        if (cur.length >= n) res.push(cur);
        return res.join("\n");
      }
      for (const x of b) { if (x >= 32 && x < 127) cur += String.fromCharCode(x); else { if (cur.length >= n) res.push(cur); cur = ""; } }
      if (cur.length >= n) res.push(cur);
      return res.join("\n");
    },
    xxd: (a, stdin) => {
      const len = takeOpt(a, "-l"); const plain = a.includes("-p");
      let b = inputBytes(nonFlags(a), stdin);
      if (len) b = b.slice(0, parseInt(len));
      if (plain) return (hexOf(b).match(/.{1,60}/g) || []).join("\n");
      const L = [];
      for (let o = 0; o < b.length; o += 16) {
        const row = b.slice(o, o + 16);
        const hx = (hexOf(row).match(/.{1,4}/g) || []).join(" ");
        L.push(`${o.toString(16).padStart(8, "0")}: ${hx.padEnd(39)}  ${esc([...row].map((x) => (x >= 32 && x < 127 ? String.fromCharCode(x) : ".")).join(""))}`);
      }
      return { html: L.join("\n") };
    },
    grep: (a, stdin) => {
      const fl = flagsOf(a);
      const rest = nonFlags(a);
      const pat = rest[0];
      if (pat == null) throw "Usage: grep [OPTION]... PATTERNS [FILE]...";
      const src = fl.includes("E") || fl.includes("P") ? pat : pat.replace(/[+?|{}()]/g, "\\$&").replace(/\\\\([+?|{}()])/g, "$1");
      let re;
      try { re = new RegExp(src, fl.includes("i") ? "i" : ""); } catch { throw "grep: Invalid regular expression"; }
      const reG = new RegExp(re.source, re.flags + "g");
      const inv = fl.includes("v"), num = fl.includes("n"), cnt = fl.includes("c"), only = fl.includes("o");
      const res = [], raw = [];
      let count = 0;
      const mark = (l) => {
        let r = "", lastI = 0;
        l.replace(reG, (m, ...rest) => { const off = rest[rest.length - 2]; r += esc(l.slice(lastI, off)) + `<span class="hl">${esc(m)}</span>`; lastI = off + m.length; return m; });
        return r + esc(l.slice(lastI));
      };
      const scan = (text, prefix) => lines(text).forEach((l, i) => {
        const hit = re.test(l);
        if (hit === inv) return;
        count++;
        const pre = (prefix ? `<span class="d">${esc(prefix)}</span>:` : "") + (num ? `<span class="x">${i + 1}</span>:` : "");
        const preT = (prefix ? prefix + ":" : "") + (num ? i + 1 + ":" : "");
        if (only && !inv) { (l.match(reG) || []).forEach((m) => { res.push(pre + `<span class="hl">${esc(m)}</span>`); raw.push(preT + m); }); return; }
        res.push(pre + (inv ? esc(l) : mark(l)));
        raw.push(preT + l);
      });
      if (rest.length < 2) scan(stdin ?? "");
      else for (const target of rest.slice(1)) {
        const n = node(resolve(target));
        if (!n) throw `grep: ${target}: No such file or directory`;
        if (n.t === "d") {
          if (!/[rR]/.test(fl)) throw `grep: ${target}: Is a directory`;
          const walk = (nd, p) => Object.entries(nd.c).forEach(([k, v]) => { if (v.t === "d") { if (can(v, ctx.euser || ctx.user, "r")) walk(v, p + "/" + k); } else if (can(v, ctx.euser || ctx.user, "r") && !v.bin) scan(v.c, p + "/" + k); });
          walk(n, target.replace(/\/$/, ""));
        } else scan(ctx.readFile(target), rest.length > 2 ? target : "");
      }
      if (cnt) return String(count);
      return { html: res.join("\n"), text: raw.join("\n") };
    },
    find: async (a) => {
      let start = ".", name = null, iname = false, type = null, usr = null, perm = null, execCmd = null;
      for (let i = 0; i < a.length; i++) {
        const x = a[i];
        if (x === "-name" || x === "-iname") { name = a[++i]; iname = x === "-iname"; }
        else if (x === "-type") type = a[++i];
        else if (x === "-user") usr = a[++i];
        else if (x === "-perm") perm = a[++i];
        else if (x === "-exec") { const e = a.indexOf(";", i); execCmd = a.slice(i + 1, e < 0 ? a.length : e); break; }
        else if (!x.startsWith("-")) start = x;
      }
      const n = node(resolve(start));
      if (!n) throw `find: '${start}': No such file or directory`;
      const re = name ? new RegExp("^" + name.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".") + "$", iname ? "i" : "") : null;
      const ok = (k, v) => (!re || re.test(k)) && (!type || (type === "d") === (v.t === "d")) && (!usr || v.owner === usr) && (!perm || (/4000|u=s|-u=s/.test(perm) ? /s/.test((v.mode || "").slice(1, 4)) : /2000|g=s/.test(perm) ? /s/.test((v.mode || "").slice(4, 7)) : true));
      const res = [], errs = [];
      const walk = (nd, p) => {
        if (nd.t !== "d") return;
        if (!can(nd, ctx.euser || ctx.user, "r")) { errs.push(`find: '${p}': Permission denied`); return; }
        for (const [k, v] of Object.entries(nd.c)) { const full = (p === "/" ? "" : p) + "/" + k; if (ok(k, v)) res.push(full); walk(v, full); }
      };
      if (ok(start.split("/").pop() || start, n)) res.push(start);
      walk(n, start === "/" ? "/" : start.replace(/\/$/, ""));
      if (execCmd && execCmd.length) {
        const outs = [];
        for (const r of res) {
          try { outs.push(outText(await exec(execCmd.map((x) => (x === "{}" ? r : x)), null))); }
          catch (e) { if (!ctx.quiet) outs.push(String(e)); }
        }
        return { text: outs.filter((x) => x !== "").join("\n").replace(/\n+$/, "") };
      }
      return { html: [...res.map(esc), ...(ctx.quiet ? [] : errs.map((e) => `<span class="e">${esc(e)}</span>`))].join("\n"), text: res.join("\n") };
    },
    sort: (a, stdin) => {
      const t = takeOpt(a, "-t"), k = takeOpt(a, "-k");
      const fl = flagsOf(a);
      let L = lines(inputText(nonFlags(a), stdin));
      const key = (l) => {
        if (!k) return l;
        const [f1, f2] = k.split(",").map((x) => parseInt(x));
        const parts = t != null ? l.split(t) : l.trim().split(/\s+/);
        return parts.slice(f1 - 1, f2 ? f2 : f1).join(t ?? " ");
      };
      const num = fl.includes("n") || /n/.test(k || "");
      L.sort((x, y) => { const a1 = key(x), b1 = key(y); return num ? (parseFloat(a1) || 0) - (parseFloat(b1) || 0) : a1 < b1 ? -1 : a1 > b1 ? 1 : 0; });
      if (fl.includes("r") || /r/.test(k || "")) L.reverse();
      if (fl.includes("u")) L = [...new Set(L)];
      return L.join("\n");
    },
    uniq: (a, stdin) => {
      const L = lines(inputText(nonFlags(a), stdin)); const r = [];
      for (const l of L) { if (r.length && r[r.length - 1][0] === l) r[r.length - 1][1]++; else r.push([l, 1]); }
      return r.map(([l, n]) => (a.includes("-c") ? String(n).padStart(7) + " " : "") + l).join("\n");
    },
    tr: (a, stdin) => {
      const s = stdin ?? "";
      if (a[0] === "-d") { const set = expandSet(a[1] || ""); return [...s].filter((ch) => !set.includes(ch)).join(""); }
      const s1 = expandSet(a[0] || ""), s2 = expandSet(a[1] || "");
      if (!s2) throw "tr: missing operand";
      return [...s].map((ch) => { const i = s1.indexOf(ch); return i < 0 ? ch : s2[Math.min(i, s2.length - 1)]; }).join("");
    },
    rev: (a, stdin) => lines(inputText(nonFlags(a), stdin)).map((l) => [...l].reverse().join("")).join("\n"),
    cut: (a, stdin) => {
      const d = takeOpt(a, "-d"); const f = takeOpt(a, "-f"); const cc = takeOpt(a, "-c");
      const pick = (spec, arr) => spec.split(",").flatMap((r) => { const [x, y] = r.split("-"); const s = parseInt(x || "1"), e = r.includes("-") ? (y ? parseInt(y) : arr.length) : s; return arr.slice(s - 1, e); });
      return lines(inputText(nonFlags(a), stdin)).map((l) => (cc ? pick(cc, [...l]).join("") : pick(f || "1", l.split(d ?? "\t")).join(d ?? "\t"))).join("\n");
    },
    base64: (a, stdin) => {
      const files = nonFlags(a);
      if (a.includes("-d") || a.includes("--decode")) {
        const t = (files.length ? ctx.readFile(files[0]) : stdin ?? "").replace(/\s+/g, "");
        try { const raw = atob(t); return { text: raw, bin: true }; } catch { throw "base64: invalid input"; }
      }
      const b = inputBytes(files, stdin);
      return (btoa(bytesToLatin1(b)).match(/.{1,76}/g) || [""]).join("\n");
    },
    base32: (a, stdin) => {
      const files = nonFlags(a);
      if (a.includes("-d")) {
        const t = (files.length ? ctx.readFile(files[0]) : stdin ?? "").replace(/[\s=]/g, "").toUpperCase();
        let bits = "", outb = [];
        for (const ch of t) { const v = b32.indexOf(ch); if (v < 0) throw "base32: invalid input"; bits += v.toString(2).padStart(5, "0"); }
        for (let i = 0; i + 8 <= bits.length; i += 8) outb.push(parseInt(bits.slice(i, i + 8), 2));
        return { text: bytesToLatin1(outb), bin: true };
      }
      const b = inputBytes(files, stdin);
      let bits = [...b].map((x) => x.toString(2).padStart(8, "0")).join(""), r = "";
      for (let i = 0; i < bits.length; i += 5) r += b32[parseInt(bits.slice(i, i + 5).padEnd(5, "0"), 2)];
      return r + "=".repeat((8 - (r.length % 8)) % 8);
    },
    md5sum: (a, stdin) => sumOf(md5Hex, a, stdin),
    sha1sum: (a, stdin) => sumOf(sha1Hex, a, stdin),
    sha256sum: (a, stdin) => sumOf(sha256Bytes, a, stdin),
    touch: (a) => { a.forEach((p) => { if (!node(resolve(p))) ctx.writeFile(p, ""); }); return null; },
    mkdir: (a) => {
      nonFlags(a).forEach((p) => {
        const parts = resolve(p); const dir = parentOf(parts);
        if (!dir) throw `mkdir: cannot create directory '${p}': No such file or directory`;
        if (dir.c[parts.at(-1)]) throw `mkdir: cannot create directory '${p}': File exists`;
        if (!can(dir, ctx.euser || ctx.user, "w")) throw `mkdir: cannot create directory '${p}': Permission denied`;
        dir.c[parts.at(-1)] = SH.dir({}, { owner: ctx.euser || ctx.user });
      });
      return null;
    },
    rm: (a) => {
      const rec = /r/i.test(flagsOf(a));
      nonFlags(a).forEach((p) => {
        const parts = resolve(p); const dir = parentOf(parts); const n = node(parts);
        if (!n) throw `rm: cannot remove '${p}': No such file or directory`;
        if (n.t === "d" && !rec) throw `rm: cannot remove '${p}': Is a directory`;
        if (!can(dir, ctx.euser || ctx.user, "w")) throw `rm: cannot remove '${p}': Permission denied`;
        delete dir.c[parts.at(-1)];
      });
      return null;
    },
    cp: (a) => { const [s, d] = nonFlags(a); const n = ctx.readNode(s); let dp = d; const dn = node(resolve(d)); if (dn && dn.t === "d") dp = d + "/" + s.split("/").pop(); ctx.writeFile(dp, n.c, { bin: n.bin }); return null; },
    mv: (a) => { const [s, d] = nonFlags(a); cmds.cp([s, d]); cmds.rm([s]); return null; },
    chmod: (a) => {
      const [m, p] = nonFlags(a);
      const n = node(resolve(p));
      if (!n) throw `chmod: cannot access '${p}': No such file or directory`;
      if (n.owner !== (ctx.euser || ctx.user) && (ctx.euser || ctx.user) !== "root") throw `chmod: changing permissions of '${p}': Operation not permitted`;
      const t = n.t === "d" ? "d" : "-";
      if (/^[0-7]{3,4}$/.test(m)) {
        const o = m.slice(-3); const sp = m.length === 4 ? +m[0] : 0;
        const tri = (d, s, ch) => { const r = (d & 4 ? "r" : "-") + (d & 2 ? "w" : "-"); const x = d & 1; return r + (s ? (x ? ch : ch.toUpperCase()) : x ? "x" : "-"); };
        n.mode = t + tri(+o[0], sp & 4, "s") + tri(+o[1], sp & 2, "s") + tri(+o[2], sp & 1, "t");
      } else {
        const mm = m.match(/^([ugoa]*)([+-=])([rwxs]+)$/);
        if (!mm) throw `chmod: invalid mode: '${m}'`;
        const who = mm[1] || "a"; const arr = n.mode.split("");
        const set = (i, ch) => (arr[i] = mm[2] === "-" ? "-" : ch);
        for (const w of who === "a" ? "ugo" : who) {
          const base = { u: 1, g: 4, o: 7 }[w];
          for (const ch of mm[3]) { if (ch === "s") { if (w !== "o") set(base + 2, "s"); } else set(base + "rwx".indexOf(ch), ch); }
        }
        n.mode = arr.join("");
      }
      return null;
    },
    sudo: async (a) => {
      const cfg = opts.sudo;
      if (a[0] === "-l") {
        if (!cfg) return `Sorry, user ${ctx.user} may not run sudo on ${opts.host || "zctf"}.`;
        return `User ${ctx.user} may run the following commands on ${opts.host || "zctf"}:\n` + cfg.allow.map((x) => `    (root) ${cfg.nopasswd ? "NOPASSWD: " : ""}${x}`).join("\n");
      }
      if (!cfg) throw `${ctx.user} is not in the sudoers file.  This incident will be reported.`;
      const cmd = a[0];
      const allowed = cfg.allow.some((x) => x === "ALL" || x.split(" ")[0].split("/").pop() === cmd || x.split(" ")[0] === cmd);
      if (!allowed) throw `Sorry, user ${ctx.user} is not allowed to execute '${a.join(" ")}' as root on ${opts.host || "zctf"}.`;
      const prev = ctx.euser; ctx.euser = "root";
      try { return await exec(a, null); } finally { ctx.euser = prev; }
    },
    nc: (a) => {
      const args = nonFlags(a);
      if (args.length < 2) throw "usage: nc <host> <port>";
      const key = `${args[0]}:${args[1]}`;
      const svc = NC_SERVICES[key] || (opts.nc && opts.nc[key]);
      if (!svc) throw `nc: connect to ${args[0]} port ${args[1]} (tcp) failed: Connection refused`;
      return { interactive: svc(ctx) };
    },
    ping: (a) => { const host = nonFlags(a)[0]; if (!host) throw "ping: usage error: Destination address required"; return `PING ${host} 56(84) bytes of data.\n64 bytes from ${host}: icmp_seq=1 ttl=64 time=0.42 ms\n64 bytes from ${host}: icmp_seq=2 ttl=64 time=0.39 ms\n--- ${host} ping statistics ---\n2 packets transmitted, 2 received, 0% packet loss`; },
    python: () => "Python thật có ở trang Công cụ → tab Python (hoặc widget Python trong bài học).",
    python3: () => cmds.python(),
    curl: async (a) => {
      const o = { method: null, headers: {}, data: null, include: false, head: false, verbose: false, follow: false, out: null };
      let url = null;
      for (let i = 0; i < a.length; i++) {
        const x = a[i];
        if (x === "-X" || x === "--request") o.method = a[++i];
        else if (x === "-H" || x === "--header") { const [k, ...v] = a[++i].split(":"); o.headers[k.trim()] = v.join(":").trim(); }
        else if (x === "-b" || x === "--cookie") o.headers["Cookie"] = a[++i];
        else if (x === "-d" || x === "--data" || x === "--data-raw" || x === "--data-urlencode") { o.data = o.data ? o.data + "&" + a[++i] : a[++i]; }
        else if (x === "-A" || x === "--user-agent") o.headers["User-Agent"] = a[++i];
        else if (x === "-e" || x === "--referer") o.headers["Referer"] = a[++i];
        else if (x === "-u" || x === "--user") o.headers["Authorization"] = "Basic " + btoa(a[++i]);
        else if (x === "-o" || x === "--output") o.out = a[++i];
        else if (/^-[a-zA-Z]+$/.test(x)) { if (x.includes("i")) o.include = true; if (x.includes("I")) o.head = true; if (x.includes("v")) o.verbose = true; if (x.includes("L")) o.follow = true; }
        else if (x.startsWith("--")) { if (x === "--include") o.include = true; if (x === "--head") o.head = true; if (x === "--location") o.follow = true; if (x === "--verbose") o.verbose = true; }
        else url = x;
      }
      if (!url) throw "curl: no URL specified!";
      let path;
      if (url.startsWith("/")) path = url;
      else {
        const m = url.match(/^(?:https?:\/\/)?([^/?#]+)(.*)$/);
        const host = m ? m[1].replace(/:\d+$/, "") : url;
        if (!m || !["lab.zctf.local", "localhost", "127.0.0.1", location.hostname].includes(host))
          throw `curl: (6) Could not resolve host: ${host}\n(Terminal giả lập chỉ truy cập được lab nội bộ: http://lab.zctf.local/lab/...)`;
        path = m[2] || "/";
        if (!path.startsWith("/")) path = "/" + path;
      }
      const method = o.method || (o.head ? "HEAD" : o.data != null ? "POST" : "GET");
      if (o.data != null && !Object.keys(o.headers).some((k) => k.toLowerCase() === "content-type")) o.headers["Content-Type"] = "application/x-www-form-urlencoded";
      let r;
      try {
        const resp = await fetch("/__curl", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ method, path, headers: o.headers, body: o.data, follow: o.follow }) });
        r = await resp.json();
        if (!resp.ok) throw r.detail || "proxy error";
      } catch (e) { throw "curl: (7) Failed to connect: " + (e.message || e); }
      const parts = [];
      if (o.verbose) {
        parts.push(`<span class="m">&gt; ${esc(method)} ${esc(path)} HTTP/1.1\n&gt; Host: lab.zctf.local\n&gt; User-Agent: ${esc(o.headers["User-Agent"] || "curl/8.5.0")}\n${Object.entries(o.headers).filter(([k]) => k !== "User-Agent").map(([k, v]) => `&gt; ${esc(k)}: ${esc(v)}`).join("\n")}\n&gt;</span>`);
      }
      const headTxt = `HTTP/1.1 ${r.status} ${r.reason}\n` + r.headers.map(([k, v]) => `${k}: ${v}`).join("\n");
      if (o.include || o.head || o.verbose) parts.push(o.verbose ? `<span class="m">${esc(headTxt).replace(/^/gm, "&lt; ")}</span>` : `<span class="x">${esc(headTxt)}</span>\n`);
      if (o.out) { ctx.writeFile(o.out, r.body); parts.push(`<span class="m">  % Total    % Received\n100  ${r.body.length}  100  ${r.body.length}</span>`); }
      else if (!o.head) parts.push(esc(r.body));
      return { html: parts.join("\n"), text: (o.include ? headTxt + "\n\n" : "") + (o.head ? "" : r.body) };
    },
    ...(opts.cmds || {}),
  };

  /* ---------- phân tích dòng lệnh ---------- */
  function tokenize(line) {
    const toks = []; let cur = "", q = null, has = false, g = false;
    const push = () => { if (cur || has) toks.push(g ? { glob: cur } : cur); cur = ""; has = false; g = false; };
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (q) { if (ch === q) q = null; else if (ch === "\\" && q === '"' && /["\\$]/.test(line[i + 1])) cur += line[++i]; else cur += ch; continue; }
      if (ch === "'" || ch === '"') { q = ch; has = true; continue; }
      if (ch === "\\" && i + 1 < line.length) { cur += line[++i]; has = true; continue; }
      if (/\s/.test(ch)) { push(); continue; }
      if (ch === "|" || ch === ";" || ch === ">" || ch === "<" || ch === "&") {
        push();
        if (ch === ">" && line[i + 1] === ">") { toks.push({ op: ">>" }); i++; }
        else if (ch === "&" && line[i + 1] === "&") { toks.push({ op: "&&" }); i++; }
        else if (ch === "|" && line[i + 1] === "|") { toks.push({ op: "||" }); i++; }
        else toks.push({ op: ch });
        continue;
      }
      if (ch === "$" && line[i + 1] === "?") { cur += "\u0000ST\u0000"; i++; continue; }
      if (ch === "$" && /[A-Za-z_{]/.test(line[i + 1] || "")) {
        const mm = line.slice(i + 1).match(/^\{?([A-Za-z_][A-Za-z0-9_]*)\}?/);
        cur += env[mm[1]] ?? ""; i += mm[0].length; continue;
      }
      if (ch === "~" && !cur && (line[i + 1] === undefined || line[i + 1] === "/" || /\s/.test(line[i + 1]))) { cur += home; continue; }
      if (ch === "*" || ch === "?") g = true;
      cur += ch;
    }
    if (q) throw "syntax error: unterminated quote";
    push();
    return toks;
  }

  const word = (t) => (t && typeof t === "object" && t.glob != null ? t.glob : t);
  function expandGlob(pat) {
    const abs = pat.startsWith("/");
    const segsP = pat.split("/").filter((x, i) => x || i === 0);
    let paths = [{ parts: abs ? [] : [...cwd], shown: abs ? "" : null }];
    for (const seg of segsP) {
      if (seg === "" ) continue;
      const next = [];
      for (const pp of paths) {
        const join = (name) => (pp.shown == null ? name : pp.shown + "/" + name);
        if (!/[*?]/.test(seg)) { next.push({ parts: seg === ".." ? pp.parts.slice(0, -1) : seg === "." ? pp.parts : [...pp.parts, seg], shown: join(seg) }); continue; }
        const n = node(pp.parts);
        if (!n || n.t !== "d") continue;
        const re = new RegExp("^" + seg.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".") + "$");
        Object.keys(n.c).sort().filter((k) => re.test(k) && (seg.startsWith(".") || !k.startsWith("."))).forEach((k) => next.push({ parts: [...pp.parts, k], shown: join(k) }));
      }
      paths = next;
    }
    const res = paths.filter((x) => node(x.parts)).map((x) => (abs ? "/" + x.shown.replace(/^\//, "") : x.shown));
    return res.length ? res : [pat];
  }
  const expandArgs = (seg) => seg.flatMap((t) => (t && typeof t === "object" && t.glob != null ? expandGlob(t.glob) : [t])).map((t) => (typeof t === "string" ? t.replace(/\u0000ST\u0000/g, String(lastStatus)) : t));
  ctx.exec = (argv, stdin) => exec(argv, stdin ?? null);
  ctx.run = (line) => runLine(line);

  async function exec(argv, stdin) {
    let [name, ...args] = argv;
    if (name == null) return null;
    let fn = cmds[name];
    let prog = null;
    if (name.includes("/") || !fn) {
      const cand = name.includes("/") ? [name] : env.PATH.split(":").map((p) => p + "/" + name);
      for (const pth of cand) { const n = node(resolve(pth)); if (n && n.t === "f") { prog = { n, pth }; break; } }
      if (!prog && name.includes("/")) throw `bash: ${name}: No such file or directory`;
    }
    if (prog) {
      const { n } = prog;
      const u = ctx.euser || ctx.user;
      if (!can(n, u, "x")) throw `bash: ${name}: Permission denied`;
      if (!n.run) {
        if (n.c.startsWith("#!")) return { text: `(script) ${n.c.split("\n").slice(1).join("\n")}` };
        throw `bash: ${name}: cannot execute binary file: Exec format error`;
      }
      const prev = ctx.euser;
      if (/s/.test((n.mode || "").slice(1, 4))) ctx.euser = n.owner;
      try { return await n.run(args, ctx, stdin); } finally { ctx.euser = prev; }
    }
    if (!fn) throw `${name}: command not found`;
    return await fn(args, stdin, ctx);
  }

  const outText = (r) => (r == null ? "" : typeof r === "string" ? r : r.text != null ? r.text : r.html != null ? r.html.replace(/<[^>]+>/g, "").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&amp;/g, "&") : "");

  async function runLine(line) {
    const toks = tokenize(line);
    // tách theo ; && ||
    const chains = []; let cur = [], op = ";";
    for (const t of toks) { if (t && t.op && [";", "&&", "||"].includes(t.op)) { chains.push({ op, toks: cur }); cur = []; op = t.op; } else cur.push(t); }
    chains.push({ op, toks: cur });
    let lastOk = true;
    for (const ch of chains) {
      if (!ch.toks.length) continue;
      if (ch.op === "&&" && !lastOk) continue;
      if (ch.op === "||" && lastOk) continue;
      lastOk = await runPipeline(ch.toks);
      lastStatus = lastOk ? 0 : 1;
      if (interactive) return;
    }
  }

  async function runPipeline(toks) {
    // tách redirect cuối
    let redir = null, quiet = false, inFile = null;
    const clean = [];
    for (let i = 0; i < toks.length; i++) {
      const t = toks[i];
      if (t && t.op === "<") { inFile = word(toks[i + 1]); i++; continue; }
      if (t && t.op === ">" && clean.length && clean[clean.length - 1] === "2" && toks[i + 1] === "/dev/null") { clean.pop(); i++; quiet = true; continue; }
      if (t && (t.op === ">" || t.op === ">>")) { redir = { append: t.op === ">>", file: word(toks[i + 1]) }; i++; continue; }
      clean.push(t);
    }
    const segs = [[]];
    for (const t of clean) { if (t && t.op === "|") segs.push([]); else if (t && t.op) throw `syntax error near unexpected token '${t.op}'`; else segs[segs.length - 1].push(t); }
    let stdin = null, last = null;
    ctx.stdinBytes = null;
    ctx.quiet = quiet;
    try {
      if (inFile != null) { const n = ctx.readNode(String(inFile)); stdin = n.c; if (n.bin) ctx.stdinBytes = latin1ToBytes(n.c); }
      for (const seg of segs) {
        if (!seg.length) throw "syntax error near unexpected token '|'";
        const r = await exec(expandArgs(seg), stdin);
        if (r && r.interactive) { startInteractive(r.interactive); return true; }
        last = r;
        stdin = outText(r);
        ctx.stdinBytes = r && r.bin ? latin1ToBytes(stdin) : null;
      }
    } catch (err) {
      if (!quiet) print(`<span class="e">${esc(String(err))}</span>`);
      return false;
    } finally { ctx.stdinBytes = null; }
    if (redir) {
      if (typeof redir.file !== "string" || !redir.file) { print(`<span class="e">syntax error near unexpected token 'newline'</span>`); return false; }
      if (redir.file === "/dev/null") return true;
      try { const t = outText(last); ctx.writeFile(redir.file, t + (t && !t.endsWith("\n") && !(last && last.noNewline) ? "\n" : ""), { append: redir.append, bin: !!(last && last.bin) }); }
      catch (e) { print(`<span class="e">bash: ${esc(String(e))}</span>`); return false; }
      return true;
    }
    if (last != null) {
      let html;
      if (typeof last === "string") html = esc(last);
      else if (last.html != null) html = last.html;
      else if (last.bin) html = esc(last.text.replace(/[\x00-\x08\x0b-\x1f\x7f-\xff]/g, (ch) => (ch.charCodeAt(0) > 0x9f && /[\u00a0-\u00ff]/.test(ch) ? ch : "�")));
      else html = esc(last.text ?? "");
      html = html.replace(/\n$/, "");
      if (html !== "" || (last && last.raw && last.text)) print(html || "&nbsp;");
    }
    return true;
  }

  /* ---------- interactive ---------- */
  function startInteractive(svc) {
    interactive = svc;
    if (svc.banner) print(esc(svc.banner));
    setPrompt();
  }
  function endInteractive(msg) {
    interactive = null;
    if (msg) print(`<span class="m">${esc(msg)}</span>`);
    setPrompt();
  }

  /* ---------- input ---------- */
  const inputLine = h(`<div class="shell-line"><span class="p"></span><input spellcheck="false" autocomplete="off" autocapitalize="off" aria-label="Lệnh"></div>`);
  out.appendChild(inputLine);
  const input = inputLine.querySelector("input");
  const promptEl = inputLine.querySelector(".p");
  function promptHtml() {
    if (interactive) return esc(interactive.prompt ?? "");
    const u = ctx.euser || ctx.user;
    return `<span class="${u === "root" ? "e" : ""}">${esc(u)}@${esc(opts.host || "zctf")}</span>:<span class="d">${esc(pathStr())}</span>${u === "root" ? "#" : "$"}&nbsp;`;
  }
  function setPrompt() {
    promptEl.innerHTML = promptHtml();
    bar.textContent = opts.title || `${ctx.user}@${opts.host || "zctf"}: ${pathStr()}`;
  }
  setPrompt();
  if (opts.motd !== false) print(`<span class="m">${opts.motd || 'Gõ <span class="hl">help</span> để xem lệnh, <span class="hl">man &lt;lệnh&gt;</span> để xem hướng dẫn.'}</span>`);

  async function submit(line) {
    if (busy) return;
    busy = true;
    input.disabled = true;
    print(promptHtml() + esc(line));
    try {
      if (interactive) {
        const svc = interactive;
        const r = await svc.onLine(line, ctx);
        if (r != null) {
          const o = typeof r === "string" ? r : r.out;
          if (o) print(esc(o));
          if (typeof r === "object" && r.prompt != null) svc.prompt = r.prompt;
          if (typeof r === "object" && r.close) endInteractive(r.closeMsg);
        }
      } else if (line.trim()) {
        history.push(line);
        hIdx = history.length;
        await runLine(line.trim());
      }
    } catch (err) {
      print(`<span class="e">${esc(String(err))}</span>`);
    }
    busy = false;
    input.disabled = false;
    setPrompt();
    input.focus({ preventScroll: true });
    out.scrollTop = out.scrollHeight;
  }

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { const v = input.value; input.value = ""; submit(v); }
    else if (e.key === "ArrowUp" && !interactive) { if (hIdx > 0) input.value = history[--hIdx]; e.preventDefault(); }
    else if (e.key === "ArrowDown" && !interactive) { input.value = hIdx < history.length - 1 ? history[++hIdx] : ((hIdx = history.length), ""); e.preventDefault(); }
    else if (e.key === "c" && e.ctrlKey && !getSelection().toString()) {
      e.preventDefault();
      print(promptHtml() + esc(input.value) + "^C");
      input.value = "";
      if (interactive) endInteractive("Đã ngắt kết nối.");
    }
    else if (e.key === "l" && e.ctrlKey) { e.preventDefault(); cmds.clear(); }
    else if (e.key === "Tab") {
      e.preventDefault();
      if (interactive) return;
      const before = input.value;
      const words = before.split(/\s+/);
      const last = words.pop();
      let cands;
      if (!words.length && !last.includes("/")) cands = Object.keys(cmds).filter((k) => k.startsWith(last)).map((k) => k + " ");
      else {
        const slash = last.lastIndexOf("/");
        const dirPart = slash >= 0 ? last.slice(0, slash + 1) : "";
        const base = last.slice(slash + 1);
        const n = node(resolve(dirPart || "."));
        cands = n && n.t === "d" ? Object.keys(n.c).filter((k) => k.startsWith(base) && (base.startsWith(".") || !k.startsWith("."))).map((k) => dirPart + k + (n.c[k].t === "d" ? "/" : " ")) : [];
      }
      if (cands.length === 1) input.value = [...words, cands[0]].join(" ");
      else if (cands.length > 1) {
        let pre = cands[0];
        for (const c2 of cands) while (!c2.startsWith(pre)) pre = pre.slice(0, -1);
        if (pre.length > last.length) input.value = [...words, pre].join(" ");
        else print(cands.map((x) => esc(x.trim())).join("  "));
      }
    }
  });
  out.addEventListener("click", () => { if (!getSelection().toString()) input.focus({ preventScroll: true }); });

  return {
    run: (line) => submit(line),
    print,
    ctx,
    focus: () => input.focus(),
    setFs: (t) => { fs = t; cwd = split(home); setPrompt(); },
  };
}

/* Widget chung: <div data-widget="shell" data-fs="tên" data-height="360"></div>
   SHELL_FS[tên] = () => cây   HOẶC   { fs: () => cây, user, home, host, motd, cmds, sudo, groups, nc, env }  */
WIDGETS.shell = (el) => {
  const d = el.dataset;
  createShell(el, { fs: d.fs || undefined, user: d.user, host: d.host, height: d.height ? +d.height : undefined });
};
