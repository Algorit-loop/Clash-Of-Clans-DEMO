/* =====================================================================
   zCTF app — router, trang, tiến độ, thử thách, hiệu ứng
   ===================================================================== */

/* ---------- Sắp xếp bài học ---------- */
const TRACK_IDX = Object.fromEntries(TRACKS.map((t, i) => [t.id, i]));
LESSONS.sort((a, b) => (TRACK_IDX[a.track] ?? 99) - (TRACK_IDX[b.track] ?? 99) || a.order - b.order);
const trackOf = (l) => TRACKS.find((t) => t.id === l.track) || TRACKS[0];
const LEVELS = { 1: "Cơ bản", 2: "Trung cấp", 3: "Nâng cao" };

/* ---------- Tiến độ (localStorage, có fallback) ---------- */
const STORE_KEY = "zctf-progress-v2";
const state = (() => {
  let s = { solved: {}, read: {}, quiz: {} };
  try { s = { ...s, ...JSON.parse(localStorage.getItem(STORE_KEY) || "{}") }; } catch {}
  return s;
})();
const save = () => { try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch {} };

const ALL_CHALS = LESSONS.flatMap((l) => Object.entries(l.challenges).map(([id, c]) => ({ id, lesson: l.id, ...c })));
const TOTAL_PTS = ALL_CHALS.reduce((s, c) => s + c.pts, 0);
const score = () => ALL_CHALS.filter((c) => state.solved[c.id]).reduce((s, c) => s + c.pts, 0);
const chalIds = (l) => Object.keys(l.challenges);
const lessonDone = (l) => (chalIds(l).length ? chalIds(l).every((id) => state.solved[id]) : !!state.read[l.id]);
const lessonPct = (l) => {
  const ids = chalIds(l);
  if (!ids.length) return state.read[l.id] ? 100 : 0;
  return Math.round((ids.filter((id) => state.solved[id]).length / ids.length) * 100);
};
const lessonTouched = (l) => chalIds(l).some((id) => state.solved[id]) || state.read[l.id] || Object.keys(state.quiz).some((k) => k.startsWith(l.id + ":"));
const trackLessons = (t) => LESSONS.filter((l) => l.track === t);
const trackPct = (t) => {
  const ls = trackLessons(t);
  return ls.length ? Math.round(ls.reduce((s, l) => s + lessonPct(l), 0) / ls.length) : 0;
};

/* ---------- Tiện ích UI ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const app = $("#app");

function mountWidgets(root) {
  $$("[data-widget]", root).forEach((ph) => {
    const fn = WIDGETS[ph.dataset.widget];
    if (!fn) { ph.innerHTML = `<div class="callout danger"><b>Widget lỗi</b><p>Chưa có widget "${esc(ph.dataset.widget)}"</p></div>`; return; }
    try { fn(ph); } catch (e) { console.error(e); ph.innerHTML = `<div class="callout danger"><b>Widget lỗi</b><p>${esc(e.message || e)}</p></div>`; }
  });
}

function updateScore(bump) {
  const el = $("#score-val");
  animateNumber(el, score());
  if (bump) { const p = $(".score-pill"); p.classList.remove("bump"); void p.offsetWidth; p.classList.add("bump"); }
}

function toast(msg) {
  let wrap = $(".toast-wrap");
  if (!wrap) { wrap = document.createElement("div"); wrap.className = "toast-wrap"; document.body.appendChild(wrap); }
  const t = document.createElement("div");
  t.className = "toast";
  t.innerHTML = msg;
  wrap.appendChild(t);
  setTimeout(() => { t.classList.add("out"); setTimeout(() => t.remove(), 300); }, 2600);
}

let revealObs;
function observeReveal(root = document) {
  if (!revealObs) {
    revealObs = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); revealObs.unobserve(e.target); } }), { threshold: 0.08, rootMargin: "0px 0px -40px 0px" });
  }
  $$(".reveal:not(.in)", root).forEach((el) => revealObs.observe(el));
}

function animateNumber(el, to, dur = 900) {
  const from = Number(el.dataset.v || 0);
  el.dataset.v = to;
  const t0 = performance.now();
  const step = (t) => {
    const k = Math.min(1, (t - t0) / dur);
    el.textContent = Math.round(from + (to - from) * (1 - Math.pow(1 - k, 3)));
    if (k < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

function enhanceCode(root) {
  $$("pre.code", root).forEach((pre) => {
    if (pre.querySelector(".copy-btn")) return;
    const b = document.createElement("button");
    b.className = "copy-btn";
    b.textContent = "copy";
    b.onclick = () => {
      const lines = pre.querySelector("code").innerText.split("\n").map((l) => l.replace(/^\$ /, ""));
      navigator.clipboard?.writeText(lines.join("\n")).then(() => { b.textContent = "đã chép"; b.classList.add("ok"); setTimeout(() => { b.textContent = "copy"; b.classList.remove("ok"); }, 1400); });
    };
    pre.appendChild(b);
  });
}

function spotlight(root) {
  $$(".cat-card", root).forEach((c) =>
    c.addEventListener("pointermove", (e) => {
      const r = c.getBoundingClientRect();
      c.style.setProperty("--mx", e.clientX - r.left + "px");
      c.style.setProperty("--my", e.clientY - r.top + "px");
    })
  );
}

/* ===================== Hiệu ứng: nền ma trận ===================== */
(function matrixBg() {
  const cv = $("#bg-canvas");
  const ctx = cv.getContext("2d");
  const chars = "01アイウエオカキクケコサシスセソ{}<>/$#zCTF".split("");
  let cols, drops, w, h;
  const fs = 16;
  const resize = () => {
    w = cv.width = innerWidth; h = cv.height = innerHeight;
    cols = Math.ceil(w / fs);
    drops = Array.from({ length: cols }, () => Math.random() * -h / fs);
  };
  resize();
  addEventListener("resize", resize);
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  let last = 0;
  const loop = (t) => {
    requestAnimationFrame(loop);
    if (t - last < 60 || document.hidden) return;
    last = t;
    ctx.fillStyle = "rgba(6,8,12,0.14)";
    ctx.fillRect(0, 0, w, h);
    ctx.font = fs + "px JetBrains Mono, monospace";
    for (let i = 0; i < cols; i++) {
      if (Math.random() > 0.45) continue;
      const y = drops[i] * fs;
      ctx.fillStyle = Math.random() > 0.97 ? "#d9ffe9" : "rgba(61,255,162,0.55)";
      ctx.fillText(chars[(Math.random() * chars.length) | 0], i * fs, y);
      if (y > h && Math.random() > 0.97) drops[i] = 0;
      drops[i] += 1;
    }
  };
  requestAnimationFrame(loop);
})();

/* ===================== Hiệu ứng: bắt được flag ===================== */
function captureFx(pts) {
  const ov = document.createElement("div");
  ov.className = "capture";
  ov.innerHTML = `<div class="capture-card"><div class="t">FLAG CAPTURED</div><div class="s">+${pts} điểm</div></div>`;
  document.body.appendChild(ov);
  setTimeout(() => ov.remove(), 2500);

  const cv = document.createElement("canvas");
  cv.id = "fx-canvas";
  cv.width = innerWidth; cv.height = innerHeight;
  document.body.appendChild(cv);
  const ctx = cv.getContext("2d");
  const colors = ["#3dffa2", "#5cc8ff", "#ffc857", "#a58bff", "#ff6bb5"];
  const ps = Array.from({ length: 140 }, () => {
    const a = Math.random() * Math.PI * 2, v = 4 + Math.random() * 9;
    return { x: innerWidth / 2, y: innerHeight / 2, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 3, life: 1, c: colors[(Math.random() * colors.length) | 0], s: 2 + Math.random() * 4, ch: Math.random() > 0.6 ? "01{}$#"[(Math.random() * 6) | 0] : null };
  });
  const step = () => {
    ctx.clearRect(0, 0, cv.width, cv.height);
    let alive = false;
    for (const p of ps) {
      if (p.life <= 0) continue;
      alive = true;
      p.x += p.vx; p.y += p.vy; p.vy += 0.18; p.vx *= 0.985; p.life -= 0.012;
      ctx.globalAlpha = Math.max(p.life, 0);
      ctx.fillStyle = p.c;
      if (p.ch) { ctx.font = "bold 14px JetBrains Mono, monospace"; ctx.fillText(p.ch, p.x, p.y); }
      else ctx.fillRect(p.x, p.y, p.s, p.s);
    }
    if (alive) requestAnimationFrame(step); else cv.remove();
  };
  step();
}

let typerToken = 0;
function runTyper(el) {
  const token = ++typerToken;
  const script = [
    ["c", "cat challenge.txt"],
    ["o", "Tìm flag trong secret.bin. Chúc may mắn!"],
    ["c", "file secret.bin"],
    ["o", "secret.bin: ASCII text"],
    ["c", "cat secret.bin"],
    ["o", "ekNURntiNG5fZDRfczRuX3M0bmd9"],
    ["cm", "# ekNURn... chính là zCTF{ ở dạng base64"],
    ["c", "cat secret.bin | base64 -d"],
    ["f", "zCTF{b4n_d4_s4n_s4ng}"],
  ];
  el.innerHTML = "";
  const cursor = document.createElement("span");
  cursor.className = "cursor";
  let li = 0;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  (async () => {
    while (token === typerToken) {
      if (li >= script.length) { await sleep(3500); if (token !== typerToken) return; el.innerHTML = ""; li = 0; continue; }
      const [type, text] = script[li++];
      const line = document.createElement("div");
      el.appendChild(line);
      if (type === "c") {
        line.innerHTML = '<span class="p">$ </span><span class="c"></span>';
        const span = $(".c", line);
        line.appendChild(cursor);
        await sleep(450);
        for (const ch of text) { if (token !== typerToken) return; span.textContent += ch; await sleep(38 + Math.random() * 45); }
        await sleep(300);
      } else {
        line.className = type;
        line.textContent = text;
        line.appendChild(cursor);
        await sleep(type === "f" ? 200 : 380);
      }
    }
  })();
}

function scrambleLoop(el) {
  if (!el) return;
  const final = el.dataset.final;
  const pool = "abcdefghijklmnopqrstuvwxyz0123456789_!@#$%";
  const token = typerToken;
  const go = () => {
    if (!document.body.contains(el) || token !== typerToken) return;
    let frame = 0;
    const total = 36;
    const tick = () => {
      if (!document.body.contains(el)) return;
      el.textContent = [...final].map((ch, i) => (frame / total > i / final.length ? ch : pool[(Math.random() * pool.length) | 0])).join("");
      if (++frame <= total) setTimeout(tick, 40);
      else setTimeout(go, 3800);
    };
    tick();
  };
  setTimeout(go, 800);
}


/* ===================== Challenge & quiz ===================== */
const DIFF = { easy: "Dễ", med: "Vừa", hard: "Khó" };

function renderChallenge(id, chal, lesson) {
  const solved = !!state.solved[id];
  const el = document.createElement("div");
  el.className = "chal" + (solved ? " solved" : "");
  el.id = "chal-" + id;
  el.style.setProperty("--c", trackOf(lesson).color);
  el.innerHTML = `
    <div class="chal-head">
      <span class="flag-ic">⚑</span><h4>${chal.title}</h4>
      <span class="tag ${chal.diff}">${DIFF[chal.diff] || chal.diff}</span>
      <span class="pts">${solved ? "✓ " : ""}${chal.pts} pts</span>
    </div>
    <div class="chal-body">
      ${chal.body}
      ${chal.widget ? `<div data-widget="${chal.widget}"${Object.entries(chal.widgetData || {}).map(([k, v]) => ` data-${k}="${esc(v)}"`).join("")}></div>` : ""}
      <form class="flag-form ${solved ? "right" : ""}" autocomplete="off">
        <input placeholder="zCTF{...}" spellcheck="false" ${solved ? 'value="Đã giải ✓" disabled' : ""} aria-label="Flag">
        ${solved ? '<button type="button" class="btn redo">↺ Làm lại</button>' : '<button class="btn primary">Nộp</button>'}
      </form>
      <div class="chal-msg"></div>
      ${chal.hints && chal.hints.length ? `<div class="hints">${chal.hints.map((x, i) => `<details class="hint"><summary>Gợi ý ${i + 1}</summary><div>${x}</div></details>`).join("")}</div>` : ""}
    </div>`;
  const form = $(".flag-form", el);
  const msg = $(".chal-msg", el);
  const redo = $(".redo", el);
  if (redo) redo.addEventListener("click", () => {
    delete state.solved[id];
    save();
    updateScore();
    refreshSide();
    const fresh = renderChallenge(id, chal, lesson);
    el.replaceWith(fresh);
    mountWidgets(fresh);
    enhanceCode(fresh);
    $("input", fresh).focus({ preventScroll: true });
    refreshLessonControls(lesson);
  });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const v = $("input", form).value.trim();
    if (!v || state.solved[id]) return;
    form.classList.remove("wrong", "right");
    void form.offsetWidth;
    if (sha256Hex(v) === chal.hash) {
      state.solved[id] = Date.now();
      save();
      captureFx(chal.pts);
      updateScore(true);
      refreshSide();
      // vẽ lại ở trạng thái đã giải (giữ nguyên widget đang dùng)
      form.classList.add("right");
      $("input", form).disabled = true;
      $("input", form).value = "Đã giải ✓";
      const btn = $("button", form);
      const rb = document.createElement("button");
      rb.type = "button"; rb.className = "btn redo"; rb.textContent = "↺ Làm lại";
      btn.replaceWith(rb);
      rb.addEventListener("click", () => { delete state.solved[id]; save(); updateScore(); refreshSide(); const fresh = renderChallenge(id, chal, lesson); el.replaceWith(fresh); mountWidgets(fresh); enhanceCode(fresh); refreshLessonControls(lesson); });
      el.classList.add("solved");
      $(".pts", el).textContent = "✓ " + chal.pts + " pts";
      msg.className = "chal-msg ok";
      msg.textContent = "Chính xác!";
      refreshLessonControls(lesson);
      if (lessonDone(lesson)) setTimeout(() => toast(`Hoàn thành bài <b>${esc(lesson.title)}</b>`), 1200);
    } else {
      form.classList.add("wrong");
      msg.className = "chal-msg err";
      msg.textContent = /^zCTF\{.*\}$/.test(v) ? "Sai flag. Thử lại nhé." : "Flag phải có dạng zCTF{...}";
    }
  });
  return el;
}

function renderQuiz(q, key) {
  const el = document.createElement("div");
  el.className = "quiz reveal in";
  const draw = () => {
    const order = q.options.map((_, i) => i).sort(() => Math.random() - 0.5);
    el.classList.remove("answered");
    el.innerHTML = `<div class="q">${q.q}</div>${order.map((i) => `<button class="opt" data-i="${i}">${q.options[i]}</button>`).join("")}<div class="explain">${q.explain || ""}</div><button class="btn sm quiz-redo" hidden>↺ Làm lại câu này</button>`;
    $$(".opt", el).forEach((b) =>
      b.addEventListener("click", () => {
        const i = +b.dataset.i;
        $$(".opt", el).forEach((x) => { x.disabled = true; if (+x.dataset.i === q.answer) x.classList.add("correct"); });
        if (i !== q.answer) b.classList.add("incorrect");
        el.classList.add("answered");
        state.quiz[key] = i === q.answer ? 1 : 0;
        save();
        $(".quiz-redo", el).hidden = false;
      })
    );
    $(".quiz-redo", el).addEventListener("click", () => { delete state.quiz[key]; save(); draw(); });
  };
  draw();
  return el;
}

/* ===================== Trang chủ ===================== */
function renderHome() {
  const firstUndone = LESSONS.find((l) => !lessonDone(l)) || LESSONS[0];
  const started = Object.keys(state.solved).length > 0;
  const tracks = TRACKS.filter((t) => trackLessons(t.id).length);
  app.innerHTML = `
  <div class="container page">
    <section class="hero">
      <div>
        <h1>Học <span class="glitch grad" data-text="CTF">CTF</span><br>từ con số 0</h1>
        <p class="lead">${LESSONS.length} bài học chia thành ${tracks.length} mảng, từ dòng lệnh Linux đến khai thác bộ nhớ. Thực hành ngay trên trình duyệt với terminal, Python, SQL và lab web chạy thật.</p>
        <div class="actions">
          <a class="btn primary" href="#/learn/${firstUndone.id}">${started ? "Học tiếp: " + firstUndone.title : "Bắt đầu bài đầu tiên"} <span class="arrow">→</span></a>
          <a class="btn" href="#/roadmap">Xem lộ trình</a>
        </div>
        <div class="hero-stats">
          <div><strong class="num" data-to="${LESSONS.length}">0</strong><span>bài học</span></div>
          <div><strong class="num" data-to="${ALL_CHALS.length}">0</strong><span>thử thách</span></div>
          <div><strong class="num" data-to="${TOTAL_PTS}">0</strong><span>điểm tối đa</span></div>
        </div>
      </div>
      <div class="hero-visual">
        <span class="float-tag t1">pwn ▸ buffer overflow</span>
        <span class="float-tag t2">crypto ▸ xor</span>
        <span class="float-tag t3">web ▸ sqli</span>
        <div class="window">
          <div class="window-bar"><i></i><i></i><i></i><span>~/ctf/challenge</span></div>
          <div class="typer" id="typer"></div>
        </div>
      </div>
    </section>

    <section class="block reveal">
      <div class="section-head">
        <h2>Mục tiêu: tìm flag</h2>
        <p>Mỗi bài CTF giấu một chuỗi bí mật như thế này. Tìm ra nó, nộp lên, nhận điểm.</p>
      </div>
      <div class="flag-demo"><span class="fp">zCTF</span><span class="fb">{</span><span class="fc scramble" data-final="b4n_d4_s4n_s4ng">b4n_d4_s4n_s4ng</span><span class="fb">}</span></div>
    </section>

    <section class="block">
      <div class="section-head reveal">
        <h2>Các mảng kiến thức</h2>
        <p>Bắt đầu với Nền tảng, sau đó chọn mảng bạn thích. Mỗi mảng đi từ cơ bản đến nâng cao.</p>
      </div>
      <div class="cat-grid">
        ${tracks.map((t, i) => {
          const ls = trackLessons(t.id);
          const nch = ls.reduce((s, l) => s + chalIds(l).length, 0);
          return `<a class="cat-card reveal" style="--c:${t.color};transition-delay:${(i % 4) * 60}ms" href="#/roadmap/${t.id}">
            <div class="cat-icon">${t.icon}</div>
            <h3>${t.title}</h3>
            <p>${t.desc}</p>
            <div class="meta"><span>${ls.length} bài · ${nch} flag</span><div class="mini-bar"><span style="width:${trackPct(t.id)}%"></span></div></div>
          </a>`;
        }).join("")}
      </div>
    </section>

    <section class="block">
      <div class="section-head reveal"><h2>Thực hành ngay trong trình duyệt</h2></div>
      <div class="cat-grid">
        <a class="cat-card reveal" style="--c:#3dffa2" href="#/tools/shell"><div class="cat-icon">$_</div><h3>Terminal Linux</h3><p>Hơn 50 lệnh: grep, find, xxd, base64, curl tới lab, nc tới dịch vụ.</p></a>
        <a class="cat-card reveal" style="--c:#ffc857;transition-delay:60ms" href="#/tools/python"><div class="cat-icon">py</div><h3>Python thật</h3><p>CPython chạy bằng WebAssembly. Viết script giải bài như trên máy thật.</p></a>
        <a class="cat-card reveal" style="--c:#5cc8ff;transition-delay:120ms" href="#/tools/sql"><div class="cat-icon">SQL</div><h3>SQLite</h3><p>Luyện SELECT, JOIN, UNION trước khi học SQL injection.</p></a>
        <a class="cat-card reveal" style="--c:#a58bff;transition-delay:180ms" href="#/tools/decode"><div class="cat-icon">⇄</div><h3>Bộ giải mã</h3><p>Base64, hex, XOR, ROT, hash, chuyển đổi số, phân tích tần suất.</p></a>
      </div>
    </section>

    <section class="block">
      <div class="section-head reveal"><h2>Cách học hiệu quả</h2></div>
      <div class="steps">
        <div class="step reveal"><h4>Đọc bài</h4><p>Nắm khái niệm, chạy thử từng lệnh ví dụ.</p></div>
        <div class="step reveal" style="transition-delay:80ms"><h4>Tự giải</h4><p>Làm thử thách. Bí thì mở gợi ý từng bước, đừng mở hết ngay.</p></div>
        <div class="step reveal" style="transition-delay:160ms"><h4>Làm lại</h4><p>Vài hôm sau bấm "Làm lại" và giải lại không cần gợi ý.</p></div>
        <div class="step reveal" style="transition-delay:240ms"><h4>Chơi giải thật</h4><p>Lập đội, tham gia giải trên CTFtime, đọc writeup sau giải.</p></div>
      </div>
    </section>
  </div>`;
  observeReveal(app);
  spotlight(app);
  $$(".hero-stats .num").forEach((n) => animateNumber(n, +n.dataset.to, 1400));
  runTyper($("#typer"));
  scrambleLoop($(".scramble"));
}

/* ===================== Trang lộ trình ===================== */
function renderRoadmap(filter) {
  const done = LESSONS.filter(lessonDone).length;
  const tracks = TRACKS.filter((t) => trackLessons(t.id).length);
  const shown = filter ? tracks.filter((t) => t.id === filter) : tracks;
  let num = 0;
  const numOf = Object.fromEntries(LESSONS.map((l) => [l.id, num++]));
  app.innerHTML = `
  <div class="container page" style="max-width:900px">
    <div class="section-head" style="padding-top:48px">
      <h2>Lộ trình</h2>
      <p>Học Nền tảng trước. Các mảng còn lại có thể học theo thứ tự tuỳ thích; trong mỗi mảng nên đi từ trên xuống.</p>
    </div>
    <div class="card progress-card">
      <div class="big-num">${done}/${LESSONS.length}</div>
      <div style="flex:1;min-width:200px">
        <div style="color:var(--muted);font-size:14px;margin-bottom:8px">bài hoàn thành · ${score()}/${TOTAL_PTS} điểm · ${Object.keys(state.solved).length}/${ALL_CHALS.length} flag</div>
        <div class="mini-bar" style="margin:0;height:6px;--c:var(--accent)"><span style="width:${(done / LESSONS.length) * 100}%"></span></div>
      </div>
      ${Object.keys(state.solved).length || Object.keys(state.read).length || Object.keys(state.quiz).length ? '<button class="btn sm" id="reset">↺ Làm lại từ đầu</button>' : ""}
    </div>
    <div class="filter-row">
      <a class="op ${filter ? "" : "on"}" href="#/roadmap">Tất cả</a>
      ${tracks.map((t) => `<a class="op ${filter === t.id ? "on" : ""}" href="#/roadmap/${t.id}" style="--c:${t.color}">${t.title}</a>`).join("")}
    </div>
    <div class="roadmap">
      ${shown.map((t) => `
        <div class="rm-stage reveal" style="--c:${t.color}"><span class="dotc"></span>${t.title.toUpperCase()}<span class="rm-pct">${trackPct(t.id)}%</span></div>
        ${trackLessons(t.id).map((l) => `
          <div class="rm-item reveal ${lessonDone(l) ? "done" : ""}" style="--c:${t.color}">
            <div class="rm-dot"><span>${String(numOf[l.id]).padStart(2, "0")}</span></div>
            <a class="rm-body" href="#/learn/${l.id}">
              <div><h4>${l.title}</h4><p>${l.short}</p></div>
              <span class="tag lv${l.level}">${LEVELS[l.level]}</span>
              <span class="tag">${l.time}${chalIds(l).length ? " · " + chalIds(l).filter((id) => state.solved[id]).length + "/" + chalIds(l).length + " flag" : ""}</span>
            </a>
          </div>`).join("")}
      `).join("")}
    </div>
  </div>`;
  observeReveal(app);
  $("#reset")?.addEventListener("click", () => {
    if (!confirm("Xoá toàn bộ tiến độ, điểm và câu trả lời để làm lại từ đầu?")) return;
    state.solved = {}; state.read = {}; state.quiz = {}; save();
    updateScore(); renderRoadmap(filter);
    toast("Đã xoá tiến độ. Bắt đầu lại nào!");
  });
}

/* ===================== Trang bài học ===================== */
let tocObs;
let currentLesson = null;
function renderLesson(id) {
  const idx = LESSONS.findIndex((l) => l.id === id);
  if (idx < 0) return renderNotFound();
  const l = LESSONS[idx];
  currentLesson = l;
  const t = trackOf(l);
  const prev = LESSONS[idx - 1], next = LESSONS[idx + 1];
  app.innerHTML = `
  <div class="read-progress"></div>
  <div class="lesson-layout page" style="--c:${t.color}">
    <aside class="side"><div class="side-list"></div></aside>
    <article>
      <div class="lesson-hero">
        <div class="crumbs"><a href="#/roadmap/${t.id}">${t.title}</a><span>/</span><span>Bài ${trackLessons(l.track).indexOf(l) + 1}/${trackLessons(l.track).length}</span><span class="tag lv${l.level}">${LEVELS[l.level]}</span><span class="tag">${l.time}</span><button class="btn sm side-toggle">☰ Danh sách bài</button></div>
        <h1><span class="ic">${t.icon}</span>${l.title}</h1>
        <p>${l.short}</p>
        <div class="lesson-ctrl"></div>
      </div>
      <div class="prose">${l.html}</div>
      <div class="complete-bar"></div>
      <nav class="lesson-nav">
        ${prev ? `<a href="#/learn/${prev.id}"><small>← Bài trước</small>${prev.title}</a>` : ""}
        ${next ? `<a class="next" href="#/learn/${next.id}"><small>Bài tiếp →</small>${next.title}</a>` : ""}
      </nav>
    </article>
    <aside class="toc"><h5>Trong bài</h5><div class="toc-links"></div></aside>
  </div>`;

  const prose = $(".prose", app);
  $$("[data-chal]", prose).forEach((ph) => {
    const ch = l.challenges[ph.dataset.chal];
    if (!ch) { ph.innerHTML = `<div class="callout danger"><b>Lỗi</b><p>Không có thử thách "${esc(ph.dataset.chal)}"</p></div>`; return; }
    ph.replaceWith(renderChallenge(ph.dataset.chal, ch, l));
  });
  $$("[data-quiz]", prose).forEach((ph) => { const i = +ph.dataset.quiz; const q = l.quiz[i]; q ? ph.replaceWith(renderQuiz(q, `${l.id}:${i}`)) : ph.remove(); });
  // thử thách / quiz chưa được đặt chỗ trong html → thêm vào cuối bài
  const placed = new Set($$(".chal", prose).map((e) => e.id.slice(5)));
  chalIds(l).filter((cid) => !placed.has(cid)).forEach((cid) => prose.appendChild(renderChallenge(cid, l.challenges[cid], l)));
  mountWidgets(prose);
  $$("h2, .callout, pre.code, table, .grid-3, .grid-2, .chal", prose).forEach((e) => { if (!e.closest(".chal") || e.classList.contains("chal")) e.classList.add("reveal"); });
  enhanceCode(prose);
  observeReveal(app);
  refreshSide();
  refreshLessonControls(l);

  $(".side-toggle", app).onclick = () => $(".side", app).classList.toggle("open");

  const heads = $$("h2[id]", prose);
  $(".toc-links", app).innerHTML = heads.map((hd) => `<a href="#/learn/${l.id}" data-target="${hd.id}">${hd.textContent}</a>`).join("");
  $$(".toc a", app).forEach((a) => a.addEventListener("click", (e) => { e.preventDefault(); document.getElementById(a.dataset.target).scrollIntoView({ behavior: "smooth" }); }));
  tocObs?.disconnect();
  tocObs = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) $$(".toc a", app).forEach((a) => a.classList.toggle("active", a.dataset.target === e.target.id)); }), { rootMargin: "-80px 0px -70% 0px" });
  heads.forEach((hd) => tocObs.observe(hd));
}

function refreshLessonControls(l) {
  if (currentLesson !== l) return;
  const ctrl = $(".lesson-ctrl");
  const bar = $(".complete-bar");
  if (!ctrl || !bar) return;
  const ids = chalIds(l);
  const solvedN = ids.filter((id) => state.solved[id]).length;
  ctrl.innerHTML = ids.length
    ? `<div class="lc-prog"><span>${solvedN}/${ids.length} flag</span><div class="mini-bar" style="--c:var(--c)"><span style="width:${(solvedN / ids.length) * 100}%"></span></div></div>${lessonTouched(l) ? '<button class="btn sm" data-redo-lesson>↺ Làm lại cả bài</button>' : ""}`
    : lessonTouched(l) ? '<button class="btn sm" data-redo-lesson>↺ Làm lại cả bài</button>' : "";
  if (ids.length) {
    bar.innerHTML = lessonDone(l)
      ? `<p>✓ Bạn đã hoàn thành bài này. Muốn luyện lại không cần gợi ý?</p><button class="btn" data-redo-lesson>↺ Làm lại cả bài</button>`
      : `<p>Giải đủ ${ids.length} flag để hoàn thành bài. Còn ${ids.length - solvedN}.</p>`;
  } else {
    bar.innerHTML = state.read[l.id]
      ? `<p>✓ Bạn đã hoàn thành bài này.</p><button class="btn" data-redo-lesson>↺ Đánh dấu chưa học</button>`
      : `<p>Đọc xong rồi?</p><button class="btn primary" data-mark-read>Đánh dấu hoàn thành</button>`;
  }
  $$("[data-redo-lesson]").forEach((b) => b.addEventListener("click", () => {
    if (ids.length && !confirm(`Làm lại bài "${l.title}"? Các flag đã giải trong bài sẽ bị xoá.`)) return;
    ids.forEach((id) => delete state.solved[id]);
    delete state.read[l.id];
    Object.keys(state.quiz).filter((k) => k.startsWith(l.id + ":")).forEach((k) => delete state.quiz[k]);
    save(); updateScore();
    const y = scrollY;
    renderLesson(l.id);
    scrollTo({ top: Math.min(y, 0) });
    toast("Đã đặt lại bài học. Làm lại nào!");
  }));
  $("[data-mark-read]")?.addEventListener("click", () => {
    state.read[l.id] = Date.now(); save();
    refreshSide(); refreshLessonControls(l);
  });
}

function refreshSide() {
  const list = $(".side-list");
  if (!list) return;
  const cur = currentLesson;
  let n = 0;
  list.innerHTML = TRACKS.filter((t) => trackLessons(t.id).length).map((t) => {
    const ls = trackLessons(t.id);
    const open = cur && cur.track === t.id;
    const items = ls.map((x) => `<li><a href="#/learn/${x.id}" class="${cur && x.id === cur.id ? "active" : ""} ${lessonDone(x) ? "done" : ""}"><span class="n">${String(LESSONS.indexOf(x)).padStart(2, "0")}</span>${x.title}${lessonDone(x) ? '<span class="chk">✓</span>' : ""}</a></li>`).join("");
    n += ls.length;
    return `<details class="side-group" style="--c:${t.color}" ${open ? "open" : ""}><summary><span class="dotc"></span>${t.title}<span class="sg-pct">${trackPct(t.id)}%</span></summary><ul>${items}</ul></details>`;
  }).join("");
}

/* ===================== Thuật ngữ ===================== */
function renderGlossary() {
  const cats = [...new Set(GLOSSARY.map((g) => g.cat))];
  app.innerHTML = `
  <div class="container page" style="max-width:980px">
    <div class="section-head" style="padding-top:48px">
      <h2>Thuật ngữ</h2>
      <p>${GLOSSARY.length} khái niệm hay gặp trong CTF và bảo mật, giải thích ngắn gọn.</p>
    </div>
    <input class="search" placeholder="Tìm thuật ngữ… (vd: XSS, endian, salt)" spellcheck="false">
    <div class="filter-row" style="margin-top:14px"><button class="op on" data-c="">Tất cả</button>${cats.map((c2) => `<button class="op" data-c="${esc(c2)}">${esc(c2)}</button>`).join("")}</div>
    <div class="gloss"></div>
  </div>`;
  const box = $(".gloss", app), q = $(".search", app);
  let cat = "";
  const norm = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/g, "d").toLowerCase();
  const draw = () => {
    const k = norm(q.value.trim());
    const items = GLOSSARY.filter((g) => (!cat || g.cat === cat) && (!k || norm(g.term + " " + g.def).includes(k))).sort((a, b) => a.term.localeCompare(b.term));
    box.innerHTML = items.length ? items.map((g) => `<div class="gl-item"><div class="gl-term">${esc(g.term)}<span class="tag">${esc(g.cat)}</span></div><div class="gl-def">${g.def}</div></div>`).join("") : '<p style="color:var(--muted)">Không tìm thấy.</p>';
  };
  q.addEventListener("input", draw);
  $$(".filter-row .op", app).forEach((b) => b.addEventListener("click", () => { $$(".filter-row .op", app).forEach((x) => x.classList.remove("on")); b.classList.add("on"); cat = b.dataset.c; draw(); }));
  draw();
}

function renderNotFound() {
  app.innerHTML = `<div class="container page" style="text-align:center;padding:120px 0"><h1 style="font-family:var(--mono);font-size:64px;margin:0;color:var(--accent)">404</h1><p style="color:var(--muted)">Trang này không tồn tại.</p><a class="btn primary" href="#/">Về trang chủ</a></div>`;
}

/* ===================== Router ===================== */
function route() {
  typerToken++;
  currentLesson = null;
  const parts = (location.hash.slice(1) || "/").split("/").filter(Boolean);
  const page = parts[0] || "";
  document.body.dataset.page = page || "home";
  $$(".nav a").forEach((a) => a.classList.toggle("active", a.dataset.page === (page || "home") || (page === "learn" && a.dataset.page === "roadmap")));
  $(".nav").classList.remove("open");
  if (!page) renderHome();
  else if (page === "learn") renderLesson(parts[1]);
  else if (page === "roadmap") renderRoadmap(parts[1]);
  else if (page === "tools") renderTools(app, parts[1]);
  else if (page === "glossary") renderGlossary();
  else if (page === "resources") renderResources(app);
  else renderNotFound();
  window.scrollTo({ top: 0, behavior: "instant" });
}

addEventListener("hashchange", route);
addEventListener("scroll", () => {
  $(".topbar").classList.toggle("scrolled", scrollY > 10);
  const rp = $(".read-progress");
  if (rp) {
    const max = document.documentElement.scrollHeight - innerHeight;
    rp.style.width = (max > 0 ? (scrollY / max) * 100 : 0) + "%";
  }
}, { passive: true });
$(".menu-btn").addEventListener("click", () => $(".nav").classList.toggle("open"));

$("#score-total").textContent = TOTAL_PTS;
updateScore();
route();
