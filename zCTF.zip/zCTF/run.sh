#!/usr/bin/env bash
# Chạy zCTF bằng FastAPI tại http://localhost:${PORT:-9000}
set -e
cd "$(dirname "$0")"
if ! .venv/bin/python -c "import fastapi, uvicorn, httpx" 2>/dev/null \
   || [ ! -f vendor/pyodide/pyodide.asm.wasm ] || [ ! -f vendor/sqljs/sql-wasm.wasm ]; then
  ./setup.sh
fi
exec .venv/bin/python server.py
