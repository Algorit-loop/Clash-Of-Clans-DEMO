// Kiểm tra toàn bộ site: node .dev/validate.mjs <port> [track] [--shots]
// - ID bài / thử thách trùng, thiếu trường, hash sai định dạng
// - Mở từng bài: lỗi JS, widget lỗi, placeholder không khớp
// - Flag trong .dev/flags/*.json ({ "chalId": "zCTF{...}" }) phải khớp hash
import { chromium } from "playwright-core";
import fs from "fs";
import path from "path";
const port = process.argv[2] || "9000";
const track = process.argv[3] && !process.argv[3].startsWith("--") ? process.argv[3] : null;
const shots = process.argv.includes("--shots");
const here = path.dirname(new URL(import.meta.url).pathname);
const flags = {};
for (const f of fs.readdirSync(path.join(here, "flags"))) if (f.endsWith(".json")) Object.assign(flags, JSON.parse(fs.readFileSync(path.join(here, "flags", f), "utf8")));
process.env.TMPDIR = path.join(here, "tmp");
fs.mkdirSync(process.env.TMPDIR, { recursive: true });
const b = await chromium.launch({ executablePath: process.env.HOME + "/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome" });
const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
let errs = [];
p.on("pageerror", (e) => errs.push("pageerror: " + e.message));
p.on("console", (m) => m.type() === "error" && !/favicon|fonts\.g/.test(m.text()) && errs.push("console: " + m.text()));
const B = `http://127.0.0.1:${port}/`;
await p.goto(B);
await p.waitForTimeout(800);
const problems = [];
if (errs.length) problems.push(["(load)", errs]), (errs = []);
const meta = await p.evaluate(() => {
  const issues = [];
  const ids = {}, cids = {};
  for (const l of LESSONS) {
    if (ids[l.id]) issues.push(`lesson id trùng: ${l.id}`);
    ids[l.id] = 1;
    for (const k of ["id", "track", "title", "short", "time", "html"]) if (!l[k]) issues.push(`${l.id}: thiếu ${k}`);
    if (!TRACKS.some((t) => t.id === l.track)) issues.push(`${l.id}: track lạ ${l.track}`);
    for (const [cid, ch] of Object.entries(l.challenges)) {
      if (cids[cid]) issues.push(`challenge id trùng: ${cid} (${cids[cid]} & ${l.id})`);
      cids[cid] = l.id;
      if (!/^[0-9a-f]{64}$/.test(ch.hash || "")) issues.push(`${cid}: hash sai định dạng`);
      for (const k of ["title", "pts", "diff", "body"]) if (ch[k] == null) issues.push(`${cid}: thiếu ${k}`);
      if (!l.html.includes(`data-chal="${cid}"`)) issues.push(`${cid}: không có <div data-chal="${cid}"> trong html (sẽ bị thêm vào cuối bài)`);
    }
    for (const m of l.html.matchAll(/data-chal="([^"]+)"/g)) if (!l.challenges[m[1]]) issues.push(`${l.id}: data-chal="${m[1]}" không tồn tại`);
    for (const m of l.html.matchAll(/data-quiz="(\d+)"/g)) if (!l.quiz[+m[1]]) issues.push(`${l.id}: data-quiz="${m[1]}" không tồn tại`);
    l.quiz.forEach((q, i) => { if (!(q.answer >= 0 && q.answer < q.options.length)) issues.push(`${l.id}: quiz ${i} answer sai`); });
    for (const m of l.html.matchAll(/data-widget="([^"]+)"/g)) if (!WIDGETS[m[1]]) issues.push(`${l.id}: widget "${m[1]}" chưa đăng ký`);
    for (const m of l.html.matchAll(/data-fs="([^"]+)"/g)) if (!SHELL_FS[m[1]]) issues.push(`${l.id}: SHELL_FS "${m[1]}" chưa có`);
  }
  const hashes = Object.fromEntries(LESSONS.flatMap((l) => Object.entries(l.challenges).map(([k, v]) => [k, [v.hash, l.track]])));
  return { issues, hashes, lessons: LESSONS.map((l) => [l.id, l.track, Object.keys(l.challenges).length]) };
});
if (meta.issues.length) problems.push(["(metadata)", meta.issues]);
const crypto = await import("crypto");
const fl = [];
for (const [cid, [hash, tr]] of Object.entries(meta.hashes)) {
  if (track && tr !== track) continue;
  if (!(cid in flags)) fl.push(`${cid}: chưa có flag trong .dev/flags/*.json`);
  else if (crypto.createHash("sha256").update(flags[cid]).digest("hex") !== hash) fl.push(`${cid}: flag "${flags[cid]}" KHÔNG khớp hash`);
}
if (fl.length) problems.push(["(flags)", fl]);
if (shots) fs.mkdirSync(path.join(here, "shots"), { recursive: true });
for (const [id, tr] of meta.lessons) {
  if (track && tr !== track) continue;
  await p.goto(B + "#/learn/" + id);
  await p.waitForTimeout(700);
  const bad = await p.evaluate(() => [...document.querySelectorAll(".callout.danger b")].filter((x) => /lỗi/i.test(x.textContent)).map((x) => x.parentElement.textContent.trim()));
  if (bad.length) errs.push(...bad);
  if (shots) await p.evaluate(() => document.querySelectorAll(".reveal").forEach((e) => e.classList.add("in")));
  if (shots) await p.screenshot({ path: path.join(here, "shots", id + ".png"), fullPage: true });
  if (errs.length) problems.push([id, errs]);
  errs = [];
}
console.log(`Bài: ${meta.lessons.filter(([, t]) => !track || t === track).length}${track ? " (track " + track + ")" : ""} · Thử thách: ${Object.values(meta.hashes).filter(([, t]) => !track || t === track).length}`);
if (!problems.length) console.log("OK — không có lỗi.");
for (const [k, v] of problems) { console.log(`\n[${k}]`); v.forEach((x) => console.log("  - " + x)); }
await b.close();
process.exit(problems.length ? 1 : 0);
