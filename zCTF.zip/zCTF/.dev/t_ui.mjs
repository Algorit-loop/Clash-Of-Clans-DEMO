import { chromium } from "playwright-core";
process.env.TMPDIR = new URL("./tmp", import.meta.url).pathname;
const b = await chromium.launch({ executablePath: process.env.HOME + "/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome" });
const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
const errs = []; p.on("pageerror", e => errs.push(e.message));
const B = "http://127.0.0.1:" + (process.argv[2] || 9100) + "/";
const shot = async (n) => p.screenshot({ path: new URL(`./shots/ui-${n}.png`, import.meta.url).pathname });
await p.goto(B); await p.waitForTimeout(600);
for (let y = 0; y < 1700; y += 300) { await p.mouse.wheel(0, 300); await p.waitForTimeout(120); }
await p.waitForTimeout(900); await shot("home-mid");
await p.goto(B + "#/roadmap"); await p.waitForTimeout(1000); await shot("roadmap");
await p.goto(B + "#/learn/" + (process.argv[3] || "linux")); await p.waitForTimeout(900);
const c = p.locator(".chal").first(); await c.scrollIntoViewIfNeeded();
await c.locator("input").fill("zCTF{f1l3_4n_c0_d4u_ch4m}"); await c.locator("button.primary").click(); await p.waitForTimeout(2600);
await shot("lesson-solved");
await p.locator(".chal .redo").first().click(); await p.waitForTimeout(400); await shot("lesson-redo");
await p.evaluate(() => scrollTo(0, 0)); await p.waitForTimeout(300); await shot("lesson-top");
console.log("ERRS", errs);
await b.close();
