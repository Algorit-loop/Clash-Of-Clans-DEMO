import { chromium } from "playwright-core";
process.env.TMPDIR = new URL("./tmp", import.meta.url).pathname;
const b = await chromium.launch({ executablePath: process.env.HOME + "/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome" });
const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
const errs = []; p.on("pageerror", e => errs.push(e.message));
const B = "http://127.0.0.1:9105/";
async function shell(cmds, idx = 0) {
  const inp = p.locator(".shell-line input").nth(idx);
  for (const c of cmds) { await inp.fill(c); await inp.press("Enter"); await p.waitForTimeout(60); }
  return (await p.locator(".shell-out").nth(idx).innerText());
}
await p.goto(B + "#/learn/rev-intro"); await p.waitForTimeout(800);
console.log(await shell(["file crackme", "strings crackme | head -20", "./crackme", "s1mpl3_p4ss", "ltrace ./vault test", "./vault d0nt_p4n1c", "objdump -d answer", "strace ./crackme", "readelf -h answer", "ltrace ./crackme"]));
await p.goto(B + "#/learn/rev-dynamic"); await p.waitForTimeout(800);
console.log(await shell(["ltrace ./lockbox AAA", "gdb ./lockbox", "disassemble check", "break my_cmp", "run AAAA", "x/s $rsi", "x/8xb $rsi", "info registers", "bt", "finish", "c", "quit", "./lockbox unl0ck_m3_n0w",
  "./trial", "objdump -d trial", "printf '\\x75' | dd of=trial bs=1 seek=$((0x11c4)) conv=notrunc", "objdump -d trial | grep 11c4", "./trial",
  "./guard", "gdb ./guard", "run", "break ptrace", "run", "finish", "set $rax = 0", "break memset", "c", "x/s $rdi", "c", "q"]));
await p.goto(B + "#/learn/rev-asm"); await p.waitForTimeout(800);
const sims = p.locator(".asm-sim");
for (let i = 0; i < 3; i++) { await sims.nth(i).locator('[data-a="run"]').click(); console.log("SIM", i, await sims.nth(i).locator(".asm-status").innerText()); }
await sims.nth(2).locator('input[data-r="rdi"]').fill("0x4075"); await sims.nth(2).locator('[data-a="reset"]').click(); await sims.nth(2).locator('[data-a="run"]').click();
console.log("SIM3 solve", await sims.nth(2).locator(".asm-status").innerText());
for (let k = 0; k < 4; k++) await sims.nth(2).locator('[data-a="step"]').click();
await sims.nth(2).screenshot({ path: new URL("./shots/asm3.png", import.meta.url).pathname });
await sims.nth(3).locator('input[data-r="rdi"]').fill("6"); await sims.nth(3).locator('input[data-r="rsi"]').fill("7"); await sims.nth(3).locator('[data-a="reset"]').click(); await sims.nth(3).locator('[data-a="run"]').click();
console.log("FREE", await sims.nth(3).locator(".asm-status").innerText());
// decompile python solves
await p.goto(B + "#/learn/rev-decompile"); await p.waitForTimeout(800);
const eds = p.locator(".py-editor");
const sols = [
  `enc = [32, 26, 16, 31, 37, 67, 111, 64, 114, 64, 52, 118, 66, 118, 19, 55, 122, 68, 23, 81, 130, 127, 27, 75, 85, 72, 132, 84, 67]\nprint("".join(chr(((e - i) & 0xff) ^ 0x5a) for i, e in enumerate(enc)))`,
  `perm = [17, 15, 11, 18, 7, 6, 19, 3, 14, 0, 9, 5, 16, 8, 13, 2, 1, 12, 4, 10]\ntarget = "__1401h{cv}TshnC_zF0"\nprint("".join(target[perm[i]] for i in range(20)))`,
  `enc = [129, 41, 244, 19, 137, 32, 223, 130, 168, 240, 215, 128, 153, 201, 229, 128, 168, 240, 215, 178, 185]\nkey = b"R3V!"\nror = lambda x, n: ((x >> n) | (x << (8 - n))) & 0xff\nprint("".join(chr(ror(e ^ key[i % 4], 3)) for i, e in enumerate(enc)))`,
];
for (let i = 0; i < 3; i++) { await eds.nth(i).locator("textarea").fill(sols[i]); await eds.nth(i).locator('[data-a="run"]').click(); await p.waitForTimeout(i ? 1500 : 9000); console.log("PY", i, await eds.nth(i).locator(".py-out").innerText()); }
// interp
await p.goto(B + "#/learn/rev-interp"); await p.waitForTimeout(800);
const jsl = p.locator(".shell-line input").last();
const obf = await p.locator("#chal-rev-js pre code").innerText();
await jsl.fill(obf.trim()); await jsl.press("Enter"); await p.waitForTimeout(300);
await jsl.fill("String.fromCharCode(..._0x2c())"); await jsl.press("Enter"); await p.waitForTimeout(300);
console.log("JS", (await p.locator(".shell-out").last().innerText()).split("\n").slice(-3).join(" | "));
const repl = p.locator(".shell-line input").first();
for (const l of ["T=[129, 75, 93, 80, 134, 110, 134, 130, 66, 115, 65, 118, 70, 115, 128, 70, 118, 131, 129, 74, 152]", "''.join(chr(t-7-i) for i,t in enumerate(T))", "xor(base64.b64decode('aVBHVWh5J3drTHcjcExyY3hMdyBu'), 0x13)"]) { await repl.fill(l); await repl.press("Enter"); await p.waitForTimeout(l.startsWith("T") ? 9000 : 500); }
console.log("PYREPL", (await p.locator(".shell-out").first().innerText()).split("\n").slice(-4).join(" | "));
console.log("ERRS", errs);
await b.close();
