import { chromium } from "playwright-core";
process.env.TMPDIR = new URL("./tmp", import.meta.url).pathname;
const b = await chromium.launch({ executablePath: process.env.HOME + "/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome" });
const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
const errs = []; p.on("pageerror", e => errs.push(e.message));
const B = "http://127.0.0.1:9103/";
const shot = (n) => new URL(`./shots/${n}.png`, import.meta.url).pathname;
await p.goto(B + "#/learn/crypto-block"); await p.waitForTimeout(1200);
await p.locator(".ecb-wrap").scrollIntoViewIfNeeded(); await p.waitForTimeout(600);
await p.locator(".ecb-wrap").screenshot({ path: shot("cr-ecb") });
const ed = p.locator(".py-editor").first();
await ed.locator("textarea").fill(`from pyodide.http import open_url
import json
def get(path): return json.loads(open_url(path).read())
known = b""
while not known.endswith(b"}"):
    padn = 15 - len(known) % 16
    blk = len(known) // 16
    tb = get("/lab/crypto/ecb/oracle?p=" + "41" * padn)["ct"][blk*32:(blk+1)*32]
    pre = b"A" * padn + known
    cands = [(pre + bytes([x]))[-16:] for x in range(32, 127)]
    res = get("/lab/crypto/ecb/oracle?p=" + ",".join(c.hex() for c in cands))["ct"]
    known += bytes([cands[[r[:32] for r in res].index(tb)][-1]])
print(known)`);
await ed.locator("button[data-a=run]").click();
await p.waitForFunction(() => /Xong|Lỗi/.test(document.querySelector(".py-status").textContent), null, { timeout: 60000 });
console.log("ECB byte:", await ed.locator(".py-out").innerText());
// nộp flag
const ch = p.locator("#chal-cr-ecb-byte");
await ch.locator("input").fill((await ed.locator(".py-out").innerText()).replace(/^b'|'$/g, ""));
await ch.locator("button.primary").click(); await p.waitForTimeout(500);
console.log("submit:", await ch.locator(".chal-msg").innerText());
// RSA common modulus trong bàn làm việc
await p.goto(B + "#/learn/crypto-rsa"); await p.waitForTimeout(1200);
const data = await p.evaluate(() => CR.rsa_cm);
const ed2 = p.locator(".py-editor").last();
await ed2.locator("textarea").fill(`def egcd(a, b):
    if b == 0: return a, 1, 0
    g, x, y = egcd(b, a % b)
    return g, y, x - (a // b) * y
n=${data.n}; e1=${data.e1}; e2=${data.e2}; c1=${data.c1}; c2=${data.c2}
g,s,t = egcd(e1,e2)
print(long_to_bytes(pow(c1,s,n)*pow(c2,t,n)%n))`);
await ed2.locator("button[data-a=run]").click();
await p.waitForFunction(() => [...document.querySelectorAll(".py-status")].some(x => /Xong|Lỗi/.test(x.textContent)), null, { timeout: 60000 });
console.log("RSA cm:", await ed2.locator(".py-out").innerText());
await p.goto(B + "#/learn/crypto-classical"); await p.waitForTimeout(1200);
await p.locator(".vg").scrollIntoViewIfNeeded(); await p.waitForTimeout(700);
await p.locator(".vg").screenshot({ path: shot("cr-vig") });
console.log("vig:", (await p.locator(".vg-out").innerText()).slice(0, 160));
await p.goto(B + "#/learn/crypto-xor"); await p.waitForTimeout(1200);
await p.locator(".xb").scrollIntoViewIfNeeded(); await p.waitForTimeout(700);
await p.locator(".xb").screenshot({ path: shot("cr-xor") });
console.log("ERRS", errs);
await b.close();
