# Quy ước viết nội dung zCTF

## File theo track (mỗi agent chỉ sửa file của mình)
- `js/lessons/<track>.js`  — gọi `lesson({...})` cho mỗi bài
- `js/widgets/<track>.js`  — `WIDGETS.ten = (el) => {...}`, `SHELL_FS.ten = {...}`, `NC_SERVICES["host:port"] = ...`, `SQL_DBS.ten = ...`
- `labs/<track>*.py`       — lab FastAPI thật, gắn tại `/lab/<tên-file>/` (cần restart server)
- `.dev/flags/<track>.json` — `{ "chalId": "zCTF{...}" }` để validate
- KHÔNG sửa: js/core/*, js/app.js, js/tools.js, css/style.css, index.html, server.py, .dev/flags/legacy.json
  (CSS riêng: gọi `addStyle("ten", "css...")` trong widget)

## lesson()
```js
lesson({
  id: "web-sqli",          // duy nhất toàn site, nên có tiền tố track
  track: "web", order: 3,  // thứ tự trong track
  level: 1|2|3,            // Cơ bản / Trung cấp / Nâng cao
  title, short, time: "40 phút",
  html: `...<h2 id="...">...</h2>... <div data-chal="web-sqli-1"></div> <div data-quiz="0"></div> <div data-widget="sql" data-db="shop"></div>`,
  quiz: [{ q, options: [...], answer: index, explain }],     // q/options/explain là HTML
  challenges: { "web-sqli-1": { title, pts, diff: "easy"|"med"|"hard", hash: sha256(flag), body: "<p>..</p>", hints: ["..", ".."], widget?: "ten" } },
});
```
- Mọi `<h2>` cần `id` (dùng cho mục lục). Code: sh`...`, py`...`, js`...`, c`...`, asm`...`, sql`...`, txt`...`, http`...`
- Thành phần có sẵn: `.callout.tip|warn|danger|idea` (`<b>Tiêu đề</b><p>..</p>`), `.grid-2`, `.grid-3`, `.card`, `table`, `ol.steps-v`, `.diagram` (bọc SVG), `.chal-data` (dữ liệu đề)
- Flag: `zCTF{...}` duy nhất. Hash: `node .dev/hash.js 'zCTF{...}'`
- Flag trả về bởi widget/lab: không để flag dạng chữ rõ trong JS (dùng base64/XOR nhẹ); trong lab Python thì để thẳng.

## Widget / runtime có sẵn
- `<div data-widget="shell" data-fs="ten" data-height="380">` — engine `createShell` (js/core/shell.js). 
  `SHELL_FS.ten = { fs: () => SH.base({..home..}, "guest", {..thư mục gốc thêm..}), user, host, motd, sudo: {nopasswd, allow:[..]}, groups, cmds: {ten: async (args, stdin, ctx) => ...}, nc: {"host:port": svc} }`
  Lệnh sẵn: ls cd pwd cat head tail wc file strings xxd grep find sort uniq tr rev cut base64 base32 md5sum sha1sum sha256sum echo touch mkdir rm cp mv chmod id whoami sudo nc curl man …; pipe, > >>, <, ;, &&, ||, 2>/dev/null
  `SH.exe(async (args, ctx, stdin) => ..., { owner: "root", mode: "-rwsr-xr-x" })` = chương trình (SUID nếu có s). Trả `{interactive:{banner, prompt, onLine}}` để hỏi input.
  `curl` gửi request thật tới `/lab/...` qua proxy `/__curl`.
- `<div data-widget="python">` REPL; `<div data-widget="python"><template>code…</template></div>` editor + Run (Pyodide thật, có long_to_bytes, xor, p32…)
- `<div data-widget="sql" data-db="ten">` (sql.js thật). `SQL_DBS.ten = { init: "SQL", examples: [...] }`
- `<div data-widget="jsconsole">`
- Helper toàn cục: h(html), esc, d64, addStyle, md5Hex, sha1Hex, sha256Hex, latin1ToBytes, bytesToLatin1, hexOf, utf8, loadScript

## Kiểm thử
```bash
PORT=91xx .venv/bin/python server.py > .dev/s91xx.log 2>&1 & echo $! > .dev/pid91xx
node .dev/validate.mjs 91xx <track> [--shots]     # shots vào .dev/shots/<lessonId>.png
kill $(cat .dev/pid91xx)                           # KHÔNG dùng pkill -f (sẽ giết cả shell của bạn)
```
Lab Python thay đổi → restart server của bạn. JS thay đổi → chỉ cần reload.

## Cập nhật engine (v2.1)
- Glob `*` `?` không trong ngoặc kép được mở rộng (vd `sha256sum mirror*/kali.iso`)
- `sort -t, -k3 -n`, `find ... -exec cmd {} \;`, `echo -n` khi ghi file, `md5sum/sha*sum` nhiều file
- Lệnh tùy biến gọi lại lệnh có sẵn: `await ctx.exec(["cat", "/etc/passwd"], stdin)` (trả về kết quả, không in), `await ctx.run("ls -la")` (chạy cả dòng và in ra)
- Có sẵn `printf "fmt" args` (hỗ trợ \xNN, %s %d %x %05d) và `$?` (mã thoát lệnh trước)
- `gids: { dev: 1002 }` trong SHELL_FS để `id` in đúng GID của group phụ
- `tr -d "\\0"` hiểu \0, \xNN, octal; `strings -e l` (UTF-16LE) có sẵn
- Code Python có ký tự `<`: dùng `<div data-widget="python"><script type="text/x-python">code thô</script></div>` thay cho `<template>`
- Thử thách có `widget: "ten", widgetData: { mode: "x" }` → `<div data-widget="ten" data-mode="x">`
