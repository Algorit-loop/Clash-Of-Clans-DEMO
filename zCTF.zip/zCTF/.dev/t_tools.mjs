import { chromium } from "playwright-core";
process.env.TMPDIR = new URL("./tmp", import.meta.url).pathname;
const b = await chromium.launch({ executablePath: process.env.HOME + "/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome" });
const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
const errs = []; p.on("pageerror", e => errs.push(e.message)); p.on("console", m => m.type()==="error" && errs.push(m.text()));
const B = "http://127.0.0.1:9100/";
await p.goto(B + "#/tools/shell"); await p.waitForTimeout(700);
const inp = p.locator(".shell-line input");
const cmds = ["cat README.txt | head -3", "ls -la", "file challenges/image.png", "strings challenges/image.png | grep zCTF", "xxd -l 32 challenges/image.png", "cat challenges/layers.txt | base64 -d | base64 -d", "tr 'A-Za-z' 'N-ZA-Mn-za-m' < challenges/rot.txt", "cat challenges/rot.txt | tr 'A-Za-z' 'N-ZA-Mn-za-m'", "grep Failed logs/auth.log | cut -d' ' -f11 | sort | uniq -c | sort -n", "find / -perm -4000 2>/dev/null", "cat /root/flag.txt", "/usr/local/bin/backup /root/flag.txt", "strings challenges/checker", "echo hello > /tmp/x.txt && cat /tmp/x.txt", "md5sum challenges/hashes.txt; echo -n password | md5sum", "curl -i http://lab.zctf.local/lab/demo/robots.txt", "curl -A zCTF-Agent -i http://lab.zctf.local/lab/demo/hidden-admin", "curl http://google.com", "id; whoami", "ls nothere || echo fallback"];
for (const c of cmds) { await inp.fill(c); await inp.press("Enter"); await p.waitForTimeout(c.startsWith("curl") ? 600 : 80); }
await inp.fill("challenges/checker"); await inp.press("Enter"); await p.waitForTimeout(100);
await inp.fill("ZCTF-4242-B4BY"); await inp.press("Enter"); await p.waitForTimeout(100);
console.log((await p.locator(".shell-out").innerText()).split("\n").slice(-120).join("\n"));
await p.screenshot({ path: new URL("./shots/t-shell.png", import.meta.url).pathname });
for (const t of ["python", "sql", "js", "hash", "convert", "cipher", "ascii", "decode"]) {
  await p.goto(B + "#/tools/" + t); await p.waitForTimeout(500);
  if (t === "python") {
    await p.locator(".py-editor button[data-a=run]").click(); await p.waitForTimeout(9000);
    console.log("PY EDITOR:", await p.locator(".py-out").innerText());
    const r = p.locator(".shell-line input"); 
    for (const l of ["x = 5", "def f(a):", "    return a*2", "", "f(x)", "long_to_bytes(0x7a435446)", "1/0"]) { await r.fill(l); await r.press("Enter"); await p.waitForTimeout(300); }
    console.log("PY REPL:", await p.locator(".shell-out").innerText());
  }
  if (t === "sql") { await p.locator(".sql-box button[data-a=run]").click(); await p.waitForTimeout(1500); console.log("SQL:", (await p.locator(".sql-res").innerText()).slice(0, 200)); }
  if (t === "js") { const r = p.locator(".shell-line input"); await r.fill("atob('ekNURg==')"); await r.press("Enter"); await p.waitForTimeout(300); await r.fill("console.log(1+1); [1,2]"); await r.press("Enter"); await p.waitForTimeout(300); console.log("JS:", await p.locator(".shell-out").innerText()); }
  if (t === "hash") { await p.locator("#h-crack").click(); console.log("HASH:", await p.locator("#h-out").innerText(), await p.locator("#h-crack-out").innerText()); }
  if (t === "convert") console.log("CONV:", await p.locator("#n-out").innerText());
  if (t === "cipher") console.log("VIG:", await p.locator("#v-out").inputValue());
  await p.screenshot({ path: new URL(`./shots/t-${t}.png`, import.meta.url).pathname });
}
console.log("ERRS", errs);
await b.close();
