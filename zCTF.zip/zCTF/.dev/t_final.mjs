import { chromium } from "playwright-core";
process.env.TMPDIR = new URL("./tmp", import.meta.url).pathname;
const b = await chromium.launch({ executablePath: process.env.HOME + "/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome" });
const errs = [];
const S = (n) => new URL(`./shots/f-${n}.png`, import.meta.url).pathname;
const B = "http://127.0.0.1:9100/";
const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
p.on("pageerror", e => errs.push(e.message));
await p.goto(B); await p.waitForTimeout(500);
await p.evaluate(() => document.querySelectorAll(".reveal").forEach(e => e.classList.add("in")));
await p.evaluate(() => scrollTo(0, 1250)); await p.waitForTimeout(500); await p.screenshot({ path: S("home-tracks") });
await p.goto(B + "#/glossary"); await p.waitForTimeout(600); await p.screenshot({ path: S("glossary") });
await p.goto(B + "#/learn/pwn-ret2win"); await p.waitForTimeout(800);
await p.evaluate(() => document.querySelectorAll(".reveal").forEach(e => e.classList.add("in")));
const w = p.locator(".chal").first(); await w.scrollIntoViewIfNeeded(); await p.evaluate(() => scrollBy(0, -300)); await p.waitForTimeout(300); await p.screenshot({ path: S("pwn") });
const m = await b.newPage({ viewport: { width: 390, height: 844 } });
m.on("pageerror", e => errs.push("m " + e.message));
for (const r of ["", "#/roadmap", "#/learn/web-sqli", "#/tools/shell", "#/glossary"]) {
  await m.goto(B + r); await m.waitForTimeout(700);
  const w2 = await m.evaluate(() => document.documentElement.scrollWidth);
  console.log("mobile", r || "home", w2);
}
await m.goto(B + "#/learn/web-sqli"); await m.waitForTimeout(700); await m.screenshot({ path: S("m-lesson") });
console.log("ERRS", errs); await b.close();
