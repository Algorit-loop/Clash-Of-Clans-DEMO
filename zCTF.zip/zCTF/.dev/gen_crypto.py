"""Sinh dữ liệu đề cho track crypto và tự giải lại để kiểm tra.
Chạy: python3 .dev/gen_crypto.py  → ghi .dev/crypto_data.json và .dev/flags/crypto.json
"""
import hashlib, json, random, math, os

R = random.Random(20261110)
HERE = os.path.dirname(os.path.abspath(__file__))
D = {}
FL = {}


def H(s):
    return hashlib.sha256(s.encode()).hexdigest()


def b2l(b):
    return int.from_bytes(b, "big")


def l2b(n):
    return n.to_bytes((n.bit_length() + 7) // 8 or 1, "big")


def is_prime(n):
    if n < 2:
        return False
    for p in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for _ in range(24):
        a = R.randrange(2, n - 2)
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def prime(bits):
    while True:
        n = R.getrandbits(bits) | (1 << (bits - 1)) | 1
        if is_prime(n):
            return n


def next_prime(n):
    n += 1
    if n % 2 == 0:
        n += 1
    while not is_prime(n):
        n += 2
    return n


def iroot(x, k):
    lo, hi = 0, 1 << (x.bit_length() // k + 2)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if mid ** k <= x:
            lo = mid
        else:
            hi = mid - 1
    return lo


def isqrt(n):
    return math.isqrt(n)


def flag(cid, f):
    FL[cid] = f
    return f


# ---------------------------------------------------------------- 1. cổ điển
def caesar(s, k):
    return "".join(chr((ord(c) - (65 if c.isupper() else 97) + k) % 26 + (65 if c.isupper() else 97)) if c.isalpha() else c for c in s)


def atbash(s):
    return "".join(chr(155 - ord(c)) if c.isupper() else chr(219 - ord(c)) if c.islower() else c for c in s)


def vig(s, key, sign=1):
    out, j = "", 0
    for c in s:
        if c.isalpha():
            b = 65 if c.isupper() else 97
            out += chr((ord(c) - b + sign * (ord(key[j % len(key)].lower()) - 97)) % 26 + b)
            j += 1
        else:
            out += c
    return out


FL["cr1"] = "zCTF{caesar_qua_de_pha}"
assert caesar("gJAM{jhlzhy_xbh_kl_woh}", -7) == FL["cr1"]

f = flag("cr-atbash", "zCTF{atbash_soi_guong}")
D["atbash"] = atbash(f)
assert atbash(D["atbash"]) == f

f = flag("cr-vig", "zCTF{vigenere_lo_khoa_vi_biet_dau_flag}")
D["vig"] = vig(f, "khoa")
# tự giải: biết 4 chữ đầu là zCTF
k = "".join(chr((ord(c.lower()) - ord(p.lower())) % 26 + 97) for c, p in zip(D["vig"][:4], "zCTF"))
assert k == "khoa" and vig(D["vig"], k, -1) == f

f = flag("cr-sub", "zCTF{tan_suat_chien_thang}")
plain = (
    "Frequency analysis is the study of the frequency of letters or groups of letters in a ciphertext. "
    "The method is used as an aid to breaking classical ciphers. It is based on the fact that, in any given "
    "stretch of written language, certain letters and combinations of letters occur with varying frequencies. "
    "Moreover, there is a characteristic distribution of letters that is roughly the same for almost all samples "
    "of that language. In English the letter e is the most common, followed by t, a, o, i and n. "
    "A simple substitution cipher replaces every letter with another letter, but it keeps those patterns, "
    "so a patient analyst can recover the whole message. Well done, the flag is " + f
)
alpha = list("abcdefghijklmnopqrstuvwxyz")
perm = alpha[:]
while any(a == b for a, b in zip(alpha, perm)):
    R.shuffle(perm)
SUB = dict(zip(alpha, perm))
D["sub"] = "".join(SUB[c.lower()].upper() if c.isupper() else SUB[c] if c.islower() else c for c in plain)
INV = {v: k for k, v in SUB.items()}
assert "".join(INV[c.lower()].upper() if c.isupper() else INV[c] if c.islower() else c for c in D["sub"]).endswith(f)

# ---------------------------------------------------------------- 2. XOR
FL["cr2"] = "zCTF{x0r_v0i_kh0a_don}"
assert bytes(b ^ 0x2A for b in bytes.fromhex("50697e6c51521a58755c1a437541421a4b754e454457")).decode() == FL["cr2"]

f = flag("cr-xor-rep", "zCTF{l4p_l41_kh04_ng4n_l4_ch3t}")
key = b"s3cr"
D["xor_rep"] = bytes(b ^ key[i % 4] for i, b in enumerate(f.encode())).hex()
ct = bytes.fromhex(D["xor_rep"])
kk = bytes(c ^ p for c, p in zip(ct, b"zCTF{"))
assert kk[:4] == key and kk[4] == key[0]

f = flag("cr-mtp", "zCTF{mot_lan_thoi_nhe_otp}")
m1 = b"THONG BAO: Buoi sinh hoat CLB chuyen sang toi thu Sau."
otp = bytes(R.randrange(256) for _ in range(len(m1)))
D["mtp_m1"] = m1.decode()
D["mtp_c1"] = bytes(a ^ b for a, b in zip(m1, otp)).hex()
D["mtp_c2"] = bytes(a ^ b for a, b in zip(f.encode(), otp)).hex()
c1, c2 = bytes.fromhex(D["mtp_c1"]), bytes.fromhex(D["mtp_c2"])
assert bytes(a ^ b ^ c for a, b, c in zip(c1, c2, m1)).decode() == f

# ---------------------------------------------------------------- 3. Toán
a, m = 1337, 1_000_000_007
inv = pow(a, -1, m)
flag("cr-inv", f"zCTF{{{inv}}}")
D["inv"] = [a, m]
assert a * inv % m == 1

base, p = 7, 1_000_000_007
e_big = 10 ** 100 + 2026
val = pow(base, e_big, p)
flag("cr-pow", f"zCTF{{{val}}}")
D["pow"] = [base, "10**100 + 2026", p, e_big % (p - 1)]
assert pow(base, e_big % (p - 1), p) == val

f = flag("cr-crt", "zCTF{crt_ghep_manh_ghep_so}")
x = b2l(f.encode())
mods = [prime(48) for _ in range(5)]
while math.prod(mods) <= x:
    mods.append(prime(48))
D["crt"] = [[x % mi, mi] for mi in mods]


def crt(pairs):
    M = math.prod(mm for _, mm in pairs)
    return sum(r * (M // mm) * pow(M // mm, -1, mm) for r, mm in pairs) % M


assert l2b(crt(D["crt"])).decode() == f

# ---------------------------------------------------------------- 4. Mã khối (lab tạo khoá khi chạy)
flag("cr-pad", "zCTF{030303}")
flag("cr-cbc", "zCTF{l4t_b1t_cbc_d0i_qu4n}")
flag("cr-ecb-cut", "zCTF{c4t_d4n_kh0i_ecb}")
flag("cr-ecb-byte", "zCTF{tung_byte_mot}")

# ---------------------------------------------------------------- 5. Hash
FL["cr3"] = "zCTF{password}"
assert hashlib.md5(b"password").hexdigest() == "5f4dcc3b5aa765d61d8327deb882cf99"

WORDS = ("123456 password 12345678 qwerty 123456789 12345 1234 111111 1234567 dragon 123123 baseball abc123 football "
         "monkey letmein 696969 shadow master 666666 qwertyuiop 123321 mustang 1234567890 michael 654321 superman "
         "1qaz2wsx 7777777 121212 000000 qazwsx 123qwe killer trustno1 jordan jennifer zxcvbnm asdfgh hunter buster "
         "soccer harley batman andrew tigger sunshine iloveyou 2000 charlie robert thomas hockey ranger daniel starwars "
         "klaster 112233 george computer michelle jessica pepper 1111 zxcvbn 555555 11111111 131313 freedom 777777 pass "
         "maggie 159753 aaaaaa ginger princess joshua cheese amanda summer love ashley nicole chelsea biteme matthew access "
         "yankees 987654321 dallas austin thunder taylor matrix").split()
D["words"] = WORDS
salt = "zctf$2026$"
pw = "matrix"
D["salt"] = [salt, hashlib.sha256((salt + pw).encode()).hexdigest()]
flag("cr-salt", f"zCTF{{{pw}}}")
assert [w for w in WORDS if hashlib.sha256((salt + w).encode()).hexdigest() == D["salt"][1]] == [pw]

pin = "4821"
msg = "user=guest&role=user"
D["mac"] = [msg, hashlib.sha256((pin + msg).encode()).hexdigest()]
flag("cr-mac", f"zCTF{{pin_{pin}}}")
assert [p for p in (f"{i:04d}" for i in range(10000)) if hashlib.sha256((p + msg).encode()).hexdigest() == D["mac"][1]] == [pin]

# ---------------------------------------------------------------- 6. RSA
E = 65537
f = flag("cr-rsa1", "zCTF{rsa_co_ban_that_de}")
p, q = prime(256), prime(256)
n = p * q
D["rsa1"] = dict(p=p, q=q, e=E, c=pow(b2l(f.encode()), E, n))
d = pow(E, -1, (p - 1) * (q - 1))
assert l2b(pow(D["rsa1"]["c"], d, n)).decode() == f

f = flag("cr-rsa-fermat", "zCTF{p_va_q_qua_gan_nhau}")
p = prime(512)
q = next_prime(p + R.getrandbits(200))
n = p * q
D["rsa_fermat"] = dict(n=n, e=E, c=pow(b2l(f.encode()), E, n))
aa = isqrt(n)
if aa * aa < n:
    aa += 1
while True:
    b2 = aa * aa - n
    bb = isqrt(b2)
    if bb * bb == b2:
        break
    aa += 1
pp, qq = aa - bb, aa + bb
assert pp * qq == n and l2b(pow(D["rsa_fermat"]["c"], pow(E, -1, (pp - 1) * (qq - 1)), n)).decode() == f

f = flag("cr-rsa-e3", "zCTF{e_nho_lay_can_bac_ba}")
p, q = prime(1024), prime(1024)
while math.gcd(3, (p - 1) * (q - 1)) != 1:
    p, q = prime(1024), prime(1024)
n = p * q
D["rsa_e3"] = dict(n=n, e=3, c=pow(b2l(f.encode()), 3, n))
assert l2b(iroot(D["rsa_e3"]["c"], 3)).decode() == f

f = flag("cr-rsa-gcd", "zCTF{chung_mot_so_nguyen_to}")
p, q1, q2 = prime(512), prime(512), prime(512)
n1, n2 = p * q1, p * q2
D["rsa_gcd"] = dict(n1=n1, n2=n2, e=E, c1=pow(b2l(f.encode()), E, n1))
g = math.gcd(n1, n2)
assert g == p and l2b(pow(D["rsa_gcd"]["c1"], pow(E, -1, (g - 1) * (n1 // g - 1)), n1)).decode() == f

f = flag("cr-rsa-cm", "zCTF{cung_n_khac_e_la_toang}")
p, q = prime(512), prime(512)
n = p * q
e1, e2 = 65537, 257
m_ = b2l(f.encode())
D["rsa_cm"] = dict(n=n, e1=e1, e2=e2, c1=pow(m_, e1, n), c2=pow(m_, e2, n))


def egcd(a, b):
    if b == 0:
        return a, 1, 0
    g, x, y = egcd(b, a % b)
    return g, y, x - (a // b) * y


g, s, t = egcd(e1, e2)
assert g == 1
mm = pow(D["rsa_cm"]["c1"], s, n) * pow(D["rsa_cm"]["c2"], t, n) % n
assert l2b(mm).decode() == f

# ---------------------------------------------------------------- ghi
HASH = {k: H(v) for k, v in FL.items()}
json.dump({"data": D, "hash": HASH}, open(os.path.join(HERE, "crypto_data.json"), "w"), indent=1, default=str)
json.dump(FL, open(os.path.join(HERE, "flags", "crypto.json"), "w"), indent=1, ensure_ascii=False)
print("OK", len(FL), "flags")
for k in ("atbash", "vig", "xor_rep", "mtp_c1", "mtp_c2"):
    print(k, D[k])
print("sub", D["sub"][:120], "...")
print("inv", inv, "pow", val, "e mod p-1", e_big % (p - 1) if False else D["pow"][3])


def _js(o):
    if isinstance(o, bool) or o is None:
        return o
    if isinstance(o, int):
        return str(o) if abs(o) > 2 ** 53 else o
    if isinstance(o, dict):
        return {k: _js(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_js(v) for v in o]
    return o


with open(os.path.join(HERE, "..", "js", "widgets", "crypto_data.js"), "w") as fh:
    fh.write("/* Sinh tự động bởi .dev/gen_crypto.py — không sửa tay. Số lớn ở dạng chuỗi. */\n")
    fh.write("const CR = " + json.dumps(_js(D), ensure_ascii=False) + ";\n")
    fh.write("const CR_HASH = " + json.dumps(HASH) + ";\n")
print("wrote js/widgets/crypto_data.js")
