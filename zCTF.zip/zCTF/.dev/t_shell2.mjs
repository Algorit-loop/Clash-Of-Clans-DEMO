import { chromium } from "playwright-core";
process.env.TMPDIR = new URL("./tmp", import.meta.url).pathname;
const b = await chromium.launch({ executablePath: process.env.HOME + "/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome" });
const p = await b.newPage();
const errs = []; p.on("pageerror", e => errs.push(e.message));
await p.goto("http://127.0.0.1:9100/#/tools/shell"); await p.waitForTimeout(700);
const inp = p.locator(".shell-line input");
for (const c of ["printf \"%s-%05d|%x\n\" ab 42 255", "printf \"\x41\x42\" | xxd", "ls nope; echo $?", "echo $?"]) { await inp.fill(c); await inp.press("Enter"); await p.waitForTimeout(80); }
console.log((await p.locator(".shell-out").innerText()).split("\n").slice(1).join("\n"));
console.log("ERRS", errs); await b.close();
