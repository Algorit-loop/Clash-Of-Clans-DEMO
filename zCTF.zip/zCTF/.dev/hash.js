// node .dev/hash.js 'zCTF{...}' ['zCTF{...}' ...]  → in SHA-256 để điền vào trường hash của thử thách
const c = require("crypto");
for (const f of process.argv.slice(2)) console.log(c.createHash("sha256").update(f).digest("hex"), f);
