import { chromium } from "playwright-core";
process.env.TMPDIR = new URL("./tmp", import.meta.url).pathname;
const b = await chromium.launch({ executablePath: process.env.HOME + "/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome" });
const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
const errs = []; p.on("pageerror", e => errs.push(e.message));
const B = "http://127.0.0.1:9104/";
async function shell(cmds) { const inp = p.locator(".shell-line input").first(); for (const c of cmds) { await inp.fill(c); await inp.press("Enter"); await p.waitForTimeout(120); } return (await p.locator(".shell-out").first().innerText()); }
async function submit(id, flag) { const ch = p.locator("#chal-" + id); await ch.locator(".flag-form input").fill(flag); await ch.locator(".flag-form button.primary").click(); await p.waitForTimeout(300); return await ch.locator(".chal-msg").innerText(); }
await p.goto(B + "#/learn/fo-file"); await p.waitForTimeout(900);
console.log(await shell(["file evidence/*", "file evidence/meme.png", "file evidence/vacation.jpg", "strings evidence/firmware.bin | grep -i pass", "strings -e l evidence/firmware.bin", "exiftool evidence/vacation.jpg", "binwalk evidence/vacation.jpg", "dd if=evidence/vacation.jpg of=out.zip bs=1 skip=5120", "unzip out.zip", "cat flag.txt", "binwalk -e evidence/vacation.jpg", "ls evidence/_vacation.jpg.extracted", "file out.zip"]));
// png fix
await p.locator(".hexed").scrollIntoViewIfNeeded(); await p.waitForTimeout(500);
const hb = p.locator(".hexed .hx-b");
const set = async (i, v) => { await hb.nth(i).fill(v); };
await set(0, "89"); await set(1, "50"); await set(2, "4e"); await set(3, "47"); await set(12, "49"); await set(13, "48"); await set(14, "44"); await set(15, "52");
await p.locator('.hexed [data-a="render"]').click(); await p.waitForTimeout(600);
console.log("IMG rendered:", await p.locator(".hexed .hx-view img").count());
await p.locator(".hexed").screenshot({ path: new URL("./shots/fo-hex.png", import.meta.url).pathname });
for (const [k, v] of [["fo-file-2", "zCTF{utf16_tr0n_kh01_str1ngs}"], ["fo-file-3", "zCTF{h34d3r_s4ch_s3}"], ["fo-file-4", "zCTF{z1p_tr0ng_4nh_jp3g}"], ["fo1", "zCTF{pdf}"]]) console.log(k, await submit(k, v));
// stego
await p.goto(B + "#/learn/fo-stego"); await p.waitForTimeout(900);
await p.locator('.lsb [data-g="ch"] button[data-v="1"]').click(); await p.locator('.lsb [data-k="bit"]').fill("1"); await p.waitForTimeout(200);
await p.locator(".lsb").screenshot({ path: new URL("./shots/fo-lsb-plane.png", import.meta.url).pathname });
await p.locator('.lsb [data-a="ex"]').click(); console.log("LSB:", (await p.locator(".lsb .xout").innerText()).slice(0, 120));
console.log(await shell(["exiftool cat.png", "strings cat.png | tail -2", "strings cat.png | tail -1 | base64 -d", "exiftool beach.jpg", "steghide extract -sf beach.jpg -p songbien2024", "cat note.txt", "binwalk cat.png"]));
// network
await p.goto(B + "#/learn/fo-network"); await p.waitForTimeout(900);
const fi = p.locator(".ws-f");
for (const f of ['http.request.method == "POST"', "ftp-data", 'dns.qry.name contains "cdn-update"', "ip.addr == 198.51.100.21 && tcp.port == 21", "bad filter ==", 'frame contains "pass"']) { await fi.fill(f); await fi.press("Enter"); await p.waitForTimeout(150); console.log("FILTER", f, "->", await p.locator(".ws-stat").innerText()); }
await fi.fill('http.request.method == "POST"'); await fi.press("Enter"); await p.locator(".ws tr.pk").first().click(); console.log("POST detail:", (await p.locator(".ws-tree").innerText()).split("\n").slice(-3).join(" | "));
await fi.fill("ftp-data"); await fi.press("Enter"); await p.locator(".ws tr.pk").first().click(); await p.locator('.ws [data-a="follow"]').click(); console.log("FOLLOW:", await p.locator(".ws-follow").innerText());
await fi.fill('dns.qry.name contains "cdn-update" && !dns.qry.name contains "done"'); await fi.press("Enter"); console.log("DNS rows:", (await p.locator(".ws tbody").innerText()).split("\n").filter((l,i)=>i%2==0).map(l=>l.split("\t").pop()).join("\n"));
await p.locator(".ws").screenshot({ path: new URL("./shots/fo-ws.png", import.meta.url).pathname });
// dfir
await p.goto(B + "#/learn/fo-dfir"); await p.waitForTimeout(900);
const out = await shell(["vol -f case/memdump.raw windows.pstree", "vol -f case/memdump.raw windows.cmdline --pid 4488", "vol -f case/memdump.raw windows.cmdline --pid 4488 | grep -oE '[A-Za-z0-9+/=]{40,}' | base64 -d | iconv -f UTF-16LE -t UTF-8", "vol -f case/memdump.raw windows.netscan", "vol -f case/memdump.raw windows.filescan", "vol -f case/memdump.raw windows.dumpfiles --virtaddr 0xe0001a2b3c40", "cat file.0xe0001a2b3c40*", "ls", "grep Failed case/logs/auth.log | grep -oE 'from [0-9.]+' | sort | uniq -c | sort -rn", "grep Accepted case/logs/auth.log | grep 203.0.113.77", "fls -r case/disk.img", "icat case/disk.img 23"]);
console.log(out.split("\n").slice(-75).join("\n"));
// osint
await p.goto(B + "#/learn/osint-search"); await p.waitForTimeout(900);
console.log(await shell(["dig TXT caphemay.example +short", "crtsh caphemay.example", "whois caphemay.example | head -3", "exiftool downloads/bao-cao-2025.pdf | grep Author", "sherlock maitt.dev", "wayback github.example/maitt.dev", "wayback github.example/maitt.dev 20230115"]));
const dk = p.locator(".dork input");
for (const q of ["cà phê mây", "site:caphemay.example filetype:pdf", "site:caphemay.example ext:env", 'site:caphemay.example intitle:"index of"', "site:caphemay.example -site:dev.caphemay.example"]) { await dk.fill(q); await dk.press("Enter"); console.log("DORK", q, "->", (await p.locator(".dk-res").innerText()).split("\n").slice(0, 6).join(" | ")); }
await p.locator(".dork").screenshot({ path: new URL("./shots/os-dork.png", import.meta.url).pathname });
await p.goto(B + "#/learn/osint-geo"); await p.waitForTimeout(900);
for (const [k, v] of [["os-geo-2", "zCTF{nam}"], ["os-geo-3", "zCTF{thai_lan}"]]) console.log(k, await submit(k, v));
await p.locator("#chal-os-geo-3").screenshot({ path: new URL("./shots/os-geo3.png", import.meta.url).pathname });
console.log("ERRS", errs);
await b.close();
