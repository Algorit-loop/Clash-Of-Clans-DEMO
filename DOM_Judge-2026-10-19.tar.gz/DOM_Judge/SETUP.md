# SETUP — Cài đặt DOMjudge trên máy này

Ghi lại toàn bộ quá trình cài DOMjudge chuẩn (image Docker chính thức, không sửa code) trong `/home/worker/DOM_Judge`, ngày 19/10/2026.
Hướng dẫn sử dụng chi tiết (tạo bài, contest, cấu hình...) xem [HUONG_DAN_SU_DUNG.md](HUONG_DAN_SU_DUNG.md).

## 1. Kết quả

| Thành phần | Trạng thái | Ghi chú |
| --- | --- | --- |
| MariaDB 11.4 | chạy | dữ liệu ở `data/mariadb/` |
| Domserver 9.0.0 | chạy (healthy) | web: `http://<IP máy>:4949` |
| Judgehost 9.0.0 × 2 | chạy | `judgehost-0` (lõi CPU 0), `judgehost-1` (lõi CPU 1) |

Đã kiểm tra bằng 7 bài nộp vào bài `hello` của contest `demo`:

| Bài nộp | Kỳ vọng | Kết quả | Thời gian chạy |
| --- | --- | --- | --- |
| C++ in đúng | AC | AC | 0.002 s |
| Python 3 in đúng | AC | AC | 0.043 s |
| Java in đúng | AC | AC | 0.045 s |
| C++ in sai | WA | WA | 0.001 s |
| C++ lặp vô hạn | TLE | TLE | 5.985 s (TL 5 s + overshoot) |
| C++ cấp phát 3 GB | bị chặn ở 2 GB | RTE, bị kill khi đạt đúng 2 147 483 648 byte (exit 137) | 3.5 s |

Sandbox giới hạn được cả thời gian lẫn bộ nhớ. DOMjudge báo bài bị OOM-kill là `RTE`, không phải `MLE`: đây là hành vi gốc của DOMjudge.
Các bài nộp thử dùng team `domjudge` (category System, ẩn khỏi bảng điểm).

## 2. Phiên bản

| Thứ | Phiên bản |
| --- | --- |
| Hệ điều hành | Ubuntu 22.04.1 LTS (máy ảo KVM, đĩa virtio `/dev/vda1`, ext4) |
| Kernel | **6.8.0-138-generic** (gói HWE), trước đó là 5.15.0-138-generic |
| Bootloader | syslinux (`/boot/syslinux.cfg`), không phải grub |
| Docker / Compose | 28.1.1 / 2.35.1 |
| cgroup | v2 (unified) |
| DOMjudge | **9.0.0** (`domjudge/domserver:9.0.0`, `domjudge/judgehost:9.0.0`, phát hành 16/10/2026) |
| MariaDB | `mariadb:11.4` |
| Trình biên dịch trong judgehost | g++ 13.3.0, Python 3.12.3, OpenJDK 21.0.12 |

Phần cứng: 16 CPU, 62 GB RAM. Máy này **đang chạy chung** với bkdnoj (`bkdnoj_*`, `lg_judge_01..05`). Hai hệ thống không dùng chung port, container hay database.

## 3. Điều kiện bắt buộc

1. **Kernel ≥ 5.19 nếu dùng cgroup v2.** Runguard của DOMjudge đọc file `memory.peak` của cgroup v2, và file này chỉ có từ kernel 5.19. Kernel cũ hơn thì judgehost báo `kernel ... is too old to record peak RAM usage with cgroup V2` và dừng. DOMjudge 8.3.1 cũng có giới hạn này. Cách khác là chuyển máy sang cgroup v1, nhưng không khuyến khích.
2. **Judgehost phải chạy `privileged: true`, `cgroup: host` (tức `--cgroupns=host`) và mount `/sys/fs/cgroup`.** Thiếu `cgroup: host` thì judgehost báo `missing cgroup hierarchy prefix under /proc/self/cgroup`.
3. **Domserver và judgehost phải cùng phiên bản.**
4. Mỗi judgehost trên cùng một máy cần `DAEMON_ID` khác nhau. `DAEMON_ID` cũng là lõi CPU mà judgehost ghim vào.
5. Cổng 4949 phải còn trống. bkdnoj không dùng cổng này.

## 4. Các bước đã làm

### Bước 1 — Tạo thư mục và docker-compose.yml

```bash
mkdir /home/worker/DOM_Judge
```

Nội dung `docker-compose.yml` cuối cùng:

```yaml
# DOMjudge 9.0.0 — official images (https://hub.docker.com/r/domjudge)
x-db-env: &db-env
  MYSQL_ROOT_PASSWORD: ${MYSQL_ROOT_PASSWORD}
  MYSQL_USER: domjudge
  MYSQL_PASSWORD: ${MYSQL_PASSWORD}
  MYSQL_DATABASE: domjudge

x-judgehost: &judgehost
  image: domjudge/judgehost:9.0.0
  restart: unless-stopped
  privileged: true
  cgroup: host
  depends_on: [domserver]
  volumes:
    - /sys/fs/cgroup:/sys/fs/cgroup

services:
  mariadb:
    image: mariadb:11.4
    restart: unless-stopped
    environment: *db-env
    command: --max-connections=1000 --max-allowed-packet=512M --innodb-log-file-size=512M
    volumes:
      - ./data/mariadb:/var/lib/mysql

  domserver:
    image: domjudge/domserver:9.0.0
    restart: unless-stopped
    depends_on: [mariadb]
    environment:
      <<: *db-env
      MYSQL_HOST: mariadb
      CONTAINER_TIMEZONE: Asia/Ho_Chi_Minh
    ports:
      - "4949:80"

  judgehost-0:
    <<: *judgehost
    hostname: judgehost-0
    environment:
      DAEMON_ID: 0
      DOMSERVER_BASEURL: http://domserver/
      JUDGEDAEMON_PASSWORD: ${JUDGEDAEMON_PASSWORD}

  judgehost-1:
    <<: *judgehost
    hostname: judgehost-1
    environment:
      DAEMON_ID: 1
      DOMSERVER_BASEURL: http://domserver/
      JUDGEDAEMON_PASSWORD: ${JUDGEDAEMON_PASSWORD}
```

### Bước 2 — Sinh mật khẩu vào `.env`

```bash
cd /home/worker/DOM_Judge
umask 077
printf 'MYSQL_ROOT_PASSWORD=%s\nMYSQL_PASSWORD=%s\nJUDGEDAEMON_PASSWORD=pending\n' \
  "$(openssl rand -hex 16)" "$(openssl rand -hex 16)" > .env
```

File `.env` có quyền 600. Không đưa nó vào git và không chia sẻ.

### Bước 3 — Chạy database và domserver

```bash
docker compose up -d mariadb domserver
```

Lần đầu, domserver tự tạo database, nạp dữ liệu mặc định (contest `demo`, 3 bài mẫu, 23 ngôn ngữ, trong đó C/C++/Java/Python 3 được bật), rồi sinh:

- mật khẩu admin: `/opt/domjudge/domserver/etc/initial_admin_password.secret`
- mật khẩu judgehost: `/opt/domjudge/domserver/etc/restapi.secret`

### Bước 4 — Chép mật khẩu judgehost vào `.env` (không in ra màn hình)

```bash
pw=$(docker compose exec -T domserver sh -c "grep -v '^#' /opt/domjudge/domserver/etc/restapi.secret | awk '{print \$4}'")
sed -i "s/^JUDGEDAEMON_PASSWORD=.*/JUDGEDAEMON_PASSWORD=$pw/" .env
unset pw
```

### Bước 5 — Nâng kernel lên 6.8 (vì kernel 5.15 thiếu `memory.peak`)

```bash
sudo apt-get update
sudo apt-get install -y linux-image-generic-hwe-22.04
```

Trước khi khởi động lại, đã kiểm tra:

- Gói kernel tự trỏ symlink `/boot/vmlinuz` → `vmlinuz-6.8.0-138-generic` và `/boot/initrd.img` → `initrd.img-6.8.0-138-generic`. `vmlinuz.old` / `initrd.img.old` vẫn trỏ về 5.15.
- Kernel 6.8 có `CONFIG_VIRTIO_BLK=y` và `CONFIG_EXT4_FS=y` (build sẵn), nên chắc chắn đọc được ổ đĩa gốc.
- Docker được bật tự chạy (`systemctl is-enabled docker` = enabled). Mọi container bkdnoj có restart policy `unless-stopped` hoặc `always`.

Đã sao lưu `/boot/syslinux.cfg` → `/boot/syslinux.cfg.bak-20261019` và thêm mục khởi động dự phòng `old` (kernel 5.15). Mục mặc định không đổi:

```
 LABEL old
  KERNEL /boot/vmlinuz.old
  APPEND ro root=UUID=1ba96178-17ba-49b6-aec9-5fd20de875a6 initrd=/boot/initrd.img.old net.ifnames=0 console=tty0 console=ttyS0,115200n8
```

Sau đó khởi động lại:

```bash
sudo reboot
```

Sau khi khởi động lại: `uname -r` = `6.8.0-138-generic`, có file `/sys/fs/cgroup/system.slice/memory.peak`, và toàn bộ container bkdnoj cùng DOMjudge tự chạy lại.

### Bước 6 — Chạy judgehost

```bash
docker compose up -d judgehost-0 judgehost-1
```

Lần đầu bị lỗi `missing cgroup hierarchy prefix ... set cgroupns=host`. Đã sửa bằng cách thêm `cgroup: host` vào khối `x-judgehost` (đã có trong file ở Bước 1), rồi chạy lại lệnh trên. Log báo `Judge started on judgehost-0-0 [DOMjudge/9.0.0]`.

### Bước 7 — Nộp thử

Nộp qua REST API bằng tài khoản admin (kết quả xem mục 1). Lưu ý: **API dùng ID ngoài** (external ID). Contest phải gọi là `demo`, không phải `1`:

```bash
B=http://localhost:4949/api/v4/contests/demo
PW=$(docker compose exec -T domserver cat /opt/domjudge/domserver/etc/initial_admin_password.secret | tr -d '\r\n')
curl -s -u "admin:$PW" -X POST $B/submissions \
  -F problem_id=hello -F language_id=cpp -F team_id=domjudge -F "code[]=@hello.cpp"
curl -s -u "admin:$PW" "$B/judgements?strict=false"
unset PW
```

### Bước 8 — Dọn dẹp

Đã xóa các image tải về trong lúc thử nghiệm: `domjudge/judgehost:8.3.1`, tag `domjudge/domserver:latest`, `mariadb:11`. Image `mariadb:latest` của bkdnoj vẫn giữ nguyên.

## 5. Lưu ý vận hành

- **Lấy mật khẩu admin:**
  `docker compose exec domserver cat /opt/domjudge/domserver/etc/initial_admin_password.secret`
  Nên đổi mật khẩu ngay trên web (Jury → Users → admin). Quên mật khẩu thì chạy:
  `docker compose exec domserver /opt/domjudge/domserver/webapp/bin/console domjudge:reset-user-password admin`
- **Khởi động lại máy:** mọi thứ tự chạy lại nhờ `restart: unless-stopped`. Nếu đã `docker compose stop` một container thì nó sẽ không tự chạy lại; khi đó chạy `docker compose up -d`.
- **Nâng cấp DOMjudge:** đổi tag của **cả** domserver và judgehost trong `docker-compose.yml` sang cùng một phiên bản. Sao lưu database trước (xem HUONG_DAN_SU_DUNG.md mục 9.1), rồi chạy `docker compose pull && docker compose up -d`.
- **Thêm máy chấm:** chép khối `judgehost-1`, đổi tên, `hostname` và `DAEMON_ID` (2, 3, ...). Nên giữ tổng số máy chấm khoảng ≤ 6, vì bkdnoj cũng dùng CPU của máy này.
- **Múi giờ:** domserver dùng `Asia/Ho_Chi_Minh`. Log của judgehost hiển thị theo giờ khác (UTC/Europe/Amsterdam); việc này không ảnh hưởng gì.
- **Kernel:** đừng gỡ gói `linux-image-generic-hwe-22.04`. Nếu quay về kernel 5.15, judgehost sẽ không chạy được.
- **Khôi phục khi kernel 6.8 lỗi:** syslinux không hiện menu. Phải dùng console của nhà cung cấp VPS để chọn mục `old`. Hoặc từ một hệ thống cứu hộ, trỏ lại symlink: `ln -sf vmlinuz-5.15.0-138-generic /boot/vmlinuz` và `ln -sf initrd.img-5.15.0-138-generic /boot/initrd.img`.
- **Bảo mật:** web đang chạy HTTP thuần. Khi mở ra Internet, đặt sau reverse proxy có HTTPS. Judgehost chạy privileged, tức có quyền gần như root trên máy.

## 6. Cấu trúc thư mục

```
/home/worker/DOM_Judge/
├── docker-compose.yml       # định nghĩa 4 dịch vụ
├── .env                     # mật khẩu (quyền 600) — KHÔNG chia sẻ
├── data/mariadb/            # dữ liệu database (thuộc root)
├── SETUP.md                 # file này
└── HUONG_DAN_SU_DUNG.md     # hướng dẫn sử dụng
```
