# Hướng dẫn sử dụng DOMjudge

Oct 19, 2026 · @Duc Dang

## 1. Tổng quan

DOMjudge 9.0.0 (bản chính thức, phát hành 16/10/2026) được cài bằng Docker trong `/home/worker/DOM_Judge`. Giao diện web chạy tại **http://<IP máy>:4949**. Tài liệu này viết dựa trên mã nguồn 9.0.0 bên trong container và [tài liệu chính thức](https://www.domjudge.org/docs/manual/main/).

DOMjudge gồm 3 thành phần:

| Thành phần | Container | Vai trò |
| --- | --- | --- |
| MariaDB | `mariadb` | Lưu mọi thứ: bài, testcase, bài nộp, kết quả, cấu hình |
| Domserver | `domserver` | Web cho admin/jury, thí sinh, bảng điểm công khai và REST API |
| Judgehost (máy chấm) | `judgehost-0`, `judgehost-1` | Hỏi domserver lấy bài nộp, biên dịch, chạy trong sandbox, gửi kết quả về |

Judgehost chủ động gọi domserver qua HTTP (`http://domserver/api`), domserver không gọi ngược lại. Vì vậy có thể đặt máy chấm ở máy khác, miễn là nó truy cập được URL của domserver.

**Trạng thái hiện tại (19/10/2026):** cả 4 container (MariaDB, domserver, judgehost-0, judgehost-1) đang chạy và đã chấm thử thành công. Máy đã được nâng lên kernel 6.8 để judgehost chạy được (xem mục 6.1 và [SETUP.md](SETUP.md)).

Các vai trò người dùng:

- **admin**: toàn quyền, sửa cấu hình, tạo contest, bài, user.
- **jury**: xem và chấm lại bài nộp, trả lời clarification, xác minh kết quả.
- **team**: thí sinh, nộp bài, xem bảng điểm, gửi câu hỏi.
- **balloon**: chỉ xem trang phát bóng bay.
- **api_reader / api_writer / api_source_reader**: tài khoản cho script dùng API.
- **judgehost**: tài khoản nội bộ máy chấm dùng (không đăng nhập web).

Mỗi tài khoản team phải gắn với một **team**. Một team có **category** (nhóm, ví dụ Participants, Observers, Jury) và có thể có **affiliation** (trường/tổ chức).

## 2. Cài đặt & vận hành

Toàn bộ cài đặt nằm trong 2 file của `/home/worker/DOM_Judge`: `docker-compose.yml` (các dịch vụ) và `.env` (mật khẩu, quyền 600, không chia sẻ). Dữ liệu database nằm ở `data/mariadb/`.

### 2.1 Ý nghĩa docker-compose.yml

| Khóa | Giá trị | Ý nghĩa / nếu đổi |
| --- | --- | --- |
| `image: domjudge/domserver:9.0.0` | phiên bản ghim cố định | Domserver và judgehost phải cùng phiên bản. Nâng cấp: đổi cả hai tag, `docker compose pull && docker compose up -d`; domserver tự migrate database |
| `mariadb: command: --max-connections=1000 --max-allowed-packet=512M --innodb-log-file-size=512M` | khuyến nghị của DOMjudge | `max-allowed-packet` phải lớn hơn file testcase/zip lớn nhất, nếu nhỏ hơn thì upload bài lớn sẽ lỗi |
| `volumes: ./data/mariadb` | dữ liệu bền | Xóa thư mục này = mất sạch dữ liệu |
| `CONTAINER_TIMEZONE: Asia/Ho_Chi_Minh` | múi giờ | Ảnh hưởng giờ hiển thị và cách hiểu giờ contest khi không ghi múi giờ |
| `ports: "4949:80"` | cổng web | Đổi số bên trái để dùng cổng khác (ví dụ `80:80`) |
| `privileged: true` + `cgroup: host` + `/sys/fs/cgroup` | bắt buộc cho judgehost | Thiếu thì sandbox không giới hạn được CPU/RAM, judgehost không khởi động (thiếu `cgroup: host` sẽ báo `missing cgroup hierarchy prefix`) |
| `DAEMON_ID` | 0, 1, ... | Số thứ tự máy chấm, cũng là lõi CPU mà nó ghim vào (mục 6) |
| `DOMSERVER_BASEURL` | `http://domserver/` | URL judgehost dùng để gọi API |
| `JUDGEDAEMON_PASSWORD` | lấy từ `restapi.secret` | Sai mật khẩu thì judgehost báo 401 và không chấm |

### 2.2 Lệnh thường dùng

Chạy trong `/home/worker/DOM_Judge`:

```bash
docker compose up -d                 # khởi động tất cả
docker compose ps                    # xem trạng thái
docker compose logs -f domserver     # xem log (Ctrl+C để thoát)
docker compose restart judgehost-0   # khởi động lại 1 máy chấm
docker compose stop                  # dừng, giữ dữ liệu
docker compose down                  # xóa container, vẫn giữ data/mariadb
```

Các container có `restart: unless-stopped`, nên tự chạy lại khi máy khởi động lại.

### 2.3 Mật khẩu admin

Lần đầu khởi động, domserver tự sinh mật khẩu ngẫu nhiên cho user `admin`. Lấy nó bằng:

```bash
docker compose exec domserver cat /opt/domjudge/domserver/etc/initial_admin_password.secret
```

Sau khi đăng nhập, đổi mật khẩu tại **Jury → Users → admin → Edit**. Quên mật khẩu thì đặt lại bằng:

```bash
docker compose exec domserver /opt/domjudge/domserver/webapp/bin/console domjudge:reset-user-password admin
```

Mật khẩu judgehost nằm trong `/opt/domjudge/domserver/etc/restapi.secret` của domserver và đã được chép vào `.env`. Khi tạo lại container domserver trên database cũ, mật khẩu này không đổi, vì nó cũng được lưu trong database.

## 3. Đăng nhập, tài khoản và đăng ký

### 3.1 Đăng nhập

Vào `http://<IP>:4949/login`. Sau khi đăng nhập, admin/jury được đưa tới `/jury`, team tới `/team`. Trang `/public` là bảng điểm công khai, không cần đăng nhập.

Ngoài đăng nhập bằng mật khẩu, có thể bật thêm phương thức trong **Config → Authentication → auth_methods**:

- `ipaddress`: đăng nhập theo địa chỉ IP của máy. Mỗi user khai báo trường **IP address**. Bật thêm `ip_autologin` thì vào thẳng, không qua trang login. Phù hợp phòng thi máy cố định.
- `xheaders`: đăng nhập qua header HTTP do reverse proxy gắn vào (SSO). Chỉ bật khi có proxy tin cậy đứng trước, nếu không ai cũng giả mạo được header.

### 3.2 Tạo tài khoản thủ công

1. **Jury → Team Categories**: kiểm tra có nhóm `Participants` (mặc định có sẵn). Nhóm có **Visible** tắt thì team trong nhóm không hiện trên bảng điểm công khai.
2. **Jury → Affiliations → Add**: tùy chọn, tên trường/lớp.
3. **Jury → Teams → Add new team**: nhập tên, chọn category, affiliation. Tick **Create user** để tạo luôn tài khoản đăng nhập (username + mật khẩu) cho team.
4. Muốn tạo tài khoản jury/admin: **Jury → Users → Add new user**, chọn role `jury` hoặc `admin`.

Nếu contest không để **Open to all teams**, phải thêm team (hoặc category) vào contest thì team mới thấy được contest (mục 4).

### 3.3 Import hàng loạt

Vào **Jury → Import / export**. Có hai định dạng:

| Định dạng | Loại import được | Ghi chú |
| --- | --- | --- |
| JSON / YAML (chuẩn [CCS Contest API](https://ccs-specs.icpc.io/)) | groups, organizations, teams, accounts | Khuyên dùng |
| TSV (định dạng cũ) | groups, teams, accounts | Dòng đầu phải là `teams\t1`, `accounts\t1`... |

Thứ tự import: groups → organizations → teams → accounts. Ví dụ `teams.json` và `accounts.yaml`:

```json
[
  {"id": "t1", "name": "Nguyen Van A", "group_ids": ["participants"], "organization_id": "lop10a1"},
  {"id": "t2", "name": "Tran Thi B",  "group_ids": ["participants"], "organization_id": "lop10a1"}
]
```

```yaml
- id: t1
  username: t1
  password: matkhau1
  type: team
  team_id: t1
  name: Nguyen Van A
```

Trường `id` của group/team là ID ngoài (external ID). Import lại cùng ID thì dữ liệu cũ được cập nhật, không tạo trùng.

### 3.4 Bật / tắt tự đăng ký

DOMjudge 9 **không có nút bật/tắt chung**. Tự đăng ký bật theo từng team category:

1. **Jury → Team Categories →** chọn nhóm (ví dụ Participants) **→ Edit**.
2. Tick **Allow self-registration**, lưu lại.
3. Trang login xuất hiện link **Register**. Người dùng tự tạo tài khoản và team, team đó vào category đã bật.

Nếu nhiều category cùng bật, form đăng ký cho người dùng chọn category. **Tắt**: bỏ tick ở mọi category. Khi không còn category nào bật, link Register biến mất và trang `/register` báo lỗi.

Ảnh hưởng cần biết: bất kỳ ai vào được trang web đều tự tạo được team. Nếu contest để **Open to all teams**, họ sẽ nộp bài và hiện trên bảng điểm. Cài đặt đã có sẵn category `Self-Registered` (đang Visible, chưa bật tự đăng ký). Nên bật tự đăng ký cho riêng category này và tắt Visible của nó, rồi duyệt và chuyển team hợp lệ sang Participants.

## 4. Tạo contest

Vào **Jury → Contests → Add new contest**. Cài đặt sẵn có một contest mẫu `demo`, có thể sửa hoặc xóa.

### 4.1 Các mốc thời gian

Các mốc phải theo đúng thứ tự: activate ≤ start ≤ freeze ≤ end ≤ unfreeze ≤ deactivate. Mốc đầu ghi tuyệt đối (`2026-10-25 08:00:00 Asia/Ho_Chi_Minh`), các mốc sau ghi được tương đối so với start (`+5:00` = 5 giờ sau start, `-0:30` = 30 phút trước start).

| Mốc | Bắt buộc | Ý nghĩa |
| --- | --- | --- |
| Activate time | có | Team thấy contest (tên, đồng hồ đếm ngược) nhưng chưa thấy đề |
| Start time | có | Hiện đề, cho nộp bài. Mốc tính penalty time |
| Scoreboard freeze | không | Từ đây bảng điểm công khai và của team ngừng cập nhật, bài nộp mới hiện là "pending". Jury vẫn thấy đầy đủ. Team vẫn thấy kết quả bài của chính mình |
| End time | có | Hết giờ. Bài nộp sau đó bị đánh dấu TOO-LATE, không tính điểm |
| Scoreboard unfreeze | không | Bảng điểm công khai hiện kết quả cuối. Để trống thì phải bấm **Unfreeze now** thủ công (hợp cho buổi trao giải) |
| Deactivate time | không | Contest biến mất khỏi giao diện team và public |

Trang **Jury → Contests** có nút **Start now / Freeze now / End now / Unfreeze now** để chạy các mốc ngay, dùng khi cần dời giờ hoặc xử lý sự cố.

### 4.2 Các tùy chọn khác

| Tùy chọn | Bật thì | Tắt thì |
| --- | --- | --- |
| Shortname / Name | Tên ngắn dùng trong URL và API; tên đầy đủ hiển thị | |
| Allow submit | Team nộp được | Khóa nộp bài (ví dụ tạm dừng vì sự cố) |
| Enabled | Contest hoạt động | Ẩn hoàn toàn, giữ dữ liệu |
| Public | Ai cũng xem được bảng điểm tại `/public` | Chỉ người đã đăng nhập mới xem được |
| Open to all teams | Mọi team (kể cả tự đăng ký) tham gia được | Chỉ team/category được liệt kê trong **Teams / Team categories** của contest |
| Process balloons | Bật trang phát bóng bay | Không tạo thông báo bóng bay |
| Medals (gold/silver/bronze) + medal categories | Bảng điểm cuối tô màu huy chương cho N đội đầu | |
| Banner / warning message | Ảnh banner và dòng cảnh báo hiển thị cho team | |

### 4.3 Gán bài vào contest

Ở phần **Problems** trong form contest, thêm từng bài:

- **Shortname**: ký hiệu bài trên bảng điểm (A, B, C...). Thứ tự cột sắp theo shortname.
- **Points**: số điểm khi giải được, mặc định 1. Theo luật ICPC thì để 1 cho mọi bài.
- **Allow submit**: tắt thì bài vẫn hiện nhưng không nộp được.
- **Allow judge**: tắt thì bài nộp được nhận nhưng không chấm, cho đến khi bật lại. Hữu ích khi phát hiện test sai giữa giờ.
- **Colour**: màu bóng bay / màu cột.
- **Lazy eval**: ghi đè cài đặt `lazy_eval_results` (mục 8) cho riêng bài này.

Có thể import cả contest từ file `contest.yaml` (cùng `problemset.yaml`) tại **Jury → Import / export**.

## 5. Tạo bài & testcase

Có hai cách: tạo trên web rồi upload test từng cặp, hoặc upload một file zip chứa cả bài. Nên dùng zip: nhanh, lặp lại được và có kiểm tra bằng lời giải mẫu.

### 5.1 Tạo trên web

1. **Jury → Problems → Add new problem**. Điền:
    - **Name**: tên bài.
    - **Timelimit** (giây, cho phép số thập phân như `1.5`).
    - **Memory limit** (kB): để trống = dùng giá trị chung `memory_limit` (mặc định 2 097 152 kB = 2 GB).
    - **Output limit** (kB): để trống = dùng `output_limit` (mặc định 8 MB).
    - **Problem text**: file đề PDF, HTML hoặc TXT, team tải được ở trang Problems.
    - **Special run script**: để trống (chỉ dùng cho bài interactive cũ).
    - **Special compare script**: để trống = so sánh mặc định. Chọn executable khác nếu bài có checker riêng.
    - **Compare script arguments**: tham số cho checker, ví dụ `float_tolerance 1e-6`.
2. Mở bài vừa tạo → **Testcases**. Mỗi testcase gồm file input (`.in`) và file đáp án (`.ans`). Tick **Sample** cho test mẫu. Các nút mũi tên dùng để đổi thứ tự test. Có thể thêm ghi chú và ảnh minh họa cho từng test.
3. Gán bài vào contest (mục 4.3).

### 5.2 Upload bằng file zip

**Jury → Problems → Import problem**: chọn contest, chọn file zip. Cấu trúc zip theo [Problem Package Format](https://www.kattis.com/problem-package-format/) của ICPC:

```
mybai.zip
├── problem.yaml              # tên, loại bài, giới hạn bộ nhớ, checker
├── domjudge-problem.ini      # (tùy chọn) timelimit, màu, điểm
├── .timelimit                # (tùy chọn) chỉ một số, ví dụ 2
├── problem.pdf               # đề bài (hoặc problem_statement/)
├── data/
│   ├── sample/   1.in 1.ans  # test mẫu, team xem được
│   └── secret/   1.in 1.ans 2.in 2.ans ...
├── output_validators/        # (tùy chọn) checker riêng
│   └── checker/ checker.cpp
└── submissions/              # (tùy chọn) lời giải mẫu
    ├── accepted/ sol.cpp
    ├── wrong_answer/
    ├── time_limit_exceeded/
    └── run_time_error/
```

Ví dụ `problem.yaml`:

```yaml
name: Tong hai so
limits:
  memory: 256      # MB
  output: 16       # MB
validation: default
validator_flags: float_tolerance 1e-6
```

Ví dụ `domjudge-problem.ini`:

```ini
timelimit = 1.5
color = #ff0000
points = 1
short-name = A
```

Lưu ý quan trọng về DOMjudge 9.0.0:

- **Time limit không đọc từ problem.yaml.** Chỉ đặt qua `domjudge-problem.ini` (`timelimit`), file `.timelimit`, hoặc sửa trên web sau khi import. Nếu không có, mặc định là 10 giây.
- Test trong `data/sample` được đánh dấu sample và tải được từ trang của team. Test chấm gồm **cả sample và secret**: sample chạy trước.
- Tên bài ngoài (external ID) lấy từ tên file zip. Import lại cùng tên zip vào cùng bài = **thay thế** toàn bộ test cũ.
- Lời giải trong `submissions/` được nộp tự động dưới danh nghĩa jury. Kết quả kỳ vọng lấy theo tên thư mục. Vào **Jury → Judging verifier** để xem lời giải nào cho kết quả khác kỳ vọng, tức test hoặc giới hạn có vấn đề.
- Kích thước file zip bị giới hạn bởi PHP `upload_max_filesize` và `max-allowed-packet` của MariaDB (512 MB).

DOMjudge có sẵn 3 bài mẫu trong container tại `/opt/domjudge/domserver/example_problems` (`hello.zip`, `fltcmp.zip`, `boolfind.zip` cho interactive) để tham khảo cấu trúc.

### 5.3 Các kiểu so sánh output

| Kiểu | Cách cấu hình | Hoạt động |
| --- | --- | --- |
| Mặc định | `validation: default`, không flag | So từng token, bỏ qua khác biệt về khoảng trắng, **không** phân biệt hoa thường |
| Phân biệt hoa thường | `validator_flags: case_sensitive` | "Yes" khác "YES" |
| Phân biệt khoảng trắng | `validator_flags: space_change_sensitive` | Thừa/thiếu dấu cách hoặc xuống dòng = sai |
| Số thực | `float_tolerance 1e-6` (hoặc `float_absolute_tolerance`, `float_relative_tolerance`) | Chấp nhận sai số tuyệt đối hoặc tương đối |
| Checker riêng | `validation: custom` + `output_validators/` | Chương trình của bạn quyết định đúng/sai |
| Interactive | `validation: custom interactive` (hoặc `type: interactive`) | Interactor nói chuyện trực tiếp với bài làm qua stdin/stdout |
| Multi-pass | `validation: custom multi-pass`, `limits.validation_passes` | Bài làm chạy nhiều lượt, checker sinh input cho lượt sau |

**Viết checker riêng** (chuẩn ICPC, không phải testlib): checker được gọi `checker <input> <đáp_án> <thư_mục_feedback> [flags] < output_của_thí_sinh`. Thoát với mã **42 = đúng**, **43 = sai**, mã khác = lỗi hệ thống. Ghi lý do vào `<thư_mục_feedback>/judgemessage.txt` để jury đọc. Checker viết bằng testlib cần sửa lại mã thoát và thứ tự tham số cho khớp.

### 5.4 Kết quả trả về

Mỗi test cho một kết quả: `correct`, `wrong-answer`, `timelimit`, `run-error`, `memory-limit`, `output-limit`, `no-output`, hoặc `compiler-error` (trước khi chạy). Kết quả cả bài được chọn theo `results_prio` (mục 8): theo mặc định, test sai đầu tiên quyết định kết quả.

## 6. Máy chấm (judgehost)

Mỗi judgehost chấm **một bài nộp tại một thời điểm**, trên **một lõi CPU riêng**. Muốn chấm nhanh hơn thì thêm judgehost. Quy tắc: số judgehost không vượt quá số lõi vật lý trừ 1–2 lõi dành cho domserver và database. Máy này có 16 lõi nhưng cũng đang chạy bkdnoj, nên 2–6 judgehost là hợp lý.

### 6.1 Yêu cầu kernel (đã xử lý trên máy này bằng cách A)

Judgehost cần cgroup để đo và giới hạn RAM. Ban đầu máy dùng cgroup v2 với kernel 5.15, thiếu file `memory.peak` (có từ kernel 5.19). Vì vậy judgehost báo `kernel ... is too old to record peak RAM usage with cgroup V2` rồi dừng. Hạ xuống DOMjudge 8.3.1 cũng không giúp được. Có hai cách sửa, cả hai đều **cần khởi động lại máy**:

| Cách | Lệnh | Đánh giá |
| --- | --- | --- |
| A. Nâng kernel lên 6.8 (gói HWE của Ubuntu 22.04), khuyên dùng | `sudo apt install linux-generic-hwe-22.04` rồi `sudo reboot` | Giữ cgroup v2, kernel được Ubuntu hỗ trợ chính thức |
| B. Chuyển về cgroup v1 | Thêm `systemd.unified_cgroup_hierarchy=0 cgroup_enable=memory swapaccount=1` vào `GRUB_CMDLINE_LINUX_DEFAULT` trong `/etc/default/grub`, chạy `sudo update-grub`, rồi `sudo reboot` | cgroup v1 đang bị loại bỏ dần, có thể ảnh hưởng Docker và dịch vụ khác |

Sau khi khởi động lại, chạy `docker compose up -d` trong `/home/worker/DOM_Judge`. Các container bkdnoj có cấu hình restart nên sẽ tự chạy lại.

### 6.2 Thêm máy chấm trên cùng máy

Trong `docker-compose.yml`, chép một khối judgehost và đổi số thứ tự:

```yaml
  judgehost-2:
    <<: *judgehost
    hostname: judgehost-2
    environment:
      DAEMON_ID: 2
      DOMSERVER_BASEURL: http://domserver/
      JUDGEDAEMON_PASSWORD: ${JUDGEDAEMON_PASSWORD}
```

Sau đó chạy `docker compose up -d judgehost-2`. Judgehost tự đăng ký với domserver và hiện trong **Jury → Judgehosts**.

- `DAEMON_ID` phải khác nhau giữa các máy chấm trên cùng một máy. Nó cũng là số lõi CPU mà máy chấm ghim vào: `DAEMON_ID: 2` chạy trên lõi 2. Hai máy chấm trùng ID sẽ tranh nhau một lõi và đo thời gian sai.
- `hostname` là tên hiển thị trong trang Judgehosts. Đổi hostname thì domserver coi đó là máy chấm mới.

### 6.3 Thêm máy chấm ở máy khác

Trên máy thứ hai (cài Docker, kernel từ 5.19 trở lên hoặc cgroup v1; nhớ thêm `--cgroupns=host`):

```bash
docker run -d --restart unless-stopped --privileged --cgroupns=host \
  -v /sys/fs/cgroup:/sys/fs/cgroup \
  --name judgehost-0 --hostname may2-judgehost-0 \
  -e DAEMON_ID=0 \
  -e DOMSERVER_BASEURL=http://<IP máy chính>:4949/ \
  -e JUDGEDAEMON_PASSWORD=<giá trị trong .env> \
  domjudge/judgehost:9.0.0
```

Phiên bản image của máy chấm phải trùng với domserver. Cổng 4949 của máy chính phải mở cho máy thứ hai.

### 6.4 Quản lý máy chấm trên web

**Jury → Judgehosts** liệt kê từng máy chấm và lần cuối nó liên lạc với domserver:

- Xanh: bình thường. Vàng: quá `judgehost_warning` giây (mặc định 30) chưa liên lạc. Đỏ: quá `judgehost_critical` giây (mặc định 120).
- **Deactivate**: máy chấm ngừng nhận bài mới. Dùng trước khi bảo trì.
- **Judgehost restrictions** (Jury → Judgehost restrictions): giới hạn một máy chấm chỉ chấm một số contest, bài hoặc ngôn ngữ, hoặc không chấm lời giải jury. Ví dụ dành riêng một máy chấm cho bài nặng.
- Bài nộp kẹt ở trạng thái đang chấm do máy chấm chết sẽ được giao lại khi máy chấm đó được khởi động lại hoặc bị deactivate.

### 6.5 Kiểm tra máy chấm hoạt động

1. `docker compose logs -f judgehost-0`: phải thấy dòng `Judge started` và không còn lỗi.
2. Trên web, mở contest `demo`, nộp bài `hello` bằng tài khoản team. Kết quả `CORRECT` nghĩa là toàn bộ hệ thống đã chạy.
3. **Jury → Config checker**: kiểm tra cấu hình tổng thể và cảnh báo nếu có lỗi.

## 7. Ngôn ngữ lập trình

Cài đặt hiện bật sẵn 4 ngôn ngữ: **C, C++, Java, Python 3**. 19 ngôn ngữ khác (Pascal, Rust, Kotlin, C#, Haskell...) đã có cấu hình nhưng đang tắt. Image judgehost chính thức chỉ cài sẵn trình biên dịch cho 4 ngôn ngữ bật sẵn.

Quản lý tại **Jury → Languages → chọn ngôn ngữ → Edit**:

| Trường | Ý nghĩa | Nếu thay đổi |
| --- | --- | --- |
| Allow submit | Team chọn được ngôn ngữ này | Tắt thì ngôn ngữ biến mất khỏi form nộp bài |
| Allow judge | Judgehost chấm bài ngôn ngữ này | Tắt thì bài vẫn được nhận nhưng chờ chấm |
| Time factor | Hệ số nhân time limit | `2` cho Java/Python = thời gian gấp đôi. Mặc định mọi ngôn ngữ là 1 |
| Extensions | Đuôi file nhận diện ngôn ngữ | Team upload `a.cpp` thì tự chọn C++ |
| Compile script | Executable dùng để biên dịch | Xem bên dưới |
| Entry point | Bài cần tên lớp/hàm chính (Java, Kotlin) | Team phải nhập hoặc hệ thống tự dò |
| Filter compiler files | Bỏ file không đúng đuôi khi biên dịch | |
| Version command | Lệnh in phiên bản trình biên dịch | Kết hợp `show_language_versions` để hiện cho team |

### 7.1 Sửa cờ biên dịch

Lệnh biên dịch nằm trong **Jury → Executables**. Executable `cpp` mặc định chạy `g++ -x c++ -Wall -O2 -static -pipe -o "$DEST" "$@"`. Lệnh này không ghi `-std`, nên dùng chuẩn mặc định của g++ trong image (g++ 13.3 trong image 9.0.0, chuẩn mặc định gnu++17). Muốn cố định chuẩn, ví dụ C++20: mở executable `cpp` → sửa file `run` thêm `-std=gnu++20` → lưu. Judgehost tải bản mới ở lần chấm kế tiếp.

### 7.2 Bật ngôn ngữ chưa có trình biên dịch

Ví dụ Pascal: chỉ bật **Allow submit** là chưa đủ. Bài nộp sẽ báo `compiler-error` vì `fpc` chưa được cài. Phải tự build image judgehost có cài thêm trình biên dịch vào chroot chấm bài (`/chroot/domjudge`), ví dụ `chroot /chroot/domjudge apt-get install -y fp-compiler`. Việc này cần thêm một Dockerfile, chưa làm trong cài đặt này.

### 7.3 Ngôn ngữ hoàn toàn mới

Tạo một executable loại `compile` (zip chứa script `run` nhận các file nguồn và tạo ra file chạy), sau đó **Jury → Languages → Add new language** và chọn executable đó làm compile script.

## 8. Mô tả các cấu hình (Configuration settings)

Tất cả nằm ở **Jury → Configuration settings**, đổi xong bấm **Save** là có hiệu lực ngay, không cần khởi động lại. Danh sách và giá trị mặc định dưới đây lấy từ `etc/db-config.yaml` của bản 9.0.0. Sau khi đổi cấu hình ảnh hưởng tới điểm (nhóm Scoring), nên bấm **Refresh scoreboard cache** ở trang Scoreboard của jury.

### 8.1 Scoring (tính điểm)

| Cấu hình | Mặc định | Ý nghĩa và ảnh hưởng khi đổi |
| --- | --- | --- |
| `verification_required` | No | Yes: kết quả chỉ công bố cho team sau khi jury bấm xác minh từng bài. An toàn hơn nhưng jury phải trực liên tục |
| `compile_penalty` | No | Yes: lỗi biên dịch cũng tính một lần sai (+penalty) và hiện trên bảng điểm |
| `penalty_time` | 20 | Số phút phạt cho mỗi lần nộp sai, chỉ tính nếu bài cuối cùng đúng. Đặt 0 để chỉ xếp theo số bài và thời điểm |
| `results_prio` | mọi lỗi 99, correct 1 | Độ ưu tiên khi gộp kết quả nhiều test. Cùng độ ưu tiên thì test sai đầu tiên quyết định. Ví dụ đặt `timelimit` 100: có test nào TLE thì cả bài là TLE dù test trước đó WA |
| `results_remap` | trống | Đổi tên kết quả, ví dụ `no-output` → `wrong-answer` để thí sinh không phân biệt được |
| `score_in_seconds` | No | Yes: penalty tính theo giây thay vì phút, ít bị hòa hơn |

### 8.2 Judging (chấm bài)

| Cấu hình | Mặc định | Ý nghĩa và ảnh hưởng khi đổi |
| --- | --- | --- |
| `memory_limit` | 2 097 152 kB (2 GB) | RAM tối đa mặc định, bao gồm cả JVM (~300 MB với Java). Bài nào có memory limit riêng thì ghi đè. Đặt quá thấp thì Java bị lỗi ngay khi khởi động |
| `output_limit` | 8 192 kB | Output tối đa, phần thừa bị cắt. Phải lớn hơn file đáp án lớn nhất, nếu không bài đúng cũng bị output-limit |
| `process_limit` | 64 | Số tiến trình bài làm được tạo. Chống fork bomb. Quá thấp thì Java/Kotlin (nhiều thread) bị run-error |
| `sourcesize_limit` | 256 kB | Kích thước mã nguồn tối đa |
| `sourcefiles_limit` | 100 | Số file trong một lần nộp. Đặt 1 để cấm nộp nhiều file |
| `script_timelimit` | 30 giây | Thời gian tối đa cho biên dịch và checker. Bài biên dịch lâu hơn sẽ là compiler-error |
| `script_memory_limit` | 2 GB | RAM tối đa cho trình biên dịch và checker |
| `script_filesize_limit` | 2 621 440 kB | Dung lượng file trình biên dịch được ghi. Quá thấp thì file chạy lớn (static) bị compiler-error |
| `timelimit_overshoot` | `1s\|10%` | Cho bài chạy quá time limit thêm bao lâu trước khi kill (lấy max của 1 giây và 10%). Chỉ ảnh hưởng việc kill, bài vẫn bị TLE nếu vượt time limit. `+` = cộng, `&` = lấy min |
| `output_storage_limit` | 50 000 byte | Lượng output/lỗi lưu vào database cho mỗi test. `-1` = không giới hạn (database phình to nhanh) |
| `lazy_eval_results` | Lazy | Lazy: dừng ở test sai đầu tiên, tiết kiệm máy chấm. Full judging: chấm hết test, jury xem được bài sai bao nhiêu test nhưng chậm hơn. Only on request: không tự chấm. Analyst mode: chỉ chấm test "đáng chú ý" |
| `judgehost_warning` / `judgehost_critical` | 30 / 120 giây | Ngưỡng báo vàng / đỏ khi máy chấm không liên lạc |
| `diskspace_error` | 1 048 576 kB (1 GB) | Đĩa máy chấm còn ít hơn mức này thì báo lỗi nội bộ và ngừng chấm |
| `default_compare` / `default_run` | `compare` / `run` | Executable so sánh / chạy mặc định cho bài không có checker riêng |
| `default_full_debug` | `full_debug` | Script tạo gói debug khi jury yêu cầu |
| `enable_parallel_judging` | Yes | Một bài nộp được chia test cho nhiều máy chấm cùng lúc, nhanh hơn khi máy chấm rảnh |
| `judgehost_activated_by_default` | Yes | No: máy chấm mới phải được admin bật tay trước khi nhận bài |

### 8.3 Clarifications (hỏi đáp)

| Cấu hình | Mặc định | Ý nghĩa |
| --- | --- | --- |
| `clar_categories` | General issue, Technical issue | Chủ đề câu hỏi ngoài các bài |
| `clar_answers` | "No comment.", "Read the problem statement carefully." | Câu trả lời mẫu cho jury chọn nhanh. Nên thêm bản tiếng Việt |
| `clar_queues` | trống | Hàng đợi để chia việc trả lời cho nhiều jury |
| `clar_default_problem_queue` | trống | Hàng đợi mặc định cho câu hỏi về bài |

### 8.4 Display (hiển thị)

| Cấu hình | Mặc định | Ý nghĩa và ảnh hưởng khi đổi |
| --- | --- | --- |
| `output_display_limit` | 2 000 byte | Lượng output jury xem được trên web cho mỗi test |
| `show_pending` | Yes | Bảng điểm hiện số bài đang chờ chấm (ô màu xanh dương) |
| `show_flags` / `show_affiliations` / `show_affiliation_logos` | Yes / Yes / No | Hiện cờ quốc gia, tên trường, logo trường trên bảng điểm |
| `show_teams_submissions` | Yes | No: ẩn các cột bài, chỉ còn tổng điểm |
| `show_compile` | always | Team xem output biên dịch: never / chỉ khi lỗi / luôn luôn |
| `show_sample_output` | No | Yes: team xem được diff output của mình với đáp án trên test mẫu. Hữu ích cho luyện tập |
| `show_too_late_result` | No | Yes: bài nộp sau giờ vẫn cho team biết đúng/sai |
| `show_balloons_postfreeze` | No | Tiếp tục phát bóng bay sau khi đóng băng bảng điểm (lộ kết quả) |
| `show_relative_time` | No | Yes: thời gian hiển thị dạng "phút thứ X" thay vì giờ thực |
| `time_format` | `H:i` | Định dạng giờ theo PHP. `H:i:s` để hiện cả giây |
| `thumbnail_size` | 200 | Kích thước ảnh thu nhỏ của ảnh minh họa testcase |
| `show_limits_on_team_page` | Yes | Hiện time/memory limit trong trang Problems của team |
| `allow_team_submission_download` | No | Yes: team tải lại được mã nguồn đã nộp |
| `team_column_width` | 0 | Giới hạn độ rộng cột tên team (0 = không giới hạn) |
| `show_public_stats` | Yes | Hiện thống kê số bài nộp, tỉ lệ đúng mỗi bài |
| `show_language_versions` | No | Hiện phiên bản trình biên dịch cho team |
| `show_teams_on_scoreboard` | Always | Always / chỉ sau khi đăng nhập / chỉ sau khi team nộp bài đầu tiên (ẩn team không tham gia) |
| `enable_ranking` | Yes | No: không hiện xếp hạng cho thí sinh. Hợp cho buổi luyện tập |

### 8.5 Authentication

| Cấu hình | Mặc định | Ý nghĩa |
| --- | --- | --- |
| `auth_methods` | trống | Thêm `ipaddress` và/hoặc `xheaders` (mục 3.1) |
| `ip_autologin` | No | Với `ipaddress`: vào thẳng không qua trang login |

### 8.6 External systems

Nhóm này chủ yếu dùng cho kỳ thi lớn kết nối nhiều hệ thống. Với lớp học, giữ mặc định.

| Cấu hình | Mặc định | Ý nghĩa |
| --- | --- | --- |
| `print_command` | trống | Lệnh in bài. Để trống = tắt chức năng in |
| `event_feed_format` | 2022-07 | Phiên bản CCS API cho event feed |
| `shadow_mode` | No | Chạy song song để đối chiếu với hệ thống chấm khác |
| `external_contest_sources_allow_untrusted_certificates`, `external_judgement_types`, `external_ccs_submission_url`, `external_contest_source_critical` | | Cấu hình cho shadow mode |
| `icat_url` | trống | Liên kết tới iCAT (công cụ phân tích của ICPC) |
| `check_new_version` | none | Tự kiểm tra bản DOMjudge mới |
| `adminer_enabled` | No | Yes: bật trình sửa database trên web cho admin. Tiện nhưng nguy hiểm, chỉ bật khi cần |

## 9. Sao lưu, bảo mật, xử lý sự cố

### 9.1 Sao lưu

Mọi dữ liệu (bài, test, bài nộp, cấu hình) nằm trong database. Sao lưu trước và sau mỗi kỳ thi:

```bash
cd /home/worker/DOM_Judge
docker compose exec -T mariadb sh -c 'mariadb-dump -uroot -p"$MYSQL_ROOT_PASSWORD" domjudge' | gzip > backup-$(date +%F).sql.gz
```

Khôi phục:

```bash
gunzip -c backup-2026-10-25.sql.gz | docker compose exec -T mariadb sh -c 'mariadb -uroot -p"$MYSQL_ROOT_PASSWORD" domjudge'
```

Giữ cả file `.env` cùng bản sao lưu, vì mật khẩu trong đó khớp với database.

### 9.2 Bảo mật

- Đổi mật khẩu admin ngay sau lần đăng nhập đầu. Xóa hoặc vô hiệu tài khoản `demo` và contest `demo` trước kỳ thi thật.
- Web chạy HTTP thuần trên cổng 4949. Khi mở ra Internet, đặt sau reverse proxy có HTTPS (Nginx, Caddy) để mật khẩu không bị lộ.
- Judgehost chạy `privileged`, nghĩa là có quyền gần như root trên máy. Sandbox của DOMjudge (runguard + chroot + cgroup) đã được dùng ở ICPC World Finals, nhưng nên chạy trên máy không chứa dữ liệu nhạy cảm.
- Không bật `adminer_enabled` và `xheaders` nếu không thật sự cần.

### 9.3 Sự cố thường gặp

| Triệu chứng | Nguyên nhân | Cách xử lý |
| --- | --- | --- |
| Judgehost liên tục khởi động lại, log báo `kernel ... too old` | Kernel dưới 5.19 với cgroup v2 | Mục 6.1 |
| Log judgehost báo `401 Unauthorized` | `JUDGEDAEMON_PASSWORD` sai | Chép lại từ `restapi.secret` của domserver vào `.env`, `docker compose up -d` |
| Bài nộp đứng mãi ở "pending" | Không có máy chấm hoạt động, hoặc bài/ngôn ngữ tắt Allow judge | Xem Jury → Judgehosts và cài đặt của bài/ngôn ngữ |
| Mọi bài đều `compiler-error` | Trình biên dịch không có trong chroot, hoặc sai cờ biên dịch | Xem compile output trong trang bài nộp của jury |
| Bài Java bị `run-error` hoặc `memory-limit` ngay | Memory limit quá thấp cho JVM | Tăng memory limit của bài, hoặc tăng time factor của Java |
| Upload bài zip báo lỗi | File quá lớn hoặc sai cấu trúc | Đọc thông báo lỗi; kiểm tra tên thư mục `data/sample`, `data/secret` |
| Test sai phát hiện giữa giờ | | Tắt **Allow judge** của bài, sửa test, bật lại, rồi **Rejudge** toàn bộ bài nộp của bài đó |
| Bảng điểm không cập nhật | Scoreboard đang đóng băng, hoặc cache cũ | Kiểm tra mốc freeze; Jury → Scoreboard → **Refresh scoreboard cache** |

### 9.4 Nguồn tham khảo

- [DOMjudge admin manual](https://www.domjudge.org/docs/manual/main/)
- [Docker image domserver](https://hub.docker.com/r/domjudge/domserver) và [judgehost](https://hub.docker.com/r/domjudge/judgehost)
- [Problem Package Format](https://www.kattis.com/problem-package-format/)
- [CCS Contest API](https://ccs-specs.icpc.io/)
- Mã nguồn 9.0.0 trong container: `etc/db-config.yaml`, `webapp/src/Service/ImportProblemService.php`, `webapp/src/Entity/TeamCategory.php`
