@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
rem Moi thu cai vao thu muc nay: .venv (thu vien Python), khong dung pip cache ngoai
set PIP_NO_CACHE_DIR=1
set PIP_DISABLE_PIP_VERSION_CHECK=1
set PYTHONNOUSERSITE=1

where python >nul 2>nul
if errorlevel 1 (
  echo [NetPulse] Khong tim thay Python. Cai Python 3.10+ tu https://www.python.org/ roi chay lai.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo [NetPulse] Tao moi truong Python trong .venv ...
  python -m venv .venv || goto :err
)
echo [NetPulse] Cai thu vien vao .venv ...
".venv\Scripts\python.exe" -m pip install -q -r backend\requirements.txt || goto :err
echo [NetPulse] Cai dat xong.
exit /b 0

:err
echo [NetPulse] Cai dat that bai.
pause
exit /b 1
