/* Thống kê & Xu hướng — consumption per hour/day/month, heatmap, speed-test history, insights */
(function () {
  const NP = window.NP;
  NP.pages = NP.pages || {};
  const GB = 1024 ** 3;
  const DAYS = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
  const RANGE_LABEL = { '24h': '24 giờ qua', '7d': '7 ngày qua', '30d': '30 ngày qua', '12m': '12 tháng qua' };

  const kpi = (id, tone, icon, label) => `
    <div class="card lift kpi tone-${tone} c-3" id="${id}" style="min-height:112px">
      <div class="kpi-top"><span class="ico">${NP.icon(icon)}</span>${label}</div>
      <div class="kpi-val"><span class="num">0</span><span class="unit"></span></div>
      <div class="kpi-foot"></div>
    </div>`;

  NP.pages.analytics = {
    title: 'Thống kê & Xu hướng',
    sub: 'Phân tích dung lượng và tốc độ theo giờ, ngày, tuần, tháng',
    render() {
      return `
      <div class="row-flex reveal" style="margin-bottom:18px">
        ${NP.seg('anRange', [['24h', '24 giờ'], ['7d', '7 ngày'], ['30d', '30 ngày'], ['12m', '12 tháng']], '7d')}
        <span class="spacer"></span>
        <button class="btn sm" id="anExport">${NP.icon('download')}Xuất CSV</button>
      </div>
      <div class="grid">
        ${kpi('aDown', 'down', 'down', 'Tổng download')}
        ${kpi('aUp', 'up', 'up', 'Tổng upload')}
        ${kpi('aAvg', 'violet', 'activity', 'Tốc độ trung bình')}
        ${kpi('aPeak', 'warn', 'zap', 'Tốc độ cao nhất')}

        <div class="card c-8">
          ${NP.cardHead('Dung lượng tiêu thụ', {
            icon: 'chart', sub: '<span id="anSub"></span>',
            right: `<div class="legend"><span><i style="background:var(--down)"></i>Download</span><span><i style="background:var(--up)"></i>Upload</span></div>${NP.seg('anMode', [['stack', 'Chồng'], ['group', 'Nhóm']], 'stack')}`,
          })}
          <div class="chart-box h-320"><canvas id="anChart"></canvas></div>
        </div>
        <div class="card c-4">
          ${NP.cardHead('Nhận định nhanh', { icon: 'sparkles', sub: 'Tự động tính từ dữ liệu' })}
          <div id="anInsights"></div>
        </div>

        <div class="card c-8">
          ${NP.cardHead('Bản đồ nhiệt sử dụng', {
            icon: 'calendar', sub: 'Trung bình theo giờ trong tuần (4 tuần gần nhất)',
            right: '<div class="heat-scale" id="heatScale"></div>',
          })}
          <div class="heatmap" id="heat"></div>
        </div>
        <div class="card c-4">
          ${NP.cardHead('Lịch sử Speed test', {
            icon: 'gauge', sub: 'Tốc độ Internet đo được theo thời gian',
          })}
          <div class="legend" style="margin-bottom:8px"><span><i style="background:var(--down)"></i>Download</span><span><i style="background:var(--up)"></i>Upload</span><span id="stPlanLg"><i class="dash" style="color:var(--good)"></i>Gói cước</span></div>
          <div class="chart-box h-240"><canvas id="stChart"></canvas></div>
          <div id="stTable" style="margin-top:10px"></div>
        </div>

        <div class="card c-12">
          ${NP.cardHead('Bảng dữ liệu', { icon: 'list', sub: 'Chi tiết theo từng khoảng' })}
          <div class="table-wrap tbl-scroll" style="max-height:360px"><table class="tbl">
            <thead><tr><th>Khoảng</th><th class="num">Download</th><th class="num">Upload</th><th class="num">Tổng</th><th class="num">Tốc độ TB</th><th class="num">Tốc độ cao nhất</th><th style="width:30%">Tỷ trọng</th></tr></thead>
            <tbody id="anTable"></tbody></table></div>
        </div>
      </div>`;
    },

    async mount(root) {
      const $ = (s) => root.querySelector(s);
      const down = NP.css('--down'), up = NP.css('--up');
      let range = '7d', mode = 'stack', data = [], chart = null;

      const setKpi = (id, value, digits, unit, foot) => {
        NP.countUp($(`#${id} .num`), value, { digits });
        $(`#${id} .unit`).textContent = unit;
        $(`#${id} .kpi-foot`).innerHTML = foot;
      };

      const drawChart = () => {
        if (chart) chart.destroy();
        chart = NP.charts.bar($('#anChart'), {
          labels: data.map((b) => b.label),
          series: [
            { label: 'Download', color: down, data: data.map((b) => b.down / GB) },
            { label: 'Upload', color: up, data: data.map((b) => b.up / GB) },
          ],
          stacked: mode === 'stack', yTitle: 'GB', tooltipValue: (v) => NP.fmtBytes(v * GB).text,
        });
      };

      const load = async () => {
        data = await NP.api.getUsage(range);
        if (!root.isConnected) return;
        const tD = data.reduce((a, b) => a + b.down, 0), tU = data.reduce((a, b) => a + b.up, 0);
        const peakB = data.reduce((m, b) => (b.peak > m.peak ? b : m), data[0]);
        const fd = NP.fmtBytes(tD), fu = NP.fmtBytes(tU);
        setKpi('aDown', +fd.value, 1, fd.unit, `${RANGE_LABEL[range]}`);
        setKpi('aUp', +fu.value, 1, fu.unit, tD ? `Tỷ lệ ↑/↓: <b class="mono">${((tU / tD) * 100).toFixed(1)}%</b>` : RANGE_LABEL[range]);
        const act = data.filter((b) => b.avg > 0);
        const avgA = act.length ? act.reduce((a, b) => a + b.avg, 0) / act.length : 0;
        const fa = NP.fmtRate(avgA, { fixed: NP.rateUnitLabel() });
        setKpi('aAvg', +fa.value, 1, fa.unit, 'Trung bình khi có lưu lượng (> 0.2 Mbps)');
        const fp = NP.fmtRate(peakB.peak, { fixed: NP.rateUnitLabel() });
        setKpi('aPeak', +fp.value, 0, fp.unit, peakB.peak ? `Lúc <b class="mono">${peakB.label}</b>` : 'Chưa có dữ liệu');
        $('#anSub').textContent = RANGE_LABEL[range];
        drawChart();

        // insights
        const totals = data.map((b) => b.down + b.up);
        const withData = totals.filter((t) => t > 0);
        const item = (icon, color, title, text) => `<div class="ev" style="grid-template-columns:30px 1fr"><span class="dot" style="background:${NP.alpha(color, 0.12)};color:${color}">${NP.icon(icon)}</span><div><div class="t">${title}</div><div class="d">${text}</div></div></div>`;
        if (withData.length < 2) {
          $('#anInsights').innerHTML = `<div class="timeline">${item('clock', NP.css('--accent'), 'Đang thu thập dữ liệu',
            `Agent ghi lưu lượng mỗi phút. Cần dữ liệu ở ít nhất 2 ${({ '24h': 'giờ', '7d': 'ngày', '30d': 'ngày', '12m': 'tháng' })[range]} để phân tích xu hướng.`)}</div>`;
        }
        // only periods where the agent actually recorded data count (leading empty buckets = agent not installed yet)
        const firstIdx = totals.findIndex((t) => t > 0);
        const span = firstIdx >= 0 ? totals.slice(firstIdx) : [];
        const maxI = totals.indexOf(Math.max(...totals));
        const minV = Math.min(...(span.length ? span : [0]));
        const minI = firstIdx >= 0 ? firstIdx + span.indexOf(minV) : 0;
        const mean = span.length ? span.reduce((a, b) => a + b, 0) / span.length : 0;
        const half = Math.floor(span.length / 2);
        const first = half ? span.slice(0, half).reduce((a, b) => a + b, 0) / half : 0;
        const second = span.length - half ? span.slice(half).reduce((a, b) => a + b, 0) / (span.length - half) : 0;
        const trend = first ? ((second - first) / first) * 100 : 0;
        const unitWord = { '24h': 'giờ', '7d': 'ngày', '30d': 'ngày', '12m': 'tháng' }[range];
        const now = new Date(), dim = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
        const proj = range === '30d' || range === '7d' ? NP.fmtBytes(mean * dim).text : null;
        if (withData.length >= 2) $('#anInsights').innerHTML = `<div class="timeline">` +
          item('trend', trend > 0 ? NP.css('--warn') : NP.css('--good'), `Xu hướng ${trend >= 0 ? 'tăng' : 'giảm'} ${Math.abs(trend).toFixed(0)}%`, `Nửa sau so với nửa đầu của ${span.length} ${unitWord} có dữ liệu.`) +
          item('zap', NP.css('--accent'), `Cao điểm: ${data[maxI].label}`, `Dùng ${NP.fmtBytes(totals[maxI]).text} — gấp ${(totals[maxI] / mean).toFixed(1)}× trung bình.`) +
          item('moon', NP.css('--link'), `Thấp điểm: ${data[minI].label}`, `Chỉ ${NP.fmtBytes(totals[minI]).text}.`) +
          item('database', NP.css('--up'), `Trung bình ${NP.fmtBytes(mean).text}/${unitWord}`, proj ? `Ước tính cả tháng (${dim} ngày): <b>${proj}</b>.` : `Tổng ${NP.fmtBytes(tD + tU).text} trong ${RANGE_LABEL[range]}.`) +
          `</div>`;

        // table
        const maxT = Math.max(1, ...totals);
        $('#anTable').innerHTML = data.slice().reverse().filter((b) => b.down + b.up > 0).map((b) => {
          const t = b.down + b.up;
          return `<tr><td><b>${b.label}</b></td><td class="num">${NP.fmtBytes(b.down).text}</td><td class="num">${NP.fmtBytes(b.up).text}</td><td class="num"><b>${NP.fmtBytes(t).text}</b></td>
            <td class="num">${NP.fmtRate(b.avg).text}</td><td class="num">${NP.fmtRate(b.peak).text}</td>
            <td><div class="meter-track" style="height:6px;display:flex;gap:2px;background:none">
              <div style="height:100%;border-radius:4px;width:${(b.down / maxT) * 100}%;background:${down}"></div>
              <div style="height:100%;border-radius:4px;width:${(b.up / maxT) * 100}%;background:${up}"></div></div></td></tr>`;
        }).join('') || `<tr><td colspan="7">${NP.emptyHTML('database', 'Chưa có dữ liệu trong khoảng này')}</td></tr>`;
      };

      NP.bindSeg(root, 'anRange', (v) => { range = v; load(); });
      NP.bindSeg(root, 'anMode', (v) => { mode = v; drawChart(); });
      $('#anExport').addEventListener('click', () => {
        const rows = [['period_start', 'label', 'download_bytes', 'upload_bytes', 'avg_bps', 'peak_bps'], ...data.map((b) => [new Date(b.ts).toISOString(), b.label, Math.round(b.down), Math.round(b.up), Math.round(b.avg), Math.round(b.peak)])];
        const blob = new Blob([rows.map((r) => r.join(',')).join('\n')], { type: 'text/csv' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob); a.download = `netpulse-usage-${range}.csv`; a.click();
        URL.revokeObjectURL(a.href);
        NP.toast('Đã xuất file CSV', 'good');
      });

      /* heatmap — sequential single hue */
      const hm = await NP.api.getHeatmap();
      const max = Math.max(1, ...hm.flat());
      const accent = NP.css('--accent');
      const cell = (v) => NP.alpha(accent, 0.06 + (v / max) * 0.88);
      let html = '<div></div>' + Array.from({ length: 24 }, (_, h) => `<div class="hh">${h % 3 === 0 ? h : ''}</div>`).join('');
      hm.forEach((row, d) => {
        html += `<div class="hl">${DAYS[d]}</div>` + row.map((v, h) => `<div class="cell" style="background:${cell(v)}" title="${DAYS[d]} ${NP.pad(h)}:00–${NP.pad(h)}:59 · trung bình ${NP.fmtBytes(v).text}"></div>`).join('');
      });
      $('#heat').innerHTML = html;
      $('#heatScale').innerHTML = 'Ít' + [0.1, 0.3, 0.5, 0.7, 0.95].map((p) => `<span style="background:${NP.alpha(accent, 0.06 + p * 0.88)}"></span>`).join('') + 'Nhiều';

      /* speed test history */
      const st = await NP.api.getSpeedHistory();
      if (!root.isConnected) return;
      const plan = NP.settings.planDownMbps;
      if (!plan) $('#stPlanLg').style.display = 'none';
      if (!st.length) {
        $('#stChart').parentNode.innerHTML = NP.emptyHTML('gauge', 'Chưa có lần speed test nào.<br><a href="#/tools">Chạy speed test</a> hoặc bật đo tự động trong Cài đặt.');
      } else NP.charts.line($('#stChart'), {
        labels: st.map((x) => NP.fmtDateTime(x.ts).slice(0, 5)),
        series: [
          { label: 'Download', color: down, data: st.map((x) => NP.toDisplayRate(x.down)), alpha: 0.18 },
          { label: 'Upload', color: up, data: st.map((x) => NP.toDisplayRate(x.up)), alpha: 0.14 },
          ...(plan ? [{ label: 'Gói cước', color: NP.css('--good'), data: st.map(() => NP.toDisplayRate(plan * 1e6)), fill: false, dash: [6, 5], width: 1.5 }] : []),
        ],
        yTitle: NP.rateUnitLabel(), tooltipValue: (v) => `${(+v).toFixed(0)} ${NP.rateUnitLabel()}`,
        tooltipTitle: (p) => NP.fmtDateTime(st[p[0].dataIndex].ts),
      });

      await load();
    },
  };
})();
