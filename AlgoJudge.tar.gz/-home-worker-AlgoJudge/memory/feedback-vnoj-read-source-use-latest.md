---
name: feedback-vnoj-read-source-use-latest
description: "When analysing VNOJ, read the actual source of VNOI-Admin/OJ and VNOI-Admin/judge-server (latest master) instead of guessing; focus on architecture"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 76a8229c-3a92-45e1-8f79-9779197e6805
  modified: 2026-11-11T10:02:17.500Z
---

When researching or explaining VNOJ, base every claim on the current source of `VNOI-Admin/OJ` (site) and `VNOI-Admin/judge-server`. Do not guess, and do not rely on `vnoj-docker` (2023) or `vnoj-docs` (2024), which are stale. Keep the scope on architecture.

**Why:** The user said twice (once while I worked on the report, once when asking for a fuller version) to "take the new source, be careful not to take the old one" and "read the source to determine the problem, don't guess". The first report was thinner and partly leaned on old repos.

**How to apply:**
- Check commit dates before reading (`git log -1`) and say which repos were used and which were stale.
- Tag claims by confidence: read directly, inferred from code, unverified. Say so explicitly when something was not run.
- Clone upstream into a dedicated research dir (`/home/worker/AlgoJudge/vnoj-src/`); do not trust `/home/worker/AlgoJudge/judge-server`, which was replaced by the user's own repo (`Algorit-loop/AlgoJudge`) on 2026-11-11.
- The live site `oj.vnoi.info` is behind a Cloudflare challenge, so production topology cannot be observed; say that instead of guessing.
- Reports are in Vietnamese; LaTeX preferred (xelatex, TikZ figures). Check figures visually after rendering.
