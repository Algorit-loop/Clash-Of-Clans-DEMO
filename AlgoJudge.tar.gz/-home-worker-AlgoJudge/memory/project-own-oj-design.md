---
name: project-own-oj-design
description: "User is designing their own OJ + DOMjudge-like site; decisions so far (stack, judge, single-machine deploy, VNOJ only as reference)"
metadata:
  node_type: memory
  type: project
  originSessionId: c77922b0-0a98-42ee-8182-dcca6c14a856
  modified: 2026-11-16T09:01:48.333Z
---

User (as of 2026-11-16) is building their own online judge (OJ + DOMjudge-ish) for personal/organization use, designing architecture before coding.

Repo layout (user dislikes generic backend/frontend names): `site/` = all Python (package `algojudge`: API, later Celery/bridge/wsevent), `ui/` = React, `judge-server/` = judge-server, `deploy/`; compose services `api`, `ui`.
Decisions: judge = VNOJ/dmoj judge-server, source vendored in repo at `judge-server/` (base upstream master 2375961) and user intends to customize it later (e.g. subtask scoring) — it IS a fork now; backend FastAPI, frontend React; MVP = problems+submissions, ICPC contests, IOI/OI contests.
**Deployment target: everything (site + judge) on ONE machine** — this overrides an earlier "several machines" answer.
VNOJ source (reference/vnoj-src) is reference only — do NOT copy its design one-to-one.

Living design doc: `/home/worker/AlgoJudge/DESIGN.md` — user asked it be kept updated whenever an important decision/fact is settled (mark [CHỐT]/[NHÁP]/[HOÃN], append to changelog). Read it at session start.

**Why:** user explicitly corrected both points.
**How to apply:** don't propose multi-host machinery (NFS, MinIO sync, cross-host LB) unless asked; justify components on their own merits, not "because VNOJ does it". See [[feedback-vnoj-read-source-use-latest]].
