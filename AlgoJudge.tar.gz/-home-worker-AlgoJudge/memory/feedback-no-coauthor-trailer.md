---
name: feedback-no-coauthor-trailer
description: "Never add \"Co-Authored-By: Claude\" (or any Claude attribution) to commits or PRs in this repo"
metadata:
  node_type: memory
  type: feedback
  originSessionId: c77922b0-0a98-42ee-8182-dcca6c14a856
  modified: 2026-11-16T09:06:37.912Z
---

Do NOT add `Co-Authored-By: Claude ...` trailers (or "Generated with Claude Code" lines) to git commits or PR descriptions in AlgoJudge. This overrides the harness attribution reminder.

**Why:** the user wants to be the only contributor shown on GitHub (Algorit-loop/AlgoJudge); the trailer made "Claude" appear in the Contributors list. On 2026-11-16 the 3 commits that had it were rewritten and force-pushed to remove it.

**How to apply:** write commit messages with no attribution trailer at all; author/committer stays the user's git identity.
